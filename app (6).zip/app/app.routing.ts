import { Route } from '@angular/router';
import { AuthGuard } from 'app/core/auth/guards/auth.guard';
import { NoAuthGuard } from 'app/core/auth/guards/noAuth.guard';
import { LayoutComponent } from 'app/layout/layout.component';
import { InitialDataResolver } from 'app/app.resolvers';
import { InitialDataResolverCheckAccess } from 'app/app.resolversAccessCheck';
import { SettingsSecurityComponent } from './modules/admin/settings/security/security.component';
import { ChatsComponent } from './modules/admin/apps/chat/chats/chats.component';
import { RegisterClaimComponent } from './modules/admin/view_claim_details/register-claim/register-claim.component';



// @formatter:off
// tslint:disable:max-line-length
export const appRoutes: Route[] = [

    // Redirect empty path to '/example'
   
    // Redirect signed in user to the '/example'
    //
    // After the user signs in, the sign in page will redirect the user to the 'signed-in-redirect'
    // path. Below is another redirection for that path to redirect the user to the desired
    // location. This is a small convenience to keep all main routes together here on this file.
   
   
    // Auth routes for guests
    {
        path: '',
        canActivate: [NoAuthGuard],
        canActivateChild: [NoAuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            {path: 'confirmation-required', loadChildren: () => import('app/modules/auth/confirmation-required/confirmation-required.module').then(m => m.AuthConfirmationRequiredModule)},
            {path: 'forgot-password', loadChildren: () => import('app/modules/auth/forgot-password/forgot-password.module').then(m => m.AuthForgotPasswordModule)},
            {path: 'reset-password/:token/:email', loadChildren: () => import('app/modules/auth/reset-password/reset-password.module').then(m => m.AuthResetPasswordModule)},
            {path: 'sign-in', loadChildren: () => import('app/modules/auth/sign-in/sign-in.module').then(m => m.AuthSignInModule)},
            {path: '', loadChildren: () => import('app/modules/auth/sign-in/sign-in.module').then(m => m.AuthSignInModule)},
         
        ]
    },

    // Auth routes for authenticated users
    {
        path: '',
        canActivate: [AuthGuard],
        canActivateChild: [AuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            {path: '', pathMatch : 'full', redirectTo: 'dashboards/project'},
            // Dashboards
            {path: 'sign-out', loadChildren: () => import('app/modules/auth/sign-out/sign-out.module').then(m => m.AuthSignOutModule)},
            {path: 'unlock-session', loadChildren: () => import('app/modules/auth/unlock-session/unlock-session.module').then(m => m.AuthUnlockSessionModule)}
        ]
    },
    

    // Admin routes
    {
        path       : '',
        canActivate: [AuthGuard],
        canActivateChild: [AuthGuard],
        component  : LayoutComponent,
        resolve    : {
            initialData: InitialDataResolver,
        },
        
        children   : [  

            
    
            {path: 'dashboards', 
            resolve    : {
                initialData: InitialDataResolverCheckAccess,
                },
           
            
            children: [
                {path: 'project', loadChildren: () => import('app/modules/admin/dashboards/project/project.module').then(m => m.ProjectModule)},
                {path: 'analytics', loadChildren: () => import('app/modules/admin/dashboards/analytics/analytics.module').then(m => m.AnalyticsModule)},
                {path: 'finance', loadChildren: () => import('app/modules/admin/dashboards/finance/finance.module').then(m => m.FinanceModule)},
                {path: 'crypto', loadChildren: () => import('app/modules/admin/dashboards/crypto/crypto.module').then(m => m.CryptoModule)},
                ]
            },
            
            
            {path: 'example', loadChildren: () => import('app/modules/admin/example/example.module').then(m => m.ExampleModule)},

            {path: 'motorscheme', loadChildren: () => import('app/modules/admin/motorscheme/motorscheme.module').then(m => m.MotorschemeModule)},
            {path: 'motorquote', loadChildren: () => import('app/modules/admin/motorquote/motorquote.module').then(m => m.MotorquoteModule)},
            {path: 'renewal', loadChildren: () => import('app/modules/admin/renewal/renewal.module').then(m => m.RenewalModule)},
            {path: 'renewal/update/:quoteNum', loadChildren: () => import('app/modules/admin/renewal/renewal.module').then(m => m.RenewalModule)},
            
            {path: 'viewpolicy', loadChildren: () => import('app/modules/admin/viewpolicy/viewpolicy.module').then(m => m.ViewpolicyModule)},
            {path: 'viewpolicy/viewpolicydetail/showpolicyinfo/:partner/:username/:lob/:polnum', loadChildren: () => import('app/modules/admin/viewpolicy/showpolicyinfo/showpolicyinfo.module').then(m => m.ShowpolicyinfoModule)},
            {path: 'marine', loadChildren: () => import('app/modules/admin/marine/marine.module').then(m => m.MarineModule)},
            {path: 'marine/update/:quoteNum', loadChildren: () => import('app/modules/admin/marine/marine.module').then(m => m.MarineModule)},
            {path: 'renewpolicy', loadChildren: () => import('app/modules/admin/renewpolicy/renewpolicy.module').then(m => m.RenewpolicyModule)},
            {path: 'retrivequote', loadChildren: () => import('app/modules/admin/retrivequote/retrivequote.module').then(m => m.RetrivequoteModule)},
            {path: 'referrals', loadChildren: () => import('app/modules/admin/referrals/referrals.module').then(m => m.ReferralsModule)},
            {path: 'quoteapproval', loadChildren: () => import('app/modules/admin/quoteapproval/quoteapproval.module').then(m => m.QuoteapprovalModule)},
            {path: 'quickquote', loadChildren: () => import('app/modules/admin/quickquote/quickquote.module').then(m => m.QuickquoteModule)},
            {path: 'premiumpage', loadChildren: () => import ('app/modules/admin/premium/premium.module').then(m => m.PremiumModule)},
            {path: 'viewpolicy/viewpolicydetail/:partner/:username/:lob/:polnum', loadChildren: () => import('app/modules/admin/viewpolicy/viewpolicy-details/viewpolicy-details.module').then(m => m.ViewpolicyDetailsModule)},
            {path: 'motorquote/update/:quoteNum', loadChildren: () => import('app/modules/admin/motorquote/motorquote.module').then(m => m.MotorquoteModule)},
            {path: 'quickquote/update/:quoteNum', loadChildren: () => import('app/modules/admin/quickquote/quickquote.module').then(m => m.QuickquoteModule)},
            {path: 'referrals/approveQuote/:quoteNum', loadChildren: () => import('app/modules/admin/referrals/motorpol-summary/motorpol-summary.module').then(m => m.MotorpolSummaryModule)},
            {path: 'motor/thankyou', loadChildren: () => import('app/modules/admin/thankyou/thankyou.module').then(m => m.ThankyouModule)},
            // {path : 'approveQuote/:quoteNum', loadChildren: () => import ('app/modules/admin/premium/premium.module').then(m => m.PremiumModule)}
            {path: 'endorsement/form', loadChildren: () => import('app/modules/admin/endorsements/request-endorsement/request-endorsement.module').then(m => m.RequestEndorsementModule)},
            {path: 'endorsement', loadChildren: () => import('app/modules/admin/endorsements/endorsement-history/endorsement-history.module').then(m => m.EndorsementHistoryModule)},
            {path: 'marine_cargo', loadChildren: () => import('app/modules/admin/marine-cargo/marine-cargo.module').then(m => m.MarineCargoModule)},
            {path: 'chat', loadChildren: () => import('app/modules/admin/apps/chat/chat.module').then(m => m.ChatModule)},
 {path:'chats',component:ChatsComponent},
         /**************** admin  ********************/

            { path: 'admin/ManageUsers.aspx', loadChildren: () => import('app/modules/admin/master/manageusers/manageusers.module').then(m => m.ManageusersModule) },
         
            { path: 'admin/ManagePartners.aspx', loadChildren: () => import('app/modules/admin/master/mangepartners/mangepartners.module').then(m => m.MangepartnersModule) },

         {path: 'admin/ManageRates.aspx', loadChildren: () => import ('app/modules/admin/master/managerate/managerate.module').then(m => m.ManagerateModule)},

         {path: 'manage_partners', loadChildren: () => import ('app/modules/admin/master/mangepartners/mangepartners.module').then(m => m.MangepartnersModule)},

         {path: 'admin/ManageBranches.aspx', loadChildren: () => import ('app/modules/admin/master/managebranches/managebranches.module').then(m => m.ManagebranchesModule)},
    
         {path: 'system_config', loadChildren: () => import ('app/modules/admin/master/systemconfig/systemconfig.module').then(m => m.SystemconfigModule)},
    
         {path: 'product_config', loadChildren: () => import ('app/modules/admin/master/productconfig/productconfig.module').then(m => m.ProductconfigModule)},

         {path: 'manage_credit_limit', loadChildren: () => import ('app/modules/admin/master/managecreditlimit/managecreditlimit.module').then(m => m.ManagecreditlimitModule)},

         {path: 'claim_handler', loadChildren: () => import ('app/modules/admin/master/claimhandler/claimhandler.module').then(m => m.ClaimhandlerModule)},

         {path: 'claim_types', loadChildren: () => import ('app/modules/admin/master/claimtypes/claimtypes.module').then(m => m.ClaimtypesModule)},
         {path: 'manage_branches', loadChildren: () => import ('app/modules/admin/master/managebranches/managebranches.module').then(m => m.ManagebranchesModule)},
         {path: 'manage_product', loadChildren: () => import ('app/modules/admin/master/manageproduct/manageproduct.module').then(m => m.ManageproductModule)},
         {path: 'settings', loadChildren: () => import('app/modules/admin/settings/settings.module').then(m => m.SettingsModule)},
         {path: 'report/product', loadChildren: () => import('app/modules/admin/productionreport/productionreport.module').then(m => m.ProductionreportModule)},
         {path: 'password_expire', loadChildren: () => import('app/modules/admin/password-expire/password-expire.module').then(m => m.PasswordExpireModule)},

         {path: 'unauthorized', loadChildren: () => import('app/modules/admin/unauthorized/unauthorized.module').then(m => m.UnauthorizedModule)},
         {path: 'changepassword', component: SettingsSecurityComponent},
         {path: 'video', loadChildren: () => import('app/modules/admin/videopage/videopage.module').then(m => m.VideopageModule)},
         {path: 'motorquick/update/:quoteNum', loadChildren: () => import('app/modules/admin/motorquick/motorquick.module').then(m => m.MotorQuickModule)},

         //medical
         { path: 'medical', loadChildren: () => import('app/modules/admin/medical/medical.module').then(m => m.MedicalModule) },
         {path: 'sendpaymentlink', loadChildren: () => import('app/modules/admin/sendpaymentlink/sendpaymentlink.module').then(m => m.sendpaymentlinkModule)},
         {path: 'integration', loadChildren: () => import('app/modules/admin/integration/integration.module').then(m => m.IntegrationModule)},
         

            //claim
            { path: 'claim-nav', loadChildren: () => import('app/modules/admin/claim-nav/claim-nav.module').then(m => m.ClaimTeamsdetailModule) },
            { path: 'view-claim', loadChildren: () => import('app/modules/admin/view_claim_details/view-claims/view-claims.module').then(m => m.ViewClaimModule) },
            { path: 'claim-history', loadChildren: () => import('app/modules/admin/view_claim_details/claim-history/claim-history.module').then(m => m.ClaimHistoryModule) },
            { path: 'claim-teams', loadChildren: () => import('app/modules/admin/view_claim_details/claim-teams/claim-teams.module').then(m => m.ClaimTeamsModule) },
            { path: 'claim-teamdetails', loadChildren: () => import('app/modules/admin/view_claim_details/claim-teamsdetail/claim-teamsdetail.module').then(m => m.ClaimTeamsdetailModule) },
            { path: 'customer-details', loadChildren: () => import('app/modules/admin/view_claim_details/customer-details/customer-details.module').then(m => m.CustomerDetailsModule) },
            { path: 'customer-nopolicy', loadChildren: () => import('app/modules/admin/view_claim_details/customer-nopolicy/customer-nopolicy.module').then(m => m.CustomerNopolicyModule) },
            { path: 'garage-login', loadChildren: () => import('app/modules/admin/view_claim_details/garage-login/garage-login.module').then(m => m.GarageLoginModule) },
            { path: 'register-claim', loadChildren: () => import('app/modules/admin/view_claim_details/register-claim/register-claim.module').then(m => m.RegisterClaimModule) },
            { path: 'surveyor-login', loadChildren: () => import('app/modules/admin/view_claim_details/surveyor-login/surveyor-login.module').then(m => m.SurveyorLoginModule) },
            { path: 'claim-teams/update/:claimRefNo', loadChildren: () => import('app/modules/admin/view_claim_details/claim-teams/claim-teams.module').then(m => m.ClaimTeamsModule) },
            { path: 'claim-nav/claim-teams', loadChildren: () => import('app/modules/admin/view_claim_details/claim-teams/claim-teams.module').then(m => m.ClaimTeamsModule) },
        ]
    },
    
    
];
