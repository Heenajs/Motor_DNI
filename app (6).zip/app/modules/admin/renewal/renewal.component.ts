import { Component, OnInit,AfterViewInit, ViewChild, ɵConsole ,ElementRef,Directive, TemplateRef,HostListener} from '@angular/core';
import { MotorquoteService } from '../../service/motorquote.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { GlobalService } from '../../service/global.service';
import Swal from 'sweetalert2';
// import { AppDateAdapter, APP_DATE_FORMATS } from '../motorquote/date.adapter';
import { Router, ActivatedRoute } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { Observable, Subscription, fromEvent } from 'rxjs';
import { config } from '../../../config';
import { MatSelectModule } from '@angular/material/select';
import {VehiModelYear} from './VehiModelYr';
import {vehimodelyrs} from './motoryear';
import { MatDialog } from '@angular/material/dialog';
import {AuthService} from 'app/core/auth/auth.service';
import {QuickquoteService} from '../../service/quickquote.service';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { MatStepper } from '@angular/material/stepper';
import { result, toUpper } from 'lodash';
import { ReturnStatement } from '@angular/compiler';
interface BenefitReplacement {
  value: string;
  viewValue: string;
}
interface Code {
  value: string;
  viewValue: string;
}

interface DrivExp {
  value: string;
  viewValue: string;
}

interface VehiTrim {
  value: string;
  viewValue: string;
}
interface VehiModelYr {
  value: string;
  label: string;
}
interface BrandNew {
  value: string;
  viewValue: string;
}
interface VehiSeatCap {
  value: string;
  viewValue: string;
}
interface VehiCylinder {
  value: string;
  viewValue: string;
  code: string;
}
interface InsType {
  value: string;
  viewValue: string;
  WebProdCode: string;
  CoreProdCode: string;
}
interface YesNo {
  value: string;
  viewValue: string;
}
interface RepairType {
  value: string;
  viewValue: string;
}
interface MotBankNam {
  value: string;
  viewValue: string;
}
interface Gender {
  value: string;
  viewValue: string;
}
interface ExpiryMonth {
  value: string;
  viewValue: string;
}

interface Country {
  id: number;
  CountryName: string;
  Active: boolean;
  CountryCode: string;
  CurrencyCode: string;
  CRS_NATION_CODE: number;
  CRS_Country_Map_Code: number;
}

interface industry {
  id: number;
  IndustryName: string;
 
}

interface Make {
  VehicleMakeId: number;
  VehicleMakeName: string;
  Active: boolean;
  IsReferral: number;
  CRS_VEH_CODE: number;
}

interface Model {

  VehicleModelId: number;
  VehicleModelName: string;
  Active: boolean;
  SeatingCapacityExDriver: number;
  BodyTypeId: number;
  CRS_MODEL_CODE: number;
  EDATA_MODEL_CODE: string;
}

interface PlateCategory {
  label: string;
  value: string;
}

interface VichleColor {

  ColorId: number;
  ColorName: string;
  CRS_COLOR_CODE: string;
}

interface MortageBank {

  Id: number;
  InstituteName: string;
  InstituteCode: string
  CRS_Bank_Map_Code: string;
}

interface BenefitReplacement {
  value: string;
  viewValue: string;
}
interface Code {
  value: string;
  viewValue: string;
}

interface DrivExp {
  value: string;
  viewValue: string;
}

interface VehiTrim {
  value: string;
  viewValue: string;
}
interface VehiModelYr {
  value: string;
  label: string;
}
interface BrandNew {
  value: string;
  viewValue: string;
}
interface VehiSeatCap {
  value: string;
  viewValue: string;
}
interface VehiCylinder {
  value: string;
  viewValue: string;
  code: string;
}
interface InsType {
  value: string;
  viewValue: string;
  WebProdCode: string;
  CoreProdCode: string;
}
interface YesNo {
  value: string;
  viewValue: string;
}
interface RepairType {
  value: string;
  viewValue: string;
}
interface MotBankNam {
  value: string;
  viewValue: string;
}
interface Gender {
  value: string;
  viewValue: string;
}
interface ExpiryMonth {
  value: string;
  viewValue: string;
}

interface Country {
  id: number;
  CountryName: string;
  Active: boolean;
  CountryCode: string;
  CurrencyCode: string;
  CRS_NATION_CODE: number;
  CRS_Country_Map_Code: number;
}

interface Make {
  VehicleMakeId: number;
  VehicleMakeName: string;
  Active: boolean;
  IsReferral: number;
  CRS_VEH_CODE: number;
 
}

interface Model {

  VehicleModelId: number;
  VehicleModelName: string;
  Active: boolean;
  SeatingCapacityExDriver: number;
  BodyTypeId: number;
  CRS_MODEL_CODE: number;
  EDATA_MODEL_CODE: string;
}

interface PlateCategory {

  label: string;
  value: string;
}

interface VichleColor {

  ColorId: number;
  ColorName: string;
  CRS_COLOR_CODE: string;
}

interface MortageBank {

  Id: number;
  InstituteName: string;
  InstituteCode: string
  CRS_Bank_Map_Code: string;
}


interface Product {
   value: string;
   viewValue: string;
 }
 interface Nationality{
   value: string;
   viewValue: string;
 }
 interface Pepstauts{
   value: string;
   viewValue: string;
 }

 interface occupation{
  OccupationId: number;
  OccupationName: string;
}

 interface VehiModelYr {
  value: string;
  label: string;
}

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL'
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY'
  }
};

@Component({
  selector: 'app-motorquote',
  templateUrl: './renewal.component.html',
  styleUrls: ['./renewal.component.scss']
})
export class RenewalComponent implements OnInit {
//  selected_motor:FormControl;
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('callDialog') callDialog: TemplateRef<any>;
  @ViewChild('callAPIDialoginvalid') callAPIDialoginvalid: TemplateRef<any>;
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  @ViewChild('termsandconditions') termsandconditions: TemplateRef<any>;
  @ViewChild('referaquote') referaquote: TemplateRef<any>;
  @ViewChild('referaquoteForm') referaquoteForm: TemplateRef<any>;
  @ViewChild('confirmquote') confirmquote: TemplateRef<any>;
 

  vehicalmodelyears = vehimodelyrs;
  public country1FilterCtrl: FormControl = new FormControl();
  public nationalFilterCtrl: FormControl = new FormControl();
  public makeFilterCtrl: FormControl = new FormControl();
  public modelFilterCtrl: FormControl = new FormControl();
  public CityFilterCtrl:FormControl = new FormControl();
  public yearFilterCtrl: FormControl = new FormControl();
  public plateFilterCtrl: FormControl = new FormControl();
  public vchColorFilterCtrl: FormControl = new FormControl();
  public mortageBankFilterCtrl: FormControl = new FormControl();
  public codeFilterCtrl: FormControl = new FormControl();
public industryFilterCtrl: FormControl = new FormControl();
public occupationFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public OccupationTypeFilter: ReplaySubject<occupation[]> = new ReplaySubject<occupation[]>(1);
  public industryTypeFilter: ReplaySubject<industry[]> = new ReplaySubject<industry[]>(1);
  public filteredCountries: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
  public filteredNationCountries: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);
  public filteredMakes: ReplaySubject<Make[]> = new ReplaySubject<Make[]>(1);
  public filteredModels: ReplaySubject<Model[]> = new ReplaySubject<Model[]>(1);
  public filteredYears: ReplaySubject<VehiModelYr[]> = new ReplaySubject<VehiModelYr[]>(1);
  public filteredPlateCat: ReplaySubject<PlateCategory[]> = new ReplaySubject<PlateCategory[]>(1);
  public filteredVchColor: ReplaySubject<VichleColor[]> = new ReplaySubject<VichleColor[]>(1);
  public filteredBank: ReplaySubject<MortageBank[]> = new ReplaySubject<MortageBank[]>(1);
  public filteredCode: ReplaySubject<Code[]> = new ReplaySubject<Code[]>(1);
  public  isHideChassisNo = false  ;
  @ViewChild('singleSelect',{static:false}) singleSelect: MatSelectModule;
  @ViewChild('myFileInput',{static:false}) myFileInput;
  @ViewChild('stepper') stepper : MatStepper;
  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;
  public maskEid = [ /[1-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/,/\d/,'-', /\d/, /\d/, /\d/, /\d/,/\d/, /\d/, /\d/, '-',/\d/, ] ;
  /** Subject that emits when the component has been destroyed. */
  private _onDestroy = new Subject<void>();

  GCC= {Yes:false,No:false , edata:false}
  vehicleValueLimit = { isSet: false, startLimit: 0, mediumLimit: 0, endLimit: 0 }

  insvehibys: any = [
    { value: 'Individual', viewValue: 'Individual', code: '100' },
    { value: 'Corporate', viewValue: 'Corporate', code: '200' },
  ];
  codes: Code[] = [
    { value: '050', viewValue: '050' },
    { value: '052', viewValue: '052' },
    { value: '054', viewValue: '054' },
    { value: '055', viewValue: '055' },
    { value: '056', viewValue: '056' },
    { value: '057', viewValue: '057' },
    { value: '058', viewValue: '058' },
  ];

  drivexps: DrivExp[] = [
    { value: 'Yes', viewValue: 'Yes' },
    { value: 'No', viewValue: 'No' },
  ];

  product: Product[] = [];
  nation: Nationality[] = [ ];
  confirmDescription: any = '';


  vehimodelyrs: VehiModelYr[] = [];
  brandnews: BrandNew[] = [
    { value: 'Yes', viewValue: 'Yes' },
    { value: 'No', viewValue: 'No' },
  ];
  vehiseatcaps: any = [
    { value: '0', viewValue: '0' },
    { value: '1', viewValue: '1' },
    { value: '3', viewValue: '3' },
    { value: '4', viewValue: '4' },
    { value: '5', viewValue: '5' },
    { value: '6', viewValue: '6' },
    { value: '7', viewValue: '7' },
    { value: '8', viewValue: '8' },
  ];


  // genders: Gender[] = [
  //   { value: 'M', viewValue: 'Male' },
  //   { value: 'F', viewValue: 'Female' },
  // ];

  genders: Gender[] = [
    { value: 'M', viewValue: 'Male' },
    { value: 'F', viewValue: 'Female' },
  ];

 

  NCDArr = [
    { value: '0', label: '0' },
    { value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
    { value: '4', label: '4' },
    { value: '5+', label: '5+' },

  ];

  activePolicyTypeArr = [
    { value: 'Yes', label: 'No INSURANCE' },
    { value: 'No', label: 'COMPREHENSIVE' },
    { value: 'Yes', label: 'THIRD PARTY LIABILITY' }
  ];

  
  noOfDorrArr = [
    
    { value: 2, label: '2' },
    { value: 3, label: '3' },
    { value: 4, label: '4' },
    { value: 5, label: '5' },

  ];



  
  calculationby = [
        { label: "By Amount", value: "0" },
        { label: "By Percent", value: "1" }
  ];


  transactionTypeArray = [
    {value: '0', label: 'New Vehicle Registration'},
    {value: '1', label: 'Vehicle Renewal'},
    {value: '2', label: 'Change in Ownership'},
  ]

  reasons = [
    {value: 'E-data missing'},
    {value: 'Invalid Data'}
  ]


  public policyStatus: any;
  formDataRes: any;
  partnersArr:any  = [];
  partnerVal: any;
  partnerName: any;
  branchVal: any;
  partnerID: any;
  localStorDta: any;
  branchId: any;
  repairtypes:any;
  repairs: any[];
  repairtypes_: { value: string; viewValue: string; }[];
  trans_ref: any;
  sideForm: FormGroup;
  sessionData: FormGroup;
  Search_vehicle:FormGroup;
  Search_policy:FormGroup;
  userDescription: boolean =false;
  emailadd: any;
  vehicylinders: any;
  expdateboolean: boolean =false;
  instypes: any;
  disabledStatus:boolean =false;
  horizontalStepperForm: FormGroup;
  invalidData:FormGroup;
  emailCode: string = 'internaluser@dni.ae';
  product_list: any;
  PartyCode: any;
  Alldata: any;
  cedantId: any;
  userId: any;
  image: any;
  email: any;
  psw: any;
  searchData: any;
  FilterVehicleData: any;
  getAllData: any;
  searchDataDetail: any;
  SchemeCodeClick : false ;
  model_year: any;
  modelId: any;
  quotation_number: any;
  policy_number: any;
  confirmAdditionalCondition:any='';
  reportissue:boolean = false;
  isReadonly = true;
  invaidEdata: {};
  Sujbectdata:any;
  Reasondata: any;
  uploadFile: any;
  Description: any;
  username: any;
  attachDocument: any;
  chassisNumber: any;
  planName: any;
  isEditable = true;
  premium: number;
    vatPer: any;
  chassisStatus: boolean= true;
  validateStatus: boolean;
  responsedata: any;
  bor_formData: FormData;
  getQuoteNumber: any;
  RoleDesc: any;
  minChassNoValid:17;
  maxChassNoValid:17;
  headerDesclaimer: any;
  unauthorizedAccess: boolean = false;
  showDescription: boolean = true;
  Desclaimer: boolean = false;
  NotificationData: any;
  mindate:Date ;
  scheme_code: string | null;
  weight: any;
  occupatindata: any;
  payLink_email:any ='';
  selectedschemecode: any;
  payLink: boolean = false;
  vehPlate: any[];
  vehiyears: VehiModelYr[];
  SCHcode: any;
  policytype: any;
  polStartDate: Date;
  prvPremium: any;
  prvSum: any;
  showSupportingDoc: boolean =false;
  MaxLDPer: any;
  MaxLDAmt: any;
  renewalDetailsData:any=[];
  MaxDSPer: any;
  ChassisNum: any;
  VATAMT1: any;
  PrevpolExpDate: any;
  highSI: any;
  renewalschemecode: string;
  dobYr: any;
  showReferbutton: boolean = true;
  confirmIssued: any;
  updateStatusDescription: any;
  termsAndConditions( type) {

    const dialogRef = this.dialog.open(this.termsandconditions);
    if(type=='SENDPAYMENTLINK'){
      this.payLink =true;
    }else{
      this.payLink =false;
    }
    this.policyStatus = type;
    this.getTermsConditions();
  }
  NCDPerData= [] ;
  //DECLARE FORMGROUPS
  insuredDetailForm: FormGroup; quotationForm: FormGroup; step2: FormGroup;

  //DECLARE ARRAYS
  vhclMakeArr: Make[]; countryArr: Country[]; vhclColorArr: VichleColor[]; cityArr: any = []; vhclModelArr: Model[]; vhclBodyTypeArr: any = []; vehitrims: any = []; tempRepairTypeArr: any = []; multilpleFile: any = []; quotationHistoryArr:any = [];
  coverData: any = []; NCDData: any = []; benfPremIdArray: any = []; savePlanDetailArr: any = []; quoteDetailArr: any = []; bankDetail: MortageBank[]; quoteDetailDataForCUst: any = []; plateCodeArray: any = []; tempAdditionalDoc: any = [];
  document_data: any = []; vehicleData: any = []; tempDocArray: any = []; public termsAndCondition: any = []; retrieveData: any = []; tempBenefitData: any = []; tempMultipleDocData: any = []; additionalDocFile:any = []; plateCatArray: any = [];
  industryTypeArr: any = []; tempTransactionTypeArr : any = []; partnerBranchArr:any=[];

  //DECLARE VARIABLES
  public accept_terms: boolean = false; language_code = 'ENG'; country = 'United Arab Emirates'; docNameType: any; chassis_No_Details: any; invalidEID: boolean = true; value: any = 0; showAllDocImg: any = 0; showMultiQuotationImg: any = 0;
  webQuoteNumber: any = ''; quoteNumber: any; public policyFee: number; VATAMT: any; Total_Primium: any; tempTotalFixPremium: number; totalFixPremium: number = 0; totalVariablePremium: number = 0; referalDescription: any = ''; showAdditionalDocImg:any = 0;
  plan_Name: any; plan_Id: any; mulOption: any; optionalBenefit: any; totalPreimum: number = 0; localStorageData: any; validateMsg: boolean = false; nofDoors: any; getVechileDetailData: any; ImagedocumentType: any; plate_code: any;
  vhcleMake: any; onModelChange: boolean = false; validtnMsg: boolean = false; emailId: any; retrieveQuoteNumber: any = ''; public showTerms: boolean = false; public editQuoteDocs: any; fileType: any; quoteDetail: any; loading_rate:any;
  public vatAMt: any; total_premium: any; policyNumber: any; vhcleValueFlag: boolean = false; public existVehiclevalue: any; loadingBy: any; loadingValue: any; checkStepper: boolean = false; accessGroup: any; quoteStatus: any;
  loadByAmount: any = 0; loadByPercent: any = 0; businessSource: any; partnerId: any; checkChassisValidation: boolean = false; SchemeCode: any; PaymentMode: any; tempTotalLoadFixPrem = 0; multipleImg: any = ''; referalStatus: boolean = false;
  public userRole:any; userType:any; calculBy:any = '0'; calculationAmt:any;  public uploadMultipleDocs :boolean =false; uploadSingleDocs:boolean = false; referral_reason:any; refAdditionalCondition:any; refDescription:any = ''; refer_condtion_type:any; refer_type:any;
  referalModel:boolean = false;selfDeclarationDiscount:any; fileUploadFlag: boolean = false; vehicle_age:any; isRenewal:any; initial_benefit_data: any; discount: any; GCC_Specification:any='';public disValidate:boolean = false; public repairLoadingAmt:number;
  public LDAmount:any = ''; LDType:any = ''; LDRate:any = ''; retrieve_repair_type = '';
    planBenefitIDforBronze :any;tcMin=10;
    tcMax = 10;
  issuePolicyBtnAccess :boolean = false; onlinePayBtnAccess :boolean = false;
  quoteConfirmBtnAccess: boolean = false; 
  issuepolConfirm: boolean = false;
  isQuoteConfrimClicked: boolean = false;

  sendPaymentLinkBtnAccess :boolean = false;
  confirmBtnAccess: boolean = false;
  AccessGroup="";
  specialDiscountAmt:any;
  confirm_type: string;
  confirm_condtion_type: number;
  //Date
  todayDate = new Date(Date.now());
  policyMinDate = new Date(Date.now());
  policyMaxDate = new Date(new Date().setDate(new Date().getDate() + 13));
  toDay = new Date(Date.now());
  minyear = new Date().getFullYear() - 1;
  maxYear = new Date().getFullYear() + 1;
  regMinDate = new Date(2000, 0, 2);
  regMaxDate = new Date(2020, 0, 2);
  year = new Date().getFullYear();
  nextDate = new Date(Date.now() + 1);
  PrevDate = new Date(Date.now() - 2);
  eidMaxDate = new Date(new Date().setFullYear(new Date().getFullYear() + 10));
  eidMinDate = new Date(Date.now());
  reg_exp_min_date = new Date(new Date().setDate(new Date().getDate() - 365));
  checkregExpDate = new Date(new Date().setDate(new Date().getDate() - 60));
  reg_exp_max_date = new Date(new Date().setDate(new Date().getDate() + 90));
  minDOB = new Date(new Date().setDate(new Date().getDate() - 365*99));
  maxDOB = new Date(new Date().setDate(new Date().getDate() - 365*18));

  minEidExpiryDate = new Date(new Date().setDate(new Date().getDate() - 30));
  maxEidExpiryDate = new Date(new Date().setDate(new Date().getDate() + 365*15));

  prevInsMaxDate = new Date(new Date().setMonth(new Date().getMonth() + 3));
  licExpMinDate = new Date(Date.now());
  licIssueMaxDate =  new Date(Date.now());
  firstRegDate:any = new Date(Date.now() - 40);
  currentdate:any = new Date(Date.now());
  isLoading=false;
  id:number;
  showBor :boolean = false;
  engineList=[];

  public hideImages = {
    reg_card_front: false,
    reg_card_back: false,
    emirates_Id_front: false,
    emirates_Id_back: false,
    driving_Lic_front: false,
    driving_Lic_back: false,
    supporting_Document: false,
    multipleDoc: false,
    additionalDoc: false,
    trade_Licence : false,
    TRN_Certificate : false
  }

  public showLoader = {
    reg_card_front: false,
    reg_card_back: false,
    bor_card: false,
    emirates_Id_front: false,
    emirates_Id_back: false,
    driving_Lic_front: false,
    driving_Lic_back: false,
    Quotation: false,
    VehicleValue: false,
    vhclMake: false,
    vhclModel: false,
    vhclTrim: false,
    vhclBodyType: false,
    vhclEngine: false,
    retrieveQuote: false,
    multipleDoc: false,
    multipleGAPDoc: false,
    supporting_Document: false,
    chasisNoButton: false,
    additionalDoc: false,
    referal: false,
    trade_Licence : false,
    TRN_Certificate : false,
    refer:false,
    confirm:false
  }
  public chnageData = {
    rg_vhcl_make: ''
  }
  
  public isCallChessisNo = true ;
  formatLabel(value: number) {
    if (value >= 5000) {
      return Math.round(value / 1000) + 'k';
    }

    return value;
  }
  @HostListener('document:click', ['$event'])
  public documentClick(event: Event): void {
    
    setTimeout(()=>{       
                          // <<<---using ()=> syntax
      this._authService.signInUsingToken();
  }, 5000);
  }
  constructor(public _route: Router, public _activatedroute: ActivatedRoute, public motorQuoteService: MotorquoteService, public formBuilder: FormBuilder,   public dialog: MatDialog, public globalService: GlobalService,private el: ElementRef,private _authService: AuthService, private quickQuoteService:QuickquoteService) { }

  ngOnInit() {
    // this._route.navigate(['motor/thankyou/']);
    this.getSchemesByProduct();
    

  this.modelYearRang();
 
  this.localStorageData = this.globalService.getLocalStorageData();
  // console.log(this.localStorageData);
  
  const routeParams = this._activatedroute.snapshot.params;
        this.partnerId = this.localStorageData.PartnerId;
        // console.log(this.partnerId);

        this.PartyCode = this.localStorageData.PartyCode;
        this.cedantId = this.localStorageData.CedantId;
        this.userId = this.localStorageData.UserId;
        this.businessSource = this.localStorageData.BusinessSource;
        this.userRole = this.localStorageData.UserRole;
        this.userType = this.localStorageData.UserType;
        this.RoleDesc = this.localStorageData.RoleDesc
        this.AccessGroup = this.localStorageData.AccessGroup
       
        // this.getPartnerBranchList();

    this.countryArr = [] ;
    if (routeParams.quoteNum) {
      this.retrieveQuoteNumber = routeParams.quoteNum.replaceAll("-","/");
      // console.log(this.retrieveQuoteNumber);
      this.isCallChessisNo =  false ;
    }
    

    this.SchemeCode = localStorage.getItem("Schemecode");
    
    // this.sideForm.get('partnerID').setValue(this.partnerId);
 
    this.tempTransactionTypeArr = this.transactionTypeArray;

    // if (this.SchemeCode == null || this.SchemeCode == '' || this.SchemeCode == undefined) {
    //   this._route.navigate(['motorscheme']);
    // }

    if(this.businessSource == 'DIRECT' && this.partnerId == 1 && this.userType == 'POS' && this.userRole == 'TELEMARKETING' && this.quoteStatus == 'REFERRED'){
      this.vehimodelyrs.push(
        { value: '1989', label: '1989' },
        { value: '1988', label: '1988' },
        { value: '1987', label: '1987' },
        { value: '1986', label: '1986' },
        { value: '1985', label: '1985' },
        { value: '1984', label: '1984' },
        { value: '1983', label: '1983' },
        { value: '1982', label: '1982' },
        { value: '1981', label: '1981' },
        { value: '1980', label: '1980' }
      );
    }
    this.showLoader.reg_card_front = false;
    this.showLoader.reg_card_back = false;
    this.showLoader.bor_card = false;
    this.showLoader.emirates_Id_front = false;
    this.showLoader.emirates_Id_back = false;
    this.showLoader.driving_Lic_front = false;
    this.showLoader.driving_Lic_back = false;
    this.showLoader.retrieveQuote = false;
    this.showLoader.supporting_Document = false;
    this.showLoader.trade_Licence = false;
    this.showLoader.TRN_Certificate = false;

    this.quotationForm = this.formBuilder.group({
        issuePolicyStepper : ['', [Validators.required]]
    });


    // this.sessionData = this.formBuilder.group({
    //   password:[Validators.required]
    // });


    this.sideForm = this.formBuilder.group({
      schemeCode: ['', Validators.required],
      partnerID: ['', Validators.required],
      branchID:['',Validators.required],
      Accounting: ['']
   });
   this.getPartnerBranchList();
   this.sessionData = this.formBuilder.group({
      password: ['',Validators.required]
   });

   this.Search_vehicle = this.formBuilder.group({
    selected_motor: [''],
      license_no:[''],
      reg_tc_no:[''],
      chassis_no:['',[Validators.required ,Validators.minLength(17),Validators.maxLength(17)]],
      policy_no:['']
 });


 this.Search_policy = this.formBuilder.group({
  
  policy_no:[this.retrieveQuoteNumber,Validators.required],
  chassis_no:['LJD0AA297L0116345',[Validators.required ,Validators.minLength(17),Validators.maxLength(17)]]
 
});
   this.invalidData = this.formBuilder.group({
    subjectData: [''],
    reason:[''],
    description:[''],

    chassisnumber:['']
   });

    this.insuredDetailForm = this.formBuilder.group({

      docRegCardFront: [''],
      reg_Card_Front: [''],
      reg_Card_FrontFilePath: '',
      reg_Card_FrontFileType: '',

      docSupporting: [''],
      supporting_Document: [''],
      supporting_DocumentFilePath: '',
      supporting_DocumentFileType: '',
      additional_DocumentFilePath: '',

      docSupportingGAP:[''],

      docRegCardBack: [''],
      reg_Card_Back: [''],
      reg_Card_BackFilePath: '',
      reg_Card_BackFileType: '',

      docEmiratedIdFront: [''],
      emirated_ID_Front: [''],
      emirated_ID_FrontFilePath: '',
      emirated_ID_FrontFileType: '',

      docEmiratedIdBack: [''],
      emirated_ID_Back: [''],
      emirated_ID_BackFilePath: '',
      emirated_ID_BackFileType: '',

      docDrivingLicFront: [''],
      driving_Lic_Front: [''],
      driving_Lic_FrontFilePath: '',
      driving_Lic_FrontFileType: '',

      docDrivingLicBack: [''],
      driving_Lic_Back: [''],
      driving_Lic_BackFilePath: '',
      driving_Lic_BackFileType: '',

      docTradeLicence : [''],
      trade_Licence : [''],
      trade_LicenceFilePath: '',
      trade_LicenceFileType: '',

      docTRNCertificate : [''],
      TRN_Certificate : [''],
      TRN_CertificateFilePath: '',
      TRN_CertificateFileType: '',

      MulkhiyaStatus: [true],

      // reg card front form fields

      rg_model_year: ['', [Validators.required]],
      rg_num_passenger: ['', [Validators.required]],
      rg_origin: [''],
      rg_vhcl_make: ['', [Validators.required]],
      rg_vhcl_model: ['', [Validators.required]],
      rg_gvm: [''],
      rg_engin_num: ['',[Validators.required,Validators.minLength(3),Validators.maxLength(20)]],
      rg_chassis_num: ['',[Validators.required ,Validators.minLength(17),Validators.maxLength(17)]],
      // reg card back form fields
      rg_traffic_plate_num: [''],
      rg_place_issue: [ '', [Validators.required]],
      rg_TC_num: ['', [Validators.required]],
      rg_type: ['', [Validators.required]],
      rg_plateCode: ['',[Validators.required]],
      rg_noOfDoor:['', [Validators.required]],
      // rg_expiry_date: ['', [Validators.required]],
      rg_reg_date: ['', [Validators.required]],
      v_value:['', [Validators.required]],
      rg_ins_exp: ['', [Validators.required]],
      rg_policy_num: [''],
      rg_mortgage: [''],
      adtnl_detail_gccSpecified: ['', [Validators.required]],
      adtnl_detail_vhclModified: ['', [Validators.required]],
      // eid front form fields
      
      e_eid:  ['',[Validators.required ]],
      e_name: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      e_nationality: ['',[Validators.required]],
      e_cardNumber: [''],
      e_expiryDate: ['',[Validators.required]],
      e_gender:['',[Validators.required]],
      e_arabic_name: [''],
      // eid back form fields

      // driving lic front form fields
      d_driv_lic_num: ['',[Validators.required]],
      d_dob:['',[Validators.required]],
      d_issue_date: ['',[Validators.required]],
      d_expiry_date: ['',[Validators.required]],
      d_place_issue: ['',[Validators.required]],
      d_TC_number: [ '',[Validators.required]],
      po_box_location:['',[Validators.required]],
      po_box_number:['',[Validators.required]],
      driver_occupation:['',[Validators.required]],
      d_lic_type: [''],

      // Additional detail fields /^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/  //'[050|052|054|055|056|057|058|059]{1}[0-9]{7}'
      adtnl_detail_email:  ['',[Validators.required, Validators.email,Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      // adtnl_detail_mbCode: ['', [Validators.required]],
      adtnl_detail_mobile: ['',Validators.compose([Validators.required,Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
      adtnl_detail_NCD: ['', [Validators.required]],
      adtnl_detail_NCD_Perc: [''],
      adtnl_detail_repairTye:['', [Validators.required]],
      // adtnl_detail_vhclValue:['', Validators.required],
      weight_empty:[''],
      weight_full:[''],

      adtnl_detail_vhclValue_high:[''],
      adtnl_detail_vhclValue_low:[''],
      adtnl_detail_vhclValue_medium:[''],
      adtnl_detail_trim: ['', [Validators.required]],
      adtnl_detail_bodyType: ['', [Validators.required]],
      adtnl_detail_engine: [''],
      adtnl_detail_cylinder: [''],

      adtnl_detail_brandNew: [''],
      adtnl_detail_address: [''],
      adtnl_detail_area: [''],
      adtnl_detail_poBoxNum: [''],
      adtnl_detail_insType: ['', [Validators.required]],
      isChassisValidate: [''],
      adtnl_detail_vhclOwnBy: ['', [Validators.required]],
      polStartDate: [new Date(Date.now()), Validators.required],
      vhclTPLCoverage: ['', [Validators.required]],
      promoCode: [''],
      vhclColor: [''],
      eIDCheck:[''],
      CC : [''],
      loading_capacity : [''],
      deductible : [''],

      //For Corporate : insured vehicle own by
      TRN_num : [''],
      trade_lic_num : [''],
      industry_type : [''],
      vat_register : ['No'],
      vat_tl_location: [''], // TO - do ,[Validators.required]
      transaction_type : ['',[Validators.required]],
      mileage : ['',[Validators.required]],

      // Added Partner And Branch

      partner:[''],
      branch:[''],
    });
    // console.log(this.insuredDetailForm);

    this.step2 = this.formBuilder.group({
      adminDeductible:['']
      //  loadingBy: [''],
      //  calculBy : [''],
      //  loadByAmount : [''],

   });
 this.getQuotationFormData();

   this.tmp_rg_ins_exp = this.insuredDetailForm.value.rg_ins_exp

    // this.checkUserAccess();
    this.getAllFormData();
    // this.getVhclNCD();
    this.getIndustryTypes();
   this.getCylinder();
   this.getVehicleCapacity();
    this.getOccupation();
    this.renewquotationsearch();
    this.insuredDetailForm.get('adtnl_detail_brandNew')?.setValue('0');
    // console.log(this.insuredDetailForm.get('adtnl_detail_brandNew')?.setValue('0'));

    if (this.insuredDetailForm.value.adtnl_detail_brandNew == 1) {

        this.transactionTypeArray = [];
        this.transactionTypeArray.push(this.tempTransactionTypeArr[0]);
        this.insuredDetailForm.get('transaction_type')?.setValue(this.transactionTypeArray[0]);
    }else{
        this.transactionTypeArray = [];
        this.transactionTypeArray.push(this.tempTransactionTypeArr[1]);
        this.transactionTypeArray.push(this.tempTransactionTypeArr[2]);
        this.insuredDetailForm.get('transaction_type')?.setValue(this.transactionTypeArray[0]);
    }
    this.onChangeTransactionType(this.insuredDetailForm.value.transaction_type.label);

 /*  Need to check and delete
    this.insuredDetailForm.get('rg_vhcl_model')?.valueChanges.subscribe(value => {

      if(this.isClickChassisValidate)  return false ;  // if validate chassis no called

      if(this.insuredDetailForm.value.rg_model_year=="") return false ;
      // console.log(this.insuredDetailForm);
      // console.log(value?.VehicleModelName);
      this.showLoader.vhclTrim = true ;
      if(value !== null && value !== undefined)
      this.motorQuoteService.getTrimList(
                                        
                                        this.insuredDetailForm.value.rg_model_year.label,
                                        value.VehicleModelName,
                                        this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName,
                                        this.sideForm.value.schemeCode
                                        ).subscribe(res=>{
                                          this.showLoader.vhclTrim = false ;
                                          let trimName = '';

                                          if(this.retrieveData.length!=0){

                                            trimName = this.retrieveData[0].TrimName;
                                          }
                                          if(this.vehicleData?.General?.Trim){
                                           
                                            trimName = this.vehicleData?.General?.Trim;
                                          }
                                          if(res.response_message.LookupList.length!=0) {
                                          this.vehitrims = res.response_message.LookupList    ;  
                                          let trimElem = '' ;
                                          if((trimName!="") || (this.vehicleData && this.vehicleData?.General))
                                          this.vehitrims.forEach((item, index) => {

                                            if(item.Name==trimName)
                                            {
                                              trimElem = item;
                                            }
                                          });
                                          if(trimElem!='')
                                          this.insuredDetailForm.get('adtnl_detail_trim')?.setValue(trimElem);
                                         }else{

                                          this.vehitrims = [{ "Name":value.VehicleModelName,"Code":""}]    ;  
                                          this.insuredDetailForm.get('adtnl_detail_trim')?.setValue(this.vehitrims[0]);

                                         }
  
                                        });
       
    });
    this.insuredDetailForm.get('adtnl_detail_trim')?.valueChanges.subscribe(value => {

      if(this.isClickChassisValidate)  return false ;  // if validate chassis no called

      if(this.insuredDetailForm.value.adtnl_detail_bodyType){
        setTimeout(() => {
          console.log(this.engineSizeList()); // gives the correct value.
        }, 1000);
      }
     // this.updateValuation_new(value);
    });

    this.insuredDetailForm.get('adtnl_detail_engine')?.valueChanges.subscribe(value => {

      if(this.isClickChassisValidate)  return false ;  // if validate chassis no called
      
        if(this.isUpdateValuation){
          setTimeout(() => {
            console.log(this.updateValuation_new()); // gives the correct value.
          }, 500); 
        }else{

          this.isUpdateValuation = true ;
        }
     
    });

*/
    

    /*****   Tod0 ****

    if( this.SchemeCode == '106'){
      this.insuredDetailForm.get('adtnl_detail_insType')?.setValue( { value: '200', viewValue: 'Third Party Liability', WebProdCode: 'MTTPL0065', CoreProdCode: '4021' });
    }else {
      this.insuredDetailForm.get('adtnl_detail_insType')?.setValue( { value: '100', viewValue: 'Comprehensive', WebProdCode: 'MT00061', CoreProdCode: '4001_1' });
    }
***/
    //-------------VALIDATION ON POLICY TYPE CHANGE --------------------------------//


    this.insuredDetailForm.get('adtnl_detail_insType')?.valueChanges.subscribe(obj => {

      if(this.isClickChassisValidate)  return false ;  // if validate chassis no called

      if (obj.ProductShortName == 'Comprehensive') {

        this.insuredDetailForm.get('adtnl_detail_repairTye')?.setValidators([Validators.required]);
        // Validators.min(this.vehicleValueLimit.startLimit), Validators.max(this.vehicleValueLimit.endLimit)
        //  this.insuredDetailForm.get('v_value').setValidators([Validators.required]);
       // this.insuredDetailForm.get('v_value').setValidators(null);

      }
      else {

        this.insuredDetailForm.get('adtnl_detail_repairTye')?.setValidators(null);


      }

      this.insuredDetailForm.get('adtnl_detail_repairTye')?.updateValueAndValidity();
   //   this.insuredDetailForm.get('v_value').updateValueAndValidity();

    });


    this.insuredDetailForm.get('adtnl_detail_bodyType')?.valueChanges.subscribe(obj => {

      if(this.isClickChassisValidate)  return false ;  // if validate chassis no called
      // if bodytye is motorcycle 'CC' is mandatory --------------- 02 Nov 20
        if(obj.BodyTypeName == 'MOTORCYCLE') {
              this.insuredDetailForm.get('CC')?.setValidators([Validators.required]);
              this.insuredDetailForm.get('loading_capacity')?.setValidators(null);
        }
        // if bodytye is Pickup 'loading_capacity' is mandatory ------------- 02 Nov 20
        else if(obj.BodyTypeName == 'PICKUP'){
            this.insuredDetailForm.get('CC')?.setValidators(null);
            this.insuredDetailForm.get('loading_capacity')?.setValidators([Validators.required]);
        }

        else{
            this.insuredDetailForm.get('CC')?.setValidators(null);
            this.insuredDetailForm.get('loading_capacity')?.setValidators(null);
        }

        this.insuredDetailForm.get('CC')?.updateValueAndValidity();
        this.insuredDetailForm.get('loading_capacity')?.updateValueAndValidity();
    });

    this.insuredDetailForm?.get('adtnl_detail_vhclOwnBy')?.valueChanges.subscribe(obj => {

        if(this.isClickChassisValidate)  return false ;  // if validate chassis no called

        if (obj?.viewValue && obj.viewValue == 'Corporate') {
          this.insuredDetailForm.get('vat_tl_location')?.setValidators([Validators.required]);

          this.insuredDetailForm.get('industry_type')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('vat_register')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('e_eid')?.setValidators(null);
          this.insuredDetailForm.get('d_dob')?.setValidators(null);
          this.insuredDetailForm.get('e_nationality')?.setValidators(null);
          this.insuredDetailForm.get('d_driv_lic_num')?.setValidators(null);
          this.insuredDetailForm.get('d_place_issue')?.setValidators(null);
          this.insuredDetailForm.get('d_issue_date')?.setValidators(null);
          this.insuredDetailForm.get('d_expiry_date')?.setValidators(null);
          this.insuredDetailForm.get('d_TC_number')?.setValidators(null);
          this.insuredDetailForm.get('e_gender')?.setValidators(null);
          this.insuredDetailForm.get('weight_empty')?.setValidators(null);
          this.insuredDetailForm.get('weight_empty')?.updateValueAndValidity();
          this.insuredDetailForm.get('weight_full')?.setValidators(null);
          this.insuredDetailForm.get('weight_full')?.updateValueAndValidity();

          this.insuredDetailForm.get('trade_lic_num')?.setValidators([Validators.required]);
          
                  this.insuredDetailForm.get('vat_register')?.valueChanges.subscribe(obj => {

                    if (obj == 'Yes') {

                      this.insuredDetailForm.get('TRN_num')?.setValidators([Validators.required]);
                    }
                    else {

                      this.insuredDetailForm.get('TRN_num')?.setValidators(null);

                    }
                      this.insuredDetailForm.get('TRN_num')?.updateValueAndValidity();

                  });

        }
        else {
          this.insuredDetailForm.get('vat_tl_location')?.setValidators(null);
          this.insuredDetailForm.get('industry_type')?.setValidators(null);
          this.insuredDetailForm.get('vat_register')?.setValidators(null);
          this.insuredDetailForm.get('d_dob')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('e_nationality')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('e_eid')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_driv_lic_num')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_place_issue')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_issue_date')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_expiry_date')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_TC_number')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('e_gender')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('trade_lic_num')?.setValidators(null);
        }

          this.insuredDetailForm.get('industry_type')?.updateValueAndValidity();
          this.insuredDetailForm.get('vat_register')?.updateValueAndValidity();
          this.insuredDetailForm.get('d_dob')?.updateValueAndValidity();
          this.insuredDetailForm.get('e_nationality')?.updateValueAndValidity();
          this.insuredDetailForm.get('e_eid')?.updateValueAndValidity();
          this.insuredDetailForm.get('d_driv_lic_num')?.updateValueAndValidity();
          this.insuredDetailForm.get('d_place_issue')?.updateValueAndValidity();
          this.insuredDetailForm.get('d_issue_date')?.updateValueAndValidity();
          this.insuredDetailForm.get('d_expiry_date')?.updateValueAndValidity();
          this.insuredDetailForm.get('d_TC_number')?.updateValueAndValidity();
          this.insuredDetailForm.get('e_gender')?.updateValueAndValidity();
          this.insuredDetailForm.get('trade_lic_num')?.updateValueAndValidity();
          this.insuredDetailForm.get('vat_tl_location')?.updateValueAndValidity();
    });

    // listen for search field value changes
    this.country1FilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterCountry();
      });

      this.occupationFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterOccupation();
      });
    // listen for search field value changes
    this.nationalFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterNationalCountry();
      });

      this.industryFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.industryfilter();
      });

    this.makeFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterMake();
      });

    this.modelFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterModel();
      });

    this.filteredYears.next(this.vehimodelyrs.slice());

    this.yearFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterYear();
      });



    this.filteredPlateCat.next(this.plateCatArray.slice());

    this.plateFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterPlateCat();
      });


    this.vchColorFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterVechColor();
      });

    this.mortageBankFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterMortageBank();
      });


    this.filteredCode.next(this.codes.slice());


    this.codeFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterCode();
      });

    this.tempRepairTypeArr = this.repairtypes;

 //   this.getQuotationFormData();

   /************* Api call for creditLimit  */

   setTimeout(()=>{this.getPartnerCreditLimit()},100);


   this.insuredDetailForm.get('adtnl_detail_NCD')?.valueChanges.subscribe(obj => {
   
    
    
    setTimeout(() => {

      if(obj!= undefined) {
        // console.log(obj);
        // console.log("debug 1",obj);
        this.motorQuoteService.getNCDPercentage(this.sideForm.value.partnerID,this.sideForm.value.schemeCode,obj.NCDCode).subscribe(res=>{

         this.NCDPerData = res.res_data ;
        this.insuredDetailForm.get('adtnl_detail_NCD_Perc')?.setValue(this.NCDPerData[0]);
    

       }) 
      }

   }), 100});

this.CheckAccessOnLoad();


setTimeout(() => {
  const schemes = ["65S", "65Q4", "66S", "65RK","66RK"," 66Q"];
  let event = this.sideForm.value.schemeCode;
  if(schemes.includes(event)){  this.chassisMin = 17 ; this.chassisMax = 17 ;
  
this.insuredDetailForm.get('rg_chassis_num')?.setValidators([Validators.required ,Validators.minLength(17),Validators.maxLength(17)]);

this.insuredDetailForm.get('rg_chassis_num')?.updateValueAndValidity();
  
  }
  else {  this.chassisMin = 6 ; this.chassisMax = 17 ;
    this.insuredDetailForm.get('rg_chassis_num')?.setValidators([Validators.required ,Validators.minLength(6),Validators.maxLength(17)]);

    this.insuredDetailForm.get('rg_chassis_num')?.updateValueAndValidity();
  
  }
  },2000);

  }
   
  ngAfterViewInit(): void
    {
      if ((this.retrieveQuoteNumber != '' && this.retrieveQuoteNumber != undefined)) {

        setTimeout(() => { 
 

          this.insuredDetailForm.get('rg_policy_num')?.setValue(this.retrieveQuoteNumber);
           this.Search_policy.get("chassis_no").setValue('');
           this.Search_policy.get("policy_no").setValue(this.retrieveQuoteNumber);
          // this.Search_policy.value.policy_no,
    
          
        //  this.getRetrieveQuoteDataModified(); 
        
        },2000);
      }
    }



 /**************  CreditLimit variables  */
  public creditLimit = {CreditLimit:0,AvailableLimit:0}
  public noCreditLimt  = 0 ;

  public getPartnerCreditLimit(){   // LOB 10 for motor

    if(this.sideForm.value.branchID!=''){
    this.motorQuoteService.partnerCreditLimit(3,this.partnerId,this.sideForm.value.branchID).subscribe(res=>{

        if(res.response_message==null){
            this.noCreditLimt = 0 ;
            this.creditLimit = {CreditLimit:0,AvailableLimit:0};
        }else{

            this.creditLimit = res.response_message;
            // console.log( this.creditLimit);
            this.noCreditLimt = 0 ;
        }
      })
    }else{

      setTimeout(() => { this.getPartnerCreditLimit(); },500);
    }
  }

  closeDesclaimer(){
    this.Desclaimer=false;
  }
  getParterLimitOnSelection(){

    this.partnerId = this.sideForm.value.partnerID;
    this.motorQuoteService.partnerCreditLimit(10,this.partnerId,this.sideForm.value.branchID).subscribe(res=>{

        if(res.response_message==null){
            this.noCreditLimt = 0 ;
            this.creditLimit = {CreditLimit:0,AvailableLimit:0};
        }else{

            this.creditLimit = res.response_message;

            this.noCreditLimt = 1 ;


        }

      })

  }

  issuePolicyCreditLimitCheck(){
     this.isEditable=false;
    this.partnerId = this.sideForm.value.partnerID;
    this.motorQuoteService.partnerCreditLimit(10,this.partnerId,this.sideForm.value.branchID).subscribe(res=>{

        if(res.response_message==null){
            this.noCreditLimt = 0 ;
            this.creditLimit = {CreditLimit:0,AvailableLimit:0};
            Swal.fire("Your credit limit seems to be exhausted. Please contact the Credit Control department.","", "error");


        }else{

            this.creditLimit = res.response_message;

            this.noCreditLimt = 1 ;

            if(this.creditLimit.AvailableLimit<(((this.totalFixPremium+this.totalVariablePremium) * 0.05) + (this.totalFixPremium+this.totalVariablePremium)))
            Swal.fire("Your credit limit seems to be exhausted. Please contact the Credit Control department.","", "error");
            else
            this.termsAndConditions("ISSUEPOLICY");
        }

      })

  }
  items = []
  weightFull = []
  weightempty(event:any){

    // console.log(this.weightFull);
    // console.log(event);
    this.weightFull = [];
     let newArr = [];
  this.weight.forEach(element => {
    // if (Number(element.VehicleCapacityValue)> Number(event.VehicleCapacityValue)){
    //   this.weightFull.push(element)
    // }
  });  

  }


  onFileChangeAttachment(event){
    // console.log(event);
  }

   //mat autocomplete
   promise1 = new Promise((resolve, reject) => {
    setTimeout(() => {
      const newValue = Math.floor(Math.random() * 20);
      resolve(newValue);
    }, 5000);
  });

   promise2 = new Promise((resolve, reject) => {
    setTimeout(() => {
      const newValue = Math.floor(Math.random() * 20);
      resolve(newValue);
    }, 8000);
  });

   promise3 = new Promise((resolve, reject) => {
    setTimeout(() => {
      const newValue = Math.floor(Math.random() * 20);
      resolve(newValue);
    }, 2000);
  });



  async onKeyVehicleData(event:any){
    
    if(this.Search_vehicle.value.selected_motor.length<4)  { this.FilterVehicleData=[] ;return false ; }
    await Promise.all([this.promise1, this.promise2, this.promise3]);
        this.isLoading = true;
        this.searchData = event.target.value;
    await this.quickQuoteService.globalSearchForData(this.searchData).subscribe(res=>{
        // console.log(res);
        this.FilterVehicleData = res.response_data;
        this.isLoading = false;
        let resData = res.response_data ; // to - do
        
        

  })
}

sendAttachment(event){
  this.attachDocument=event.target.files[0].name;
  this.motorQuoteService.uploadAttachment(this.attachDocument).subscribe(res=>{
    // console.log(res);
  })


}

update(){

}
onSelectionChange(event, selectedId) {

    this.getAllData = event.source.value;
    this.id = selectedId;
    // console.log(this.id);

    // console.log(event.source.value, event.source.selected);
    this.quickQuoteService.getAllData( this.id).subscribe(res=>{
        // console.log(res.response_data);
        this.close();
      let  resdata = res.response_data;
      this.quoteDetail = resdata;
      // console.log(this.quoteDetail);
        this.quoteDetail.VehicleMake = resdata.VehicleMake;
        this.quoteDetail.VehicleModel = resdata.VehicleModel;
        this.quoteDetail.TrimCode = resdata.TrimCode;
        this.quoteDetail.TrimName = resdata.VehicleTrim;
        this.quoteDetail.BodyType = resdata.BodyType;
        
   
        let  resData = res.response_data;
        this.isClickChassisValidate = true ;
        this.insuredDetailForm.get('rg_chassis_num').setValue(res.response_data.ChassisNumber);

        // Model Year Binding 
        this.vehimodelyrs = [] ;
        this.vehimodelyrs.push({ value: resData.ModelYear.toString(), label:resData.ModelYear.toString() });
        this.insuredDetailForm.get("rg_model_year").setValue(this.vehimodelyrs[0]);
   
        
        // Vehicle Make Binding 
        this.vhclMakeArr = [] ;
        this.vhclMakeArr.push({ VehicleMakeId:1,
                                VehicleMakeName: resData.VehicleMake,
                                Active: true ,
                                IsReferral:0,
                                CRS_VEH_CODE:1
                               });
        this.insuredDetailForm.get("rg_vhcl_make").setValue(this.vhclMakeArr[0]);
   
   
        // Vehicle Model Binding 
        this.vhclModelArr = [] ;
        this.vhclModelArr.push({ VehicleModelId:1,
                                VehicleModelName: resData.VehicleModel,
                                Active: true ,
                                SeatingCapacityExDriver:0,
                                BodyTypeId:1,
                                CRS_MODEL_CODE:1,
                                EDATA_MODEL_CODE:"No"
                               });
        this.insuredDetailForm.get("rg_vhcl_model").setValue(this.vhclModelArr[0]);
   
   
         // Vehicle Body Type Binding 
        this.vhclBodyTypeArr = [] ;
        this.vhclBodyTypeArr.push({id:1,BodyTypeName:resData.BodyType});
        this.insuredDetailForm.get("adtnl_detail_bodyType").setValue(this.vhclBodyTypeArr[0]);
   
   
        // Vehicle Trim Binding 
        this.vehitrims = [] ;
        this.vehitrims.push({ Name:resData.VehicleTrim });
        this.insuredDetailForm.get("adtnl_detail_trim").setValue(this.vehitrims[0]);
   
   
        // Vehicle Engine Binding 
        let engineData = resData.EngineSize ;
        this.engineList= [  {Name:engineData , Code:engineData , Cylinders:engineData,Passengers:4} ] ;
        this.insuredDetailForm.get('adtnl_detail_engine').setValue(this.engineList[0]);
   
        // Vehicle Cylinders Binding 
        this.vehicylinders = [{Id	:1 , CylinderName	: resData.EngineCylinders	,  CylinderCode :	"2"}];
        this.insuredDetailForm.get("adtnl_detail_cylinder").setValue(this.vehicylinders[0]);
   
   
        // Vehicle Number Of Passenger Binding 
        this.vehiseatcaps = [{value	:1 , viewValue	: resData.NoOfSeats	}];
        this.insuredDetailForm.get("rg_num_passenger").setValue(this.vehiseatcaps[0].viewValue);
                
        this.insuredDetailForm.get("v_value").setValue(resData.SumInsured);
        this.vehicleValueLimit.startLimit= Number(resData.ValuationLow);
        this.vehicleValueLimit.endLimit= Number(resData.ValuationHigh);

        this.Search_vehicle.reset();
        this.FilterVehicleData=[];
         this.isClickChassisValidate = false ;   
         this.Search_vehicle.reset();

        
    })

}

isEditRetriveOnPageLoad = true ; // if page retrive data then on edata call  suminsured not changed
quoteDetailPrev:any= [];


sendEmail(){
  // console.log(this.invalidData);
  this.Sujbectdata=this.invalidData.value.subjectData;
  this.Description=this.invalidData.value.description;
  this.username=this.localStorageData.UserName;
  this.chassisNumber=this.invalidData.value.chassisnumber;


  this.motorQuoteService.sendEmailToAdmin(this.Sujbectdata,this.Description,this.username,this.chassisNumber).subscribe(res=>{
    // console.log(res);
  })
  this.close();
}

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  get f() { return this.insuredDetailForm.get; }
  onFileChange1(event) {
    this.myFileInput.nativeElement.value = '';
  }
  //------------------------------------------ FOR DOCUMENTS UPLOAD (SINGLE)----------------------------------------------//
  onFileChange(event, docName, FiledName, files: FileList) {


    this.docNameType = FiledName;

    if (this.docNameType == 'reg_Card_Front') {
      this.showLoader.reg_card_front = true;
    }

    if (this.docNameType == 'reg_Card_Back') {
      this.showLoader.reg_card_back = true;
    }

    if (this.docNameType == 'emirated_ID_Front') {
      this.showLoader.emirates_Id_front = true;
    }

    if (this.docNameType == 'emirated_ID_Back') {
      this.showLoader.emirates_Id_back = true;
    }

    if (this.docNameType == 'driving_Lic_Front') {
      this.showLoader.driving_Lic_front = true;
    }

    if (this.docNameType == 'driving_Lic_Back') {
      this.showLoader.driving_Lic_back = true;
    }

    if (this.docNameType == 'supporting_Document') {
      this.showLoader.supporting_Document = true;
    }

    if (this.docNameType == 'trade_Licence') {
      this.showLoader.trade_Licence = true;
    }

    if (this.docNameType == 'TRN_Certificate') {
      this.showLoader.TRN_Certificate = true;
    }

    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('docName', docName);
    formData.append('source', 'B2B');
    formData.append('stage', 'QUOTE');
    formData.append('schemeCode', this.SchemeCode);
    // Array.from(files).forEach(f => formData.append('file', f))

    this.motorQuoteService.uploadDocuments(formData).subscribe(res => {
      // console.log(res);
      let updateMemResponse = res;
      this.document_data = updateMemResponse.Document_data;


      if (updateMemResponse.res_code == 1) {

        this.showLoader.reg_card_front = false;
        this.showLoader.reg_card_back = false;
        this.showLoader.emirates_Id_front = false;
        this.showLoader.emirates_Id_back = false;
        this.showLoader.driving_Lic_front = false;
        this.showLoader.driving_Lic_back = false;
        this.showLoader.supporting_Document = false;
        this.showLoader.trade_Licence = false;
        this.showLoader.TRN_Certificate = false;

        let fileType = updateMemResponse.File.split(".");
        fileType = fileType[fileType.length - 1];
        fileType = fileType == "pdf" ? "PDF" : "IMG";


        let formArrayValue: any = this.insuredDetailForm.value;


        formArrayValue[FiledName] = updateMemResponse.File;
        formArrayValue[FiledName + "FilePath"] = updateMemResponse.FileDir;
        let tempDocumentArray = {
          file_name: FiledName,
          file_dir: updateMemResponse.FileDir,
          docName: updateMemResponse.File,
        }


        if (FiledName == 'reg_Card_Front') {
          this.hideImages.reg_card_front = true;
          this.insuredDetailForm.get('reg_Card_FrontFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('reg_Card_Front')?.setValue(updateMemResponse.File);
          this.insuredDetailForm.get('reg_Card_FrontFileType')?.setValue(fileType);
          this.tempDocArray[1] = tempDocumentArray;
        }
        if (FiledName == 'reg_Card_Back') {
          this.hideImages.reg_card_back = true;
          this.insuredDetailForm.get('reg_Card_BackFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('reg_Card_BackFileType')?.setValue(fileType);
          this.tempDocArray[0] = tempDocumentArray;
        }
        if (FiledName == 'emirated_ID_Front') {
          this.hideImages.emirates_Id_front = true;
          this.insuredDetailForm.get('emirated_ID_FrontFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('emirated_ID_FrontFileType')?.setValue(fileType);
          this.tempDocArray[2] = tempDocumentArray;
        }
        if (FiledName == 'emirated_ID_Back') {
          this.hideImages.emirates_Id_back = true;
          this.insuredDetailForm.get('emirated_ID_BackFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('emirated_ID_BackFileType')?.setValue(fileType);
          this.tempDocArray[3] = tempDocumentArray;
        }
        if (FiledName == 'driving_Lic_Front') {
          this.hideImages.driving_Lic_front = true;
          this.insuredDetailForm.get('driving_Lic_FrontFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('driving_Lic_FrontFileType')?.setValue(fileType);
          this.tempDocArray[4] = tempDocumentArray;
        }

        if (FiledName == 'driving_Lic_Back') {
          this.hideImages.driving_Lic_back = true;
          this.insuredDetailForm.get('driving_Lic_BackFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('driving_Lic_BackFileType')?.setValue(fileType);
          this.tempDocArray[5] = tempDocumentArray;
        }

        if (FiledName == 'supporting_Document') {
          this.hideImages.supporting_Document = true;
          this.insuredDetailForm.get('supporting_DocumentFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('supporting_DocumentFileType')?.setValue(fileType);
          this.tempDocArray[6] = tempDocumentArray;
        }

        if (FiledName == 'trade_Licence') {
          this.hideImages.trade_Licence = true;
     
          this.insuredDetailForm.get('trade_LicenceFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('trade_LicenceFileType')?.setValue(fileType);
          this.tempDocArray[7] = tempDocumentArray;
        }

        if (FiledName == 'TRN_Certificate') {
          this.hideImages.TRN_Certificate = true;
          this.insuredDetailForm.get('TRN_CertificateFilePath')?.setValue(updateMemResponse.FileDir);
          this.insuredDetailForm.get('TRN_CertificateFileType')?.setValue(fileType);
          this.tempDocArray[8] = tempDocumentArray;
        }

        if (fileType == "pdf") {
          formArrayValue[FiledName + "FileType"] = "PDF";
        } else {
          formArrayValue[FiledName + "FileType"] = "IMG";
        }
        formArrayValue["docRegCardFront"] = "";
        formArrayValue['docRegCardBack'] = "";
        formArrayValue["docEmiratedIdFront"] = "";
        formArrayValue['docEmiratedIdBack'] = "";
        formArrayValue["docDrivingLicFront"] = "";
        formArrayValue["docDrivingLicBack"] = "";
        formArrayValue["docSupporting"] = "";
        formArrayValue["docTradeLicence"] = "";
        formArrayValue["docTRNCertificate"] = "";

        if (this.document_data.Errocode == 106) {
          if (FiledName == 'reg_Card_Front') {

            this.hideImages.reg_card_front = false;
          }
          if (FiledName == 'reg_Card_Back') {
            this.hideImages.reg_card_back = false;
          }
          if (FiledName == 'emirated_ID_Front') {
            this.hideImages.emirates_Id_front = false;
          }
          if (FiledName == 'emirated_ID_Back') {
            this.hideImages.emirates_Id_back = false;
          }
          if (FiledName == 'driving_Lic_Front') {
            this.hideImages.driving_Lic_front = false;
          }
          if (FiledName == 'driving_Lic_back') {
            this.hideImages.driving_Lic_back = false;
          }
          if (FiledName == 'supporting_Document') {
            this.hideImages.supporting_Document = false;
          }
          if (FiledName == 'trade_Licence') {
            this.hideImages.trade_Licence = false;
          }
          if (FiledName == 'TRN_Certificate') {
            this.hideImages.TRN_Certificate = false;
          }

        //  Swal.fire("", this.document_data.ErrorDescription, "error");
        // Invalid document type selected or the document resolution is very low to read the data. Please upload another clean copy and try. Sorry for the inconvenience.
            Swal.fire("Invalid document type selected or the document resolution is very low to read the data.","Please upload another clean copy and try. Sorry for the inconvenience.", "error");
            return false;
        }

        if (this.document_data.DocumentType == 'Emirates-Id' && this.document_data.DocumentSubType == 'Front') {

          this.getEmiratesIdData(1, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Emirates-Id' && this.document_data.DocumentSubType == 'Back') {

          this.getEmiratesIdData(2, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Driving License' && this.document_data.DocumentSubType == 'Front') {

          this.getDrivingLicData(1, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Driving License' && this.document_data.DocumentSubType == 'Back') {

          this.getDrivingLicData(2, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Vehicle License' && this.document_data.DocumentSubType == 'Back') {

          this.insuredDetailForm.get('rg_vhcl_make')?.setValue('');
          this.insuredDetailForm.get('rg_vhcl_model')?.setValue('');
          this.insuredDetailForm.get('adtnl_detail_trim')?.setValue('');
          this.insuredDetailForm.get('adtnl_detail_bodyType')?.setValue('');

          if(updateMemResponse.vechile_data.VehicleDetails){

          if(updateMemResponse.vechile_data.length>0)
          this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;

          this.getRegCardData(1, this.document_data); }
        }
        else if (this.document_data.DocumentType == 'Vehicle License' && this.document_data.DocumentSubType == 'Front') {

          this.getRegCardData(2, this.document_data);
        }

        else if (this.document_data.DocumentType == 'Vehicle License' && this.document_data.DocumentSubType == 'Both') {
            if(updateMemResponse.vechile_data.length>0)
              this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
              this.getRegCardData(1, this.document_data);
              this.getRegCardData(2, this.document_data);
        }

        else if (this.document_data.DocumentType == 'Driving License' && this.document_data.DocumentSubType == 'Both') {

              this.getDrivingLicData(1, this.document_data);
              this.getDrivingLicData(2, this.document_data);
        }

        else if (this.document_data.DocumentType == 'Emirates-Id' && this.document_data.DocumentSubType == 'Both') {

              this.getEmiratesIdData(1, this.document_data);
              this.getEmiratesIdData(2, this.document_data);
        }

        else if(this.document_data.DocumentType == 'Other-Document'){
          if(updateMemResponse.vechile_data.length>0)
          this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
          this.getRegCardData(1, this.document_data);
        }


      }

      if (updateMemResponse.response_code == 5) {

        this.showLoader.reg_card_front = false;
        this.showLoader.reg_card_back = false;
        this.showLoader.emirates_Id_front = false;
        this.showLoader.emirates_Id_back = false;
        this.showLoader.driving_Lic_front = false;
        this.showLoader.driving_Lic_back = false;
        this.showLoader.supporting_Document = false;
        this.showLoader.trade_Licence = false;
        this.showLoader.TRN_Certificate = false;

        Swal.fire("Please select valid file format.", "only .pdf, .jpg, .png and .jpeg file formats allowed.", 'error');

      }

      if (updateMemResponse.response_code == 6) {
        this.showLoader.reg_card_front = false;
        this.showLoader.reg_card_back = false;
        this.showLoader.emirates_Id_front = false;
        this.showLoader.emirates_Id_back = false;
        this.showLoader.driving_Lic_front = false;
        this.showLoader.driving_Lic_back = false;
        this.showLoader.supporting_Document = false;
        this.showLoader.trade_Licence = false;
        this.showLoader.TRN_Certificate = false;

        Swal.fire(updateMemResponse.response_status);
      }



      setTimeout(() => {
        this.onModelChange = true;
      }, 30000);
      this.onFileChange1(event)
    });
  }
//-------------------------------------------- MULTIPLE DOCUMENTS ---------------------------------------//
async uploadMultipleDocuments(event) {

        this.showLoader.multipleDoc = true;

    this.multilpleFile = [];
    for (var i = 0; i < event.target.files.length; i++) {
      this.showLoader.multipleDoc = true;
      const formData = new FormData();
      formData.append('file', event.target.files[i]);
      formData.append('stage', 'QUOTE');
      formData.append('schemeCode', this.SchemeCode);

      this.motorQuoteService.uploadMultipleDocuments(formData).subscribe(res => {

        let updateMemResponse = res;
        this.document_data = updateMemResponse.Document_data;


        this.hideImages.multipleDoc = true;

        if (updateMemResponse.res_code == 1) {
          let fileType = updateMemResponse.File.split(".");
          fileType = fileType[fileType.length - 1];
          fileType = fileType == "pdf" ? "PDF" : "IMG";


          this.multilpleFile.push({
            "file": updateMemResponse.FileDir,
            "fileType": fileType,
            'file_name': 'Other',
            'file_dir': updateMemResponse.FileDir,
            'docName': updateMemResponse.File,
          });

          this.tempMultipleDocData = this.multilpleFile;

            this.showLoader.multipleDoc = false;

          // this.document_data.forEach((item, index) => {

          //   if (item.ErroCode == 'Null') {

          //     if (item.DocumentType == 'Emirates-Id' && (item.DocumentSubType == 'Front' || item.DocumentSubType == 'Front_Old'|| item.DocumentSubType == 'Front_New')) {

          //       this.getEmiratesIdData(1, item);
          //     }
          //     else if (item.DocumentType == 'Emirates-Id' && (item.DocumentSubType == 'Back' || item.DocumentSubType == 'Back_Old' || item.DocumentSubType == 'Back_New')) {

          //       this.getEmiratesIdData(2, item);
          //     }
          //     else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Front') {

          //       this.getDrivingLicData(1, item);
          //     }
          //     else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Back') {

          //       this.getDrivingLicData(2, item);
          //     }
          //     else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Back') {

          //         console.log(updateMemResponse.vechile_data);
          //       if(updateMemResponse.vechile_data){
          //       this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
          //        this.updateValuation_new();

          //       }


          //       // if(item["Chassis No"].length < 17 || item["Chassis No"] == '' || item["Chassis No"] == 'Not Found'){
          //       //   //

          //       // }else{
          //       this.getRegCardData(1, item);
          //       //}

          //     }
          //     else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Front') {

          //       this.getRegCardData(2, item);
          //     }
          //     else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Both') {
          //       this.getRegCardData(2, item);
          //       if(updateMemResponse.vechile_data.length>0)
          //       this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
          //       this.getRegCardData(1, item);
          //     }
          //     else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Both') {
          //       this.getDrivingLicData(2, item);
          //       this.getDrivingLicData(1, item);
          //     }
          //     else if (item.DocumentType == 'Emirates-Id' && item.DocumentSubType == 'Both') {
          //       this.getEmiratesIdData(2, item);
          //       this.getEmiratesIdData(1, item);
          //     }
          //   }
          // });
        }
        if (updateMemResponse.response_code == 5) {

          this.showLoader.multipleDoc = false;

          Swal.fire("Please select valid file format.", "only .pdf, .jpg, .png and .jpeg file formats allowed.", 'error');

        }

        if (updateMemResponse.response_code == 6) {

          this.showLoader.multipleDoc = false;

          Swal.fire(updateMemResponse.response_status);
        }


            // console.log((event.target.files.length-1),i);



      });
      //await this.sleep(10000);
    }
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

//------------------------------------------- UPLOAD ADDITIONAL DOCUMENTS ---------------------------------//
  uploadAdditionalDoc(event) {

    this.showLoader.additionalDoc = true;

    this.additionalDocFile = [];
  for (var i = 0; i < event.target.files.length; i++) {

    const formData = new FormData();
    formData.append('file', event.target.files[i]);
    formData.append('stage', 'QUOTE_ADDINFO');
    formData.append('quotation_number', this.webQuoteNumber);

    this.motorQuoteService.uploadMultipleDocuments(formData).subscribe(res => {

    let updateMemResponse = res;
    this.document_data = updateMemResponse.Document_data;


    this.hideImages.additionalDoc = true;

    return false ;

    if (updateMemResponse.res_code == 1) {
      let fileType = updateMemResponse.File.split(".");
      fileType = fileType[fileType.length - 1];
      fileType = fileType == "pdf" ? "PDF" : "IMG";


      this.additionalDocFile.push({
        "file": updateMemResponse.FileDir,
        "fileType": fileType,
        'file_name': 'Additional_Doc',
        'file_dir': updateMemResponse.FileDir,
        'docName': updateMemResponse.File,
      });

      this.tempAdditionalDoc = this.additionalDocFile;

        this.showLoader.additionalDoc = false;

    }
    if (updateMemResponse.response_code == 5) {

        this.showLoader.additionalDoc = false;
        Swal.fire("Please select valid file format.", "only .pdf, .jpg, .png and .jpeg file formats allowed.", 'error');

    }

    if (updateMemResponse.response_code == 6) {

        this.showLoader.additionalDoc = false;
        Swal.fire(updateMemResponse.response_status);
    }

  });
}
}


  getRegCardData(type, docData) {
    // console.log("--- debug 1---");
    if (type == 1) {
      this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;

      if (this.document_data.Data['Chassis No.'] == "Not Found" || this.vehicleData?.StatusCode == 422) {
        this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
        this.insuredDetailForm.get('isChassisValidate')?.setValue('');


      } else {
        this.checkChassisValidation = true;
        this.insuredDetailForm.get('rg_chassis_num')?.setValue(this.document_data.Data['Chassis No.'].replaceAll("O","0").replaceAll("I","1"));
        this.insuredDetailForm.get('isChassisValidate')?.setValue('1');

      }

        //GCC
        //console.log(this.vehicleData);
        if(this.vehicleData) this.GCC_Specification = this.vehicleData?.General.Region;
        if(this.vehicleData?.General.Region != null && this.vehicleData?.General.Region != ''){
                 let gcc_specification = this.vehicleData?.General.Region == 'GCC' ? 'No' : 'Yes';
                 this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue(gcc_specification);
        }else{
              this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue('No');
        }
        this.GCC.edata = true;
      if (this.document_data.Data['G. V. W.'] == "Not Found") {
        this.insuredDetailForm.get('rg_gvm')?.setValue('');
      } else {
        this.insuredDetailForm.get('rg_gvm')?.setValue(this.document_data.Data['G. V. W.']);
      }

      let enginNumber = this.document_data.Data['Eng. No.'];
      this.insuredDetailForm.get('rg_engin_num')?.setValue(enginNumber.trim());

      this.nofDoors = this.vehicleData?.General.NoOfDoors;
      //this.insuredDetailForm.get('rg_vhcl_model')?.setValue(this.document_data.Data['Expiry Date']);

      this.fileUploadFlag = true;
      //Model year
      let modelYear = this.vehicleData?.General.ModelYear;
      var indexMYear = this.vehimodelyrs.findIndex(function (obj, k) {
        return obj.label === modelYear;
      });
      let yearVal = this.vehimodelyrs[indexMYear];
      // console.log(yearVal);
      this.insuredDetailForm.get('rg_model_year')?.setValue(yearVal);


      this.chnageData.rg_vhcl_make = this.vehicleData?.General.Make;

      this.getVhclMakeData(this.vehicleData?.General.Make, yearVal, 2);

      //NO OF PAASENGER
      let numOfPass = this.vehicleData?.General.NoOfSeats;
      var iPassenger = this.vehiseatcaps.findIndex(function (obj, k) {
        return obj.viewValue == (numOfPass - 1);
      });

      let passengerVal = this.vehiseatcaps[iPassenger];
      // console.log(passengerVal)
      this.insuredDetailForm.get('rg_num_passenger')?.setValue(passengerVal);

      //ORIGIN
      let origin = this.document_data.Data['Origin'];
      var indexOrin = this.countryArr.findIndex(function (obj, k) {
        return obj.CountryName === origin;
      });
      let originVal = this.countryArr[indexOrin];
      this.insuredDetailForm.get('rg_origin')?.setValue(originVal);

      //cylinders

      let cylVal;
      this.vehicylinders.forEach((item, index) => {

        if (item.Id == this.vehicleData?.Technical.EngineCylinders) {
          cylVal = item;
        }
      });

      this.insuredDetailForm.get('adtnl_detail_cylinder')?.setValue(cylVal);


    }


    if (type == 2) {

      this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;

      let dateExp: string = this.document_data.Data['Exp. Date'];
      dateExp = dateExp.replace(/-/gi, "/");
      let dateReg: string = this.document_data.Data['Reg. Date'];
      dateReg = dateReg.replace(/-/gi, "/");
      let dateInsp: string = this.document_data.Data['Ins. Exp.'];
      dateInsp = dateInsp.replace(/-/gi, "/");
      let strTCNum: string = this.document_data.Data['T. C. No.'];

      // if (this.document_data.Data['Exp. Date'] != "Not Found")
      //   this.insuredDetailForm.get('rg_expiry_date')?.setValue(this.dateConvert(dateExp));
      // else {
      //   this.insuredDetailForm.get('rg_expiry_date')?.setValue('');
      // }

      if (this.document_data.Data['Ins. Exp.'] != "Not Found")
        this.insuredDetailForm.get('rg_ins_exp')?.setValue(this.dateConvert(dateInsp));
      else {
        this.insuredDetailForm.get('rg_ins_exp')?.setValue('');
      }

      if (this.document_data.Data['Reg. Date'] != "Not Found")
        this.insuredDetailForm.get('rg_reg_date')?.setValue(this.dateConvert(dateReg));
      else {
        this.insuredDetailForm.get('rg_reg_date')?.setValue('');
      }

      this.insuredDetailForm.get('rg_policy_num')?.setValue(this.document_data.Data['Policy No.']);

      this.insuredDetailForm.get('rg_TC_num')?.setValue(this.document_data.Data['T. C. No.']);
      this.insuredDetailForm.get('rg_traffic_plate_num')?.setValue(this.document_data.Data['Traffic Plate No.']);

      if (this.insuredDetailForm.value.d_TC_number == '') {
        this.insuredDetailForm.get('d_TC_number')?.setValue(this.insuredDetailForm.value.rg_TC_num);
      }

      let plate_code_array = this.document_data.Data['Traffic Plate No.'].split('/');

      //Mortgage Bank
      if (this.document_data.Data['Mortgage By'] == "Not Found") {
        this.insuredDetailForm.get('rg_mortgage')?.setValue('');

      } else {
        let mBank = this.document_data.Data['Mortgage By'];
        var indexBank = this.bankDetail.findIndex(function (obj, k) {
          return obj.InstituteName.toLowerCase() === mBank.toLowerCase();
        });
        let bankVal = this.bankDetail[indexBank];
        this.insuredDetailForm.get('rg_mortgage')?.setValue(bankVal);
      }
      //REG PLACE
      let regPlace = this.document_data.Data['Place of Issue'];
      this.plate_code = this.document_data.Data['Plate_code'] != "" ? this.document_data.Data['Plate_code'] : plate_code_array[0];

      if (strTCNum.length == 8) {
        var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
          return obj.CityName === 'Dubai';
        });
        let placelVal = this.cityArr[indexRegPlace];
        this.insuredDetailForm.get('rg_place_issue')?.setValue(placelVal);
        this.getPlateCode(placelVal.CityName, 3);
      } else if (this.document_data.Data['Place of Issue'] != 'Not Found' && strTCNum.length != 8) {
        var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
          return obj.CityName.toLowerCase() === regPlace.toLowerCase();
        });
        let placelVal = this.cityArr[indexRegPlace];
        this.insuredDetailForm.get('rg_place_issue')?.setValue(placelVal);
        this.getPlateCode(placelVal.CityName, 3);
      } else {
        this.insuredDetailForm.get('rg_place_issue')?.setValue('');
      }

      //REG TyPE == PLATE CATEGORY
      if (this.document_data.Data['Registration Type'] == "Not Found" || this.document_data.Data['Registration Type'] == null || this.document_data.Data['Registration Type'] == '') {
        this.insuredDetailForm.get('rg_type')?.setValue('');

      } else {
        let regType = this.document_data.Data['Registration Type'];
        var indexRegType = this.plateCatArray.findIndex(function (obj, k) {
          return obj.value.toLowerCase() === regType.toLowerCase();
        });
        let typelVal = this.plateCatArray[indexRegType];
        this.insuredDetailForm.get('rg_type')?.setValue(typelVal.value);

        this.insuredDetailForm.get('e_name')?.setValue(this.document_data.Data['Owner']);
        

      }


    }
    // let yearVal = this.vehimodelyrs[indexMYear];
    // this.insuredDetailForm.get('rg_model_year')?.setValue(yearVal);

    // this.chnageData.rg_vhcl_make = this.vehicleData?.General.Make;

    // this.getVhclMakeData(this.vehicleData?.General.Make, yearVal, 2);

  }

  getDrivingLicData(type, docData) {
    if (type == 1) {

      this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;

      let dateDob: string = this.document_data.Data['Date of Birth'];
      dateDob = dateDob.replace(/-/gi, "/");
      let dateIssue: string = this.document_data.Data['Issue Date'];
      dateIssue = dateIssue.replace(/-/gi, "/");
      let dateExp: string = this.document_data.Data['Expiry Date'];
      dateExp = dateExp.replace(/-/gi, "/");

      if (this.document_data.Data['License No.'] != 'Not Found') {
        this.insuredDetailForm.get('d_driv_lic_num')?.setValue(this.document_data.Data['License No.']);
      } else {
        this.insuredDetailForm.get('d_driv_lic_num')?.setValue('');
      }


      // else {
      //     this.insuredDetailForm.get('d_dob')?.setValue('');
      // }



      if (this.document_data.Data['Issue Date'] != "Not Found")
        this.insuredDetailForm.get('d_issue_date')?.setValue(this.dateConvert(dateIssue));
      else {
        this.insuredDetailForm.get('d_issue_date')?.setValue('');
      }


      if (this.document_data.Data['Expiry Date'] != "Not Found")
        this.insuredDetailForm.get('d_expiry_date')?.setValue(this.dateConvert(dateExp));
      else {
        this.insuredDetailForm.get('d_expiry_date')?.setValue('');
      }


      // Driving Reg. Place
      let regPlace = this.document_data.Data['Place of Issue'];
      if(regPlace != 'Not Found' && regPlace !='' && regPlace != null){
            var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
              return obj.CityName.toLowerCase() === regPlace.toLowerCase();
            });
            let placelVal = this.cityArr[indexRegPlace];
            this.insuredDetailForm.get('d_place_issue')?.setValue(placelVal);
            this.getIssuePlace(placelVal.CityName);
      }


       // 11 - 02 -2021 : If emirates id file not uploaded then name should be taken from driving lic file
        if(this.insuredDetailForm.value.e_name == ''){
              if(this.document_data.Data['Name'] == "Not Found" ){
                      this.insuredDetailForm.get('e_name')?.setValue('');
              }else{
                      this.insuredDetailForm.get('e_name')?.setValue(this.document_data.Data['Name']);
              }
        }
        if(this.insuredDetailForm.value.e_nationality == ''){
              // Nationality
              let nationality = this.document_data.Data['Nationality'];
              var indexNationality = this.countryArr.findIndex(function (obj, k) {
                return obj.CountryName === nationality;
              });
              let nationalVal = this.countryArr[indexNationality];
              this.insuredDetailForm.get('e_nationality')?.setValue(nationalVal);

        }
        if(this.insuredDetailForm.value.d_dob == ''){
          //  if(this.document_data.Data['Date of Birth'] != "Not Found" && this.insuredDetailForm.value.d_dob == '')
          if(this.document_data.Data['Date of Birth'] != "Not Found"){

              let DOB = dateDob.split("/");
              let driverAge = this.calculateAge(DOB[0],DOB[1],DOB[2]);
              // console.log(driverAge);
                  if(driverAge>=18 && driverAge<=80)
                  this.insuredDetailForm.get('d_dob')?.setValue(this.dateConvert(dateDob));
          }
      }
        // if(this.insuredDetailForm.value.d_dob == ''){
        //       if(this.document_data.Data['Date of Birth'] != "Not Found" && this.insuredDetailForm.value.d_dob == '')
        //             this.insuredDetailForm.get('d_dob')?.setValue(this.dateConvert(dateDob));
        // }



    }
    // if (type == 2) {
    //   this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;

    //   let licType = this.document_data.Data['Permitted Vehicles'][0].Type;



    //   this.insuredDetailForm.get('d_lic_type')?.setValue(licType);

    //   if (this.document_data.Data['Traffic Code No.'] != 'Not Found') {
    //     this.insuredDetailForm.get('d_TC_number')?.setValue(this.document_data.Data['Traffic Code No.'].trim());
    //   } else {
    //     this.insuredDetailForm.get('d_TC_number')?.setValue('');
    //   }

    // }


  }


  getEmiratesIdData(type, docData) {

    if (type == 1) {

      this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;

      // if(this.document_data.Data['ID Number']=="Not Found" && this.document_data.Data['ID-NumberInArabic']!=''){ alert(1);
      //   this.motorQuoteService.translateInEnglish(this.document_data.Data['ID-NumberInArabic']).subscribe(res => {

      //   });
      // }

      this.insuredDetailForm.get('e_arabic_name')?.setValue(this.document_data.Data['NameInArabic']);

      if (this.document_data.Data['ID Number'] == "Not Found") {
            this.insuredDetailForm.get('e_eid')?.setValue('');
      } else{
              this.insuredDetailForm.get('e_eid')?.setValue(this.document_data.Data['ID Number'].replaceAll("-",""));
      }

      if(this.document_data.Data['Name'] == "Not Found" ){

        this.insuredDetailForm.get('e_name')?.setValue('');

     } else{  this.insuredDetailForm.get('e_name')?.setValue(this.document_data.Data['Name']);  }


      // Nationality
      let nationality = this.document_data.Data['Nationality'];
      var indexNationality = this.countryArr.findIndex(function (obj, k) {

        return obj.CountryName === nationality;
      });
      let nationalVal = this.countryArr[indexNationality];
      this.insuredDetailForm.get('e_nationality')?.setValue(nationalVal);

      

    }

    if (type == 2) {
      this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;

      let dateDob: string = this.document_data.Data['Date of Birth'];
      dateDob = dateDob.replace(/-/gi, "/");

      let dateExp: string = this.document_data.Data['Expiry Date'];
      dateExp = dateExp.replace(/-/gi, "/");

      this.insuredDetailForm.get('e_cardNumber')?.setValue(this.document_data.Data['Card Number']);
      this.insuredDetailForm.get('e_expiryDate')?.setValue(this.dateConvert(dateExp));

      let gender = this.document_data.Data['Sex']
      //Gender
      var indexGender = this.genders.findIndex(function (obj, k) {
        return obj.value === gender;
      });
      let gnderVal = this.genders[indexGender];
      this.insuredDetailForm.get('e_gender')?.setValue(gnderVal);

      if (this.document_data.Data['Date of Birth'] != "Not Found" && this.document_data.Data['Date of Birth'] != ""){
        // console.log("Debug = ",this.document_data.Data['Date of Birth']);
        this.insuredDetailForm.get('d_dob')?.setValue(this.dateConvert(dateDob));


      }
        

    }



  }

  dateConvert(inputFormat) {
// console.log(inputFormat)
    let vDOEntryArray = inputFormat.split('/');
    let DOEntry = new Date();
    DOEntry.setDate(vDOEntryArray[0]);
    DOEntry.setMonth(vDOEntryArray[1] - 1);
    DOEntry.setFullYear(vDOEntryArray[2]);

    return DOEntry;

  }

  checkTermsCond() {
    this.accept_terms = !this.accept_terms;
  }


  closeImg(type) {
    if (type == 1) {
      this.hideImages.reg_card_front = false;
      this.insuredDetailForm.get('reg_Card_Front')?.setValue('');
      this.insuredDetailForm.get('reg_Card_FrontFilePath')?.setValue('');
      this.insuredDetailForm.get('rg_model_year')?.setValue('');
      this.insuredDetailForm.get('rg_num_passenger')?.setValue('');
      this.insuredDetailForm.get('rg_origin')?.setValue('');
      this.insuredDetailForm.get('rg_vhcl_make')?.setValue('');
      this.insuredDetailForm.get('rg_vhcl_model')?.setValue('');
      this.insuredDetailForm.get('rg_gvm')?.setValue('');
      this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
      this.insuredDetailForm.get('rg_engin_num')?.setValue('');
      this.insuredDetailForm.get('adtnl_detail_cylinder')?.setValue('');


    }
    if (type == 2) {
      this.hideImages.reg_card_back = false;

      this.insuredDetailForm.get('reg_Card_Back')?.setValue('');
      this.insuredDetailForm.get('reg_Card_BackFilePath')?.setValue('');
      this.insuredDetailForm.get('rg_traffic_plate_num')?.setValue('');
      this.insuredDetailForm.get('rg_place_issue')?.setValue('');
      this.insuredDetailForm.get('rg_TC_num')?.setValue('');
      this.insuredDetailForm.get('rg_type')?.setValue('');
    //  this.insuredDetailForm.get('rg_expiry_date')?.setValue('');
      this.insuredDetailForm.get('rg_reg_date')?.setValue('');
      this.insuredDetailForm.get('rg_ins_exp')?.setValue('');
      this.insuredDetailForm.get('rg_policy_num')?.setValue('');
      this.insuredDetailForm.get('rg_mortgage')?.setValue('');

    }
    if (type == 3) {
      this.hideImages.emirates_Id_front = false;
      this.insuredDetailForm.get('emirated_ID_Front')?.setValue('');
      this.insuredDetailForm.get('emirated_ID_FrontFilePath')?.setValue('');
      this.insuredDetailForm.get('e_eid')?.setValue('');
      this.insuredDetailForm.get('e_name')?.setValue('');
      this.insuredDetailForm.get('e_nationality')?.setValue('');
    }
    if (type == 4) {
      this.hideImages.emirates_Id_back = false;
      this.insuredDetailForm.get('emirated_ID_Back')?.setValue('');
      this.insuredDetailForm.get('emirated_ID_BackFilePath')?.setValue('');
      this.insuredDetailForm.get('e_cardNumber')?.setValue('');
      this.insuredDetailForm.get('e_expiryDate')?.setValue('');
      this.insuredDetailForm.get('e_gender')?.setValue('');
    }
    if (type == 5) {
      this.hideImages.driving_Lic_front = false;
      this.insuredDetailForm.get('driving_Lic_Front')?.setValue('');
      this.insuredDetailForm.get('driving_Lic_FrontFilePath')?.setValue('');
      this.insuredDetailForm.get('d_driv_lic_num')?.setValue('');
      this.insuredDetailForm.get('d_dob')?.setValue('');
      this.insuredDetailForm.get('d_issue_date')?.setValue('');
      this.insuredDetailForm.get('d_expiry_date')?.setValue('');
      this.insuredDetailForm.get('d_place_issue')?.setValue('');
    }

    if (type == 6) {
      this.hideImages.driving_Lic_back = false;
      this.insuredDetailForm.get('driving_Lic_Back')?.setValue('');
      this.insuredDetailForm.get('driving_Lic_BackFilePath')?.setValue('');
      this.insuredDetailForm.get('d_TC_number')?.setValue('');
      this.insuredDetailForm.get('d_lic_type')?.setValue('');
    }

    if (type == 7) {
      this.hideImages.multipleDoc = false;
      this.multilpleFile = [];
    }





  }
  //--------------------------------- GET ALL FORM DROPDOWN DATA -----------------------------
  // getAllFormData() {
  //   let error = false;

  // //  let promise = new Promise((resolve,reject)=> {
  // //         setTimeout(() => {
  // //           if (error){
  // //               reject('error');
  // //           }else {
  // //             resolve('Done');
  //               this.motorQuoteService.getAllFormData('COMPREHENSIVE').subscribe(res => {
  //                 // console.log("Async Work Complete");
  //                 this.cityArr = res.cityData;

  //                 // var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
  //                 //   return obj.CityName === 'Dubai';
  //                 // });
  //                 // let placelVal = this.cityArr[indexRegPlace];
  //                 // this.insuredDetailForm.get('rg_place_issue')?.setValue(placelVal);

  //                 this.vhclColorArr = res.vehicleColorsData;

  //                 this.filteredVchColor.next(this.vhclColorArr.slice());
  //                 this.countryArr = res.countryData;

  //                 // this.insuredDetailForm.get("licIssueContry")?.setValue(this.countryArr[32]);
  //                 this.filteredCountries.next(this.countryArr.slice());

  //                 res.PlateCategory.forEach((item, index) => {
  //                   this.plateCatArray.push(item);
  //                 })
  //                 this.filteredPlateCat.next(this.plateCatArray.slice());

  //                 // this.insuredDetailForm.get("nationality")?.setValue(this.countryArr[32]);
  //                 this.filteredNationCountries.next(this.countryArr.slice());
  //                 console.log( this.filteredNationCountries)
  //                 console.log(  this.filteredNationCountries.next(this.countryArr.slice()))

  //               });

  //               this.motorQuoteService.getBankDetail().subscribe(res => {

  //                 this.bankDetail = res.bankdetailsData;
  //                 this.filteredBank.next(this.bankDetail.slice());



  //               });

  //               this.getVhclNCD();
  //          // }



  // //         }, 1000);

  // //         return promise;
  // //  })

  //   // promise.then(
  //   //   () => this.getVhclNCD(),
  //   //   (err) => console.error(err)
  //   // );

  // }

  async getAllFormData() {
    let error = false;

  //  let promise = new Promise((resolve,reject)=> {
  //         setTimeout(() => {
  //           if (error){
  //               reject('error');
  //           }else {
  //             resolve('Done');
                this.motorQuoteService.getDropdownData('COMPREHENSIVE', '0', this.language_code, this.country,'').subscribe(res => {
                  // console.log("Async Work Complete");
                  this.cityArr = res.cityData;

                  // var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
                  //   return obj.CityName === 'Dubai';
                  // });
                  // let placelVal = this.cityArr[indexRegPlace];
                  // this.insuredDetailForm.get('rg_place_issue')?.setValue(placelVal);

                  this.vhclColorArr = res.vehicleColorsData;

                  this.filteredVchColor.next(this.vhclColorArr.slice());
                  this.countryArr = res.countryData;
                  // console.log(res.countryData)
                  // this.insuredDetailForm.get("licIssueContry")?.setValue(this.countryArr[32]);
                  this.filteredCountries.next(this.countryArr.slice());

                  res.PlateCategory.forEach((item, index) => {
                    this.plateCatArray.push(item);
                  })
                  this.filteredPlateCat.next(this.plateCatArray.slice());

                  

                  // this.insuredDetailForm.get("nationality")?.setValue(this.countryArr[32]);
                  this.filteredNationCountries.next(this.countryArr.slice());
                  // console.log(1111)
                  // console.log(this.filteredNationCountries.next(this.countryArr.slice()))

                });

                this.motorQuoteService.getBankDetail().subscribe(res => {

                 

                  let newArray:any = [ { CRS_Bank_Map_Code: "",   Id: 0 ,    InstituteCode: null ,   InstituteName: "" }] ;
                  this.bankDetail  = newArray.concat(res.bankdetailsData);
                  
                    this.filteredBank.next(this.bankDetail.slice());

                });

                this.getVhclNCD();
           
  }



  //------------------------------ GET VEHICLE NCD ---------------------------------------------
  getVhclNCD() {
        this.motorQuoteService.getVehicleNcd(this.language_code, 'MOTOR').subscribe(res => {
          this.NCDData = res.vechileNCDData;

        
        });
  }

  //---------------------------------- GET INDUSTRY TYPE --------------------------------------------------------//
  getIndustryTypes(){
        this.motorQuoteService.getIndustryTypes('MT').subscribe(res => {
                this.industryTypeArr = res.industries;
               
                this.industryTypeFilter.next(this.industryTypeArr.slice());
                // console.log(this.industryTypeFilter);
        });
  }
  //------------------------------ GET VEHICLE MAKE DATA ---------------------------------//
  async getVhclMakeData(vhcleMake, year, type) {
  // alert(1)
  if(!this.isUpdateValuation) return false ;
  if(!this.SchemeCodeClick) return false ;
  if(this.isClickChassisValidate) return false ;
  if(!year) return ;
    this.showLoader.vhclMake = true;
    let makeValue = '';

    this.insuredDetailForm.get("adtnl_detail_brandNew").setValue(0);
      this.checkBrandNew();
// console.log("------------------------------------------");
      this.regMinDate = new Date(year.value-2, 0, 1);
      // console.log(this.regMinDate);
      
      
      let currDate = new Date();
      if(Number(year.value)+2 >=currDate.getFullYear())
        {
          this.regMaxDate = new Date();
            
        }else
        this.regMaxDate = new Date(year.value+2, 31, 11);
        // console.log(this.regMaxDate);
    if(this.insuredDetailForm.value.adtnl_detail_insType){

      makeValue = this.insuredDetailForm.value.adtnl_detail_insType.ProductShortName;
    }
    this.insuredDetailForm.get("adtnl_detail_brandNew").setValue("0");
    this.motorQuoteService.getVhclMake(makeValue, this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue, this.language_code,  year.value, this.SchemeCode).subscribe(res => {

     this.checkEngineValidation();
      this.checkTrimValidation();

      this.vhclMakeArr = res.vechileMakeValuesData;
      // console.log( this.vhclMakeArr);
      this.showLoader.vhclMake = false;

        if ((type == 2 || type == 1) && typeof (this.vhclMakeArr) != undefined && typeof (this.vhclMakeArr) != "undefined") {
          //VEHICLE Make ----- filter
          let makeVal;
          this.vhclMakeArr.forEach((item, index) => {
            if (item.VehicleMakeName == vhcleMake) {
              makeVal = item;
            }
          });
          this.modelId= makeVal.VehicleMakeId;
          this.insuredDetailForm.get('rg_vhcl_make')?.setValue(makeVal);


          if (type == 2)
            this.getVhclModel(makeVal.VehicleMakeId, 2, year);
          else
            this.getVhclModel(makeVal.VehicleMakeId, 1, year);
        }

        if (type == 3 && typeof (this.vhclMakeArr) != undefined && typeof (this.vhclMakeArr) != "undefined") {
          //VEHICLE Make ----- filter
          let makeVal;
          this.vhclMakeArr.forEach((item, index) => {
            if (item.VehicleMakeName == vhcleMake) {
              makeVal = item;
            }
          });

          this.insuredDetailForm.get('rg_vhcl_make')?.setValue(makeVal);
          this.chassis_No_Details.General.Make = makeVal.VehicleMakeId;
          this.getVhclModel(makeVal.VehicleMakeId, 3, year);
        }

          if (res.response_code == 1) {
            // this.onVehiclAgeChange(year);
            this.filteredMakes.next(this.vhclMakeArr.slice());
          }
          this.showLoader.vhclMake = false;
          this.onVehiclAgeChange(this.insuredDetailForm.value.rg_model_year);
      });


     this.onVehiclAgeChange(this.insuredDetailForm.value.rg_model_year);
  }

    //------------------------------ GET VEHICLE MAKE DATA ---------------------------------//
  async getVhclMakeDataByRetrive(respData) {
      // alert(1)
       let year = respData.VehicleModelYear ;
       let vhcleMake = respData.VehicleMake ;
       let type  = 1 ;
        this.showLoader.vhclMake = true;
      
        this.motorQuoteService.getVhclMake(respData.CurrentInsurance,
                                           respData.InsuredType, 
                                           this.language_code,
                                           respData.VehicleModelYear, 
                                           this.SchemeCode).subscribe(res => {
    
    
    
          this.vhclMakeArr = res.vechileMakeValuesData;
          // console.log( this.vhclMakeArr);
          this.showLoader.vhclMake = false;
    
            if ((type == 2 || type == 1) && typeof (this.vhclMakeArr) != undefined && typeof (this.vhclMakeArr) != "undefined") {
              //VEHICLE Make ----- filter
              let makeVal;
              this.vhclMakeArr.forEach((item, index) => {
                if (item.VehicleMakeName == vhcleMake) {
                  makeVal = item;
                }
              });
              this.modelId= makeVal.VehicleMakeId;
              this.insuredDetailForm.get('rg_vhcl_make')?.setValue(makeVal);
    
              //  console.log("Get make value : ",makeVal.VehicleMakeId);
              if (type == 2)
                this.getVhclModel(makeVal.VehicleMakeId, 2, year);
              else
                this.getVhclModel(makeVal.VehicleMakeId, 1, year);
            }
    
            if (type == 3 && typeof (this.vhclMakeArr) != undefined && typeof (this.vhclMakeArr) != "undefined") {
              //VEHICLE Make ----- filter
              let makeVal;
              this.vhclMakeArr.forEach((item, index) => {
                if (item.VehicleMakeName == vhcleMake) {
                  makeVal = item;
                }
              });
    
              this.insuredDetailForm.get('rg_vhcl_make')?.setValue(makeVal);
              this.chassis_No_Details.General.Make = makeVal.VehicleMakeId;
              this.getVhclModel(makeVal.VehicleMakeId, 3, year);
            }
    
              if (res.response_code == 1) {
                // this.onVehiclAgeChange(year);
                this.filteredMakes.next(this.vhclMakeArr.slice());
              }
              this.showLoader.vhclMake = false;
              this.onVehiclAgeChange(Number(this.insuredDetailForm.value.rg_model_year));
          });
    
      }
    

  //------------------------------ GET VEHICLE MODEL -----------------------------------------
  getVhclModel(vehclMkId, type, year) {

   // this.onVehiclAgeChange(year);

   if(this.isClickChassisValidate)  return false ;  // if validate chassis no called

    if(!year.value){

      year = {value:year};
    }
    this.showLoader.vhclModel = true;

      this.motorQuoteService.getVehicleModel('P', this.insuredDetailForm.value.rg_vhcl_make, this.language_code, null, year.value,this.sideForm.value.schemeCode).subscribe(res => {
        // console.log(res);

        this.vhclModelArr = res.vechileModelData;
        if (res.response_code == 1) {

          this.filteredModels.next(this.vhclModelArr.slice()); // FOr ng select search
        }
        // console.log("debug 001 ",this.vehicleData);
        if ((type == 2 || type == 1) && typeof (this.vhclModelArr) != undefined && typeof (this.vhclModelArr) != "undefined") {

          let trim = this.vehicleData?.General?.Trim? this.vehicleData?.General.Trim : this.quoteDetail?.TrimCode;
          let model = this.vehicleData?.General?.Model? this.vehicleData?.General.Model : this.quoteDetail?.VehicleModel;

          
          let ModalName = (vehclMkId == 34 || vehclMkId == 7) ? trim : model;

          var indexModel = this.vhclModelArr.findIndex(function (obj, k) {

            return obj.VehicleModelName === ModalName;
          });
          let modelVal = this.vhclModelArr[indexModel];

          if(indexModel !==-1){
              this.insuredDetailForm.get('rg_vhcl_model')?.setValue(modelVal);
              if (type == 2)
                this.getMotorBodyType(modelVal.VehicleModelId, 2, year, modelVal.VehicleModelName);
              else
                this.getMotorBodyType(modelVal.VehicleModelId, 1, year, modelVal.VehicleModelName);
              }
            }

        if (type == 3 && typeof (this.vhclModelArr) != undefined && typeof (this.vhclModelArr) != "undefined") {

          let ModalName = (this.chassis_No_Details.General.Make == 34 || this.chassis_No_Details.General.Make == 7) ? this.chassis_No_Details.General.Trim : this.chassis_No_Details.General.Model;

            if(ModalName != '' && ModalName != null){
                  var indexModel = this.vhclModelArr.findIndex(function (obj, k) {
                    return obj.VehicleModelName === ModalName;
                  });
                  let modelVal = this.vhclModelArr[indexModel];
                  this.insuredDetailForm.get('rg_vhcl_model')?.setValue(modelVal);
                  this.getMotorBodyType(modelVal.VehicleModelId, 3, year, modelVal.VehicleModelName);
              }

        }
        this.showLoader.vhclModel = false;

        var d = new Date(this.insuredDetailForm.value.rg_reg_date);
        let firstRegYear: number = d.getFullYear();

        var p = new Date(this.insuredDetailForm.value.polStartDate);
        let policyStartDateYear: number = p.getFullYear();
        let vhclYear = this.insuredDetailForm.value.rg_model_year;

        let timeDiff = Math.abs(this.insuredDetailForm.value.rg_reg_date - this.insuredDetailForm.value.polStartDate);
        let days_difference =  Math.floor(timeDiff / (1000 * 60 * 60 * 24));

        let  D1 = Math.ceil(1 + (days_difference/397)); //this will give you years
        let  D2 = (Number(policyStartDateYear) - Number(vhclYear.value)) + 1;
        let vehicle_age = Math.max(D2,D1);
        let D3 = Math.abs(D2 - D1);
        if(D3 == 1){
            vehicle_age = D1;
        }
        else{
            vehicle_age = Math.max(D2,D1);
        }

        if (vehicle_age >= 5) {
          if ((this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName == "BMW" || this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName == "MINI") && this.SchemeCode == '104') {

          } else {

         //   this.insuredDetailForm.get('adtnl_detail_repairTye')?.setValue(this.repairtypes[0]);

          }
        }
      });

  }


  getVhclModel2(vehclMkId, type, year, vhclmodel) {

    // this.onVehiclAgeChange(year);

     this.showLoader.vhclModel = true;

       this.motorQuoteService.getVehicleModel('P', this.insuredDetailForm.value.rg_vhcl_make, this.language_code, null, year.value,this.sideForm.value.schemCode).subscribe(res => {

         this.vhclModelArr = res.vechileModelData;
         if (res.response_code == 1) {

           this.filteredModels.next(this.vhclModelArr.slice()); // FOr ng select search
         }

         if ((type == 2 || type == 1) && typeof (this.vhclModelArr) != undefined && typeof (this.vhclModelArr) != "undefined") {


           var indexModel = this.vhclModelArr.findIndex(function (obj, k) {

             return obj.VehicleModelName === vhclmodel;
           });
           let modelVal = this.vhclModelArr[indexModel];
//  console.log(modelVal)
           this.insuredDetailForm.get('rg_vhcl_model')?.setValue(modelVal);
           if (type == 2)
             this.getMotorBodyType(modelVal.VehicleModelId, 2, year, modelVal.VehicleModelName);
           else
             this.getMotorBodyType(modelVal.VehicleModelId, 1, year, modelVal.VehicleModelName);
         }

         if (type == 3 && typeof (this.vhclModelArr) != undefined && typeof (this.vhclModelArr) != "undefined") {

           let ModalName = (this.chassis_No_Details.General.Make == 34 || this.chassis_No_Details.General.Make == 7) ? this.chassis_No_Details.General.Trim : this.chassis_No_Details.General.Model;

             if(ModalName != '' && ModalName != null){
                   var indexModel = this.vhclModelArr.findIndex(function (obj, k) {
                     return obj.VehicleModelName === ModalName;
                   });
                   let modelVal = this.vhclModelArr[indexModel];

                   if(indexModel!=-1){
                   this.insuredDetailForm.get('rg_vhcl_model')?.setValue(modelVal);
                   this.getMotorBodyType(modelVal.VehicleModelId, 3, year, modelVal.VehicleModelName);
                   }
               }

         }
         this.showLoader.vhclModel = false;

         var d = new Date(this.insuredDetailForm.value.rg_reg_date);
         let firstRegYear: number = d.getFullYear();

         var p = new Date(this.insuredDetailForm.value.polStartDate);
         let policyStartDateYear: number = p.getFullYear();
         let vhclYear = this.insuredDetailForm.value.rg_model_year;

         let timeDiff = Math.abs(this.insuredDetailForm.value.rg_reg_date - this.insuredDetailForm.value.polStartDate);
         let days_difference =  Math.floor(timeDiff / (1000 * 60 * 60 * 24));

         let  D1 = Math.ceil(1 + (days_difference/397)); //this will give you years
         let  D2 = (Number(policyStartDateYear) - Number(vhclYear.value)) + 1;
         let vehicle_age = Math.max(D2,D1);
         let D3 = Math.abs(D2 - D1);
         if(D3 == 1){
             vehicle_age = D1;
         }
         else{
             vehicle_age = Math.max(D2,D1);
         }

         if (vehicle_age >= 5) {
           if ((this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName == "BMW" || this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName == "MINI") && this.SchemeCode == '104') {

           } else {

        //     this.insuredDetailForm.get('adtnl_detail_repairTye')?.setValue(this.repairtypes[0]);

           }
         }
       });

   }


  //------------------------------- GET MOTOR BODY TYPE AND VEHICLE SPECIFICATION------------------------------------------
  getMotorBodyType(vhclModelId, type, year, modelName) {
    
    if(this.isClickChassisValidate)  return false ;  // if validate chassis no called
    if (typeof (vhclModelId) == "undefined" || typeof (vhclModelId) == undefined) return false;

    this.showLoader.vhclTrim = true;
    this.showLoader.vhclBodyType = true;

    this.motorQuoteService.getMotorBodyType(this.insuredDetailForm.value.adtnl_detail_insType.viewValue, this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue, vhclModelId, this.language_code, year.value, modelName).subscribe(res => {

      this.vhclBodyTypeArr = res.vechileMotoBodyTypeData;
     //this.vehitrims = res.vechilesSpecificationData;



      if (res.response_code == 1 || res.response_code == 2) {
        this.showLoader.vhclTrim = false;
        this.showLoader.vhclBodyType = false;
      }

      if ((type == 2 || type == 1) && typeof (this.vhclBodyTypeArr) != undefined && typeof (this.vhclBodyTypeArr) != "undefined") {

        //VEHICLE TRIM
        let trimName = this.vehicleData?.General?.Trim? this.vehicleData.General.Trim: this.quoteDetail?.TrimName;
        let bodyType = this.vehicleData?.General?.BodyType? this.vehicleData?.General.BodyType : this.quoteDetail?.BodyType;
        // if(this.vehicleData?.General.Trim == null){

        // }
        // else{
          
        

          //BODY TYPE
         
          var indexbodyType = this.vhclBodyTypeArr.findIndex(function (obj, k) {
            return obj.BodyTypeName === bodyType;
          });
          let bdTyVal = this.vhclBodyTypeArr[indexbodyType];
         
          this.insuredDetailForm.get('adtnl_detail_bodyType')?.setValue(bdTyVal);


          var indexTrim = this.vehitrims.findIndex(function (obj, k) {
            return obj.Name === trimName;
          });

          let trimVal = this.vehitrims[indexTrim];
          // console.log(trimVal)
          this.insuredDetailForm.get('adtnl_detail_trim')?.setValue(trimVal); 
         
      }

      if (type == 3 && typeof (this.vhclBodyTypeArr) != undefined && typeof (this.vhclBodyTypeArr) != "undefined") {
        //VEHICLE TRIM ------- not given

        let trimName = this.chassis_No_Details.General.Trim + " " + "-" + " " + this.chassis_No_Details.Technical.EngineDisplacementNominal.Value.trim;
        let bodyType = this.chassis_No_Details.General.BodyType;

        var indexTrim = this.vehitrims.findIndex(function (obj, k) {
          return obj.VehicleSpecName === trimName;
        });

        let trimVal = this.vehitrims[indexTrim];
      //  this.insuredDetailForm.get('adtnl_detail_trim')?.setValue(trimVal);

        //BODY TYPE
        var indexbodyType = this.vhclBodyTypeArr.findIndex(function (obj, k) {
          return obj.BodyTypeName === bodyType;
        });
        let bdTyVal = this.vhclBodyTypeArr[indexbodyType];
        this.insuredDetailForm.get('adtnl_detail_bodyType')?.setValue(bdTyVal);
      }
    
    });

  }

  /************** Country Filter */

  private filterCountry() {
    if (!this.countryArr) {
      return;
    }
    // get the search keyword
    let search = this.country1FilterCtrl.value;
    if (!search) {
      this.filteredCountries.next(this.countryArr.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredCountries.next(
      this.countryArr.filter(bank => bank.CountryName.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterNationalCountry() {
    if (!this.countryArr) {
      return;
    }
    // get the search keyword
    let search = this.nationalFilterCtrl.value;
    if (!search) {
      this.filteredNationCountries.next(this.countryArr.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredNationCountries.next(
      this.countryArr.filter(bank => bank.CountryName.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterOccupation(){

    if (!this.occupatindata) {
      return;
    }
    // console.log(this.occupatindata)
    // get the search keyword
    let search = this.occupationFilterCtrl.value;
    if (!search) {
      this.OccupationTypeFilter.next(this.occupatindata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.OccupationTypeFilter.next(
      this.occupatindata.filter(bank => bank.OccupationName.toLowerCase().indexOf(search) > -1)
    );

  }

  private industryfilter() {
    if (!this.industryTypeArr) {
      return;
    }
   
    // get the search keyword
    let search = this.industryFilterCtrl.value;
    if (!search) {
      this.industryTypeFilter.next(this.industryTypeArr.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    // console.log(this.industryTypeArr);
    this.industryTypeFilter.next(
      this.industryTypeArr.filter(bank => bank.IndustryName.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterMortageBank() {
    if (!this.bankDetail) {
      return;
    }

    // get the search keyword
    let search = this.mortageBankFilterCtrl.value;

    if (!search) {
      this.filteredBank.next(this.bankDetail.slice());
      return;
    } else {
      search = search.toLowerCase();
    }


    // filter the banks
    this.filteredBank.next(
      this.bankDetail.filter(bank => bank.InstituteName.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterVechColor() {
    if (!this.vhclColorArr) {
      return;
    }

    // get the search keyword
    let search = this.vchColorFilterCtrl.value;
    if (!search) {
      this.filteredVchColor.next(this.vhclColorArr.slice());
      return;
    } else {
      search = search.toLowerCase();
    }


    // filter the banks
    this.filteredVchColor.next(
      this.vhclColorArr.filter(bank => bank.ColorName.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterPlateCat() {
    if (!this.plateCatArray) {
      return;
    }

    // get the search keyword
    let search = this.plateFilterCtrl.value;
    if (!search) {
      this.filteredPlateCat.next(this.plateCatArray.slice());
      return;
    } else {
      search = search.toLowerCase();
    }


    // filter the banks
    this.filteredPlateCat.next(
      this.plateCatArray.filter(bank => bank.label.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterCode() {
    if (!this.codes) {
      return;
    }

    // get the search keyword
    let search = this.codeFilterCtrl.value;
    if (!search) {
      this.filteredCode.next(this.codes.slice());
      return;
    } else {
      search = search.toLowerCase();
    }


    // filter the banks
    this.filteredCode.next(
      this.codes.filter(bank => bank.viewValue.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterYear() {
    if (!this.vehimodelyrs) {
      return;
    }

    // get the search keyword
    let search = this.yearFilterCtrl.value;
    if (!search) {
      this.filteredYears.next(this.vehimodelyrs.slice());
      return;
    } else {
      search = search.toLowerCase();
    }

    // filter the banks
    this.filteredYears.next(
      this.vehimodelyrs.filter(bank => bank.label.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterMake() {
    if (!this.vhclMakeArr) {
      return;
    }
    // get the search keyword
    let search = this.makeFilterCtrl.value;
    if (!search) {
      this.filteredMakes.next(this.vhclMakeArr.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredMakes.next(
      this.vhclMakeArr.filter(bank => bank.VehicleMakeName.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterModel() {
    if (!this.vhclModelArr) {
      return;
    }
    // get the search keyword
    let search = this.modelFilterCtrl.value;
    if (!search) {
      this.filteredModels.next(this.vhclModelArr.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredModels.next(
      this.vhclModelArr.filter(bank => bank.VehicleModelName.toLowerCase().indexOf(search) > -1)
    );
  }

  //----------- CONVERT DATE INTO DD/MM/YYYY FORMAT ------------//
  convertDate(inputFormat) {
    // let vDOEntryArray = inputFormat.split('/');
    // let DOEntry = new Date();
    // DOEntry.setDate(vDOEntryArray[0]);
    // DOEntry.setMonth(vDOEntryArray[1] - 1);
    // DOEntry.setFullYear(vDOEntryArray[2]);
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat);
    return ([ d.getFullYear(),pad(d.getMonth()+1),pad(d.getDate())].join('-'));
    return ([pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('-'));

  }

  convertStartDate(inputFormat){
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat);
    //return ([ d.getFullYear(),pad(d.getMonth()+1),pad(d.getDate())].join('-'));
    return ([pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/'));

  }

  //----------------------------------------VALIDATION FOR AGE ------------------------------------------------//
  lic_issue_min ;
  calucateLicIssueDate(inputData, type) {
    // console.log(inputData); 
    const d =     new Date( inputData);
    
    this.lic_issue_min = new Date(new Date(d).setDate(365*18));
  }
  calculateAge(birthMonth, birthDay, birthYear) {
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var currentMonth = currentDate.getMonth();
    var currentDay = currentDate.getDate(); 
    var calculatedAge = currentYear - birthYear;
  
    if (currentMonth < birthMonth - 1) {
        calculatedAge--;
    }
    if (birthMonth - 1 == currentMonth && currentDay < birthDay) {
        calculatedAge--;
    }
    return calculatedAge;
  }
  validateDOBYear(){

 
    // console.log(this.insuredDetailForm.value.d_dob);
    let d =     new Date( this.insuredDetailForm.value.d_dob);
    if(this.webQuoteNumber == ''){
      this.dobYr = this.insuredDetailForm.value.e_eid.toString().replace(/-/g, "").substring(0, 4);
    }
    else if(this.webQuoteNumber != ''){
      this.dobYr = this.insuredDetailForm.value.e_eid.toString().replace(/-/g, "").substring(3, 7);
    }
    // let dobYr = this.insuredDetailForm.value.e_eid.replace(/-/g, "").substring(3,7);
    let licIssueDate= new Date( this.insuredDetailForm.value.d_issue_date);
    let difference = (licIssueDate.getTime() - d.getTime());
    var ageInYears=difference/(1000*60*60*24*365);
    // console.log(d.getFullYear()+"=="+dobYr);
    if(d.getFullYear()!=this.dobYr){
  
      Swal.fire("","DOB is not matching with Emirates Id. Please verify.","warning");
      this.stepper.previous();
      return false ;
    } else{
  
        if(ageInYears<18){
        Swal.fire("","Invalid licence issue date selected. Please verify.","warning");
       this.stepper.previous();
       return  false ;
        }else
         return true ;
    
    }
  
  }
  calucateAge(inputData, type) {
   // console.log((new Date(inputData).getDate());
 //  policyMaxDate = new Date(new Date().setDate(new Date().getDate() + 30));


    // console.log(this.lic_issue_min);
      if (inputData != '') {
          let timeDiff = Math.abs(Date.now() - inputData);
          if (type == 1) {
              return Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
          }

          if (type == 2) {
              return Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
          }
      } else {
          return '';
      }
  }
  //------------------------------------ GET QUOTATION ---------------------------------------------//

   noFoundQuote = '' ;
   contrinutionData = { "ODPremium": 0,"TPPremium":0}
  getQuotation(stepper, type) {
    
    // if(this.multiGap.length==0) { Swal.fire("Please upload supporting document."); stepper.previous(); return false ; }
   

    // let modifyValue = this.existVehiclevalue == 1 ? this.existVehiclevalue:null;
   // let dob = this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.code == '100' ? this.convertDate(this.insuredDetailForm.value.d_dob) : '';
  
   //let vehicle_value = this.insuredDetailForm.value.adtnl_detail_insType.value == 100 ? this.insuredDetailForm.value.adtnl_detail_vhclValue : 0;

   if (this.convertDate(this.insuredDetailForm.value.rg_ins_exp) < this.convertDate(this.policyMinDate)) {

    let isFilealreadyUploaded =  false ;

    this.multilpleFile.forEach((item,index)=>{

      if(item?.DocumentType =='supporting_Document_GAP') { isFilealreadyUploaded = true ;

      }
    })

    if (isFilealreadyUploaded==false && this.multiGap.length == 0) { Swal.fire("Please upload supporting document."); stepper.previous(); return false; }

  }


  let vehicle_value =this.insuredDetailForm.value.v_value.value;
    let brand_new = (this.insuredDetailForm.value.rg_model_year.value != this.maxYear || this.insuredDetailForm.value.rg_model_year.value != this.year || this.insuredDetailForm.value.rg_model_year.value != this.minyear) ? { code: '0', value: 'N' } : { code: '1', value: 'Y' };
    let vehicleType = this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.code == '100' ? { code: '1001', value: 'Private' } : { code: '1001', value: 'Private' };
    // let policy_expire_date = this.insuredDetailForm.value.vhclTPLCoverage == 'No' ? this.nextDate : this.PrevDate;
    let policy_expire_date = this.convertDate(this.insuredDetailForm.value.rg_ins_exp);
    let emiratesId = this.insuredDetailForm.value.e_eid.replace(/-/gi, "");
   // var sCode = "ALL";
    let policy_status =  'RENEWAL' ;
    if(!this.validateDOBYear())  return false ;
    let modifyValue = this.existVehiclevalue == 1 ? this.existVehiclevalue:null;
    let repairType = this.insuredDetailForm.value.adtnl_detail_insType.value == 100 ? this.insuredDetailForm.value.adtnl_detail_repairTye : { value: 'Garage', viewValue: 'Garage' };
    // if (this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName == "BMW" || this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName == "MINI") {
    //   if (this.SchemeCode == "104")
    //     sCode = "104";
    // }
    // else if (this.SchemeCode == "104") {
    //   sCode = "ALL";
    // }
    let PrevpolExpDate = this.quoteDetail.PreviousPolExpDate ;
    let motorArrayQuote = {

       // cedant_broker_id:this.quickquoteinfo.value.partner,
      //  broker_branch_id:this.quickquoteinfo.value.branch,
      
      motor_quote_type:"FULLQUOTE",
       product_code: this.insuredDetailForm.value.adtnl_detail_insType.ProductCode,
       cedant_broker_id:this.sideForm.value.partnerID,
      broker_branch_id:this.sideForm.value.branchID,
      insured_type: this.insuredDetailForm.value.adtnl_detail_vhclOwnBy,
      insured_name: this.insuredDetailForm.value.e_name,
      gender: this.insuredDetailForm.value.e_gender,
      dob: this.convertDate(this.insuredDetailForm.value.d_dob),
      prospect_age: this.calucateAge(this.insuredDetailForm.value.d_dob, 1),
      nationality: this.insuredDetailForm.value.e_nationality,
      email: this.insuredDetailForm.value.adtnl_detail_email,
      mobile: this.insuredDetailForm.value.adtnl_detail_mobile,
      code: this.insuredDetailForm.value.adtnl_detail_mbCode,
      UAE_lic_age: this.convertDate(this.insuredDetailForm.value.d_issue_date),
      UAELicAge: this.calucateAge(this.insuredDetailForm.value.d_issue_date, 2),
      license_country: this.insuredDetailForm.value.e_nationality,
      NCD: this.insuredDetailForm.value.adtnl_detail_NCD,
      NCDPerc: this.insuredDetailForm.value.adtnl_detail_NCD_Perc,
      model_year: this.insuredDetailForm.value.rg_model_year,
      make: this.insuredDetailForm.value.rg_vhcl_make,
      model: this.insuredDetailForm.value.rg_vhcl_model,
      trim: this.insuredDetailForm.value.adtnl_detail_trim,
      body_type: this.insuredDetailForm.value.adtnl_detail_bodyType,
      engineSize: this.insuredDetailForm.value.adtnl_detail_engine,
      cylinders: this.insuredDetailForm.value.adtnl_detail_cylinder,
      passenger: this.insuredDetailForm.value.rg_num_passenger,
      registered_date: this.convertDate(this.insuredDetailForm.value.rg_reg_date),
      GCCSpecified: this.insuredDetailForm.value.adtnl_detail_gccSpecified,
      vhclModified: this.insuredDetailForm.value.adtnl_detail_vhclModified,
      registered_place: this.insuredDetailForm.value.rg_place_issue,
      chassis_no: this.insuredDetailForm.value.rg_chassis_num,
      repair_type: repairType,
      sum_insured:this.insuredDetailForm.value.v_value,
      emirates_id: emiratesId,
      policy_type: this.insuredDetailForm.value.adtnl_detail_insType,
      ExistingCover: this.insuredDetailForm.value.vhclTPLCoverage,
      policy_expire_date: this.convertDate(policy_expire_date),
      brand_new: brand_new,
      customer_id: "0",
      lead_id: "0",
      NCD_docs: "No",
      registration_type: vehicleType,
      VEHENGINESIZE: '1',
      source: 'B2B',
      document_data: this.tempDocArray,
      multiple_doc_data: this.tempMultipleDocData,
      GVM: this.insuredDetailForm.value.rg_gvm,
      origin: this.insuredDetailForm.value.rg_origin,
      policy_num: this.insuredDetailForm.value.rg_policy_num,
      eid_card_num: this.insuredDetailForm.value.e_cardNumber,
      reg_ins_exp_date: this.convertDate(this.insuredDetailForm.value.rg_ins_exp),
    //  reg_exp_date: this.convertDate(this.insuredDetailForm.value.rg_expiry_date),
      eid_exp_date: this.convertDate(this.insuredDetailForm.value.e_expiryDate),
      driv_lic_issue_date: this.convertDate(this.insuredDetailForm.value.d_issue_date),
      driv_lic_exp_date: this.convertDate(this.insuredDetailForm.value.d_expiry_date),
      driv_lic_issuePlace: this.insuredDetailForm.value.d_place_issue,
      name_in_arabic: this.insuredDetailForm.value.e_arabic_name,
      traffic_code: this.insuredDetailForm.value.rg_TC_num,
      license: this.insuredDetailForm.value.d_driv_lic_num,
      mortgage: this.insuredDetailForm.value.rg_mortgage,
      plate_number: this.insuredDetailForm.value.rg_traffic_plate_num,
      plate_code: this.insuredDetailForm.value.rg_plateCode,
      plate_category: this.insuredDetailForm.value.rg_type,
      driv_lic_TC_number: this.insuredDetailForm.value.d_TC_number,
      driv_lic_type: this.insuredDetailForm.value.d_lic_type,
      vehicleColor: this.insuredDetailForm.value.vhclColor,
      RepairType:this.insuredDetailForm.value.adtnl_detail_repairTye.RepairType,
      SchemeCode: this.sideForm.value.schemeCode,
      modifiedVhclValue: modifyValue,
      start_date: this.convertStartDate(this.insuredDetailForm.value.polStartDate),
      policy_status : policy_status,
      deductible_value : this.insuredDetailForm.value.deductible,
      TRN_number : this.insuredDetailForm.value.TRN_num,
      trade_Lic_number : this.insuredDetailForm.value.trade_lic_num,
      industry_type : this.insuredDetailForm.value.industry_type,
      transaction_type : this.insuredDetailForm.value.transaction_type.label,
      branchID : this.sideForm.value.branchID,
      isBrandNew:0,
      prev_policy_number: this.Search_policy.value.policy_no,
      isTaxReg: this.insuredDetailForm.value.vat_register
      

    };
    // console.log(motorArrayQuote)


    var gender = "";
    if(this.insuredDetailForm.value.e_gender){
      gender =  this.insuredDetailForm.value.e_gender.value;

    }

    let policyDetail = {
      
      quotation_number: this.webQuoteNumber,
      CRS_quotation_number: this.quoteNumber,
      traffic_code: this.insuredDetailForm.value.rg_TC_num,
      license: this.insuredDetailForm.value.d_driv_lic_num,
      emirates: this.insuredDetailForm.value.rg_place_issue,
      address: this.insuredDetailForm.value.adtnl_detail_address,
      PO_box: this.insuredDetailForm.value.adtnl_detail_poBoxNum,
      occupation: '',
      national_id: this.insuredDetailForm.value.e_eid,
      arabic_name:this.insuredDetailForm.value.e_arabic_name,
      home_office_number: '',
      start_date: this.convertDate(this.insuredDetailForm.value.polStartDate),
      end_date: '15/07/2022',
      color: '',
      chassis_no: this.insuredDetailForm.value.rg_chassis_num,
      engine: this.insuredDetailForm.value.rg_engin_num,
      plate: '54687',
      mortgage: this.insuredDetailForm.value.rg_mortgage,
      payment_mode: 'ONLINE',
      named_driver: this.insuredDetailForm.value.e_name,
      additional_driver_under_age: '0',
      IP_address: '',
      mobile: this.insuredDetailForm.value.adtnl_detail_mobile,
      code: this.insuredDetailForm.value.adtnl_detail_mbCode,
      driving_License_Front: this.insuredDetailForm.value.driving_Lic_Front,
      driving_license_Back: '',
      Reg_Card_Front: this.insuredDetailForm.value.reg_Card_Front,
      Reg_Card_Back: this.insuredDetailForm.value.reg_Card_Back,
      EID_Front: this.insuredDetailForm.value.emirated_ID_Front,
      EID_Back: this.insuredDetailForm.value.emirated_ID_Backk,
      dealer_quote: '',
      vhclPlateCategory:  this.insuredDetailForm.value.rg_type,
      plateCode: this.insuredDetailForm.value.rg_plateCode,
      plateNumber: this.insuredDetailForm.value.rg_traffic_plate_num,
      area: this.insuredDetailForm.value.adtnl_detail_area,
      noOfDoors: this.nofDoors,
      gender: gender,
      nationality: this.insuredDetailForm.value.e_nationality,
      source :'B2B',
      promocode:this.insuredDetailForm.value.promoCode,
      vat_tl_location:this.insuredDetailForm.value.vat_tl_location,
      po_box_number:this.insuredDetailForm.value.po_box_number,
      po_box_location:this.insuredDetailForm.value.po_box_location,
      driver_occupation:this.insuredDetailForm.value.driver_occupation,
      mileage:this.insuredDetailForm.value.mileage,
      weight_empty:this.insuredDetailForm.value.weight_empty,
      weight_full:this.insuredDetailForm.value.weight_full,
      rg_noOfDoor:this.insuredDetailForm.value.rg_noOfDoor,
      multiGap:this.multiGap


    }


    this.showLoader.referal = true;
    this.quoteDetailArr = motorArrayQuote;
    this.emailId = this.insuredDetailForm.value.adtnl_detail_email;
    this.payLink_email = this.insuredDetailForm.value.adtnl_detail_email;
  


    this.motorQuoteService.insertQuoterenewal(motorArrayQuote,policyDetail,this.userId,this.partnerId,this.cedantId,this.branchId).subscribe(res => {
      this.responsedata = res
      // if (res.response_code == 6){
      //   Swal.fire("", res.reason, "error");
      //   stepper.previous();
      // }
    //   if (type != 0){
    //     stepper.next();
    // }

    this.prvPremium = res?.calContribution[0]?.PrvYrPremium;
    this.prvSum = res?.calContribution[0]?.PrvYrSumInsured;
    this.PrevpolExpDate = res.PreviousPolExpDate;

    this.webQuoteNumber = res.webQuotationNumber;
    this.quoteNumber = res.webQuotationNumber;
    // if(this.convertDate( this.convertDate(this.insuredDetailForm.value.rg_ins_exp)) <= this.convertDate(this.policyMinDate)){

    //   this.referalStatus = true ;
  
    //   Swal.fire("The policy is already expired and there is gap in insurance. Please refer the quote to DNI Underwriters.","Your quote reference number is " +this.webQuoteNumber,"error");

    //   stepper.previous();

    //   return false ;
    // }


    if(this.responsedata.premium <= 0){
      this.referalStatus = true ;
      //  this.noCreditLimt = 0 ;
      // this.creditLimit = {CreditLimit:0,AvailableLimit:0};
      Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");

        stepper.previous();
   }
    if (!res.BasePremium || !res.premium	) {
      this.webQuoteNumber = res.webQuotationNumber;
      this.quoteNumber = res.webQuotationNumber;
      this.showLoader.Quotation = false;
      this.showLoader.retrieveQuote = false;
      this.referalStatus = true;
      this.referral_reason = res.referral_reason;
   //   this.savePolicyDetail(1);
      Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");

      stepper.previous();
      return false ;
    }
    this.PlanDataJson.planBenefitData.benefit_data = [];
  //  this.showLoader.Quotation = false;
      this.PlanDataJson.planBenefitData.benefit_data = [];
      this.showLoader.retrieveQuote = false;
     // let thirdPartyAPIResponse = res.thirdPartyAPIData.Status.Description.split(("no tariff available").toLowerCase());

     this.showLoader.chasisNoButton = true;
     this.motorQuoteService.validateChassisNumber(this.insuredDetailForm.value.rg_chassis_num,this.partnerId,this.userId,this.sideForm.value.schemeCode,"R").subscribe(resChassis => {
       let validateRes = resChassis;

       if (validateRes.validateChassisNumber == 'W') {
         Swal.fire(validateRes.validateChassisMessage);
        this.showLoader.chasisNoButton = false;

         this.insuredDetailForm.get('isChassisValidate')?.setValue('');
         this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
        // return false;
        stepper.previous();
       }


      //  if(validateRes.validateChassisNumber=="E"){
      //   this.showLoader.chasisNoButton = false;

      //    this.insuredDetailForm.get('isChassisValidate')?.setValue('');
      //    this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
        
      //   Swal.fire(validateRes.validateChassisMessage);
      //   stepper.previous();
      //   return false ;
      // }
    
    else if(validateRes.validateChassisNumber == 'A' || validateRes.validateChassisNumber == 'BOR'){
      this.showLoader.chasisNoButton = false;

      if(validateRes.validateChassisNumber == 'BOR') {
        this.getQuoteNumber =   this.responsedata.webQuotationNumber;
        this.showBor = true;
        // console.log(this.getQuoteNumber);
        stepper.previous();
        Swal.fire(validateRes.validateChassisMessage);
         
  
      }

      this.showLoader.Quotation = false;

      if (res.response_code == 1000){
        const dialogRef = this.dialog.open(this.callAPIDialog);
      }

      if (res.response_code == 0) {
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        Swal.fire("Sorry! Plan not available.", " ", "error");

        stepper.previous();
      }

      else if (res.response_code == 2) {
        this.webQuoteNumber = res.web_quotation_number;
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        this.referalStatus = true;
        this.referral_reason = res.referral_reason;
     //   this.savePolicyDetail(1);
        

     if(this.quoteStatus=="ADDITIONALINFO")
     {
       Swal.fire('Your details have been submitted to our team of UWs for review. ',
         'You will be notified soon after the review. Your Quotation Reference# ' +
           this.webQuoteNumber,
         'warning'
     );

     this._route.navigate(['renewpolicy']);

     } else {
      Swal.fire(
       'Thank you for you request, based on your application details, the case needs to be referred for further review.',
       'An email will be sent to you shortly. If you need further assistance call us at 600 5 80000',
       'warning'
     );

        Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");

        stepper.previous();
      }
     }
      else if (res.response_code == 4) {
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        Swal.fire("", res.thirdPartyAPIData.Status.Description, "error");
        // this.webQuoteNumber = res.web_quotation_number;
        this.referalStatus = true;
        this.referral_reason = res.referral_reason;
     //    this.savePolicyDetail(1);
        stepper.previous();
      }

      else if (res.response_code_ == 400 ||res.response_code == 5) {
            this.showLoader.Quotation = false;
            this.showLoader.retrieveQuote = false;
            // console.log(this.quoteStatus)
         //  console.log(thirdPartyAPIResponse.length)
          // && thirdPartyAPIResponse.length > 1
            if(this.quoteStatus == 'REFERRED' && this.businessSource == 'DIRECT' && this.partnerId == 1 && this.userType == 'POS' && this.userRole == 'TELEMARKETING' ){
                  Swal.fire({
                    title: res.thirdPartyAPIData.Status.Description,
                    text: "Do you want to trigger a referral scheme?",
                    showCancelButton: true,
                    confirmButtonColor: '#3085D6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes'
                  }).then((result) => {
                    if (result.value) {
                      this.SchemeCode = '108';
                      this.referalStatus = false;
                      this.showLoader.Quotation = true;
                      this.showLoader.retrieveQuote = true;
                      this.updateQuotation(stepper,1);
                    }
                    else if (result.dismiss === Swal.DismissReason.cancel) {
                          //Swal.fire("Cancelled", ":)", "error");
                          stepper.previous();
                          return false;
                        }
                  });
            }
              else{
          
                      Swal.fire("", validateRes.validateChassisMessage, "error");
                      // this.webQuoteNumber = res.web_quotation_number;
                      this.referral_reason = res.referral_reason;
                      this.referalStatus = true;
                //      this.savePolicyDetail(1);
                      stepper.previous();
              }

         }
        else if(res.response_code_r == 7){
        // this.webQuoteNumber = res.web_quotation_number_r;
        this.referral_reason = res.response_message_r;
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        this.referalStatus = true;
       //    this.savePolicyDetail(1);
       //  Swal.fire("", res.thirdPartyAPIData.Status.Description, "error");

        stepper.previous();
        }

       else {

        if(this.quoteStatus=="ADDITIONALINFO")
          {
          Swal.fire('Your details have been submitted to our team of UWs for review. ',
            'You will be notified soon after the review. Your Quotation Reference# ' +
              this.webQuoteNumber,
            'warning'
          );

        this._route.navigate(['renewpolicy']);

       }
        // console.log(this.insuredDetailForm.value.adtnl_detail_vhclValue);
        // console.log(this.insuredDetailForm?.value?.adtnl_detail_vhclValue?.value);

        this.disabledStatus=true;
        this.referalStatus = false;
        
        this.contrinutionData = { "ODPremium": this.responsedata.calContribution[0].ODPremium,
        "TPPremium":this.responsedata.calContribution[0].TPPremium }


        this.initial_benefit_data =   this.responsedata?.planBenefitData?.benefit_data;

       // this.policyFee = 1;
        this.policyFee = 0;
        this.totalVariablePremium = 0;
        this.PlanDataJson =   this.responsedata;
        this.totalFixPremium =   this.responsedata.BasePremium;
        this.tempTotalFixPremium =  this.totalFixPremium;
        this.plan_Name = this.PlanDataJson.planBenefitData.data[0].PlanName;
        this.plan_Id = this.PlanDataJson.planBenefitData.data[0].PlanId;
        this.benfPremIdArray = this.PlanDataJson.planBenefitData.data;
        this.webQuoteNumber = this.PlanDataJson.webQuotationNumber;
        this.quoteNumber = this.PlanDataJson.quotationNumber;
        this.tempBenefitData = this.PlanDataJson.planBenefitData.benefit_data;
        // if(type==2){
        //   this.sendRefferMailToAdmin(2);
        // }

        this.premium =   this.responsedata.BasePremium;
       this.showLoader.retrieveQuote = false;

        if(this.webQuoteNumber == '' || this.webQuoteNumber == null){
           stepper.previous();
        }
        this.PlanDataJson?.planBenefitData?.data?.forEach((item, index) => {

          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1) {
            this.mulOption = item.multipleOptionData[0];
            this.PlanDataJson.planBenefitData.data[index].benefitSelectedData = item.multipleOptionData[0];
            this.PlanDataJson.planBenefitData.data[index].multiOptID = item.multipleOptionData[0].BenefitId;
            this.PlanDataJson.planBenefitData.data[index].Price = item.multipleOptionData[0].Price;
            this.PlanDataJson.planBenefitData.data[index].checked = false;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;

          }

          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1) {

            this.PlanDataJson.planBenefitData.data[index].checked = false;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;

          }


        });

        this.checkOptionalBenefit(this.optionalBenefit);

       // let discount = this.PlanDataJson.thirdPartyAPIData.NcdDiscount.NcdPerc / 100;
        this.discount = 0;

       
        if(this.insuredDetailForm.value.adtnl_detail_repairTye.viewValue == 'Premium Garage'){
              this.applyLoadingOnChangeRepairType();
        }

        // console.log("Debug 1");
        this.tempTotalFixPremium = this.totalFixPremium;

        //  this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.tempTotalFixPremium * discount);
        this.totalFixPremium = this.tempTotalFixPremium - this.discount;
        this.totalFixPremium = this.totalFixPremium + this.policyFee;
        this.tempTotalLoadFixPrem = this.totalFixPremium;
        //  console.log("Checking premium");
        this.VATAMT = this.PlanDataJson.vatAMount;
        // console.log(this.PlanDataJson.vatAMount);
        this.vatPer	 = this.PlanDataJson.vatPer/100	;
        this.Total_Primium = this.PlanDataJson.totalPremium + this.totalVariablePremium+this.totalVariablePremium*this.vatPer;
        this.loadingBy = '1';
        this.premium = this.PlanDataJson.premium  - this.discount ;
        if (this.tempTotalFixPremium<=500) {
          stepper.previous();

        }
        // else
            // this.savePolicyDetail(1);
            this.checkAccessForPolicyIssueButtons();
            this.addOptionalBenigits(318,2);
            this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
        
            this.addOptionalBenigits(318,2);
            this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
      }


    }
  });


    });

    this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
  }



  getQuotationRef(stepper, type) {

  

    this.showLoader.refer = true;
    
    // if(this.multiGap.length==0) { Swal.fire("Please upload supporting document."); stepper.previous(); return false ; }
   

    // let modifyValue = this.existVehiclevalue == 1 ? this.existVehiclevalue:null;
   // let dob = this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.code == '100' ? this.convertDate(this.insuredDetailForm.value.d_dob) : '';
  
   //let vehicle_value = this.insuredDetailForm.value.adtnl_detail_insType.value == 100 ? this.insuredDetailForm.value.adtnl_detail_vhclValue : 0;

  //  if (this.viewSupportingDocument.length==0) {
  //   Swal.fire("", "Please upload the supporting documents", 'error');
  //       this.insuredDetailForm.markAllAsTouched();
  //       return false;
  // }

  let vehicle_value =this.insuredDetailForm.value.v_value.value;
    let brand_new = (this.insuredDetailForm.value.rg_model_year.value != this.maxYear || this.insuredDetailForm.value.rg_model_year.value != this.year || this.insuredDetailForm.value.rg_model_year.value != this.minyear) ? { code: '0', value: 'N' } : { code: '1', value: 'Y' };
    let vehicleType = this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.code == '100' ? { code: '1001', value: 'Private' } : { code: '1001', value: 'Private' };
    // let policy_expire_date = this.insuredDetailForm.value.vhclTPLCoverage == 'No' ? this.nextDate : this.PrevDate;
    let policy_expire_date = this.convertDate(this.insuredDetailForm.value.rg_ins_exp);
    let emiratesId = this.insuredDetailForm.value.e_eid.replace(/-/gi, "");
   // var sCode = "ALL";
    let policy_status =  'RENEWAL' ;
    if(!this.validateDOBYear())  return false ;
    let modifyValue = this.existVehiclevalue == 1 ? this.existVehiclevalue:null;
    let repairType = this.insuredDetailForm.value.adtnl_detail_insType.value == 100 ? this.insuredDetailForm.value.adtnl_detail_repairTye : { value: 'Garage', viewValue: 'Garage' };
    // if (this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName == "BMW" || this.insuredDetailForm.value.rg_vhcl_make.VehicleMakeName == "MINI") {
    //   if (this.SchemeCode == "104")
    //     sCode = "104";
    // }
    // else if (this.SchemeCode == "104") {
    //   sCode = "ALL";
    // }
    let PrevpolExpDate = this.quoteDetail.PreviousPolExpDate ;
    let motorArrayQuote = {

       // cedant_broker_id:this.quickquoteinfo.value.partner,
      //  broker_branch_id:this.quickquoteinfo.value.branch,
      
      motor_quote_type:"FULLQUOTE",
       product_code: this.insuredDetailForm.value.adtnl_detail_insType.ProductCode,
       cedant_broker_id:this.sideForm.value.partnerID,
      broker_branch_id:this.sideForm.value.branchID,
      insured_type: this.insuredDetailForm.value.adtnl_detail_vhclOwnBy,
      insured_name: this.insuredDetailForm.value.e_name,
      gender: this.insuredDetailForm.value.e_gender,
      dob: this.convertDate(this.insuredDetailForm.value.d_dob),
      prospect_age: this.calucateAge(this.insuredDetailForm.value.d_dob, 1),
      nationality: this.insuredDetailForm.value.e_nationality,
      email: this.insuredDetailForm.value.adtnl_detail_email,
      mobile: this.insuredDetailForm.value.adtnl_detail_mobile,
      code: this.insuredDetailForm.value.adtnl_detail_mbCode,
      UAE_lic_age: this.convertDate(this.insuredDetailForm.value.d_issue_date),
      UAELicAge: this.calucateAge(this.insuredDetailForm.value.d_issue_date, 2),
      license_country: this.insuredDetailForm.value.e_nationality,
      NCD: this.insuredDetailForm.value.adtnl_detail_NCD,
      NCDPerc: this.insuredDetailForm.value.adtnl_detail_NCD_Perc,
      model_year: this.insuredDetailForm.value.rg_model_year,
      make: this.insuredDetailForm.value.rg_vhcl_make,
      model: this.insuredDetailForm.value.rg_vhcl_model,
      trim: this.insuredDetailForm.value.adtnl_detail_trim,
      body_type: this.insuredDetailForm.value.adtnl_detail_bodyType,
      engineSize: this.insuredDetailForm.value.adtnl_detail_engine,
      cylinders: this.insuredDetailForm.value.adtnl_detail_cylinder,
      passenger: this.insuredDetailForm.value.rg_num_passenger,
      registered_date: this.convertDate(this.insuredDetailForm.value.rg_reg_date),
      GCCSpecified: this.insuredDetailForm.value.adtnl_detail_gccSpecified,
      vhclModified: this.insuredDetailForm.value.adtnl_detail_vhclModified,
      registered_place: this.insuredDetailForm.value.rg_place_issue,
      chassis_no: this.insuredDetailForm.value.rg_chassis_num,
      repair_type: repairType,
      sum_insured:this.insuredDetailForm.value.v_value,
      emirates_id: emiratesId,
      policy_type: this.insuredDetailForm.value.adtnl_detail_insType,
      ExistingCover: this.insuredDetailForm.value.vhclTPLCoverage,
      policy_expire_date: this.convertDate(policy_expire_date),
      brand_new: brand_new,
      customer_id: "0",
      lead_id: "0",
      NCD_docs: "No",
      registration_type: vehicleType,
      VEHENGINESIZE: '1',
      source: 'B2B',
      document_data: this.tempDocArray,
      multiple_doc_data: this.tempMultipleDocData,
      GVM: this.insuredDetailForm.value.rg_gvm,
      origin: this.insuredDetailForm.value.rg_origin,
      policy_num: this.insuredDetailForm.value.rg_policy_num,
      eid_card_num: this.insuredDetailForm.value.e_cardNumber,
      reg_ins_exp_date: this.convertDate(this.insuredDetailForm.value.rg_ins_exp),
    //  reg_exp_date: this.convertDate(this.insuredDetailForm.value.rg_expiry_date),
      eid_exp_date: this.convertDate(this.insuredDetailForm.value.e_expiryDate),
      driv_lic_issue_date: this.convertDate(this.insuredDetailForm.value.d_issue_date),
      driv_lic_exp_date: this.convertDate(this.insuredDetailForm.value.d_expiry_date),
      driv_lic_issuePlace: this.insuredDetailForm.value.d_place_issue,
      name_in_arabic: this.insuredDetailForm.value.e_arabic_name,
      traffic_code: this.insuredDetailForm.value.rg_TC_num,
      license: this.insuredDetailForm.value.d_driv_lic_num,
      mortgage: this.insuredDetailForm.value.rg_mortgage,
      plate_number: this.insuredDetailForm.value.rg_traffic_plate_num,
      plate_code: this.insuredDetailForm.value.rg_plateCode,
      plate_category: this.insuredDetailForm.value.rg_type,
      driv_lic_TC_number: this.insuredDetailForm.value.d_TC_number,
      driv_lic_type: this.insuredDetailForm.value.d_lic_type,
      vehicleColor: this.insuredDetailForm.value.vhclColor,
      RepairType:this.insuredDetailForm.value.adtnl_detail_repairTye.RepairType,
      SchemeCode: this.sideForm.value.schemeCode,
      modifiedVhclValue: modifyValue,
      start_date: this.convertStartDate(this.insuredDetailForm.value.polStartDate),
      policy_status : policy_status,
      deductible_value : this.insuredDetailForm.value.deductible,
      TRN_number : this.insuredDetailForm.value.TRN_num,
      trade_Lic_number : this.insuredDetailForm.value.trade_lic_num,
      industry_type : this.insuredDetailForm.value.industry_type,
      transaction_type : this.insuredDetailForm.value.transaction_type.label,
      branchID : this.sideForm.value.branchID,
      isBrandNew:0,
      prev_policy_number: this.Search_policy.value.policy_no,
      isTaxReg: this.insuredDetailForm.value.vat_register
      

    };
    // console.log(motorArrayQuote)


    var gender = "";
    if(this.insuredDetailForm.value.e_gender){
      gender =  this.insuredDetailForm.value.e_gender.value;

    }

    let policyDetail = {
      
      quotation_number: this.webQuoteNumber,
      CRS_quotation_number: this.quoteNumber,
      traffic_code: this.insuredDetailForm.value.rg_TC_num,
      license: this.insuredDetailForm.value.d_driv_lic_num,
      emirates: this.insuredDetailForm.value.rg_place_issue,
      address: this.insuredDetailForm.value.adtnl_detail_address,
      PO_box: this.insuredDetailForm.value.adtnl_detail_poBoxNum,
      occupation: '',
      national_id: this.insuredDetailForm.value.e_eid,
      arabic_name:this.insuredDetailForm.value.e_arabic_name,
      home_office_number: '',
      start_date: this.convertDate(this.insuredDetailForm.value.polStartDate),
      end_date: '15/07/2022',
      color: '',
      chassis_no: this.insuredDetailForm.value.rg_chassis_num,
      engine: this.insuredDetailForm.value.rg_engin_num,
      plate: '54687',
      mortgage: this.insuredDetailForm.value.rg_mortgage,
      payment_mode: 'ONLINE',
      named_driver: this.insuredDetailForm.value.e_name,
      additional_driver_under_age: '0',
      IP_address: '',
      mobile: this.insuredDetailForm.value.adtnl_detail_mobile,
      code: this.insuredDetailForm.value.adtnl_detail_mbCode,
      driving_License_Front: this.insuredDetailForm.value.driving_Lic_Front,
      driving_license_Back: '',
      Reg_Card_Front: this.insuredDetailForm.value.reg_Card_Front,
      Reg_Card_Back: this.insuredDetailForm.value.reg_Card_Back,
      EID_Front: this.insuredDetailForm.value.emirated_ID_Front,
      EID_Back: this.insuredDetailForm.value.emirated_ID_Backk,
      dealer_quote: '',
      vhclPlateCategory:  this.insuredDetailForm.value.rg_type,
      plateCode: this.insuredDetailForm.value.rg_plateCode,
      plateNumber: this.insuredDetailForm.value.rg_traffic_plate_num,
      area: this.insuredDetailForm.value.adtnl_detail_area,
      noOfDoors: this.nofDoors,
      gender: gender,
      nationality: this.insuredDetailForm.value.e_nationality,
      source :'B2B',
      promocode:this.insuredDetailForm.value.promoCode,
      vat_tl_location:this.insuredDetailForm.value.vat_tl_location,
      po_box_number:this.insuredDetailForm.value.po_box_number,
      po_box_location:this.insuredDetailForm.value.po_box_location,
      driver_occupation:this.insuredDetailForm.value.driver_occupation,
      mileage:this.insuredDetailForm.value.mileage,
      weight_empty:this.insuredDetailForm.value.weight_empty,
      weight_full:this.insuredDetailForm.value.weight_full,
      rg_noOfDoor:this.insuredDetailForm.value.rg_noOfDoor,
      multiGap:this.multiGap


    }


    this.showLoader.referal = true;
    this.quoteDetailArr = motorArrayQuote;
    this.emailId = this.insuredDetailForm.value.adtnl_detail_email;
    this.payLink_email = this.insuredDetailForm.value.adtnl_detail_email;
    this.motorQuoteService.insertQuoterenewal(motorArrayQuote,policyDetail,this.userId,this.partnerId,this.cedantId,this.branchId).subscribe(res => {
    //  if (res.response_code == 6){
    //     Swal.fire("", res.reason, "error");
    //     stepper.previous();
    //   }
      this.prvPremium = res?.calContribution[0]?.PrvYrPremium;
      this.prvSum = res?.calContribution[0]?.PrvYrSumInsured;

      



     this.responsedata = res ;
    //  console.log(0);

     if(res?.webQuotationNumber){
     this.webQuoteNumber = res?.webQuotationNumber ;

     this.quoteNumber = res.webQuotationNumber;
     }else{
      this.webQuoteNumber = res?.web_quotation_number ;

      this.quoteNumber = res.web_quotation_number;

     }
      // if (type != 2){
      //   this.sendRefferMailToAdmin(2);
      // }
    
        this.sendRefferMailToAdmin(1);
    

 this.PlanDataJson.planBenefitData.benefit_data = [];

 this.showLoader.chasisNoButton = true;

 



// validation chassis end
  //     if(res.premium <= 0){
  //     //  this.noCreditLimt = 0 ;
  //      // this.creditLimit = {CreditLimit:0,AvailableLimit:0};
  //       Swal.fire("Your credit limit seems to be exhausted. Please contact the Credit Control department.","", "error");
  //       stepper.previous();
  // }

  //    else if (res.response_code == 0) {
  //       this.showLoader.Quotation = false;
  //       this.showLoader.retrieveQuote = false;
  //       Swal.fire("Sorry! Plan not available.", " ", "error");

  //       stepper.previous();
  //     }

  //     else if (res.response_code == 4) {
  //       this.webQuoteNumber = res.web_quotation_number;
  //       this.showLoader.Quotation = false;
  //       this.showLoader.retrieveQuote = false;
  //       this.referalStatus = true;
  //       this.referral_reason = res.referral_reason;
  //    //   this.savePolicyDetail(1);
  //       Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");

  //       stepper.previous();
  //     }
  //     else if (res.response_code == 2) {
  //       this.webQuoteNumber = res.web_quotation_number;
  //       this.showLoader.Quotation = false;
  //       this.showLoader.retrieveQuote = false;
  //       this.referalStatus = true;
  //       this.referral_reason = res.referral_reason;
  //       if(type == 2){
  //         this.sendRefferMailToAdmin(2);
  //       }
  //    //   this.savePolicyDetail(1);
  //       Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");

  //       stepper.previous();
  //     }

  //     else if (res.response_code_ == 400 || res.response_code == 5) {
  //       this.showLoader.Quotation = false;
  //       this.showLoader.retrieveQuote = false;
  //       this.webQuoteNumber = res.web_quotation_number;
  //       this.referral_reason = res.referral_reason;
  //       this.referalStatus = true;
  //    //   this.savePolicyDetail(1);
  //       Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");
  //       stepper.previous();
  //     }

  //     else if(res.response_code_r == 7){
  //       this.webQuoteNumber = res.web_quotation_number_r;
  //       this.referral_reason = res.response_message_r;
  //       this.showLoader.Quotation = false;
  //       this.showLoader.retrieveQuote = false;
  //       this.referalStatus = true;

  //      // this.savePolicyDetail(1);
  //       Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");

  //       stepper.previous();
  //     }


  //     else {
  //   //    this.validateChassisNum()
  //       this.showLoader.referal = false;
  //       this.disabledStatus=true;
  //       this.referalStatus = false;
  //       this.initial_benefit_data = res.planBenefitData.benefit_data;
  //      // this.policyFee = 1;
  //      this.planName = res.planName;
  //       this.policyFee = 0;
  //       this.totalVariablePremium = 0;
  //       this.PlanDataJson = res;
  //       this.totalFixPremium = res.totalPremium;
  //       this.plan_Name = this.PlanDataJson.planBenefitData.data[0].PlanName;
  //       this.plan_Id = this.PlanDataJson.planBenefitData.data[0].PlanId;
  //       this.benfPremIdArray = this.PlanDataJson.planBenefitData.data;
  //       this.webQuoteNumber = this.PlanDataJson.webQuotationNumber;
  //       this.quoteNumber = this.PlanDataJson.quotationNumber;
  //       this.tempBenefitData = this.PlanDataJson.planBenefitData.benefit_data;

  //       this.showLoader.Quotation = false;
  //       this.showLoader.retrieveQuote = false;

  //       if(this.webQuoteNumber == '' || this.webQuoteNumber == null){
  //          stepper.previous();
  //       }

  //       this.PlanDataJson.planBenefitData.data.forEach((item, index) => {

  //         if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1) {
  //           this.mulOption = item.multipleOptionData[0];
  //           this.PlanDataJson.planBenefitData.data[index].benefitSelectedData = item.multipleOptionData[0];
  //           this.PlanDataJson.planBenefitData.data[index].multiOptID = item.multipleOptionData[0].BenefitId;
  //           this.PlanDataJson.planBenefitData.data[index].Price = item.multipleOptionData[0].Price;
  //           this.PlanDataJson.planBenefitData.data[index].checked = false;
  //           this.PlanDataJson.planBenefitData.data[index].offerChecked = false;

  //         }

  //         if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1) {

  //           this.PlanDataJson.planBenefitData.data[index].checked = false;
  //           this.PlanDataJson.planBenefitData.data[index].offerChecked = false;

  //         }

  //       });


  //       // let discount = this.PlanDataJson.thirdPartyAPIData.NcdDiscount.NcdPerc/100;
  //       // this.discount = this.PlanDataJson.thirdPartyAPIData.NcdDiscount.NcdAmnt;

  //       this.discount =0;

  //      if(this.insuredDetailForm.value.adtnl_detail_repairTye.viewValue == 'Premium Garage'){
  //           this.applyLoadingOnChangeRepairType();
  //      }


  //       // this.tempTotalFixPremium = this.totalFixPremium;

  //       // //  this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.tempTotalFixPremium * discount);
  //       // this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.discount);

  //       // this.totalFixPremium = Math.round(this.totalFixPremium + this.policyFee);
  //       // this.tempTotalLoadFixPrem = this.totalFixPremium;
  //       // this.totalVariablePremium= 0 ;
  //       // this.VATAMT = Math.round((this.totalFixPremium + this.totalVariablePremium) * 0.05).toFixed(2);
  //       // this.Total_Primium = Math.round(this.totalFixPremium + this.totalVariablePremium + this.VATAMT);
  //       // this.loadingBy = '1';

  //       this.tempTotalFixPremium = this.totalFixPremium;

  //       //  this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.tempTotalFixPremium * discount);
  //       this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.discount);
  //       this.totalFixPremium = Math.round(this.totalFixPremium + this.policyFee);
  //       this.tempTotalLoadFixPrem = this.totalFixPremium;
  //        console.log("Checking premium");
  //       this.VATAMT = this.PlanDataJson.vatAMount;
  //       this.vatPer	 = this.PlanDataJson.vatPer/100	;
  //       this.Total_Primium = this.PlanDataJson.totalPremium + this.totalVariablePremium+this.totalVariablePremium*this.vatPer;
  //       this.loadingBy = '1';
  //       this.premium = this.PlanDataJson.premium  - this.discount ;
  //       if (this.tempTotalFixPremium<=500) {
  //         stepper.previous();

  //       }
  //       //this.savePolicyDetail(1);
  //       this.checkAccessForPolicyIssueButtons();
  //     }

    });
  }

  PlanDataJson: any = {
    "quotationNumber": "",
    "productCode": "",
    "planBenefitData": {},
    "data": []

  };

  // onMulOptionDataChange(eve, i, mulOption) {

  //   this.PlanDataJson.planBenefitData.data[i].benefitSelectedData = eve;
  //   this.PlanDataJson.planBenefitData.data[i].multiOptID = eve.BenefitId;
  //   this.PlanDataJson.planBenefitData.data[i].Price = eve.Price;
  //   this.PlanDataJson.planBenefitData.data[i].checked = false;
  //   this.addOptionalBenigits(1, 2);
  // }

  CheckAccessOnLoad(){

    this.motorQuoteService.checkUserAccess('RENEWAL', this.localStorageData.EmailAddress, 'MT',this.retrieveQuoteNumber).subscribe(res => {
      
      let response = res;
      
      //  this.checkStepper = false;
      if (response.userAccessData == 0) {
      this.unauthorizedAccess= true;
      //  Swal.fire( "You are not authorized to access this section. Please contact your relationship manager.", 'error');

      
     
      }
      else{

        this.Desclaimer = true;
        this.headerDesclaimer = response.HeaderDisclaimer;

      }

        });
 }

  addOptionalBenigits_1(id, event) {

    this.PlanDataJson?.planBenefitData?.data?.forEach((item, index) => {

        //admin this.accessGroup == 'ADMIN
        if (this.businessSource == 'DIRECT' && this.partnerId == 1 && this.userRole == 'TELEMARKETING' && this.userType == 'POS') {

          if (item.offerChecked == true) {
            //this.PlanDataJson.planBenefitData.data[index].checked = true;
            this.totalVariablePremium = Number(this.totalVariablePremium + 1);
          }
          if (item.checked == false) {
            //this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          }
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1 && item.offerChecked == false) {

                  if(id == 321){
                        if(item.BenefitId == this.planBenefitIDforBronze && item.checked == true){

                          this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                            item.checked = false;
                        }
                  }
                   // 477 for production & 509 for online test - Roadside Assistance - Bronze
                  if(id == this.planBenefitIDforBronze){

                        if(item.BenefitId == 321 && item.checked == true){
                          this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                            item.checked = false;
                        }
                  }
            this.optionalBenefit = this.optionalBenefit + "," + item.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);

          }

          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1 && item.offerChecked == false) {
            this.optionalBenefit = this.optionalBenefit + "," + this.mulOption.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);

          }


        } else {

           //USER

          if (item.offerChecked == true) {
            this.PlanDataJson.planBenefitData.data[index].checked = true;
            this.totalVariablePremium = Number(this.totalVariablePremium + 1);
          }
          if (item.checked == false) {
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          }

          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1 && item.offerChecked == false) {

            if(id == 321){

                  if(item.BenefitId == this.planBenefitIDforBronze && item.checked == true){

                    this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                      item.checked = false;
                  }
            }
            // 477 for production & 509 for online test
            if(id == this.planBenefitIDforBronze){

                  if(item.BenefitId == 321 && item.checked == true){
                    this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                      item.checked = false;
                  }
            }
            this.optionalBenefit = this.optionalBenefit + "," + item.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);

          }

          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1 && item.offerChecked == false) {
            // console.log(this.mulOption.BenefitId)
            // console.log(item.Price)
            this.optionalBenefit = this.optionalBenefit + "," + this.mulOption.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
            // console.log(this.totalVariablePremium);
          }


        }

    });

  //  this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);

  }


  addOptionalBenigits(id, event) {

    // alert(id)
  
  
    this.totalVariablePremium = 0;
    this.optionalBenefit = "";

    if( typeof this.PlanDataJson.planBenefitData.data != undefined)
   
    this.PlanDataJson?.planBenefitData?.data?.forEach((item, index) => {
    
        //admin this.accessGroup == 'ADMIN
        if (this.localStorageData.BusinessSource == 'DIRECT' && this.localStorageData.Partner_ID == 1 && this.localStorageData.UserRole == 'TELEMARKETING' && this.localStorageData.UserType == 'POS') {
  
          if (item.offerChecked == true) {
            //this.PlanDataJson.planBenefitData.data[index].checked = true;
            this.totalVariablePremium = Number(this.totalVariablePremium + 1);
          }
          if (item.checked == false) {
            //this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          }


                      /************  60D and 66A hai and
                Bus hoga - then Passenger cover mandatory - CRS cover code - 6722

                Truck or Trailer - Driver cover is mandatory - CRS cover code - 6721 
                
                */
                if(   toUpper(this.insuredDetailForm.value.adtnl_detail_bodyType.BodyTypeName) =='BUS' 
                    && (this.sideForm.value.schemeCode=="60D" || this.sideForm.value.schemeCode=="66A")
                    && (this.insuredDetailForm.value.rg_vhcl_make.CRS_VEH_CODE==6721)
                )  { 
                  this.PlanDataJson.planBenefitData.data[index].disable = true;
                  this.PlanDataJson.planBenefitData.data[index].checked = true;
                }


                if(  ( toUpper(this.insuredDetailForm.value.adtnl_detail_bodyType.BodyTypeName) =='BUS' ) 
                  && (this.sideForm.value.schemeCode=="60D" || this.sideForm.value.schemeCode=="66A")
                && (this.insuredDetailForm.value.rg_vhcl_make.CRS_VEH_CODE==6721 || this.insuredDetailForm.value.rg_vhcl_make.CRS_VEH_CODE==6721)
                )  { 
                  this.PlanDataJson.planBenefitData.data[index].disable = true;
                  this.PlanDataJson.planBenefitData.data[index].checked = true;
                }
          
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1 && item.offerChecked == false) {
          
                  if(id == 321){
                        if(item.BenefitId == this.planBenefitIDforBronze && item.checked == true){
                         
                          this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                            item.checked = false;
                        }
                  }
                   // 477 for production & 509 for online test - Roadside Assistance - Bronze
                  if(id == this.planBenefitIDforBronze){
                
                        if(item.BenefitId == 321 && item.checked == true){
                          this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                            item.checked = false;
                        }
                  }
            this.optionalBenefit = this.optionalBenefit + "," + item.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
     
          }
  
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1 && item.offerChecked == false) {
            this.optionalBenefit = this.optionalBenefit + "," + this.mulOption.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
          
          }
  
  
        } else {
  
           //USER
  
          if (item.offerChecked == true) {
            this.PlanDataJson.planBenefitData.data[index].checked = true;
            this.totalVariablePremium = Number(this.totalVariablePremium + 1);
          }
          if (item.checked == false) {
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          }
         
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1 && item.offerChecked == false) {
  
            if(id == 321){
            
                  if(item.BenefitId == this.planBenefitIDforBronze && item.checked == true){
                  
                    this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                      item.checked = false;
                  }
            }
            // 477 for production & 509 for online test
            if(id == this.planBenefitIDforBronze){
             
  
                  if(item.BenefitId == 321 && item.checked == true){
                    this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                      item.checked = false;
                  }
            }
            this.optionalBenefit = this.optionalBenefit + "," + item.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
          
          }
  
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1 && item.offerChecked == false) {
            this.optionalBenefit = this.optionalBenefit + "," + this.mulOption.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
          }


          
  
        
        }
  
    });

    
  
  }

  checkOptionalBenefit(benefitId) {

    if(typeof (benefitId) != undefined && typeof (benefitId) != "undefined" ){

    let benefitIdArray = benefitId.split(',');

    this.totalVariablePremium = 0;

    benefitIdArray.forEach((item1, index1) => {

      this.PlanDataJson?.planBenefitData?.data?.forEach((item, index) => {
        if (item.BenefitId == item1) {

          this.PlanDataJson.planBenefitData.data[index].checked = true;
          this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
        }

      });

      this.PlanDataJson?.planBenefitData?.data?.forEach((item, index) => {

        if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1) {

          item.multipleOptionData.forEach((multiItem, multiIndex) => {
            if (multiItem.BenefitId == item1) {

              this.mulOption = item.multipleOptionData[multiIndex];
              this.PlanDataJson.planBenefitData.data[index].checked = true;
              this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
              this.PlanDataJson.planBenefitData.data[index].multiOptID = item.multipleOptionData[multiIndex].BenefitId;
              this.PlanDataJson.planBenefitData.data[index].Price = item.multipleOptionData[multiIndex].Price;

            }
                  // console.log("Line no 2771");
          });

        }

      });

    });

  }
  this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
}

//--------------------------------APPLY 20% LOADING ON PREMIUM GARAGE REPAIR TYPE ----------------------------//
applyLoadingOnChangeRepairType(){

           this.repairLoadingAmt = Math.round(((20 * Number(this.totalFixPremium)) / 100));   //FOR BY PERCENT
          this.totalFixPremium += this.repairLoadingAmt;

}

//----------------------------------- VIEW QUOTE PDF -------------------------------------------
  viewQuotePDF() {
    this.showLoader.Quotation = true;
    let vatAMt = (this.premium + this.totalVariablePremium) * this.vatPer;
    let total_premium = this.totalFixPremium + this.totalVariablePremium + vatAMt+this.loadByAmount;
    // console.log(this.loadByAmount);
    let loadingAmt = this.loadByAmount;
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      base_premium: this.premium ,
      total_premium: this.total_premium,
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_code: this.insuredDetailForm.value.adtnl_detail_insType,
      VAT: vatAMt.toFixed(2),
      benefitPreId: this.benfPremIdArray,
      calculation_type : this.calculBy,
      loading_by : this.loadingBy,
      loading_amount  : loadingAmt,
      loadis_rate : this.loading_rate,
      premiumGarageAmount : this.repairLoadingAmt,
      // dedctible:this.step2.value.adminDeductible,
    }

    this.motorQuoteService.insertPlanData(this.PlanDataJson.quotationNumber, this.PlanDataJson.PlanDataJson, this.totalFixPremium,
    this.totalVariablePremium,
    this.policyFee,
    total_premium,
    this.PlanDataJson.planBenefitData.data,
    this.PlanDataJson.planBenefitData.benefit_data,
    // this.step2.value.adminDeductible,
    this.insuredDetailForm.value.adtnl_detail_repairTye,
    this.savePlanDetailArr,
    this.insuredDetailForm.value.adtnl_detail_insType.viewValue,
    'B2B',
    this.SchemeCode,'','','','',this.contrinutionData
    ).subscribe(res => {

      if(res.response_code==99 || res.response_code==909){

        Swal.fire("", res.show_message, 'error');
        this.showLoader.Quotation = false;
        return false ;
      }


      
      this.motorQuoteService.getQuoteDetailPDF(this.webQuoteNumber,this.partnerId,"B2B").subscribe(res => {


        this.showLoader.Quotation = false;
        setTimeout(
          function () {

          }.bind(this),
          600
        );
        let viewPDF = res;
        if (viewPDF.response_code == 1) {
          window.open(viewPDF.pdfPath, "_blank");
        }
      });
      //  this.editableStep.Quotation = false ;



    });

  }

  getPartnerBranchList() {
    


    this.partnerBranchArr = [];


    if(this.sideForm.value.partnerID=='') return false ;

    this.motorQuoteService
        .getpartnerBranch(this.sideForm.value.partnerID)
        .subscribe((res) => {
          // console.log(res);
         
            let updateRes: any = res;

            this.partnerBranchArr = updateRes.branchList;
            // console.log(this.partnerBranchArr)
            this.branchId = updateRes.branchList[0].Id;
            // console.log(this.branchId);

           
            // console.log('25658');
            // console.log(this.retrieveQuoteNumber);
          
                              this.sideForm.get('branchID')?.setValue(this.branchId);
                   this.sideForm.get('Accounting')?.setValue(this.branchId);
            if (this.retrieveQuoteNumber == '') {
                this.partnerBranchArr.forEach((item, index) => {

                
                    if (item.Id == this.branchId) {
                        this.branchVal = item;

                    }
                });
                // console.log('60256')
                  this.sideForm.get('branchID')?.setValue(this.branchVal);
                   this.sideForm.get('Accounting')?.setValue(this.branchVal);
            } else {

                // console.log('60256')
                // console.log( this.branchId);
                this.sideForm.get('branchID')?.setValue(this.branchId);
                this.sideForm.get('Accounting')?.setValue(this.branchId);
                // this.sideForm.get('Accounting')?.setValue(this?.quoteDetail?.CedantBrokerBranchId);
                // this.sideForm.get('branchID')?.setValue(this?.quoteDetail?.CedantBrokerBranchId);

            }
        });
}

 //------------------------------- UPDATE QUOTATION ----------------------------------------------//
  updateQuotation(stepper, type) {
    console.log(this.insuredDetailForm);
  
  // console.log(this.quoteDetail.PreviousPolExpDate);
  

  // console.log(this.webQuoteNumber,this.quoteNumber);
  if (this.convertDate(this.insuredDetailForm.value.rg_ins_exp) < this.convertDate(this.policyMinDate)) {
    // console.log(this.insuredDetailForm);

    let isFilealreadyUploaded =  false ;

    this.multilpleFile.forEach((item,index)=>{

      if(item?.DocumentType =='supporting_Document_GAP') { isFilealreadyUploaded = true ;

      }
    })

    if (isFilealreadyUploaded==false && this.multiGap.length == 0) { Swal.fire("Please upload supporting document."); stepper.previous(); return false; }

  }
  

  //let modifyValue = this.existVehiclevalue == 1 ? this.existVehiclevalue : null;
  let modifyValue = null;

 // let dob = this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.code == '100' ? this.convertDate(this.insuredDetailForm.value.d_dob) : '';
  let repairType = this.insuredDetailForm.value.adtnl_detail_insType.value == 100 ? this.insuredDetailForm.value.adtnl_detail_repairTye : { value: 'Garage', viewValue: 'Garage' };
  let vehicle_value = this.insuredDetailForm.value.adtnl_detail_insType.value == 100 ? this.insuredDetailForm.value.v_value : 0;
  let brand_new = (this.insuredDetailForm.value.rg_model_year.value != this.maxYear || this.insuredDetailForm.value.rg_model_year.value != this.year || this.insuredDetailForm.value.rg_model_year.value != this.minyear) ? { code: '0', value: 'N' } : { code: '1', value: 'Y' };
  let vehicleType = this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.code == '100' ? { code: '1001', value: 'Private' } : { code: '1001', value: 'Private' };
  let policy_expire_date = this.insuredDetailForm.value.vhclTPLCoverage == 'No' ? this.nextDate : this.PrevDate;
  let emiratesId = this.insuredDetailForm.value.e_eid.replace(/-/gi, "");
  let policy_status = 'RENEWAL' ;

  let PrevpolExpDate = this.quoteDetail.PreviousPolExpDate ;
  
  
  let motorArrayQuote = {
    cedant_broker_id:this.sideForm.value.partnerID,
    broker_branch_id:this.sideForm.value.branchID,
    quotation_number: this.quoteNumber?this.quoteNumber:this.noFoundQuote,
    web_quote_number: this.webQuoteNumber?this.webQuoteNumber:this.noFoundQuote,
    insured_type: this.insuredDetailForm.value.adtnl_detail_vhclOwnBy,
    insured_name: this.insuredDetailForm.value.e_name,
    gender: this.insuredDetailForm.value.e_gender,
    dob: this.convertDate(this.insuredDetailForm.value.d_dob),
    prospect_age: this.calucateAge(this.insuredDetailForm.value.d_dob, 1),
    nationality: this.insuredDetailForm.value.e_nationality,
    email: this.insuredDetailForm.value.adtnl_detail_email,
    mobile: this.insuredDetailForm.value.adtnl_detail_mobile,
    code: this.insuredDetailForm.value.adtnl_detail_mbCode,
    UAE_lic_age: this.convertDate(this.insuredDetailForm.value.d_issue_date),
    UAELicAge: this.calucateAge(this.insuredDetailForm.value.d_issue_date, 2),
    license_country: this.insuredDetailForm.value.e_nationality,
    NCD: this.insuredDetailForm.value.adtnl_detail_NCD,
    NCDPerc: this.insuredDetailForm.value.adtnl_detail_NCD_Perc,
    model_year: this.insuredDetailForm.value.rg_model_year,
    make: this.insuredDetailForm.value.rg_vhcl_make,
    model: this.insuredDetailForm.value.rg_vhcl_model,
    trim: this.insuredDetailForm.value.adtnl_detail_trim,
    body_type: this.insuredDetailForm.value.adtnl_detail_bodyType,
    engineSize: this.insuredDetailForm.value.adtnl_detail_engine,
    cylinders: this.insuredDetailForm.value.adtnl_detail_cylinder,
    passenger: this.insuredDetailForm.value.rg_num_passenger,
    registered_date: this.convertDate(this.insuredDetailForm.value.rg_reg_date),
    GCCSpecified: this.insuredDetailForm.value.adtnl_detail_gccSpecified,
    vhclModified: this.insuredDetailForm.value.adtnl_detail_vhclModified,
    registered_place: this.insuredDetailForm.value.rg_place_issue,
    chassis_no: this.insuredDetailForm.value.rg_chassis_num,
    repair_type: repairType,
    sum_insured:this.insuredDetailForm.value.v_value,
    emirates_id: emiratesId,
    policy_type: this.insuredDetailForm.value.adtnl_detail_insType,
    ExistingCover: this.insuredDetailForm.value.vhclTPLCoverage,
    policy_expire_date: this.convertDate(policy_expire_date),
    brand_new: brand_new,
    customer_id: "0",
    lead_id: "0",
    NCD_docs: "No",
    registration_type: vehicleType,
    VEHENGINESIZE: '1',
    source: 'B2B',
    document_data: this.tempDocArray,
    multiple_doc_data: this.tempMultipleDocData,
    GVM: this.insuredDetailForm.value.rg_gvm,
    origin: this.insuredDetailForm.value.rg_origin,
    policy_num: this.insuredDetailForm.value.rg_policy_num,
    eid_card_num: this.insuredDetailForm.value.e_cardNumber,
    reg_ins_exp_date: this.convertDate(this.insuredDetailForm.value.rg_ins_exp),
  //  reg_exp_date: this.convertDate(this.insuredDetailForm.value.rg_expiry_date),
    eid_exp_date: this.convertDate(this.insuredDetailForm.value.e_expiryDate),
    driv_lic_issue_date: this.convertDate(this.insuredDetailForm.value.d_issue_date),
    driv_lic_exp_date: this.convertDate(this.insuredDetailForm.value.d_expiry_date),
    driv_lic_issuePlace: this.insuredDetailForm.value.d_place_issue,
    name_in_arabic: this.insuredDetailForm.value.e_arabic_name,
    traffic_code: this.insuredDetailForm.value.rg_TC_num,
    license: this.insuredDetailForm.value.d_driv_lic_num,
    mortgage: this.insuredDetailForm.value.rg_mortgage,
    plate_number: this.insuredDetailForm.value.rg_traffic_plate_num,
    plate_code: this.insuredDetailForm.value.rg_plateCode,
    plate_category: this.insuredDetailForm.value.rg_type,
    driv_lic_TC_number: this.insuredDetailForm.value.d_TC_number,
    driv_lic_type: this.insuredDetailForm.value.d_lic_type,
    RepairType:this.insuredDetailForm.value.adtnl_detail_repairTye.RepairType,
    vehicleColor: this.insuredDetailForm.value.vhclColor,
    SchemeCode: this.sideForm.value.SchemeCode,
    start_date: this.convertStartDate(this.insuredDetailForm.value.polStartDate),
    modifiedVhclValue: modifyValue,
    policy_status : policy_status,
    deductible_value : this.insuredDetailForm.value.deductible,
    TRN_number : this.insuredDetailForm.value.TRN_num,
    trade_Lic_number :  this.insuredDetailForm.value.trade_lic_num,
    industry_type : this.insuredDetailForm.value.industry_type,
    transaction_type : this.insuredDetailForm.value.transaction_type.label,
    branchID : this.sideForm.value.branchID,
    isBrandNew:this.insuredDetailForm.value.adtnl_detail_brandNew,
    additional_DocumentFilePath:this.insuredDetailForm.value.additional_DocumentFilePath,
    prev_policy_number: this.Search_policy.value.policy_no,
    isTaxReg: this.insuredDetailForm.value.vat_register

  };


  this.quoteDetailArr = motorArrayQuote;
  this.emailId = this.insuredDetailForm.value.adtnl_detail_email;

  var gender = "";
  if(this.insuredDetailForm.value.e_gender){
    gender =  this.insuredDetailForm.value.e_gender.value;

  }
//  console.log(this.noFoundQuote);
  let policyDetail = {
    quotation_number: this.webQuoteNumber?this.webQuoteNumber:this.noFoundQuote,
    CRS_quotation_number: this.quoteNumber?this.quoteNumber:this.noFoundQuote,
    traffic_code: this.insuredDetailForm.value.rg_TC_num,
    license: this.insuredDetailForm.value.d_driv_lic_num,
    emirates: this.insuredDetailForm.value.rg_place_issue,
    address: this.insuredDetailForm.value.adtnl_detail_address,
    PO_box: this.insuredDetailForm.value.adtnl_detail_poBoxNum,
    occupation: '',
    national_id: this.insuredDetailForm.value.e_eid,
    arabic_name: '',
    home_office_number: '',
    start_date: this.convertDate(this.insuredDetailForm.value.polStartDate),
    end_date: '22/12/2019',
    color: '',
    chassis_no: this.insuredDetailForm.value.rg_chassis_num,
    engine: this.insuredDetailForm.value.rg_engin_num,
    plate: '54687',
    mortgage: this.insuredDetailForm.value.rg_mortgage,
    payment_mode: 'ONLINE',
    named_driver: this.insuredDetailForm.value.e_name,
    additional_driver_under_age: '0',
    IP_address: '',
    mobile: this.insuredDetailForm.value.adtnl_detail_mobile,
    code: this.insuredDetailForm.value.adtnl_detail_mbCode,
    driving_License_Front: this.insuredDetailForm.value.driving_Lic_Front,
    driving_license_Back: '',
    Reg_Card_Front: this.insuredDetailForm.value.reg_Card_Front,
    Reg_Card_Back: this.insuredDetailForm.value.reg_Card_Back,
    EID_Front: this.insuredDetailForm.value.emirated_ID_Front,
    EID_Back: this.insuredDetailForm.value.emirated_ID_Backk,
    dealer_quote: '',
    vhclPlateCategory: this.insuredDetailForm.value.rg_type,
    plateCode: this.insuredDetailForm.value.rg_plateCode,
    plateNumber: this.insuredDetailForm.value.rg_traffic_plate_num,
    area: this.insuredDetailForm.value.adtnl_detail_area,
    noOfDoors: this.nofDoors,
    gender: gender,
    nationality: this.insuredDetailForm.value.e_nationality,
    source :'B2B',
    vat_tl_location:this.insuredDetailForm.value.vat_tl_location,
    po_box_number:this.insuredDetailForm.value.po_box_number,
    po_box_location:this.insuredDetailForm.value.po_box_location,
    driver_occupation:this.insuredDetailForm.value.driver_occupation,
    mileage:this.insuredDetailForm.value.mileage,
    weight_empty:this.insuredDetailForm.value.weight_empty,
    weight_full:this.insuredDetailForm.value.weight_full,
    loading_by : this.loadingBy,
    loading_amount  : this.loadByAmount,
    loadis_rate : this.loading_rate,
    rg_noOfDoor:this.insuredDetailForm.value.rg_noOfDoor,   
    multiGap:this.multiGap,
    PrvInsPolNo:this.Search_policy.value.policy_no

  }
  this.payLink_email = this.insuredDetailForm.value.adtnl_detail_email;
  if(this.webQuoteNumber == '' || this.webQuoteNumber == null){
    this.getQuotation(stepper, type);
  }
  else if(this.webQuoteNumber != ''){
    this.motorQuoteService.updateQuotationRenewal(motorArrayQuote, policyDetail).subscribe(res => {
      
      //  if (res.response_code == 6){
      //   Swal.fire("", res.reason, "error");
      //   stepper.previous();
      // }
      if(this.clickSupportRefer==true) return false ;
      this.responsedata = res
    //   if (type != 0){
    //     stepper.next();
    // }
    if (res.response_code == 2) {
      this.webQuoteNumber = res.web_quotation_number;
      this.showLoader.Quotation = false;
      this.showLoader.retrieveQuote = false;
      this.referalStatus = true;
      this.referral_reason = res.referral_reason;
      Swal.fire("", this.referral_reason,"error")
   //   this.savePolicyDetail(1);
      

  //  if(this.quoteStatus=="ADDITIONALINFO")
  //  {
  //    Swal.fire('Your details have been submitted to our team of UWs for review. ',
  //      'You will be notified soon after the review. Your Quotation Reference# ' +
  //        this.webQuoteNumber,
  //      'warning'
  //  );

  //  this._route.navigate(['renewpolicy']);

  //  } 
  //  else {
  //   Swal.fire(
  //    'Thank you for you request, based on your application details, the case needs to be referred for further review.',
  //    'An email will be sent to you shortly. If you need further assistance call us at 600 5 80000',
  //    'warning'
  //  );

  //     Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");

      
  //   }
    stepper.previous();
   }
    if(res?.calContribution){
      this.prvPremium = res?.calContribution[0]?.PrvYrPremium;
      this.prvSum = res?.calContribution[0]?.PrvYrSumInsured;
      }
      this.prvPremium = res?.calContribution[0]?.PrvYrPremium;
      this.updateStatusDescription = res.calContribution[0].StatusDesc;
    this.prvSum = res?.calContribution[0]?.PrvYrSumInsured;
    this.webQuoteNumber = res.webQuotationNumber;
    this.quoteNumber = res.webQuotationNumber;
    this.VATAMT1 = res.vatAMount
    //   if (this.convertDate(this.insuredDetailForm.value.rg_ins_exp) <= this.convertDate(this.policyMinDate)) {
      
    //   console.log(this.convertDate(PrevpolExpDate));
    //   console.log(this.convertDate(this.policyMinDate));
    //   this.referalStatus = true ;
    //   Swal.fire("The policy is already expired and there is gap in insurance. Please refer the quote to DNI Underwriters.","Your quote reference number is " +this.webQuoteNumber,"error");
    //   stepper.previous();
  
    //   return false ;
    // }
  
  
    if(this.responsedata.premium <= 0){
      this.referalStatus = true ;
      //  this.noCreditLimt = 0 ;
      // this.creditLimit = {CreditLimit:0,AvailableLimit:0};
      Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");
  
        stepper.previous();
   }
  
      if (!res.BasePremium || !res.premium) {
      
        this.webQuoteNumber = res.webQuotationNumber;

      this.quoteNumber = res.webQuotationNumber;
      this.showLoader.Quotation = false;
      this.showLoader.retrieveQuote = false;
      this.referalStatus = true;
      this.referral_reason = res.referral_reason;
   //   this.savePolicyDetail(1);
      Swal.fire("Thank you for your request, based on your application details, the case needs to be referred for further review.", "An email will be sent to you shortly. If you need further assistance call us at 600 580 000", "error");
  
      stepper.previous();
      return false ;
    }
    this.PlanDataJson.planBenefitData.benefit_data = [];
  //  this.showLoader.Quotation = false;
      this.PlanDataJson.planBenefitData.benefit_data = [];
      this.showLoader.retrieveQuote = false;
     // let thirdPartyAPIResponse = res.thirdPartyAPIData.Status.Description.split(("no tariff available").toLowerCase());
  
     this.showLoader.chasisNoButton = true;
     this.motorQuoteService.validateChassisNumber(this.insuredDetailForm.value.rg_chassis_num,this.partnerId,this.userId,this.sideForm.value.schemeCode,"R").subscribe(resChassis => {
       let validateRes = resChassis;
  
       if (validateRes.validateChassisNumber == 'W') {
         Swal.fire(validateRes.validateChassisMessage);
        this.showLoader.chasisNoButton = false;
  
         this.insuredDetailForm.get('isChassisValidate')?.setValue('');
         this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
        // return false;
        stepper.previous();
       }
  
  
      //  if(validateRes.validateChassisNumber=="E"){
      //   this.showLoader.chasisNoButton = false;
  
      //    this.insuredDetailForm.get('isChassisValidate')?.setValue('');
      //    this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
        
      //   Swal.fire(validateRes.validateChassisMessage);
      //   stepper.previous();
      //   return false ;
      // }
    
    else if(validateRes.validateChassisNumber == 'A' || validateRes.validateChassisNumber == 'BOR'){
      this.showLoader.chasisNoButton = false;
  
         if (validateRes.validateChassisNumber == 'BOR') {
       
        this.getQuoteNumber =   this.responsedata.webQuotationNumber;
        this.showBor = true;
        // console.log(this.getQuoteNumber);
        stepper.previous();
        Swal.fire(validateRes.validateChassisMessage);
         
  
      }
  
      this.showLoader.Quotation = false;
  
      if (res.response_code == 1000){
        const dialogRef = this.dialog.open(this.callAPIDialog);
      }
  
         if (res.response_code == 0) {
        
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        Swal.fire("Sorry! Plan not available.", " ", "error");
  
        stepper.previous();
      }
  
     
         else if (res.response_code == 4) {
           
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        Swal.fire("", res.thirdPartyAPIData.Status.Description, "error");
        // this.webQuoteNumber = res.web_quotation_number;
        this.referalStatus = true;
        this.referral_reason = res.referral_reason;
     //    this.savePolicyDetail(1);
        stepper.previous();
      }
      else if (res.response_code_ == 400 ||res.response_code == 5) {
            this.showLoader.Quotation = false;
            this.showLoader.retrieveQuote = false;
            // console.log(this.quoteStatus)
         //  console.log(thirdPartyAPIResponse.length)
          // && thirdPartyAPIResponse.length > 1
            if(this.quoteStatus == 'REFERRED' && this.businessSource == 'DIRECT' && this.partnerId == 1 && this.userType == 'POS' && this.userRole == 'TELEMARKETING' ){
                  Swal.fire({
                    title: res.thirdPartyAPIData.Status.Description,
                    text: "Do you want to trigger a referral scheme?",
                    showCancelButton: true,
                    confirmButtonColor: '#3085D6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes'
                  }).then((result) => {
                    if (result.value) {
                      this.SchemeCode = '108';
                      this.referalStatus = false;
                      this.showLoader.Quotation = true;
                      this.showLoader.retrieveQuote = true;
                      this.updateQuotation(stepper,1);
                    }
                    else if (result.dismiss === Swal.DismissReason.cancel) {
                     
                          //Swal.fire("Cancelled", ":)", "error");
                          stepper.previous();
                          return false;
                        }
                  });
            }
              else{
             
                      Swal.fire("", validateRes.validateChassisMessage, "error");
                      // this.webQuoteNumber = res.web_quotation_number;
                      this.referral_reason = res.referral_reason;
                      this.referalStatus = true;
                //      this.savePolicyDetail(1);
                      stepper.previous();
              }
  
         }
         else if (res.response_code_r == 7) {
         
        // this.webQuoteNumber = res.web_quotation_number_r;
        this.referral_reason = res.response_message_r;
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        this.referalStatus = true;
       //    this.savePolicyDetail(1);
       //  Swal.fire("", res.thirdPartyAPIData.Status.Description, "error");
  
        stepper.previous();
        }
         else if (res.quoteConditionCheck.lenght == 0) {
          
          // this.webQuoteNumber = res.web_quotation_number_r;
          this.referral_reason = res.response_message_r;
          this.showLoader.Quotation = false;
          this.showLoader.retrieveQuote = false;
          this.referalStatus = true;
         //    this.savePolicyDetail(1);
          Swal.fire( this.referral_reason, res?.response_message_, "error");
  
          stepper.previous();
          }
       else {
  
        if(this.quoteStatus=="ADDITIONALINFO")
          {
          Swal.fire('Your details have been submitted to our team of UWs for review. ',
            'You will be notified soon after the review. Your Quotation Reference# ' +
              this.webQuoteNumber,
            'warning'
          );
  
        this._route.navigate(['renewpolicy']);
  
       }
        // console.log(this.insuredDetailForm.value.adtnl_detail_vhclValue);
        // console.log(this.insuredDetailForm?.value?.adtnl_detail_vhclValue?.value);
  
        this.disabledStatus=true;
        this.referalStatus = false;
        
        this.contrinutionData = { "ODPremium": this.responsedata.calContribution[0].ODPremium,
        "TPPremium":this.responsedata.calContribution[0].TPPremium }
  
  
        this.initial_benefit_data =   this.responsedata?.planBenefitData?.benefit_data;
  
       // this.policyFee = 1;
        this.policyFee = 0;
        this.totalVariablePremium = 0;
        this.PlanDataJson =   this.responsedata;
        this.totalFixPremium =   this.responsedata.BasePremium;
        this.tempTotalFixPremium =  this.totalFixPremium;
        this.plan_Name = this.PlanDataJson.planBenefitData.data[0].PlanName;
        this.plan_Id = this.PlanDataJson.planBenefitData.data[0].PlanId;
        this.benfPremIdArray = this.PlanDataJson.planBenefitData.data;
        this.webQuoteNumber = this.PlanDataJson.webQuotationNumber;
        this.quoteNumber = this.PlanDataJson.quotationNumber;
        this.tempBenefitData = this.PlanDataJson.planBenefitData.benefit_data;
        // if(type==2){
        //   this.sendRefferMailToAdmin(2);
        // }
  
        this.premium =   this.responsedata.BasePremium;
       this.showLoader.retrieveQuote = false;
  
           if (this.webQuoteNumber == '' || this.webQuoteNumber == null) {
          
           stepper.previous();
        }
        this.PlanDataJson?.planBenefitData?.data?.forEach((item, index) => {
  
          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1) {
            this.mulOption = item.multipleOptionData[0];
            this.PlanDataJson.planBenefitData.data[index].benefitSelectedData = item.multipleOptionData[0];
            this.PlanDataJson.planBenefitData.data[index].multiOptID = item.multipleOptionData[0].BenefitId;
            this.PlanDataJson.planBenefitData.data[index].Price = item.multipleOptionData[0].Price;
            this.PlanDataJson.planBenefitData.data[index].checked = false;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
  
          }
  
          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1) {
  
            this.PlanDataJson.planBenefitData.data[index].checked = false;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
  
          }
  
  
        });
  
        this.checkOptionalBenefit(this.optionalBenefit);
  
       // let discount = this.PlanDataJson.thirdPartyAPIData.NcdDiscount.NcdPerc / 100;
        this.discount = 0;
  
       
        if(this.insuredDetailForm.value.adtnl_detail_repairTye.viewValue == 'Premium Garage'){
              this.applyLoadingOnChangeRepairType();
        }
  
        // console.log("Debug 1");
        this.tempTotalFixPremium = this.totalFixPremium;
  
        //  this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.tempTotalFixPremium * discount);
        this.totalFixPremium = this.tempTotalFixPremium - this.discount;
        this.totalFixPremium = this.totalFixPremium + this.policyFee;
        this.tempTotalLoadFixPrem = this.totalFixPremium;
        //  console.log("Checking premium");
        this.VATAMT = this.PlanDataJson.vatAMount;
        this.vatPer	 = this.PlanDataJson.vatPer/100	;
        this.Total_Primium = this.PlanDataJson.totalPremium + this.totalVariablePremium+this.totalVariablePremium*this.vatPer;
        this.loadingBy = '1';
        this.premium = this.PlanDataJson.premium  - this.discount ;
           if (this.tempTotalFixPremium <= 500) {
             console.log(this.tempTotalFixPremium)
          stepper.previous();
  
        }
        // else
            // this.savePolicyDetail(1);
            this.checkAccessForPolicyIssueButtons();
            this.addOptionalBenigits(318,2);
            this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
        
            this.addOptionalBenigits(318,2);
            this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
      }
  
  
    }
  });
  
  
    });
  }
 
  this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
}



  //------------------------------------ SAVE QUOTE PLAN ------------------------------------------
  getQuotePlan() {
    // console.log(this.VATAMT1);
    // console.log(((((this.totalFixPremium+this.totalVariablePremium) * 0.05) + (this.totalFixPremium+this.totalVariablePremium))-(this.totalFixPremium+this.totalVariablePremium)));

    //this.addOptionalBenigits(321, '');
    this.addOptionalBenigits(318,2);
    this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);

    this.addOptionalBenigits(318,2);
    this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
     this.close();
    this.showLoader.Quotation = true;
    this.showLoader.referal = false;
  
    let vatAMt = ((((this.totalFixPremium+this.totalVariablePremium) * 0.05) + (this.totalFixPremium+this.totalVariablePremium))-(this.totalFixPremium+this.totalVariablePremium));
    // this.vatAMt = vatAMt;
    // let vatAMt = this.VATAMT1;
    // console.log(this.PlanDataJson.vatAMount);
    let total_premium = this.totalFixPremium ;
  
    let loadingAmt = this.calculBy == 1 ? this.loadingByPercent : this.loadByAmount;
    //   this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      total_premium: this.totalFixPremium,
      base_premium: this.premium,
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_code: this.insuredDetailForm.value.adtnl_detail_insType,
      VAT: vatAMt,
      benefitPreId: this.benfPremIdArray,
      calculation_type : this.calculBy,
      loading_by : this.loadingBy,
      loading_amount  : loadingAmt,
      loadis_rate : this.loading_rate,
      premiumGarageAmount : this.repairLoadingAmt,
      // dedctible:this.step2.value.adminDeductible,

    }

    this.motorQuoteService.insertPlanData(this.PlanDataJson.quotationNumber, this.PlanDataJson.PlanDataJson, this.totalFixPremium,
      this.totalVariablePremium,
      this.policyFee,
      total_premium,
      this.PlanDataJson.planBenefitData.data,
      this.PlanDataJson.planBenefitData.benefit_data,
      this.insuredDetailForm.value.adtnl_detail_repairTye,
      this.savePlanDetailArr,
      // this.step2.value.adminDeductible,
      this.insuredDetailForm.value.adtnl_detail_insType.viewValue,
      'B2B',
      this.SchemeCode,'','','','',this.contrinutionData

    ).subscribe(res => {

      if(res.response_code==99 || res.response_code==909){

        Swal.fire("", res.show_message, 'error');
        this.showLoader.Quotation = false;
        return false ;
      }

      if (this.policyStatus == 'ISSUEPOLICY') {
        this.PaymentMode = 'CRD';
        localStorage.setItem('pageStatus', 'ISSUPOLICY');
        this.saveAdditionalInfo(3);
      }

      if (this.policyStatus == 'PAYMENT') {
        this.PaymentMode = 'ONL';
        localStorage.setItem('pageStatus', 'PAYMENT');
        Swal.fire("Your details will be saved and you will be re-directed to Payment gateway page", " Do not click back or click any button", 'success');
        this.saveAdditionalInfo(2);
      }

      if (this.policyStatus == 'SENDPAYMENTLINK') {
        this.saveAdditionalInfo(4);
      }

      // if(this.policyStatus == 'REFERED'){
      //         this.showLoader.Quotation = false;
      //         Swal.fire('Your quote has been referred to our expert team of UWs for review.', 'You will be notified soon after the review. Your Quotation Reference# ' + this.webQuoteNumber, 'success');
      //          this._route.navigate(['renewpolicy']);
      // }

      if(this.policyStatus == 'REJECTED'){
              this.showLoader.Quotation = false;
              Swal.fire('', 'Quotation '+ this.webQuoteNumber + ' has been rejected and a notification is sent to the user.', 'success');
               this._route.navigate(['renewpolicy']);
      }

      if(this.policyStatus == 'APPROVED') {
        this.saveAdditionalInfo(1);
              this.showLoader.Quotation = false;
              Swal.fire('', 'Quotation '+ this.webQuoteNumber + ' has been approved and sent to user for policy issuance.', 'success');
               this._route.navigate(['renewpolicy']);
      }

      if(this.policyStatus == 'ADDITIONALINFO') {
            this.showLoader.Quotation = false;
            Swal.fire('', 'Quotation '+ this.webQuoteNumber + ' has been sent to user to provide additional information as requested.', 'success');
            this._route.navigate(['renewpolicy']);
      }

    });

  }

  //------------------------------ SEND EMAIL ---------------------------------------------//
  getQuotePlanEmail() {
    this.showLoader.Quotation = true;
    // this.policyFee = this.vehicleDetailForm.value.insType.value == 200 ? 50 : 0;
    // let vatAmt = (this.totalFixPremium + this.totalVariablePremium + this.policyFee) * 0.05;
    // let total_premium = this.totalFixPremium + this.totalVariablePremium + this.policyFee + vatAmt;

    let vatAMt = (this.totalFixPremium + this.totalVariablePremium) * 0.05;
    let total_premium = this.totalFixPremium + this.totalVariablePremium + vatAMt;
    let loadingAmt =this.loadByAmount;
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      total_premium: total_premium,
      base_premium: Math.round(this.totalFixPremium),
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_code: this.insuredDetailForm.value.adtnl_detail_insType,
      VAT: vatAMt,
      benefitPreId: this.benfPremIdArray,
      calculation_type : this.calculBy,
      loading_by : this.loadingBy,
      loading_amount  : loadingAmt,
      loadis_rate : this.loading_rate,
      premiumGarageAmount : this.repairLoadingAmt,
      // dedctible:this.step2.value.adminDeductible,

    }

    this.motorQuoteService.insertPlanData(this.PlanDataJson.quotationNumber, this.PlanDataJson.PlanDataJson, Math.round(this.totalFixPremium),
    this.totalVariablePremium,
    this.policyFee,
    total_premium,
    this.PlanDataJson.planBenefitData.data,
    this.PlanDataJson.planBenefitData.benefit_data,
    this.insuredDetailForm.value.adtnl_detail_repairTye,
    // this.step2.value.adminDeductible,
    this.savePlanDetailArr,
    this.insuredDetailForm.value.adtnl_detail_insType.viewValue,
    'B2B',
    this.SchemeCode,'','','','',this.contrinutionData
    ).subscribe(res => {

      if(res.response_code==99 || res.response_code==909){

        Swal.fire("", res.show_message, 'error');
        this.showLoader.Quotation = false;
      }else{

      this.sendMail();
      this.showLoader.Quotation = false;
      //  this.editableStep.Quotation = false ;

      Swal.fire("", "Thank you for choosing Dubai National Insurance for insuring your car. We have sent an email to your registered email with all the quotation details. Your Quotation Reference# " + this.webQuoteNumber, 'success');
      }
    });
    
  }

  sendMail() {
    this.motorQuoteService.sendMail(this.webQuoteNumber, this.emailId,'').subscribe(res => {
      // console.log(res);

    });
  }

  saveData(){
    this.email = this.localStorageData.EmailAddress;
    this.psw = this.sessionData.value.password;
    // console.log(this.email);
    // console.log(this.psw);
    if (this.email == ''){
        this._route.navigate(['/sign-in']);
    }
    else{
        this._authService.validateuser(this.email, this.psw).subscribe(()=>{
            // const redirectURL = this._activatedroute.snapshot;
            // console.log(redirectURL);
            // this._route.navigateByUrl(redirectURL);
        })
    }
    this._route.navigate(['/renewpolicy']);
    this.close();
}


//--------------------------------------- GET USER ACCESS PERMISSION -------------------------------------------//

  async getUserAccessPermission(stepper, type, stepperType) {
    console.log(this.insuredDetailForm);
    

    // if(this.insuredDetailForm.value.adtnl_detail_vhclValue<=0) {

    //   Swal.fire("Please enter Sum Insured Value");

    //   return false ;
    // }

    this.checkEID(this.insuredDetailForm.value.e_eid);
    this.checkStepper = true;

    // this.horizontalStepperForm.get('e_expiryDate').setValidators(null);
    // console.log(this.insuredDetailForm.get);
    // console.log(this.insuredDetailForm.value.rg_chassis_num);
   // await this.validateChassisNum(this.insuredDetailForm.value.rg_chassis_num);

    if (type == 1 || type == 2) {
      this.insuredDetailForm.markAllAsTouched();
    

  // console.log(this.insuredDetailForm.value.adtnl_detail_insType.ProductShortName);
   if(this.insuredDetailForm.value.adtnl_detail_insType.ProductShortName.toUpperCase()=='THIRD PARTY LIABILITY'){

      this.insuredDetailForm.get('adtnl_detail_repairTye').setValidators([Validators.required]);
      // Validators.min(this.vehicleValueLimit.startLimit), Validators.max(this.vehicleValueLimit.endLimit)
      //  this.insuredDetailForm.get('v_value').setValidators([Validators.required]);
      this.insuredDetailForm.get('v_value').setValidators(null);

    }
    else {

      this.insuredDetailForm.get('v_value').setValidators([Validators.required,Validators.min(this.vehicleValueLimit.startLimit),Validators.max(this.vehicleValueLimit.endLimit)]);

      // this.horizontalStepperForm.get('adtnl_detail_repairTye').setValidators(null);
    }

    this.insuredDetailForm.get('adtnl_detail_repairTye').updateValueAndValidity();
    this.insuredDetailForm.get('v_value').updateValueAndValidity();
    



      if(this.insuredDetailForm.value.rg_place_issue.CityName == 'Dubai'){
            this.insuredDetailForm.get('rg_TC_num')?.setValidators([ Validators.minLength(8), Validators.maxLength(8),]);
            // this.horizontalStepperForm.get('d_TC_number').setValidators([ Validators.minLength(8), Validators.maxLength(8),]);
        }else{
            this.insuredDetailForm.get('rg_TC_num')?.setValidators([ Validators.minLength(10), Validators.maxLength(10),]);
            // this.horizontalStepperForm.get('d_TC_number').setValidators([ Validators.minLength(10), Validators.maxLength(10),]);
        }

        this.insuredDetailForm.get('rg_TC_num')?.updateValueAndValidity();
        // this.horizontalStepperForm.get('d_TC_number').updateValueAndValidity();

        if(this.insuredDetailForm.value.adtnl_detail_brandNew == 1){
              // this.horizontalStepperForm.get('rg_plateCode').setValidators(null);
              // this.horizontalStepperForm.get('rg_traffic_plate_num').setValidators(null);
              this.insuredDetailForm.get('rg_reg_date')?.setValidators(null);

          }else{
              // this.horizontalStepperForm.get('rg_plateCode').setValidators([Validators.required]);
              // this.horizontalStepperForm.get('rg_traffic_plate_num').setValidators([Validators.required]);
              this.insuredDetailForm.get('rg_reg_date')?.setValidators([Validators.required]);
          }

        // this.horizontalStepperForm.get('rg_plateCode').updateValueAndValidity();
        // this.horizontalStepperForm.get('rg_traffic_plate_num').updateValueAndValidity();
        this.insuredDetailForm.get('rg_reg_date')?.updateValueAndValidity();

        if(this.tempMultipleDocData.length == 0 && this.tempDocArray.length == 0){

          Swal.fire("", "Please upload mandatory documents", 'error');
          stepper.previous();
          return false;
      }

      if(this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue.toLowerCase() == 'corporate' && this.insuredDetailForm.value.trade_LicenceFilePath == ''){
        Swal.fire("", "Please upload Trade License copy", 'error');
        stepper.previous();
        return false;
  }
  if(this.insuredDetailForm.value.vat_register  == 'Yes' && this.insuredDetailForm.value.TRN_CertificateFilePath == ''){
        Swal.fire("", "Please upload TRN certificate copy", 'error');
        stepper.previous();
        return false;
  }


      /*
      if(this.tempMultipleDocData.length == 0 && this.tempDocArray.length == 0){

          Swal.fire("", "Please upload mandatory documents", 'error');
          return false;
      }

    */
    //  this.tempMultipleDocData  =1 ;

     if( this.tempMultipleDocData.length == 0 && (this.tempDocArray.length >= 0) ){

              if(this.insuredDetailForm.value.MulkhiyaStatus == 'Yes'){
                      if(this.insuredDetailForm.value.reg_Card_BackFilePath == '' ){
                          Swal.fire("", "Please upload the vehicle registration front copy", 'error');
                          stepper.previous();
                          return false;
                      }
                      else if(this.insuredDetailForm.value.reg_Card_FrontFilePath == ''){
                          Swal.fire("", "Please upload the vehicle registration back copy", 'error');
                          stepper.previous();
                          return false;
                      }
              }
              else if(this.insuredDetailForm.value.MulkhiyaStatus == 'No'){
                      if(this.insuredDetailForm.value.supporting_DocumentFilePath == '' ){
                        Swal.fire("", "Please upload mandatory supporting document copy", 'error');
                        stepper.previous();
                        return false;
                      }
              }
              else if(this.insuredDetailForm.value.driving_Lic_FrontFilePath == '' && this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue != 'Corporate'){
                      Swal.fire("", "Please upload driving license front copy", 'error');
                      stepper.previous();
                      return false;
              } else if(this.insuredDetailForm.value.driving_Lic_BackFilePath == '' && this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue != 'Corporate'){
                      Swal.fire("", "Please upload driving license back copy", 'error');
                      stepper.previous();
                      return false;
              }

      }

    

      // if(this.convertDate(this.insuredDetailForm.value.polStartDate) > this.convertDate(this.insuredDetailForm.value.rg_ins_exp)){
      //     Swal.fire('', 'Invalid previous policy insurance expiry date selected.', 'error');
      //     return false;
      // }

      // comment on 18 Nov
      // if(this.convertDate(this.insuredDetailForm.value.rg_ins_exp) >= this.convertDate(this.toDay) && this.convertDate(this.insuredDetailForm.value.polStartDate) >= this.convertDate(this.toDay)){
      //   let insExpDate =  new Date(new Date(this.insuredDetailForm.value.rg_ins_exp).setDate(new Date(this.insuredDetailForm.value.rg_ins_exp).getDate() + 1));

      //         if(this.convertDate(this.insuredDetailForm.value.polStartDate) > this.convertDate(insExpDate))
      //         {
      //           Swal.fire('', 'Policy start date cannot be later than previous insurance expiry date.', 'error');
      //           return false;

      //         }
      // }else{

      //         Swal.fire('', 'Invalid policy start date and/or previous insurance exp date.', 'error');
      //         return false;
      // }

      if (this.insuredDetailForm.value.rg_model_year.value >= (this.minyear - 1) && this.insuredDetailForm.value.adtnl_detail_insType.value == 100 && this.insuredDetailForm.value.adtnl_detail_brandNew != 1) {
        this.insuredDetailForm.get('rg_reg_date')?.setValidators([Validators.required]);

        if (this.insuredDetailForm.value.adtnl_detail_brandNew != 1) {
        //   if (this.regMaxDate < this.insuredDetailForm.value.rg_reg_date || this.regMinDate > this.insuredDetailForm.value.rg_reg_date) {
        //     Swal.fire("Invalid 1st registration date", "", 'error');
        //     if (stepperType == 0) {
        //       stepper.previous();
        //     }
        //     return false;
        //   }
         }
      } else {
        // this.horizontalStepperForm.get('rg_reg_date').setValidators(null);
      }

      this.insuredDetailForm.get('rg_reg_date')?.updateValueAndValidity();

      if (this.insuredDetailForm.invalid) {
          this.validtnMsg = true;
          console.log(this.insuredDetailForm)
          // console.log(this.insuredDetailForm.controls.status)
          Swal.fire("", "Please fill all the mandatory data", 'error');
          console.log(this.insuredDetailForm.controls)
          return false;
      }

      /*********  To do later 
      if( this.insuredDetailForm.value.adtnl_detail_NCD.NCDCode > this.vehicle_age){
          Swal.fire('', 'Invalid NCD value selected.', 'error');
          return false;
      }
      */
      // if(this.validateStatus==false){
      //   return false
      // }



      // if ( this.insuredDetailForm.value.adtnl_detail_insType.value == 100)
          // if (Number(this.insuredDetailForm.value.adtnl_detail_vhclValue) < Number(this.vehicleValueLimit.startLimit) || Number(this.insuredDetailForm.value.adtnl_detail_vhclValue) > Number(this.vehicleValueLimit.endLimit)) {
          //   // if (stepperType == 0) {
          //     this.referalStatus = true;
          //     this.showLoader.Quotation = false;
          //     this.showLoader.retrieveQuote = false;
          //     this.referalStatus = true;
          //     this.expdateboolean =true;
          //     Swal.fire( " You can refer to underwritter","vehicle Value should be between "+this.vehicleValueLimit.startLimit +'-'+this.vehicleValueLimit.endLimit, "error");
          //     stepper.previous();
          //   // }
          //   return false;
          // }

          if(this.insuredDetailForm.value.adtnl_detail_insType.viewValue == 'Comprehensive' && (this.insuredDetailForm.value.deductible == '' || this.insuredDetailForm.value.deductible == null)){
                      this.referalStatus = true ;
          }
    }

  
    this.validtnMsg = false;
    this.showLoader.Quotation = true;
    this.showLoader.retrieveQuote = true;
    stepper.next();
    this.motorQuoteService.checkUserAccess('RENEWAL', this.localStorageData.EmailAddress, 'MT',this.retrieveQuoteNumber).subscribe(res => {
    
      let response = res;
      //  this.checkStepper = false;
      if (response.userAccessData == 0) {
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        Swal.fire("", "Permission Denied", 'error');
        stepper.previous();
      
      } else {
        let validateData = {
          sumInsured: this.insuredDetailForm.value.v_value,
          schemecode: this.sideForm.value.schemeCode,
          bodyType: this.insuredDetailForm.value.adtnl_detail_bodyType,
          coverType: this.insuredDetailForm.value.adtnl_detail_insType.ProductShortName,
          insuredType :  this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue,
          quotationNo : this.webQuoteNumber,
          partnerId : this.partnerId
        }

        this.motorQuoteService.validateScheme(validateData).subscribe((res) =>{
        //  
        // console.log(res);

        if(res.Data[0].StatusCode == 200){
          if(this.validateDOBYear()==true)

          if (type == 1) {
          
            this.getQuotation(stepper, stepperType);
          }

          if (type == 2) {
            
            this.updateQuotation(stepper, stepperType);
          }
        }
    else{
              Swal.fire(res.Data[0].StatusMsg);
              stepper.previous();
              this.showLoader.Quotation = false;
              this.showLoader.retrieveQuote = false;
             // this.showLoader.Quotation = false;
        }

        });







      }
    });
  }

  isClickChassisValidate = false ;
  tmpChassisNo= '';
   validateChassisNum(event) {
   
    event = this.insuredDetailForm.value.rg_chassis_num ;
    if(this.insuredDetailForm.value.rg_chassis_num!=this.quoteDetailPrev.ChassisNumber && this.isCallChessisNo==false)
    { 
      
      Swal.fire({
        title: "Chassis Number Change",
        text: "By changing the risk details, the premium might change. Do you wish to continue?",
        showCancelButton: true,
        confirmButtonColor: '#3085D6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
      }).then((result) => {
        if (result.value) {

          this.isCallChessisNo=true ;
          this.isClickChassisValidate = false;
          this.tmpChassisNo = event;
          

          this.validateChassisNum('');
        }else{

          this.insuredDetailForm.get("rg_chassis_num").setValue(this.quoteDetailPrev.ChassisNumber);
          return false;

        }

      });
      
    }else{
          
          if(this.isCallChessisNo==false) { this.validateChassisNum(''); return false ; }

          
    }

    if(this.isCallChessisNo==false)  return false ;
      // this.validChassisNum = true;

     if(this.tmpChassisNo == event) return false ; else  this.tmpChassisNo = event ;
    if(event.length==0){
      this.modelYearRang();
    }
    if (event == ''  ||  event.length<this.chassisMin || event.length>this.chassisMax) {
      
    this.insuredDetailForm.get('rg_model_year').setValue('');
    this.insuredDetailForm.get('rg_mode_make')?.setValue('');
    this.insuredDetailForm.get('rg_vhcl_model')?.setValue('');
    this.insuredDetailForm.get('adtnl_detail_bodyType').setValue('');
    this.insuredDetailForm.get('adtnl_detail_trim').setValue('');
            
    this.insuredDetailForm.get('adtnl_detail_engine').setValue('');
    this.insuredDetailForm.get('CC').setValue('');
    this.insuredDetailForm.get('loading_capacity').setValue('');
   
      
      //this.blankChassis = true;
      return false;
    }

  
    // this.blankChassis = false;
    this.showLoader.chasisNoButton = true;

    this.insuredDetailForm.get('rg_model_year').setValue('');
    this.insuredDetailForm.get('rg_mode_make')?.setValue('');
    this.insuredDetailForm.get('rg_vhcl_model')?.setValue('');
    this.insuredDetailForm.get('adtnl_detail_bodyType').setValue('');
    this.insuredDetailForm.get('adtnl_detail_trim').setValue('');
            
    this.insuredDetailForm.get('adtnl_detail_engine').setValue('');
    this.insuredDetailForm.get('CC').setValue('');
    this.insuredDetailForm.get('loading_capacity').setValue('');
    this.insuredDetailForm.get('adtnl_detail_cylinder').setValue('');

    this.motorQuoteService.validateChassisNumber(event,this.partnerId,this.userId,this.sideForm.value.schemeCode,"R").subscribe(res => {
      let validateRes = res;
      
      this.showLoader.chasisNoButton = false;
     
      if (validateRes.validateChassisNumber == 'W') {
        Swal.fire(validateRes.validateChassisMessage);
        this.showLoader.chasisNoButton = false;

       // this.insuredDetailForm.get('isChassisValidate')?.setValue('');
      //  this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
       // return false;
      }
      else if(validateRes.validateChassisNumber == 'A' || validateRes.validateChassisNumber == 'BOR') {

       
        this.showLoader.chasisNoButton = true;
      //  if(this.insuredDetailForm.value.adtnl_detail_insType.ProductShortName!='THIRD PARTY LIABILITY')
        this.motorQuoteService.getDetailsByVIN(event,this.sideForm.value.schemeCode,0,this.insuredDetailForm.value.adtnl_detail_brandNew).subscribe(async res => {
          this.showLoader.chasisNoButton = false;

          if(res.vechileData.StatusCode==500) { this.insuredDetailForm.controls['rg_model_year'].disable(); return false ; }
          else  this.insuredDetailForm.controls['rg_model_year'].enable();

      //     const schems = [ "66A","66S", "66RK", "66Q" ];

      // if(schems.includes(this.sideForm.value.schemeCode)) return false;
          /**  if scheme code block edata  */
          this.isHideChassisNo = false ;

          if(res.response_code==2 || res.response_message == "Failed"	)  { this.showLoader.chasisNoButton = false; return false ; }


           if(res.response_code==5){
              this.isHideChassisNo = false ;
              this.insuredDetailForm.get('rg_chassis_num').setValue('');
              this.modelYearRang();
              Swal.fire(" ", res.response_message, "error");
              return false ;
            }

            if(res.validateChassisNumber=="E"){
              this.isHideChassisNo = false ;
              this.insuredDetailForm.get('rg_chassis_num').setValue('');
              this.modelYearRang();
           //  Swal.fire(" ", res.response_message, "error");
              return false ;
            }


          if(res.response_code==0 && res.access.ParameterValue=="NO"){
            this.isHideChassisNo = true ;

            this.insuredDetailForm.get('rg_model_year').setValue('');
            this.insuredDetailForm.get('rg_mode_make').setValue('');
            this.insuredDetailForm.get('rg_vhcl_model').setValue('');
            this.insuredDetailForm.get('adtnl_detail_bodyType').setValue('');
            this.insuredDetailForm.get('adtnl_detail_trim').setValue('');
            
            this.insuredDetailForm.get('adtnl_detail_engine').setValue('');
            this.insuredDetailForm.get('CC').setValue('');
            this.insuredDetailForm.get('loading_capacity').setValue('');
            this.insuredDetailForm.get('adtnl_detail_cylinder').setValue('');
            return false ;
          }


          this.isClickChassisValidate = true ;
          this.getVechileDetailData = res.vechileData;
          this.chassis_No_Details = res.vechileData.VehicleDetails;
          this.importEdata = res.import?.Report;
          this.quoteDetail = this.getVechileDetailData;



          if (res.vechileData.StatusCode == 400 || res.vechileData.StatusCode == 422 || res.vechileData.ExpiresIn == 1200) {

           
              // Need to write logic 

          }else{

            
              this.fillFormWithEdataResponse();
              this.showLoader.chasisNoButton = false;

          }


        }) // getDetailsByVIN closing
       
        
          return true;
      }else {
        this.stepper.previous();
            Swal.fire(validateRes.validateChassisMessage);
            this.chassisStatus=false;
            this.validateStatus=false;
      
          //  return false
          }
        });
      }
  minlength=17;
  maxlength=17;
  getQuotationFormData(){

    this.motorQuoteService.getQuotationFormData().subscribe(response =>{
      // console.log(response);
      this.formDataRes = response;
      this.minlength = response.ChassisNoValidMin;
      this.maxlength = response.ChassisNoValidMax;
      this.partnersArr = this.formDataRes.Partners;
      // this.partnerBranchArr = this.formDataRes.branchList;
      // this.sideForm.get("partnerID")?.setValue(this.partnerId);
//  console.log(this.partnerId)
//  console.log(this.retrieveQuoteNumber )
      if(this.retrieveQuoteNumber !=='' ){
    
        // console.log(this.partnerId);
        this.sideForm.get("partnerID")?.setValue(this.partnerId);

        this.getPartnerBranchList();
     }


    });

  }

  getSchemesByProduct(){
    
    this.motorQuoteService.getSchemesByProduct('MT').subscribe(result=>{
    this.product_list = result.getSchemesByProduct;
    this.selectedschemecode = result.getSchemesByProduct[0].SchemeCode;
    if(result.getSchemesByProduct[0].SchemeCode== "65S" || result.getSchemesByProduct[0].SchemeCode == "65Q4"){
      // alert(1);
      // console.log(this.insuredDetailForm);
      this.insuredDetailForm.get('weight_empty').setValidators(null);
      this.insuredDetailForm.get('weight_full').setValidators(null);

      this.insuredDetailForm.get('weight_empty').updateValueAndValidity();
      this.insuredDetailForm.get('weight_full').updateValueAndValidity();
    }
    // console.log(this.selectedschemecode);
    this.sideForm.get("schemeCode")?.setValue(localStorage.getItem("Schemecode"));
    // console.log(result)
    let data =  localStorage.getItem("Schemecode");
    this.SchemeCode= localStorage.getItem("Schemecode")
  })
}


GetSchemesForRenewal(schemeCode){
    
  this.motorQuoteService.GetSchemesForRenewal('MT',schemeCode).subscribe(result=>{
  this.product_list = result.getSchemesByProduct;
  this.selectedschemecode = result.getSchemesByProduct[0].SchemeCode;
  if(result.getSchemesByProduct[0].SchemeCode== "65S" || result.getSchemesByProduct[0].SchemeCode == "65Q4"){
    // alert(1);
    // console.log(this.insuredDetailForm);
    this.insuredDetailForm.get('weight_empty').setValidators(null);
    this.insuredDetailForm.get('weight_full').setValidators(null);

    this.insuredDetailForm.get('weight_empty').updateValueAndValidity();
    this.insuredDetailForm.get('weight_full').updateValueAndValidity();
  }
  // console.log(this.selectedschemecode);
  this.sideForm.get("schemeCode")?.setValue(localStorage.getItem("Schemecode"));
  // console.log(result)
  let data =  localStorage.getItem("Schemecode");
  this.SchemeCode= localStorage.getItem("Schemecode")
})
}


  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
        event.preventDefault();
    }
}

  getVehicleCapacity(){
    this.scheme_code = this.sideForm.value.schemeCode;
    this.partnerID = this.sideForm.value.partnerID;
    this.motorQuoteService.getVehicleCapacity(this.sideForm.value.schemeCode, this.partnerID).subscribe(result =>{
      // console.log(result.response_data[0].VehicleCapacityValue);
      this.weight = result.response_data;
      // console.log(this.weight);
    })
  }

  getOccupation(){
    this.motorQuoteService.getOccupation('MT').subscribe(res=>{
      this.occupatindata = res.response_data;
      // console.log(  this.occupatindata);

      this.OccupationTypeFilter.next(this.occupatindata);
      // console.log(  this.OccupationTypeFilter);
    });
  }

  onPrevInsExpdateChange(){

       // if(this.convertDate(this.insuredDetailForm.value.polStartDate) > this.convertDate(this.insuredDetailForm.value.rg_ins_exp)){

        if(this.convertDate(this.insuredDetailForm.value.rg_ins_exp) >= this.convertDate(this.toDay) && this.convertDate(this.insuredDetailForm.value.polStartDate) >= this.convertDate(this.toDay)){
          let insExpDate =  new Date(new Date(this.insuredDetailForm.value.rg_ins_exp).setDate(new Date(this.insuredDetailForm.value.rg_ins_exp).getDate() + 1));
                if(this.convertDate(insExpDate) >= this.convertDate(this.insuredDetailForm.value.polStartDate)){
                      return true;
                }
                if(this.convertDate(this.insuredDetailForm.value.polStartDate) > this.convertDate(insExpDate))
                {
                  Swal.fire('', 'Invalid start date and/or previous insurance expiry date.', 'error');
                  return false;

                }
        }else{
                Swal.fire('', 'Iinvalid start date or previous insurance exp date.', 'error');
                return false;
        }


              // this.insuredDetailForm.get('polStartDate')?.setValue(insExpDate);
       // }
  }
  //------------------------------- VALIDATION FOR EMIRATES ID ----------------------------------------------//
  checkEID(value) {
    // console.log(this.insuredDetailForm);
    value = this.insuredDetailForm.value.e_eid;
    // console.log(value);
    this.value = value;
    // console.log(this.value)
    this.value = this.value.replace(/-/g, "");
    let pattern = /^784-?[0-9]{4}-?[0-9]{7}-?[0-9]{1}$/;
    // alert("pattern");
    // console.log(pattern.test(this.value));
    if (pattern.test(this.value) == false)  {
      // alert("id is invalid");
      this.invalidEID = false;
    }
    else{
      this.invalidEID = true;
    }
    return;
        // if  
        if(this.invalidEID = true){
          Swal.fire('Please Enter Valid Emirates Id', '', 'info')
        }
    if (this.value == "111111111111111" || this.value == "000000000000000" || this.value == "222222222222222" || this.value == "333333333333333") {
      this.invalidEID = false;
      this.insuredDetailForm.get("eIDCheck")?.setValue('1');

      // return this.invalidEID;
    }

    else {
      //The Luhn Algorithm.
      var nCheck = 0, nDigit = 0, bEven = false;
      this.value = this.value.replace(/\D/g, "");


      //784-1982-6961498-2

      for (let n = this.value.length - 1; n >= 0; n--) {

        var cDigit = this.value.charAt; nDigit = parseInt(this.value[n]);

        if (bEven) {
          if ((nDigit *= 2) > 9)
            nDigit -= 9;
        }

        nCheck += nDigit;
        bEven = !bEven;



      }

      if ((nCheck % 10) == 0) {
        //if valid, ok, check next
        this.invalidEID = false;
        this.insuredDetailForm.get("eIDCheck")?.setValue(1);

        return this.invalidEID;

      }
      else {
        this.invalidEID = true;
        this.insuredDetailForm.get("eIDCheck")?.setValue('');

        return this.invalidEID;
        //alert('Invalid Emirates ID. Please enter valid emirates Id including (-) dash/hypen.');
      }



    }

  }
  
  //---------------------- VALIDATION FOR NUMBERS & DECIMAL NUM ----------------------------------------//
  checkValidInputData(event: any, type) {
    // console.log(type);

    this.globalService.checkValidInputData(event, type);
  }
  preventAllEvents(event: any) {

    this.globalService.preventAllEvents(event);
  }

 

  check_valueChange(amount){
if(this.insuredDetailForm.controls.v_value.errors){
// console.log(amount);
Swal.fire({
  title: 'Invalid Sum Insured ',
  text: 'Sum Insured entered is out of defined range. If you wish to continue with the entered Sum Insured, the quote will be referred to UW. Do you wish to continue?',
  // type: "warning",
  showCancelButton: true,
  confirmButtonText: 'Yes',
  cancelButtonText: 'No'
}).then((result) => {
  if (result.value) {
    this.referalStatus=true;
    // this.insuredDetailForm.get('v_value').setValidators(Validators.required);
}
else if (result.dismiss === Swal.DismissReason.cancel) {
  Swal.fire('Cancelled','', 'error');
  this.insuredDetailForm.get('v_value')?.setValue(amount);
}
else{
  
  // this.insuredDetailForm.get('v_value').setValidators(null);

}
// this.insuredDetailForm.get('v_value').updateValueAndValidity();
     });
}



  }
  //------------------------------------- SAVE POLICY DETAIL (SAVE IN DATABASE)---------------------------------------------//
  savePolicyDetail(type) {
    //this._route.navigateByUrl('/motorquote/thankyou');
    var gender = "";
    if(this.insuredDetailForm.value.e_gender){
      gender =  this.insuredDetailForm.value.e_gender.value;

    }

    let policyDetail = {
      quotation_number: this.webQuoteNumber,
      CRS_quotation_number: this.quoteNumber,
      traffic_code: this.insuredDetailForm.value.rg_TC_num,
      license: this.insuredDetailForm.value.d_driv_lic_num,
      emirates: this.insuredDetailForm.value.rg_place_issue,
      address: this.insuredDetailForm.value.adtnl_detail_address,
      PO_box: this.insuredDetailForm.value.adtnl_detail_poBoxNum,
      occupation: '',
      national_id: this.insuredDetailForm.value.e_eid,
      arabic_name: '',
      home_office_number: '',
      start_date: this.convertDate(this.insuredDetailForm.value.polStartDate),
      end_date: '22/12/2019',
      color: '',
      chassis_no: this.insuredDetailForm.value.rg_chassis_num,
      engine: this.insuredDetailForm.value.rg_engin_num,
      plate: '54687',
      mortgage: this.insuredDetailForm.value.rg_mortgage,
      payment_mode: 'ONLINE',
      named_driver: this.insuredDetailForm.value.e_name,
      additional_driver_under_age: '0',
      IP_address: '',
      mobile: this.insuredDetailForm.value.adtnl_detail_mobile,
      code: this.insuredDetailForm.value.adtnl_detail_mbCode,
      driving_License_Front: this.insuredDetailForm.value.driving_Lic_Front,
      driving_license_Back: '',
      Reg_Card_Front: this.insuredDetailForm.value.reg_Card_Front,
      Reg_Card_Back: this.insuredDetailForm.value.reg_Card_Back,
      EID_Front: this.insuredDetailForm.value.emirated_ID_Front,
      EID_Back: this.insuredDetailForm.value.emirated_ID_Backk,
      dealer_quote: '',
      vhclPlateCategory: this.insuredDetailForm.value.rg_type,
      plateCode: this.insuredDetailForm.value.rg_plateCode,
      plateNumber: this.insuredDetailForm.value.rg_traffic_plate_num,
      area: this.insuredDetailForm.value.adtnl_detail_area,
      noOfDoors: this.nofDoors,
      gender: gender,
      nationality: this.insuredDetailForm.value.e_nationality,
      source :'B2B'

    }

    this.motorQuoteService.savePolicyDetail(policyDetail, this.quoteDetailArr).subscribe(res => {

      if (type == 2) {

      }


    });
  }
  //----------------------------------------- SAVE ADDITIONAL INFO (THIRD PARTY API)--------------------------------------------------------
  saveAdditionalInfo(type) {

  let name = this.insuredDetailForm.value.e_name;

    this.motorQuoteService.saveAdditionalInfo(this.quoteNumber, this.webQuoteNumber, this.insuredDetailForm.value.rg_mortgage, 'N', name, this.insuredDetailForm.value.adtnl_detail_insType, this.insuredDetailForm.value.rg_engin_num, this.insuredDetailForm.value.e_gender.value, this.PaymentMode,'B2B').subscribe(res => {
      if (res.response_code == 1) {

        if (type == 1) {
          //this.savePolicyDetail(1);
        }

        if (type == 2) {

          let vatAMt = (this.totalFixPremium + this.totalVariablePremium) * 0.05;
          let total_premium = this.totalFixPremium + this.totalVariablePremium + vatAMt;
          let loadingAmt = this.calculBy == 1 ? this.loadingByPercent : this.loadByAmount;
          this.savePlanDetailArr = {
            quotation_number: this.webQuoteNumber,
            plan_id: this.plan_Id,
            total_premium: total_premium,
            base_premium: Math.round(this.totalFixPremium),
            optional_benefit_premiun: this.totalVariablePremium,
            admin_fees: this.policyFee,
            CRS_quote_number: this.quoteNumber,
            service_fees: 0,
            product_code: this.insuredDetailForm.value.adtnl_detail_insType,
            VAT: vatAMt,
            benefitPreId: this.benfPremIdArray,
            calculation_type : this.calculBy,
            loading_by : this.loadingBy,
            loading_amount  : loadingAmt,
            loadis_rate : this.loading_rate,
            premiumGarageAmount : this.repairLoadingAmt,
            // dedctible:this.step2.value.adminDeductible,
            
          }

          this.motorQuoteService.insertPlanData(this.PlanDataJson.quotationNumber, this.PlanDataJson.PlanDataJson, Math.round(this.totalFixPremium),
          this.totalVariablePremium,
          this.policyFee,
          total_premium,
          this.PlanDataJson.planBenefitData.data,
          // this.step2.value.adminDeductible,
          this.PlanDataJson.planBenefitData.benefit_data,
          this.insuredDetailForm.value.adtnl_detail_repairTye,
          this.savePlanDetailArr,
          this.insuredDetailForm.value.adtnl_detail_insType.viewValue,
          'B2B',
          this.sideForm.value.schemeCode,'','','','',this.contrinutionData
          ).subscribe(res => {

            if(res.response_code==99 || res.response_code==909){

              Swal.fire("", res.show_message, 'error');
              this.showLoader.Quotation = false;
              return false ;
            }

          });



          // FOR PAYMENT



          let return_url = "http://k2key.in/motor_ins//dashboard";
          let site_url = "http://k2key.in/motor_ins/" + this._route.url;

          //this.paymentLoader = this.globalService.spinnerShow();
          this.showLoader.Quotation = true;

          this.motorQuoteService.paymentAuth(this.webQuoteNumber, site_url, return_url, 'MT', '1', '', 'B2B').subscribe(res => {
            let payRes = res;

            // if (payRes.res_code == 101) {
            //   Swal.fire(payRes.res_msg);
            //   // this.paymentLoader = this.globalService.spinnerHide();
            //   this.showLoader.Quotation = false;
            //   return false;
            // }

            // else if (payRes.result.response_code == 4012 && payRes.res_code == 1) {

            //   //this.paymentLoader = this.globalService.spinnerHide();
            //   this.showLoader.Quotation = false;
            //   localStorage.setItem('Payment_Order_ID', payRes.result.p_id);
            //   localStorage.setItem('Payment_Order_Tokan', payRes.result.token);
            //   localStorage.setItem('Payment_Quotation_Number', this.webQuoteNumber);

            //   window.location.href = payRes.result.payment_url;

            // }

            if(payRes.res_code == 101){
              // alert(payRes.res_msg);
              // this.paymentLoader = this.globalService.spinnerHide();
              return false;
        }

        else if( payRes.res_code == 1 ){

              // this.paymentLoader = this.globalService.spinnerHide();
              // localStorage.setItem('Payment_Order_ID',payRes.result.p_id);
              // localStorage.setItem('Payment_Order_Tokan',payRes.result.token);
              // localStorage.setItem('Payment_Quotation_Number',this.quoteNum);

              //   window.location.href = payRes.result.payment_url;

              this.trans_ref = payRes.result.tran_ref;
              localStorage.setItem('Trans_Ref',this.trans_ref);
              localStorage.setItem('TokenId',payRes.result.token);
              // console.log( this.webQuoteNumber)
              localStorage.setItem('Payment_Quotation_Number', this.webQuoteNumber);
              // this.paymentLoader = this.globalService.spinnerHide();
                window.location.href = payRes.result.redirect_url;


            }


          });
        }

        if (type == 3) {

          this.approvePolicyRequest();    // for issue policy

        }

        if (type == 4) {

          this.sendPaymentLink();    // for send payment link

        }


      }

    });

  }
  //------------------------------------ SEND PAYMENT LINK ------------------------------------------//
  sendPaymentLink() {

    this.motorQuoteService.sendPaymentLink(this.webQuoteNumber, 'MT', this.payLink_email,'B2B',this.quoteNumber,'').subscribe(res => {

      let payRes = res;

      if (payRes.res_code == 1) {

        // this.motorQuoteService.sendReferralMailToAdmin(this.webQuoteNumber, '', this.emailadd,'QUOTECONFIRMED', '',this.tempMultipleDocData,'','').subscribe(res => {

        // });
        Swal.fire('', 'Payment link has been sent to customer for the reference no. ' + this.webQuoteNumber, 'success');

        this._route.navigate(['motorscheme']);

      }
      this.showLoader.Quotation = false;
    });
  }

  getAllmenuData() {

    this.motorQuoteService.getAllFormData(this.emailCode).subscribe(res => {
      this.Alldata = res;

    });
  }
  //------------------------------------ VIEW POLICY SUMMARY ------------------------------------------//
  viewPolicySummary(PolicyNumber) {
    this.motorQuoteService.viewPolicySummary(this.quoteNumber, this.webQuoteNumber, 'B2B', PolicyNumber).subscribe(res => {
      if (res.response_code == 1) {
        this.showLoader.Quotation = false;
        this.policy_number = res.policy_number;
        localStorage.setItem("Policy_Number", this.policy_number);
        if (this.isQuoteConfrimClicked) {
          let extraField = { sumInc: this.sumInc, chgDeduct: this.chgDeduct, optBenfit: this.optBenfit, supportingDoc: this.multiGap }
          this.motorQuoteService.sendReferralMailToAdmin(this.webQuoteNumber, encodeURIComponent(this.referalDescription), this.emailadd, "QUOTE CONFIRM", '', this.referral_reason, this.tempMultipleDocData, this.refAdditionalCondition, extraField).subscribe(res => {
          });
        }
        this._route.navigate(['motor/thankyou/']);
      }
    });
  }

  insertPolicy() {

    let motorPolicyValuesArray = {


      cedant_id:"3",
      user_id:this.userId,
      patner_id:"1",
      customer_id:"1",
      branch_id:"1",
      traffic_code:"4213524",
      license:"8768766",
      emirates:"144",
      address:"Dubai",
      PO_box:"43534",
      occupation:"Accounts Manager",
      national_id:"12",
      arabic_name:"راهول",
      home_office_number:"0558798799",
      start_date:"2020-08-13 04:26:14.870",
      end_date:"2020-08-13 04:26:14.870",
      color:"2",
      chassis:"JN8AY2NY8E9073146",
      engine:"4FGFR344F",
      body_type:"2",
      plate:"34124",
      mortage:"company ",
      payment_mode:"ONLINE",
      named_driver:"Said El Hage Ahmad",
      additional_driver_under_age:"34",
      IP_address:"123.1231.241",
      mobile:"0558798799"


    }

    this.quotation_number= this.webQuoteNumber;

    this.motorQuoteService.insertPolicy(motorPolicyValuesArray,this.quotation_number).subscribe(res => {

      // this._route.navigateByUrl('agentMotor/MTquotepage/thankyou/' + this.policyNumber +"/"+ this.webQuoteNumber +"/"+" ");
      // res.policy_number
    this.viewPolicySummary(res.policyNumber[0].PolicyNumber);

    });
  }
  //----------------------------------- APPROVE POLICY REQUEST -------------------------------------//
  approvePolicyRequest() {

    this.motorQuoteService.approvePolicyRequest(this.quoteNumber, this.webQuoteNumber,'B2B').subscribe(res => {

      if (res.response_code == 1) {
        let polNum = res.approvePolicyRequest.PolNo;
        let policy_uid = res.approvePolicyRequest.PolicyUid;

        localStorage.setItem('Payment_Quotation_Number', this.webQuoteNumber);
        localStorage.setItem('CRS_Quotation_Number',this.quoteNumber);

        if(polNum == '' || polNum == null || polNum == undefined){
          localStorage.removeItem('Policy_Number');
          localStorage.removeItem('Policy_UID');
        }else{
          localStorage.setItem('Policy_Number', polNum);
          localStorage.setItem('Policy_UID', policy_uid);
        }

        this.insertPolicy();
      }

    },
    (error) => {
      localStorage.removeItem('Policy_Number');
      localStorage.removeItem('Policy_UID');
      localStorage.setItem('Payment_Quotation_Number', this.webQuoteNumber);
      localStorage.setItem('CRS_Quotation_Number',this.quoteNumber);
      this._route.navigate(['/motor/thankyou/']);
    });
  }


  //---------------------------------------- GET PLATE CODE ARRAY -----------------------------//
  getPlateCode(regPlaceId, type) {
  

    let plateSource = regPlaceId;
    

    if (typeof (plateSource) != undefined && typeof (plateSource) != "undefined") {
      this.motorQuoteService.getPlateCode(this.language_code, plateSource,this.insuredDetailForm.value.rg_type).subscribe(res => {

        this.plateCodeArray = res.plateCodeData;

        if(this.insuredDetailForm.value.adtnl_detail_brandNew == 1 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined"){
              var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
                return obj.PlateCode == "NEW NUMBER";
              });
              let plCodeVal = this.plateCodeArray[indexPlCode];
              this.insuredDetailForm.get('rg_plateCode')?.setValue(plCodeVal);
        }

        if (type == 2 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined" && this.quoteDetail?.plateCode) {
          //Plate COde
          let plateCode = this.quoteDetail.plateCode;

          var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
            return obj.PlateCode === plateCode;
          });
          let plCodeVal = this.plateCodeArray[indexPlCode];
          this.insuredDetailForm.get('rg_plateCode')?.setValue(plCodeVal);
        }

        if (type == 3 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined") {
          //Plate COde
          let plateCode = this.plate_code;
          if (plateCode != undefined) {
            var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
              return obj.PlateCode === plateCode;
            });
            let plCodeVal = this.plateCodeArray[indexPlCode];
            this.insuredDetailForm.get('rg_plateCode')?.setValue(plCodeVal);
          }
        }

        if(this.retrieveData && this.retrieveData.length!=0) {
          
          let item= '';
          this.plateCodeArray.forEach(element => {
            if(this.retrieveData[0].PlateCode)
            if( element.PlateCode == this.retrieveData[0].PlateCode){
              item = element;
            }
            
          });
          if(item!='')
          this.insuredDetailForm.get('rg_plateCode')?.setValue(item);
          
         }

      });

    

    }
    if(this.insuredDetailForm.value.rg_place_issue.CityName !="Dubai"){

      this.tcMin = 10 ; this.tcMax=10;
    }else{

      this.tcMin = 8 ; this.tcMax=8;
    }



  }


  getPlateCodeRenew(regPlaceId, type) {
  

    let plateSource = regPlaceId;
    

    if (typeof (plateSource) != undefined && typeof (plateSource) != "undefined") {
      this.motorQuoteService.getPlateCode(this.language_code, plateSource,type).subscribe(res => {

        this.plateCodeArray = res.plateCodeData;

        if(this.insuredDetailForm.value.adtnl_detail_brandNew == 1 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined"){
              var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
                return obj.PlateCode == "NEW NUMBER";
              });
              let plCodeVal = this.plateCodeArray[indexPlCode];
              this.insuredDetailForm.get('rg_plateCode')?.setValue(plCodeVal);
        }

        if (type == 2 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined" && this.quoteDetail?.plateCode) {
          //Plate COde
          let plateCode = this.quoteDetail.plateCode;

          var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
            return obj.PlateCode === plateCode;
          });
          let plCodeVal = this.plateCodeArray[indexPlCode];
          this.insuredDetailForm.get('rg_plateCode')?.setValue(plCodeVal);
        }

        if (type == 3 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined") {
          //Plate COde
          let plateCode = this.plate_code;
          if (plateCode != undefined) {
            var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
              return obj.PlateCode === plateCode;
            });
            let plCodeVal = this.plateCodeArray[indexPlCode];
            this.insuredDetailForm.get('rg_plateCode')?.setValue(plCodeVal);
          }
        }

        if(this.retrieveData && this.retrieveData.length!=0) {
          
          let item= '';
          this.plateCodeArray.forEach(element => {
            if(this.retrieveData[0].PlateCode)
            if( element.PlateCode == this.retrieveData[0].PlateCode){
              item = element;
            }
            
          });
          if(item!='')
          this.insuredDetailForm.get('rg_plateCode')?.setValue(item);
          
         }

      });

    

    }
    if(this.insuredDetailForm.value.rg_place_issue.CityName !="Dubai"){

      this.tcMin = 10 ; this.tcMax=10;
    }else{

      this.tcMin = 8 ; this.tcMax=8;
    }



  }


  //------------------------------------------ GET VEHICLE VALUE -------------------------------------------------//
  updateValuation() {
    if(!this.isEditRetriveOnPageLoad) return false;
    if (this.vhcleValueFlag == false && this.insuredDetailForm.value.adtnl_detail_insType.CoreProdCode == '4001_1') {
      if (this.insuredDetailForm.value.rg_vhcl_make != '' && this.insuredDetailForm.value.rg_vhcl_model != '' && this.insuredDetailForm.value.adtnl_detail_trim != '' && this.insuredDetailForm.value.adtnl_detail_bodyType != '') {

        this.showLoader.VehicleValue = true;


        let vehicleDetailArray = {
          chassisNum: this.insuredDetailForm.value.rg_chassis_num,
          insType: this.insuredDetailForm.value.adtnl_detail_insType,
          repairType: this.insuredDetailForm.value.adtnl_detail_repairTye.RepairType,
          vhclBodyType: this.insuredDetailForm.value.adtnl_detail_bodyType,
          vhclCylinder: this.insuredDetailForm.value.adtnl_detail_cylinder,
          vhclGCCSpecifird: this.insuredDetailForm.value.adtnl_detail_gccSpecified,
          vhclMake: this.insuredDetailForm.value.rg_vhcl_make,
          vhclModel: this.insuredDetailForm.value.rg_vhcl_model,
          vhclModelYr: this.insuredDetailForm.value.rg_model_year,
          vhclSeatCapcity: this.insuredDetailForm.value.rg_num_passenger,
          vhclTrim: this.insuredDetailForm.value.adtnl_detail_trim,
          engine:this.vehicleData,
          SchemeCode: this.sideForm.value.schemeCode,
          PartnerId:this.sideForm.value.partnerID,
          isBrandNew:this.insuredDetailForm.value.adtnl_detail_brandNew
        }

        this.motorQuoteService.getMotorValuation(vehicleDetailArray).subscribe(res => {

          //  console.log(res.Valuation.Medium)
          if (res.StatusCode == 200) {
            this.existVehiclevalue = 0;
            this.vehicleValueLimit.isSet = true;
            this.referalStatus = false;
                  this.vehicleValueLimit.startLimit = Number(res.Valuation.Low);
                  this.vehicleValueLimit.endLimit = Number(res.Valuation.High);
            this.insuredDetailForm.get('v_value')?.setValue(res.Valuation.Medium);
            this.insuredDetailForm.get('v_value').setValidators([Validators.required,Validators.min(this.vehicleValueLimit.startLimit),Validators.max(this.vehicleValueLimit.endLimit)]);

              this.insuredDetailForm.get('v_value').updateValueAndValidity();


          } else {

            this.existVehiclevalue = 1;
            this.referalStatus = true;
            this.vehicleValueLimit.startLimit = 0;
            this.vehicleValueLimit.endLimit = 300000;
            // this.insuredDetailForm.get('v_value').setValidators([Validators.required]);
            // this.insuredDetailForm.get('v_value').updateValueAndValidity();
            this.insuredDetailForm.get('v_value')?.setValue('');
            this.vehicleValueLimit.isSet = false;

          }

          this.showLoader.VehicleValue = false;

        });
      }
    } else {
      this.vhcleValueFlag = false;
    }


  }

  changeChasisValidation(type) {

    // commented for timing
    if (this.checkChassisValidation == false) {
      this.insuredDetailForm.get('isChassisValidate')?.setValue('');
      if (type == 1) {
        this.insuredDetailForm.get('rg_model_year')?.setValue('');
        this.insuredDetailForm.get('rg_vhcl_make')?.setValue('');
        this.insuredDetailForm.get('rg_vhcl_model')?.setValue('');
        this.insuredDetailForm.get('adtnl_detail_trim')?.setValue('');
        this.insuredDetailForm.get('adtnl_detail_bodyType')?.setValue('');
        this.insuredDetailForm.get('adtnl_detail_cylinder')?.setValue('');
        this.insuredDetailForm.get('rg_num_passenger')?.setValue('');
        this.insuredDetailForm.get('adtnl_detail_brandNew')?.setValue('0');
        this.insuredDetailForm.get('rg_plateCode')?.setValue('');

      }
    } else {
      this.checkChassisValidation = false;
    }

  }
  //--------------------------Duplicate Chassis Number-------------
  // ValidateChassis(chassisNo){
  //   this.motorQuoteService.ValidateChassis(chassisNo).subscribe(res=>{
  //     // console.log(res);
  //   })
  // }

//------------------------------------- VALIDATE CHASSIS NUMBER ------------------------------------------------------------//
  // validateChassisNum(chassisNo, stepper, type) {
  //   // this.validChassisNum = true;

  //   if (chassisNo == '') {
  //     //this.blankChassis = true;
  //     return false;
  //   }

  //   // this.vehicleDetailForm.get('isChassisValidate')?.setValue('');
  //   // this.additionalDetailForm.get('isChassisValidate')?.setValue('');
  //   // let stepperD = stepper;



  //   // this.blankChassis = false;
  //   this.showLoader.chasisNoButton = true;
  //   this.motorQuoteService.validateChassisNumber(chassisNo).subscribe(res => {
  //     let validateRes = res;

  //     if (validateRes.validateChassisNumber == '1') {
  //       this.showLoader.chasisNoButton = false;

  //       this.insuredDetailForm.get('isChassisValidate')?.setValue('');
  //       this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
  //       return false;
  //     } else {

  //       this.motorQuoteService.getDetailsByVIN(chassisNo).subscribe(res => {
  //         this.showLoader.chasisNoButton = false;
  //         this.getVechileDetailData = res.vechileData;
  //         this.chassis_No_Details = this.getVechileDetailData.VehicleDetails;

  //         if (res.vechileData.StatusCode == 400 || res.vechileData.StatusCode == 422 || res.vechileData.ExpiresIn == 1200) {
  //           Swal.fire(" ", "Invalid Chassis No.", "error");
  //           if (type == 1) {
  //             this.insuredDetailForm.get('isChassisValidate')?.setValue('');
  //             this.insuredDetailForm.get('rg_vhcl_make')?.setValue('');
  //             this.insuredDetailForm.get('rg_model_year')?.setValue('');
  //             this.insuredDetailForm.get('rg_num_passenger')?.setValue('');
  //             this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue('');
  //             this.insuredDetailForm.get('rg_vhcl_model')?.setValue('');
  //             this.insuredDetailForm.get('adtnl_detail_trim')?.setValue('');
  //             this.insuredDetailForm.get('adtnl_detail_bodyType')?.setValue('');
  //             this.insuredDetailForm.get('adtnl_detail_cylinder')?.setValue('');
  //             this.insuredDetailForm.get('adtnl_detail_vhclValue')?.setValue('');
  //             this.insuredDetailForm.get('rg_chassis_num')?.setValue('');

  //           }

  //         }

  //         else {

  //           if (this.insuredDetailForm.value.rg_chassis_num != '') {
  //             this.insuredDetailForm.get('isChassisValidate')?.setValue('1');


  //             //VEHICLE YEAR
  //             let yearVal;
  //             this.vehimodelyrs.forEach((item, index) => {

  //               if (item.label == this.getVechileDetailData.VehicleDetails.General.ModelYear) {
  //                 yearVal = item;
  //               }
  //             });

  //             this.insuredDetailForm.get('rg_model_year')?.setValue(yearVal);
  //             console.log(this.getVechileDetailData.VehicleDetails.General.Make);
  //             this.getVhclMakeData(this.getVechileDetailData.VehicleDetails.General.Make, this.getVechileDetailData.VehicleDetails.General.ModelYear, 1)

  //             //VEHICLE Make ----- filter
  //             // let makeVal
  //             // this.vhclMakeArr.forEach((item, index) => {

  //             //   if (item.VehicleMakeName == this.getVechileDetailData.VehicleDetails.General.Make) {
  //             //     makeVal = item;
  //             //   }
  //             // });
  //             // this.insuredDetailForm.get('rg_vhcl_make')?.setValue(makeVal);

  //             // this.onVehiclAgeChange(yearVal);

  //          //   Vehicle Cylinders
  //             let cylVal;
  //             this.vehicylinders.forEach((item, index) => {

  //               if (item.Id == this.getVechileDetailData.VehicleDetails.Technical.EngineCylinders) {
  //                 cylVal = item;
  //               }
  //             });
  //             this.insuredDetailForm.get('adtnl_detail_cylinder')?.setValue(cylVal);

  //             //Passenger Count
  //             let PasgerVal;

  //             this.vehiseatcaps.forEach((item, index) => {
  //               if (item.value == (this.getVechileDetailData.VehicleDetails.General.NoOfSeats - 1)) {
  //                 PasgerVal = item;
  //               }
  //             });
  //             this.insuredDetailForm.get('rg_num_passenger')?.setValue(PasgerVal);

  //             this.GCC_Specification = this.getVechileDetailData.VehicleDetails.General.Region;
  //             if(this.getVechileDetailData.VehicleDetails.General.Region != '' && this.getVechileDetailData.VehicleDetails.General.Region != null){
  //                   let gcc_specification = this.getVechileDetailData.VehicleDetails.General.Region == 'GCC' ? 'No' : 'Yes';
  //                   this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue(gcc_specification);

  //             }else{
  //               this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue('');
  //             }


  //             //Vehicle Color
  //             if (this.getVechileDetailData.VehicleDetails.General.ColourEN != '') {
  //               let colorVal;
  //               this.vhclColorArr.forEach((item, index) => {
  //                 if (item.ColorName == this.getVechileDetailData.VehicleDetails.General.ColourEN) {
  //                   colorVal = item;
  //                 }
  //               });

  //               this.insuredDetailForm.get('vhclColor')?.setValue(colorVal);
  //             }

  //             let enginNo = this.getVechileDetailData.VehicleDetails.General.EngineNo;
  //             this.insuredDetailForm.get('rg_engin_num')?.setValue(enginNo);

  //             this.nofDoors = this.getVechileDetailData.VehicleDetails.General.NoOfDoors;
  //           }


  //         }


  //       });

  //     }
  //   });
  // }

  vehicalsearchClose() {
    this.dialog.closeAll();
  }

  searchVehicle() {
     this.dialog.open(this.callAPIDialog1);
  }

  nonEditableFields(GCC_Specification){

      if(GCC_Specification != '' && GCC_Specification != null){
                return true;
      }
 }

  checkBrandNew() {

    if(this.insuredDetailForm.value.rg_model_year.label<new Date().getFullYear() && this.insuredDetailForm?.value?.adtnl_detail_brandNew == 1){


      Swal.fire({
        title: 'Do you want to change from  used to Brand new , confirming mileage is Zero (0) ?',
        showDenyButton: true,
       
        confirmButtonText: 'Yes',
     
      }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          this.insuredDetailForm.get('rg_reg_date')?.setValidators(null);

            this.transactionTypeArray = [];
            this.transactionTypeArray.push(this.tempTransactionTypeArr[0]);
            this.insuredDetailForm.get('transaction_type')?.setValue(this.transactionTypeArray[0]);
        } else if (result.isDenied) {

          this.insuredDetailForm.get('adtnl_detail_brandNew').setValue('0');
          
        
        }
      })

    }else{


    // console.log(this.insuredDetailForm?.value?.adtnl_detail_brandNew);
        if (this.insuredDetailForm?.value?.adtnl_detail_brandNew == 1) {
          this.insuredDetailForm.get('rg_reg_date')?.setValidators(null);

            this.transactionTypeArray = [];
            this.transactionTypeArray.push(this.tempTransactionTypeArr[0]);
            this.insuredDetailForm.get('transaction_type')?.setValue(this.transactionTypeArray[0]);
        }else{
            this.transactionTypeArray = [];
            this.transactionTypeArray.push(this.tempTransactionTypeArr[1]);
            this.transactionTypeArray.push(this.tempTransactionTypeArr[2]);
            this.insuredDetailForm.get('transaction_type')?.setValue(this.transactionTypeArray[0]);
        }


      
        this.insuredDetailForm.get('rg_reg_date')?.updateValueAndValidity();

        this.insuredDetailForm.get('rg_plateCode')?.setValue(''); }
  }

  checkMulkiyaCopy() {
    if (this.insuredDetailForm.value.MulkhiyaStatus == '0') {
      this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue('');
      this.insuredDetailForm.get('rg_model_year')?.setValue('');
      this.insuredDetailForm.get('rg_num_passenger')?.setValue('');
      this.insuredDetailForm.get('rg_origin')?.setValue('');
      this.insuredDetailForm.get('adtnl_detail_cylinder')?.setValue('');
    //  this.insuredDetailForm.get('rg_expiry_date')?.setValue('');
      this.insuredDetailForm.get('rg_ins_exp')?.setValue('');
      this.insuredDetailForm.get('rg_policy_num')?.setValue('');
      this.insuredDetailForm.get('rg_reg_date')?.setValue('');
      this.insuredDetailForm.get('rg_TC_num')?.setValue('');
      this.insuredDetailForm.get('rg_traffic_plate_num')?.setValue('');
      this.insuredDetailForm.get('rg_chassis_num')?.setValue('');
      this.insuredDetailForm.get('isChassisValidate')?.setValue('');
      this.insuredDetailForm.get('rg_engin_num')?.setValue('');
      this.insuredDetailForm.get('rg_vhcl_model')?.setValue('');
      this.insuredDetailForm.get('adtnl_detail_trim')?.setValue('');
      this.insuredDetailForm.get('adtnl_detail_bodyType')?.setValue('');
      this.insuredDetailForm.get('rg_vhcl_make')?.setValue('');
      this.insuredDetailForm.get('reg_Card_BackFilePath')?.setValue('');
      this.insuredDetailForm.get('reg_Card_FrontFilePath')?.setValue('');
    } else {
      this.insuredDetailForm.get('supporting_DocumentFilePath')?.setValue('');
    }
  }

  //--------------------------------- ON MODEL YEAR CHANGE -------------------------------------//
  onVehiclAgeChange(vhclYear) {

// console.log(vhclYear)
    var d = new Date(this.insuredDetailForm.value.rg_reg_date);
    let firstRegYear: number = d.getFullYear();

    var p = new Date(this.insuredDetailForm.value.polStartDate);
    let policyStartDateYear: number = p.getFullYear();

    let vhclNextYear = Number(vhclYear) + 2;
    let vhclPrevYear = Number(vhclYear) -2;
    let schemeYear = Number(firstRegYear) - Number(vhclYear);

    this.regMinDate = new Date(vhclPrevYear, 0, 1);

    let currDate = new Date();
    if(Number(vhclYear)+2 >=currDate.getFullYear())
    {
      this.regMaxDate = new Date();

    }else
    this.regMaxDate = new Date(Number(vhclYear)+2, 11, 30);
    // this.regMaxDate = new Date();
    // console.log(this.regMaxDate);

    let vhclAge = this.year - vhclYear;


    let timeDiff = Math.abs(this.insuredDetailForm.value.rg_reg_date - this.insuredDetailForm.value.polStartDate);
    let days_difference =  Math.floor(timeDiff / (1000 * 60 * 60 * 24));

    let  D1 = Math.ceil(1 + (days_difference/397)); //this will give you years
    let  D2 = (Number(policyStartDateYear) - Number(vhclYear)) ;
       this.vehicle_age = Math.max(D2,D1);
    // let D3 = Math.abs(D2 - D1);
    // if(D3 == 1){
    //   this.vehicle_age = D1;
    // }
    // else{
    //   this.vehicle_age = Math.max(D2,D1);
    // }
    // console.log(  this.vehicle_age);
 

  }

   engineDefaultValue = "";
   isUpdateValuation = true ;
   isEditGCC =  false;
  

 

  getCylinder(){
    this.motorQuoteService.getCylinderData1().subscribe(res => {
      this.vehicylinders =res.cylinder;
      // console.log(  this.vehicylinders);
    });
  }

  onMulOptionDataChange(eve, i, mulOption) {

    this.PlanDataJson.planBenefitData.data[i].benefitSelectedData = eve;
    this.PlanDataJson.planBenefitData.data[i].multiOptID = eve.BenefitId;
    this.PlanDataJson.planBenefitData.data[i].Price = eve.Price;
    this.PlanDataJson.planBenefitData.data[i].checked = false;
    this.addOptionalBenigits(1, 2);
  }

  //---------------------------- GET DOCUMENTS DATA FOR RETRIEVE -----------------------------------------------------------//
  getDataForEditQuoteDocs(quoteNumber) {
    this.motorQuoteService.getDataForEditQuoteDoc(quoteNumber).subscribe(res => {


      this.editQuoteDocs = res.getDataForEditQuoteDoc;


      if(res.response_message!="Failed"){


          this.editQuoteDocs.forEach((item, index) => {

            if(item.DocumentType=="Supporting Document")  this.viewSupportingDocument.push(item);
            var sDoc= false ;
            this.fileType = item.DocFileName.split(".");
            this.fileType = this.fileType[this.fileType.length - 1];
            this.fileType = this.fileType == "pdf" ? "PDF" : "IMG";
            if ((item.DocumentType != "Other" || item.DocumentType != "Additional_Doc") && item.DocFilePath != '') {
                    this.tempDocArray = this.editQuoteDocs;
              }

           //   console.log(this.editQuoteDocs[index].DocFilePath);
            if (item.DocumentType == "reg_Card_Front" && item.DocFilePath != '') {
              sDoc= true ;
              this.showLoader.reg_card_front = false;
              this.hideImages.reg_card_front = true;
              this.insuredDetailForm.get('reg_Card_FrontFilePath')?.setValue(this.editQuoteDocs[index].DocFilePath);
           //   console.log(this.insuredDetailForm.value.reg_Card_FrontFilePath)
              this.insuredDetailForm.get('reg_Card_FrontFileType')?.setValue(this.fileType);

            }

            if (item.DocumentType == "reg_Card_Back" && item.DocFilePath != '') {
              sDoc= true ;

              this.showLoader.reg_card_back = false;
              this.hideImages.reg_card_back = true;
              this.insuredDetailForm.get('reg_Card_BackFilePath')?.setValue(this.editQuoteDocs[index].DocFilePath);
              this.insuredDetailForm.get('reg_Card_BackFileType')?.setValue(this.fileType);
            }

            if (item.DocumentType == "emirated_ID_Front" && item.DocFilePath != '') {
              sDoc= true ;
              this.showLoader.emirates_Id_front = false;
              this.hideImages.emirates_Id_front = true;
              this.insuredDetailForm.get('emirated_ID_FrontFilePath')?.setValue(this.editQuoteDocs[index].DocFilePath);
              this.insuredDetailForm.get('emirated_ID_FrontFileType')?.setValue(this.fileType);
            }

            if (item.DocumentType == "emirated_ID_Back" && item.DocFilePath != '') {
              sDoc= true ;
              this.showLoader.emirates_Id_back = false;
              this.hideImages.emirates_Id_back = true;
              this.insuredDetailForm.get('emirated_ID_BackFilePath')?.setValue(this.editQuoteDocs[index].DocFilePath);
              this.insuredDetailForm.get('emirated_ID_BackFileType')?.setValue(this.fileType);
            }

            if (item.DocumentType == "driving_Lic_Front" && item.DocFilePath != '') {
              sDoc= true ;
              this.showLoader.driving_Lic_front = false;
              this.hideImages.driving_Lic_front = true;
              this.insuredDetailForm.get('driving_Lic_FrontFilePath')?.setValue(this.editQuoteDocs[index].DocFilePath);
              this.insuredDetailForm.get('driving_Lic_FrontFileType')?.setValue(this.fileType);
            }

            if (item.DocumentType == "driving_Lic_Back" && item.DocFilePath != '') {
              sDoc= true ;
              this.showLoader.driving_Lic_back = false;
              this.hideImages.driving_Lic_back = true;
              this.insuredDetailForm.get('driving_Lic_BackFilePath')?.setValue(this.editQuoteDocs[index].DocFilePath);
              this.insuredDetailForm.get('driving_Lic_BackFileType')?.setValue(this.fileType);

            }

            if (item.DocumentType == "trade_Licence" && item.DocFilePath != '') {
              sDoc= true ;
              this.showLoader.trade_Licence = false;
              this.hideImages.trade_Licence = true;
              this.insuredDetailForm.get('trade_LicenceFilePath')?.setValue(this.editQuoteDocs[index].DocFilePath);
              this.insuredDetailForm.get('trade_LicenceFileType')?.setValue(this.fileType);

            }

            if (item.DocumentType == "TRN_Certificate" && item.DocFilePath != '') {
              sDoc= true ;
              this.showLoader.TRN_Certificate = false;
              this.hideImages.TRN_Certificate = true;
              this.insuredDetailForm.get('TRN_CertificateFilePath')?.setValue(this.editQuoteDocs[index].DocFilePath);
              this.insuredDetailForm.get('TRN_CertificateFileType')?.setValue(this.fileType);

            }


            if ((item.DocumentType == "Other" ||   sDoc==false)  && item.DocFilePath != '') {
              this.showLoader.multipleDoc = false;
              this.hideImages.multipleDoc = true;

             this.multilpleFile = this.editQuoteDocs;
            //  console.log(  this.multilpleFile);
          //  this.multilpleFile.push(item);

              this.tempMultipleDocData = this.multilpleFile;

              this.multilpleFile.forEach((item1, index1) => {
                        let fileType = this.multilpleFile[index1].DocFileName.split(".");
                        fileType = fileType[fileType.length - 1];
                        fileType = fileType == "pdf" ? "PDF" : "IMG";
                        this.multilpleFile[index1].file = this.multilpleFile[index1].DocFilePath;
                        this.multilpleFile[index1].fileType = fileType;
                       
              });



            }


            if(item.DocumentType == "Additional_Doc"  && item.DocFilePath != ''){    //&& item.UploadedStage == "QUOTE_ADDINFO"
                  this.showLoader.additionalDoc = false;
                  this.hideImages.additionalDoc = true;

                   this.additionalDocFile = this.editQuoteDocs;
                //
                  this.additionalDocFile.forEach((item1, index1) => {

                          let fileType = this.additionalDocFile[index1].DocFileName.split(".");
                          fileType = fileType[fileType.length - 1];
                          fileType = fileType == "pdf" ? "PDF" : "IMG";
                          this.additionalDocFile[index1].file = this.additionalDocFile[index1].DocFilePath;
                          this.additionalDocFile[index1].fileType = fileType;

                  });

                  this.additionalDocFile.push(item);

                    // console.log(this.additionalDocFile);
            }

          });

      }
    });
  }
// this.tempDocArray.length
  getTermsConditions() {

    this.showTerms = true;
    this.motorQuoteService.getTermsConditions('B2B').subscribe(res => {
      if (res.response_code == 1) {
        this.showTerms = false;
        this.termsAndCondition = res.termsAndCondition;
      }

    });
  }

  getIssuePlace(place) {
    this.insuredDetailForm.get('adtnl_detail_address')?.setValue(place);
  }

  callChangeStepper(event: any, stepper) {

    if (event.selectedIndex == 0) {
          this.checkStepper = false;
          this.disabledStatus = false ;
    }

    if (event.selectedIndex == 1) {

      if (this.checkStepper == false) {

             let type = (this.webQuoteNumber == '' ) ? 1 : 2;
             if(this.validateDOBYear()==true)

             this.getUserAccessPermission(stepper,type,0)
      }else{
          this.checkStepper = true;
      }
    }

    if (event.selectedIndex == 2) {

            return false;
    }

  }

  public additionalLoading:number; additionalDiscount:number; loadingByPercent:number;

  //----------------- APPLY DISCOUNT ON PREMIUM WITH VAT ----------------//
  calculateDiscount(loadingby, loadByAmount, calculationType) {

    // for  discount
    if(loadingby == 2 ){

          if(calculationType == 1 && loadByAmount >= 45){       // for percent

            Swal.fire('','Invalid percent selected for discount','error');
                return false;
          }
         if(calculationType == 0 && loadByAmount >= 500){     // for amount

            Swal.fire('','Invalid amount selected for discount','error');
                return false;
          }

    }

    // for loading
    if(loadingby == 1){
          if(this.businessSource == 'DIRECT'){   // for admin

              if(calculationType == 1 && loadByAmount >= 45){       // for percent

                Swal.fire('','Invalid percent selected for loading','error');
                    return false;
              }
              if(calculationType == 0 && loadByAmount >= 2000){     // for amount

                Swal.fire('','Invalid amount selected for loading','error');
                    return false;
              }
          }else{         // for user

              if(calculationType == 1 && loadByAmount >= 20){       // for percent

                Swal.fire('','Invalid percent selected for loading','error');
                    return false;
              }
              if(calculationType == 0 && loadByAmount >= 250){     // for amount

                Swal.fire('','Invalid amount selected for loading','error');
                    return false;
              }
          }


    }

    const  copy = JSON.parse(JSON.stringify(this.tempBenefitData));
    // console.log(copy);
    let base_Primium = copy;
    // console.log(this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData);

    this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData;

    let Multiple: number;

    if (loadingby == 1) {
         Multiple = 1;
    } else {
        Multiple = -1;
    }

    this.totalFixPremium = this.tempTotalLoadFixPrem;

    let loadingAmt = loadByAmount;

    //let discount:number = Number(this.PlanDataJson.thirdPartyAPIData.NcdDiscount.NcdAmnt);
    let discount:number = 0 ;
    let policyFee:number = 0 ;

    this.tempBenefitData.forEach((item, index) => {
        if (this.insuredDetailForm.value.adtnl_detail_insType.value == 200 && item.Code == '40099') {
            //get policy fee
            policyFee = item.premium ;
        }
    });


    if(loadingby == 1){
              this.additionalLoading = loadingAmt;

    }else{
              this.additionalDiscount = loadingAmt;
    }
    if(loadingby == 1){
    if(calculationType == 1){

        this.totalFixPremium = Number(Number(this.premium) + Number(this.premium*loadingAmt/100));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) *this.PlanDataJson.vatPer/100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData =  copy  ;
    }
    else{

        this.totalFixPremium = Number(Number(this.premium) + Number(loadingAmt));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) *this.PlanDataJson.vatPer/100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData =  copy  ;

    }

    }else{

        if(calculationType == 1){

            this.totalFixPremium = Number(Number(this.premium) - Number(this.premium*loadingAmt/100));
            this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) *this.PlanDataJson.vatPer/100;
            this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
            this.tempBenefitData =  copy  ;
        }
        else{

            this.totalFixPremium = Number(Number(this.premium) - Number(loadingAmt));
            this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) *this.PlanDataJson.vatPer/100;
            this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
            this.tempBenefitData =  copy  ;

        }

    }


  }


  //sherinedke
  showMultipleDoc(fileName, documentType) {
    this.multipleImg = fileName;
    this.showAllDocImg = 1;
    this.ImagedocumentType = documentType;
  }
  modalboxclose() {
    this.showAllDocImg = 0;
  }
  quotationmultimg() {
    this.showMultiQuotationImg = 1;
  }
  closeQuotationImg() {
    this.showMultiQuotationImg = 0;
  }

  additionalDocImg(){
      this.showAdditionalDocImg = 1;
  }

  closeadditionalDocImg(){
      this.showAdditionalDocImg = 0;
  }
  sumInc = ''; chgDeduct = ''; optBenfit = '';
  sendConfirmMailToAdmin(type){
    if (type == 7) {
      if (this.confirmDescription == '') {
        this.validtnMsg = true;
        return false;
      }
      this.showDescription = false;
      this.validtnMsg = false;
      this.showLoader.referal = true;
    }
    let confirm_type;
    let event_type;
    if (type == 7) {
      event_type = 'RENEWALCONFIRMED';      // BOR Document
      confirm_type = '';
      this.policyStatus = 'CONFIRM';
    }
    let extraField = { sumInc: this.sumInc, chgDeduct: this.chgDeduct, optBenfit: this.optBenfit }
    this.motorQuoteService.sendReferralMailToAdmin(this.webQuoteNumber, encodeURIComponent(this.confirmDescription), this.emailadd, event_type, confirm_type, this.referral_reason, this.tempMultipleDocData, this.confirmAdditionalCondition, extraField).subscribe(res => {

      if (res.response_code == 1) {
        this.showLoader.referal = false;
        if(type == 7 ){
          if(this.policyStatus = 'CONFIRM'){
            this.showLoader.referal = false;
            Swal.fire('','Quotation ' + this.webQuoteNumber +' has been Confirmed and a notification is sent to the user.','success');
            this.getQuotePlan();
            this.referalModel = false;
             this._route.navigate(['motorscheme']);
            }
        }
      }

      this.close();

    });


  }

  sendRefferMailToAdmin(type) {
  if (type == 1 || type == 2 ) {
    if (this.referalDescription == '') {
      this.validtnMsg = true;
      return false;
    }
    this.validtnMsg = false;
    this.showLoader.referal = true;
  }

  if (type == 3 || type == 4 || type == 5) {
      if (this.referalDescription == '') {
          this.validtnMsg = true;
          return false;
      }
      this.validtnMsg = false;
      this.showLoader.referal = true;
  }


  let refer_type;
  let event_type;


  if (type == 1 || type == 2) {
    event_type = 'REFERQUOTE';        // REFER A QUOTE
    refer_type = type == 1 ? 'SYSTEM' : 'MANUAL';
    this.policyStatus = 'REFERED';

  }

  if (type == 3) {
      event_type = 'REFERAPPROVED';     // APPROVED
      refer_type = '';
      this.policyStatus = 'APPROVED';
  }

  if (type == 4) {
        event_type = 'REFERREJECTED';      // REJECTED
        refer_type = '';
        this.policyStatus = 'REJECTED';
  }

  if (type == 5) {
      event_type = 'ADDITIONALINFO';      // ADDITIONAL INFO
      refer_type = '';
      this.policyStatus = 'ADDITIONALINFO';
  }

  if (type == 6) {
    event_type = 'BORQUOTE';      // BOR Document
    refer_type = '';
    this.policyStatus = 'BORQUOTE';
}

  this.motorQuoteService.sendReferralMailToAdmin(this.webQuoteNumber, this.referalDescription,this.emailadd ,event_type, refer_type,this.referral_reason,this.tempMultipleDocData,this.refAdditionalCondition,'').subscribe(res => {
    this.close();
    this.showLoader.refer = false;
    if (res.response_code == 1) {
      if (type == 1 || type == 2) {
        this.showLoader.referal = false;
        Swal.fire('Your quote has been referred to our expert team of UWs for review.', 'You will be notified soon after the review. Your Quotation Reference# ' + this.webQuoteNumber, 'success');
      
         this._route.navigate(['renewpolicy']);
      }

      if(type == 2 || type == 3 || type == 4 || type == 5 ) {

            this.getQuotePlan();
            this.referalModel = false;
      }

  

    }

  });



  }


  isEmptyObject(obj) {
    return (obj && (Object.keys(obj).length === 0));
  }
  popupTitle = "";
  getConfirmCondition(confirm_val){
    const dialogRef = this.dialog.open(this.confirmquote);
    this.referalModel = true;
    if(confirm_val == 'CONFIRM'){
      this.popupTitle = "Confirm a Quote";
      this.confirm_type = 'Confirm';
      this.confirm_condtion_type = 7;
    }
  }


  getReferalCondtion(ref_val) {
    
    // if ( this.insuredDetailForm.invalid && this.invalidEID == true ) {
    //   Swal.fire("", "Please fill all mandatory data", 'error');
    //       this.insuredDetailForm.markAllAsTouched();
    //       return false;
    // }
    // else if(this.tempMultipleDocData.length == 0 && this.tempDocArray.length == 0){
    //     Swal.fire("", "Please upload mandatory documents", 'error');
    //     return false;
    // }

    // if (this.viewSupportingDocument.length==0) {
    //   Swal.fire("", "Please upload the supporting documents", 'error');
    //       this.insuredDetailForm.markAllAsTouched();
    //       return false;
    // }
    // else     if(this.multiGap.length==0) { Swal.fire("Please upload supporting document.");  return false ; }
    // else 
    if(ref_val == 'REFERRAL'){
      const dialogRef = this.dialog.open(this.referaquote);
      this.referalModel = true;
      this.refer_type = 'Refer';
      this.refer_condtion_type = 2;
    }
     if(ref_val == 'APPROVED') {
      const dialogRef = this.dialog.open(this.referaquote);
      this.refer_type = 'Approve';
      this.refer_condtion_type = 3;
    }
    if(ref_val == 'REJECTED') {
      const dialogRef = this.dialog.open(this.referaquote);
      this.refer_type = 'Reject';
      this.refer_condtion_type = 4;
    }
     if(ref_val == 'ADDITIONALINFO'){
      const dialogRef = this.dialog.open(this.referaquote);
      this.refer_type = 'Additional Info';
      this.refer_condtion_type = 5;
    }
    if (ref_val == 'QUOTECONFIRMED') {
      const dialogRef = this.dialog.open(this.confirmquote);
      this.popupTitle = "Quote Confirm";
      this.refer_type = 'Confirm Info';
      this.refer_condtion_type = 6;
    }
          
  }
  clickSupportRefer = false;
  getReferalCondtionWithSupportingDoc(ref_val){ 
    let isFilealreadyUploaded =  false ;
    this.multilpleFile.forEach((item,index)=>{
      if(item?.DocumentType =='supporting_Document_GAP') { isFilealreadyUploaded = true ;
      }
    })

    if(isFilealreadyUploaded==false && this.convertDate(this.insuredDetailForm.value.rg_ins_exp) < this.convertDate(this.policyMinDate) && this?.viewSupportingDocument.length==0){
      Swal.fire(' ', 'Please upload supporting document', 'error');
      return false ;
    }

    else if ( this.insuredDetailForm.invalid && this.invalidEID == true ) {
        Swal.fire("", "Please fill all mandatory data", 'error');
            this.insuredDetailForm.markAllAsTouched();
            return false;
      }

      else if(this.tempMultipleDocData.length == 0 && this.tempDocArray.length == 0){
          Swal.fire("", "Please upload mandatory documents", 'error');
          return false;
      }
    const dialogRef = this.dialog.open(this.referaquoteForm);
    this.referalModel = true;
          if(ref_val == 'APPROVED'){ this.popupTitle = "Approve a Quote";
            this.refer_type = 'Approve';
            this.refer_condtion_type = 3;
          }

          if(ref_val == 'REJECTED'){ this.popupTitle = "Reject a Quote";
            this.refer_type = 'Reject';
            this.refer_condtion_type = 4;
          }

          if(ref_val == 'REFERRAL'){ this.popupTitle = "Refer a Quote"; 
            this.refer_type = 'Refer';
            this.refer_condtion_type = 2;
          }

          if(ref_val == 'ADDITIONALINFO'){ this.popupTitle = "Additional info "; 
            this.refer_type = 'Additional Info';
            this.refer_condtion_type = 5;
          }

  }

  redirectOnQuoteStatus(){
         this._route.navigate(["agentMotor/MTquotepage/approveQuote/" + this.webQuoteNumber]);
  }

  getTonnage(){

    if(this.showLoader.retrieveQuote) return false ;
        this.motorQuoteService.getTonnage(this.insuredDetailForm.value.rg_vhcl_make,
                                         this.insuredDetailForm.value.rg_vhcl_model,
                                         ).subscribe(res =>{

                  if(res.response_code == 1){
                       this.insuredDetailForm.get('loading_capacity')?.setValue(res.tonnageName);
                  }

        });
  }


  getQuotationHistory(quoteNumber){
        this.motorQuoteService.getQuotationHistory(quoteNumber,'MT').subscribe(res =>{
          // console.log(res);
                  if(res.response_code == 1){
                          this.quotationHistoryArr = res.quotationHistoryList;

                          // console.log(this.quotationHistoryArr);
                  }


        });
  }
  public deductCnt = 0 ;


onChangeVATRegister(){



}

insuredVechOwnedBy(){

        if (this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue == 'Corporate') {

          this.insuredDetailForm.get('industry_type')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('vat_register')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('e_eid')?.setValidators(null);
          this.insuredDetailForm.get('d_dob')?.setValidators(null);
          this.insuredDetailForm.get('e_nationality')?.setValidators(null);
          this.insuredDetailForm.get('d_driv_lic_num')?.setValidators(null);
          this.insuredDetailForm.get('d_place_issue')?.setValidators(null);
          this.insuredDetailForm.get('d_issue_date')?.setValidators(null);
          this.insuredDetailForm.get('d_expiry_date')?.setValidators(null);
          this.insuredDetailForm.get('d_TC_number')?.setValidators(null);
          this.insuredDetailForm.get('e_gender')?.setValidators(null);
          this.insuredDetailForm.get('trade_lic_num')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('vat_tl_location')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('vat_tl_location')?.setValidators(null);
        

                  this.insuredDetailForm.get('vat_register')?.valueChanges.subscribe(obj => {

                    if (obj == 'Yes') {

                      this.insuredDetailForm.get('TRN_num')?.setValidators([Validators.required]);
                    }
                    else {

                      this.insuredDetailForm.get('TRN_num')?.setValidators(null);

                    }
                      this.insuredDetailForm.get('TRN_num')?.updateValueAndValidity();

                  });

        }
        else {

          this.insuredDetailForm.get('industry_type')?.setValidators(null);
          this.insuredDetailForm.get('vat_register')?.setValidators(null);
          this.insuredDetailForm.get('d_dob')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('e_nationality')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('e_eid')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_driv_lic_num')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_place_issue')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_issue_date')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_expiry_date')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('d_TC_number')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('e_gender')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('trade_lic_num')?.setValidators(null);
        }

        this.insuredDetailForm.get('industry_type')?.updateValueAndValidity();
        this.insuredDetailForm.get('vat_register')?.updateValueAndValidity();
        this.insuredDetailForm.get('d_dob')?.updateValueAndValidity();
        this.insuredDetailForm.get('e_nationality')?.updateValueAndValidity();
        this.insuredDetailForm.get('e_eid')?.updateValueAndValidity();
        this.insuredDetailForm.get('d_driv_lic_num')?.updateValueAndValidity();
        this.insuredDetailForm.get('d_place_issue')?.updateValueAndValidity();
        this.insuredDetailForm.get('d_issue_date')?.updateValueAndValidity();
        this.insuredDetailForm.get('d_expiry_date')?.updateValueAndValidity();
        this.insuredDetailForm.get('d_TC_number')?.updateValueAndValidity();
        this.insuredDetailForm.get('e_gender')?.updateValueAndValidity();
        this.insuredDetailForm.get('trade_lic_num')?.updateValueAndValidity();
        this.insuredDetailForm.get('vat_tl_location')?.updateValueAndValidity();
}

onPrevPolChange(prevPolDate){

    if(this.toDay < prevPolDate &&  prevPolDate < new Date(new Date().setDate(new Date().getDate() + 13))){
      this.policyMinDate = new Date(Date.now());
      this.policyMaxDate = new Date(new Date(prevPolDate).setDate(prevPolDate.getDate() + 1));
      this.insuredDetailForm.get('polStartDate')?.setValue(this.policyMinDate);
    }else{
      this.policyMinDate = new Date(Date.now());
      this.policyMaxDate = new Date(new Date().setDate(new Date().getDate() + 13));
      this.insuredDetailForm.get('polStartDate')?.setValue(this.toDay);
    }
}

changeToUpperCase(iputData){

       return iputData.toUpperCase();


}

onChangeTransactionType(transaction_type){

      if ( transaction_type == 'Renewal' ||  transaction_type ==='Vehicle Renewal') {

          this.insuredDetailForm.get('rg_plateCode')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('rg_traffic_plate_num')?.setValidators([Validators.required]);
          this.insuredDetailForm.get('vhclColor')?.setValidators([Validators.required]);


      

      }
      else {

        this.insuredDetailForm.get('rg_plateCode')?.setValidators(null);
        this.insuredDetailForm.get('rg_traffic_plate_num')?.setValidators(null);
        this.insuredDetailForm.get('vhclColor')?.setValidators(null);

        }

        this.insuredDetailForm.get('rg_plateCode')?.updateValueAndValidity();
        this.insuredDetailForm.get('rg_traffic_plate_num')?.updateValueAndValidity();
        this.insuredDetailForm.get('vhclColor')?.updateValueAndValidity();
}



openImgDialog(img) {
  const dialogRef = this.dialog.open(this.callAPIDialog);
  dialogRef.afterClosed().subscribe((result) => {});
  // console.log(img);
  this.image = img;
}

close() {
  this.dialog.closeAll();
}

opentc() {
  const dialogRef = this.dialog.open(this.termsandconditions);
  dialogRef.afterClosed().subscribe((result) => {});

}

//----------------------------- CHECK  USER ACCESS FOR POLICY ISSUE BUTTONS ------------------------------//
checkAccessForPolicyIssueButtons() {
  this.motorQuoteService.checkAccessToPolicyButtons('MT').subscribe(res => {
    this.confirmIssued = res.QuoteConfirmAction;
    localStorage.setItem("confirmQuote", this.confirmIssued);
    if (res.IsNonPayIssueAllowed == 0) {
      this.issuePolicyBtnAccess = true;
    }
    if (res.IsOnlinePaymentAllowed == 0) {
      this.onlinePayBtnAccess = true;
    }
    if (res.IsSendPayLinkAllowed == 0) {
      this.sendPaymentLinkBtnAccess = true;
    }
    if (res.QuoteConfirmAction == "CONFIRM" && res.IsQuoteConfirmAllowed == 0) {
      this.confirmBtnAccess = true;
    }
    if (res.QuoteConfirmAction == "ISSUEPOL" && res.IsQuoteConfirmAllowed == 0) {
      this.issuepolConfirm = true;
    }
  });
}


//------------------------- CHECK USER ACCESS FOR PAGE ------------------------------------//
checkUserAccess(){
  this.motorQuoteService.checkUserAccess('RENEWAL',this.localStorDta.EmailAddress, 'MT',this.retrieveQuoteNumber).subscribe(res => {
    // alert("12345")
    let response = res;
    

        if (response.userAccessData == 0) {                 // userAccessData = 1 ------ give access
              Swal.fire('Sorry !','You can not authorised.','error');
              // this._route.navigateByUrl('motorscheme');                                         // userAccessData = 0 ------- access denied
              this.showLoader.retrieveQuote = false;
              return false;
        }else{

            this.showLoader.retrieveQuote = false;
        }
    });
}

// ---------------------------------------------------For Validation Focus-------------------------------------------------------

checkValidation(){
  // this.insuredDetailForm.invalid.focus()console.log(1)
  // console.log(this.invalidEID)
  if(this.invalidEID == true){
    this.stepper.next();
   
  }
  else{
    this.insuredDetailForm.setErrors({ 'invalid': true });
    // console.log(this.insuredDetailForm)
    return;
  }
    if (this.insuredDetailForm.value.invalid  ) {
      const invalidControl = this.el.nativeElement.querySelector('.ng-invalid');
      invalidControl.focus();
      // break;
   }
   

}

// ----------------------------------------------------Discount-----------------------------------------------------------
getDiscountOnSelfDeclaration(){

  this.motorQuoteService.getDiscountOnSelfDeclaration(this.webQuoteNumber,"MT").subscribe(res =>{
       this.selfDeclarationDiscount = res.PromoDiscount;

       const  copy = JSON.parse(JSON.stringify(this.tempBenefitData));
       let base_Primium = copy;
       let  discountAmt = 0;
       this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData;
       this.totalFixPremium = this.tempTotalLoadFixPrem;
       let discount:number = 0;
       let policyFee:number = 0 ;

       this.tempBenefitData.forEach((item, index) => {
           if (this.insuredDetailForm.value.adtnl_detail_insType.value == 200 && item.Code == '40099') {
               //get policy fee
               policyFee = item.premium ;
           }
       });

           this.tempBenefitData.forEach((item, index) => {

             // FOR COMPRENSIVE
             if (this.insuredDetailForm.value.adtnl_detail_insType.value == 100 && item.Code == '40001') {

              let newBasePremium = this.totalFixPremium;

             // console.log('newBasePremium : '+newBasePremium );
               discountAmt = Math.round(((this.selfDeclarationDiscount * Number(newBasePremium)) / 100));   //FOR BY PERCENT
                  // console.log('discount amount : ',discountAmt);

                   let totalPrem:number = 0 ;
                   totalPrem += newBasePremium;
                   totalPrem += discount ;
                   totalPrem -= discountAmt;

                   // console.log('Total Pre : ', totalPrem);

                         if(Number(base_Primium[1].premium) > Number(base_Primium[0].premium)){
                               totalPrem -= parseInt(base_Primium[0].premium);
                         }else{
                               totalPrem -= parseInt(base_Primium[1].premium);
                         }

                         this.PlanDataJson.planBenefitData.benefit_data[index].premium = totalPrem;

             }

             // FOR TPL
             if (this.insuredDetailForm.value.adtnl_detail_insType.value == 200 && item.Code == '40002') {

               let newBasePremium = this.totalFixPremium;


                     discountAmt = Math.round(((this.selfDeclarationDiscount * Number(newBasePremium)) / 100));  //FOR BY PERCENT

                       let totalPrem:number = 0 ;

                       if(this.PlanDataJson.planBenefitData.benefit_data[index].Code == 40002){
                               totalPrem = parseInt(base_Primium[index].premium) - discountAmt;
                       }

                         this.PlanDataJson.planBenefitData.benefit_data[index].premium = totalPrem;


             }

           });

           this.totalFixPremium = Math.round(Number(this.totalFixPremium) - Number(discountAmt));
           // console.log('Base Premium : ', this.totalFixPremium);
           this.VATAMT = (this.totalFixPremium + this.totalVariablePremium) * 0.05;
           // console.log('VAT AMOUNT : ',this.VATAMT);
           this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
           // console.log('Total Premium : ',this.Total_Primium);
           this.specialDiscount();
           this.tempBenefitData =  copy ;
     });
}

specialDiscount(){
  this.motorQuoteService.getSpecialDiscount().subscribe(res =>{
          if(res.response_code == 1){
              this.specialDiscountAmt = res.special_discount;

              this.totalFixPremium = Math.round(Number(this.totalFixPremium) - Number(this.specialDiscountAmt));
              // console.log('Base Premium 1 : ', this.totalFixPremium);
              this.VATAMT = (this.totalFixPremium + this.totalVariablePremium) * 0.05;
              // console.log('VAT AMOUNT 1 : ',this.VATAMT);
              this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
              // console.log('Total Premium 1 : ',this.Total_Primium);
          }
  });
}
getinsuredType_renewal(res){
  this.motorQuoteService.getInsuredType(this.sideForm.value.schemeCode).subscribe(result=>{
    
   this.instypes = result.insuredType;

    this.instypes.forEach((item, index) => {
      console.log(res.PolicyType);
      console.log(item.ProductShortName)
     if(res.PolicyType==item.ProductShortName)   this.insuredDetailForm.get('adtnl_detail_insType')?.setValue(item);

    });

    // console.log(this.insuredDetailForm.value.adtnl_detail_insType);

  })
}




openReportModal(){
    const dialogRef = this.dialog.open(this.callAPIDialoginvalid);
}

chassisMin = 10 ;
chassisMax = 17 ;

getinsuredType(event){

 

  if(event == "undefined" || event == undefined) return false ;

  this.checkEngineValidation();
  this.checkTrimValidation();
  if(!this.isUpdateValuation) return false ;
  this.SchemeCodeClick = false;
  if(this.retrieveQuoteNumber == ''){
  this.motorQuoteService.getInsuredType(event).subscribe(result=>{
// console.log(this.retrieveQuoteNumber);


    setTimeout(()=>{  
    this.instypes = result.insuredType;
    // console.log(this.instypes);
    let insTypeArr = [] ;
    this.instypes.forEach((item, index) => {
          
      insTypeArr.push({viewValue:item.PolicyType,value:item.PolicyType,code:200});
    
  },2000);
  //  this.insvehibys = insTypeArr ;
  //  this.insuredDetailForm.get('adtnl_detail_insType')?.setValue(this.instypes[0]);
  //  this.insuredDetailForm.get('adtnl_detail_vhclOwnBy')?.setValue(this.insvehibys[0]);


     this.modelYearRang();
    },100);
  
    })
  }
  if(this.retrieveQuoteNumber != ''){
    this.renewquotationsearch(); 
  }
  

    //65S, 65Q4, 66S, 65RK, 66RK, 66Q
    const schemes = ["65S", "65Q4", "66S", "65RK","66RK"," 66Q"];
    if(schemes.includes(event)){  this.chassisMin = 17 ; this.chassisMax = 17 ; }
    else {  this.chassisMin = 10 ; this.chassisMax = 17 ; }
    this.insuredDetailForm.get('rg_model_year').setValue('');
    this.insuredDetailForm.get('rg_vhcl_make').setValue('');
    this.insuredDetailForm.get('rg_vhcl_model').setValue('');
    this.insuredDetailForm.get('adtnl_detail_bodyType').setValue('');
    this.insuredDetailForm.get('adtnl_detail_trim').setValue('');
    
    this.insuredDetailForm.get('adtnl_detail_engine').setValue('');
    this.insuredDetailForm.get('CC').setValue('');
    this.insuredDetailForm.get('loading_capacity').setValue('');
    this.insuredDetailForm.get('adtnl_detail_cylinder').setValue('');
    this.insuredDetailForm.get('rg_chassis_num').setValue('');

    
  
}

validateScheme(){
  let validateData = {
    sumInsured: this.insuredDetailForm.value.adtnl_detail_vhclValue,
    schemecode: this.sideForm.value.schemeCode,
    bodyType: this.insuredDetailForm.value.adtnl_detail_bodyType,
    coverType: this.insuredDetailForm.value.adtnl_detail_insType.ProductShortName,
    insuredType :  this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue,
    quotationNo : this.webQuoteNumber,
    partnerId : this.partnerId
  }

  this.motorQuoteService.validateScheme(validateData).subscribe((res) =>{

    });

}


getRrepairType(){
  // console.log(this.insuredDetailForm)
  if(this.vehicle_age<=0) this.vehicle_age=1 ;
 let RepairData = {
  vhclBodyType: this.insuredDetailForm.value.adtnl_detail_bodyType,
  partnerid: this.partnerId,
  schemecode: this.sideForm.value.schemeCode,
  vhclModelYr: this.insuredDetailForm.value.rg_model_year,
  vhclMake: this.insuredDetailForm.value.rg_vhcl_make,
  vhclModel: this.insuredDetailForm.value.rg_vhcl_model,
  insuredType :  this.insuredDetailForm.value.adtnl_detail_vhclOwnBy.viewValue,
  webQuoteNumber:this.webQuoteNumber,
  age:this.vehicle_age
}

this.motorQuoteService.getRrepairType(RepairData).subscribe((res) =>{

// console.log(res);

let response = res;
this.repairs = response.Data;
this.repairtypes=this.repairs
// console.log(this.repairtypes)
this.insuredDetailForm.get('adtnl_detail_repairTye')?.setValue(this.repairtypes);
if(this.retrieve_repair_type != ''){
      var indRepairType;
      this.repairtypes.forEach((item, index) => {
        if (item.RepairType.toLowerCase() == this.quoteDetail.RepairType.toLowerCase()) {
              indRepairType = item;
        }
      });
      if(indRepairType)
      this.insuredDetailForm.get('adtnl_detail_repairTye')?.setValue(indRepairType);
      else
       this.insuredDetailForm.get('adtnl_detail_repairTye').setValue(this.repairtypes[0]);

      if(this.repairtypes.length==1) this.insuredDetailForm.get('adtnl_detail_repairTye').setValue(this.repairtypes[0]);
      
}

});

}

valuationAvl = 1 ;
updateValuation_new(){
  

  if(this.insuredDetailForm.value.rg_model_year){
        if(this.insuredDetailForm.value.rg_chassis_num=='') return false;
        if(!this.isEditRetriveOnPageLoad) return false;

        const schems = [ "66S", "66RK", "66Q" ];

        if(schems.includes(this.sideForm.value.schemeCode)) return false;

 
        let vehicleDetailArray = {
            chassisNum: this.insuredDetailForm.value.rg_chassis_num,
            insType: this.insuredDetailForm.value.adtnl_detail_insType,
            repairType: this.insuredDetailForm.value.adtnl_detail_repairTye.RepairType,
            vhclBodyType: this.insuredDetailForm.value.adtnl_detail_bodyType,
            vhclCylinder: this.insuredDetailForm.value.adtnl_detail_cylinder,
            vhclGCCSpecifird: this.insuredDetailForm.value.adtnl_detail_gccSpecified,
            vhclMake: this.insuredDetailForm.value.rg_vhcl_make,
            vhclModel: this.insuredDetailForm.value.rg_vhcl_model,
            vhclModelYr: this.insuredDetailForm.value.rg_model_year,
            vhclSeatCapcity: this.insuredDetailForm.value.rg_num_passenger,
            vhclTrim: this.insuredDetailForm.value.adtnl_detail_trim,
            engineSize:this.insuredDetailForm.value.adtnl_detail_engine,
            SchemeCode: this.sideForm.value.schemeCode,
            PartnerId:this.sideForm.value.partnerID,
            isBrandNew:this.insuredDetailForm.value.adtnl_detail_brandNew
          }
        this.motorQuoteService.getMotorValuation(vehicleDetailArray).subscribe(res => {

          // {"RequestId":null,"StatusCode":400,"Message":"Valuation is not available for the given Specs/vehicle."} Message	"Valuation is not available for the given Specs/vehicle."   to do

          if(res.StatusCode==400){

            this.valuationAvl = 0;
            this.insuredDetailForm.get('adtnl_detail_vhclValue')?.setValue('');
            this.vehicleValueLimit.startLimit = 0;
                                                       
            this.vehicleValueLimit.endLimit = 0 ;
          }
            // console.log(res?.Valuation?.Medium)
          if (res.StatusCode == 200) {
            this.valuationAvl = 1;
            this.existVehiclevalue = 0;
            this.referalStatus = false;
            this.vehicleValueLimit.isSet = true;
                  this.vehicleValueLimit.startLimit = Number(res.Valuation.Low);
                  this.vehicleValueLimit.endLimit = Number(res.Valuation.High);
              //           this.insuredDetailForm.get('v_value').setValidators([Validators.required]);
              //  this.insuredDetailForm.get('v_value').updateValueAndValidity();
                  this.insuredDetailForm.get('v_value').setValue(Number(res.Valuation.Medium));

                  this.insuredDetailForm.get('v_value').setValidators([Validators.required,Validators.min(this.vehicleValueLimit.startLimit),Validators.max(this.vehicleValueLimit.endLimit)]);

                this.insuredDetailForm.get('v_value').updateValueAndValidity();

          } else {

            this.existVehiclevalue = 1;
            this.referalStatus = true;
            this.vehicleValueLimit.startLimit = 0;
            this.vehicleValueLimit.endLimit = 300000;
  //           this.insuredDetailForm.get('v_value').setValidators([Validators.required]);
  //  this.insuredDetailForm.get('v_value').updateValueAndValidity();
            this.insuredDetailForm.get('v_value')?.setValue('');
            this.vehicleValueLimit.isSet = false;

          }

          this.showLoader.VehicleValue = false;

        });

       // this.getRrepairType();

      }else{


        setTimeout(()=>{ 

          this.updateValuation_new();
         },500);
      }

    }

    openDialog() {
      this.dialog.open;
    }

    getdetailsbySearch(){
      if (this.Search_vehicle.invalid) {
        Swal.fire("", "Please enter mandatory data", 'error');
    }
    else{
      let data={
        chasisNo: this.Search_vehicle.value.chassis_no,
        RegTcNo: this.Search_vehicle.value.reg_tc_no,
        LicNo: this.Search_vehicle.value.license_no,
        cedentBrokerID: this.sideForm.value.partnerID,

      }
      this.motorQuoteService.getDetailsBySearch(data).subscribe(res => {

        this.close();
        if(res.response_code==2){
          this.insuredDetailForm.get("rg_chassis_num").setValue(this.Search_vehicle.value.chassis_no);
           this.validateChassisNum(this.Search_vehicle.value.chassis_no);
         }else{

          
          if(res.response_message=="Failed") return false ;
        let resdata = res?.vechileData[0];
        
        this.quoteDetail = resdata;
        this.insuredDetailForm.get('e_name')?.setValue(resdata.InsuredName);
        this.insuredDetailForm.get('adtnl_detail_email')?.setValue(resdata.InsuredEmail);
        this.insuredDetailForm.get('adtnl_detail_mobile')?.setValue(resdata.InsuredMobile);
        this.insuredDetailForm.get('adtnl_detail_address')?.setValue(resdata.InsuredAddress);
        this.insuredDetailForm.get('adtnl_detail_area')?.setValue(resdata.Area);
        this.insuredDetailForm.get('rg_chassis_num')?.setValue(resdata.ChassisNumber);
        this.checkChassisValidation = true;
        this.insuredDetailForm.get('isChassisValidate')?.setValue('1');

        this.insuredDetailForm.get('e_eid')?.setValue(resdata.EmiratesIdNumber);
        this.insuredDetailForm.get('rg_engin_num')?.setValue(resdata.EngineNumber);

        this.insuredDetailForm.get('d_driv_lic_num')?.setValue(resdata.LicenceNumber);
        this.insuredDetailForm.get('d_dob')?.setValue(this.dateConvert(resdata.InsuredDOB));
        this.insuredDetailForm.get('d_dob')?.setValue(new Date(resdata.InsuredDOB));
        this.insuredDetailForm.get('adtnl_detail_brandNew')?.setValue(resdata.IsBrandNew);
        this.insuredDetailForm.get('rg_policy_num')?.setValue(resdata.PrvInsPolNo);

        let yearVal;
        this.vehimodelyrs.forEach((item, index) => {
          if (item.label == resdata.VehicleModelYear) {
            yearVal = item;
          }
        });
        this.insuredDetailForm.get('rg_model_year')?.setValue(yearVal);
        // console.log(resdata.VehicleMake);
        this.quoteDetail.VehicleMake = resdata.VehicleMake;
        this.quoteDetail.VehicleModel = resdata.VehicleModel;
        this.quoteDetail.TrimCode = resdata.TrimCode;
        this.quoteDetail.TrimName = resdata.TrimName;
        this.quoteDetail.BodyType = resdata.BodyType;
        //this.retrieve_repair_type = this.getVechileDetailData.RepairType;
        //  this.quoteDetail.RepairType = resData.RepairType;

        this.getVhclMakeData(this.quoteDetail.VehicleMake, yearVal, 1);

        var indexNationality;
        
        this.countryArr.forEach((item, index) => {
          if (item.CountryName == resdata.Nationality) {
            indexNationality = item;
          }
        });
        this.insuredDetailForm.get('e_nationality')?.setValue(indexNationality);



          //     //Vehicle Cylinders
          var indexCylinder = this.vehicylinders.findIndex(function (obj, k) {
            return obj.CylinderCode === resdata.VehicleCylinders;
          });
          let cylVal = this.vehicylinders[indexCylinder];
          this.insuredDetailForm.get('adtnl_detail_cylinder')?.setValue(cylVal);


            //Vehicle Color
            if (resdata.VehicleColor == null || resdata.VehicleColor == '') {
              this.insuredDetailForm.get('vhclColor')?.setValue('');
            } else {
              var indexColor = this.vhclColorArr.findIndex(function (obj, k) {
                return obj.ColorName === resdata.VehicleColor;
              });
              let clrVal = this.vhclColorArr[indexColor];
              this.insuredDetailForm.get('vhclColor')?.setValue(clrVal);
            }

            //     //Gender
          var indexGender = this.genders.findIndex(function (obj, k) {
            return obj.value ===  resdata.InsuredGender;
          });
          let gnderVal = this.genders[indexGender];
          this.insuredDetailForm.get('e_gender')?.setValue(gnderVal);


            if(resdata.RegistrationPlace != '' && resdata.RegistrationPlace != null && resdata.RegistrationPlace != undefined ){

              var indexPlace = this.cityArr.findIndex(function (obj, k) {
                return obj.CityName === resdata.RegistrationPlace;
              });
              let placeal = this.cityArr[indexPlace];
              this.insuredDetailForm.get('rg_place_issue')?.setValue(placeal);
              this.quoteDetail.regplace = placeal.CityName;
              this.getPlateCodeRenew(this.quoteDetail.RegistrationPlace, this.quoteDetail.PlateCategory);
          }

        }
      });

    }

}


regExpDate:any;
  renewquotationsearch() {
    console.log(this.localStorageData.PartnerId);
    console.log(this.Search_policy.value.chassis_no);
    console.log(this.Search_policy.value.policy_no)
  
    
  // alert("to renewal page")


  let data = {
    chasisNo: this.Search_policy.value.chassis_no,
    polNo: this.Search_policy.value.policy_no,
    partnerID: this.localStorageData.PartnerId
    }
    console.log(this.Search_policy.value.policy_no)
    console.log(data);
    this.motorQuoteService.getDetailForRenew(data).subscribe(res => {
      
      if (this.localStorageData.UserRole == 'RM' && this.retrieveQuoteNumber != '') {
        this.sideForm.disable();
        this.insuredDetailForm.disable();
      }
      if (res.response_code == 300) {
        this.showReferbutton = false;
        this.referral_reason = res.response_message_r;
        Swal.fire(this.referral_reason, 'You will be notified soon after the review. Your Quotation Reference# ' +
        this.webQuoteNumber, "warning");
      this.stepper.previous();
      return false;
        }
    this.isUpdateValuation = false;
    if(res.response_message=="Failed") return false ;
      let resData = res.vechileData[0];
      this.quoteStatus = resData.StatusDesc;
    localStorage.setItem("Schemecode",resData.SchemeCode)
    this.GetSchemesForRenewal(resData.SchemeCode);
    this.quoteDetailPrev = resData;
    this.highSI = this.quoteDetailPrev.HighSI
    // console.log( this.highSI);
    this.renewalDetailsData.push(res);
    // console.log( this.renewalDetailsData);
    this.onVehiclAgeChange(resData.VehicleModelYear)
    // console.log(resData);
    this.quoteDetail = resData;
    this.webQuoteNumber = resData.WebQuotationNumber;
    // console.log(this.webQuoteNumber)
    this.getPartnerBranchList();
    this.getDataForEditQuoteDocs(resData.WebQuotationNumber);
    this.getQuotationHistory(resData.WebQuotationNumber);

    //   if(resData?.SchemeCode)
    //  this.sideForm.get("schemeCode")?.setValue(resData.SchemeCode);
    //  else
      this.sideForm.get("schemeCode")?.setValue(resData.SchemeCode);
      
    localStorage.setItem("POL_No", this.quoteDetail.POL_NO);
      if (this.quoteDetailPrev.HighSI < 25000) {
      this.motorQuoteService.getSchemesByProduct('MT').subscribe((res) => {
        this.product_list.splice(1, 1);
        console.log(this.product_list[1]);
        this.sideForm.get("schemeCode").setValue(this.product_list[0].SchemeCode)
      })
    }
    this.motorQuoteService.getInsuredType(resData.SchemeCode).subscribe(result => {
      setTimeout(() => {
        this.instypes = result.insuredType;
        // console.log(this.instypes);
        let insTypeArr = [];
        this.instypes.forEach((item, index) => {
          insTypeArr.push({ viewValue: item.PolicyType, value: item.PolicyType, code: 200 });
        });
      });
    })

    //  console.log(resData.POBoxLocation)
    //po box location
    var indexPo_box_location = this.cityArr.findIndex(function (obj, k) {
      return obj.CityName === resData.POBoxLocation;
    });
    this.insuredDetailForm.get('po_box_location')?.setValue(this.cityArr[indexPo_box_location]);
    this.checkEngineValidation();
    if (this.userId == 2) {
      this.disabledStatus = false;
    }
    else {
      this.disabledStatus = true;
    }
    this.policytype = resData.PolicyType;
    // console.log(resData.PolicyType)
    setTimeout(() => {
      this.getinsuredType_renewal(resData)
    }, 2000);

    /************ if corporate then add weight_empty and weight_fulll  */
    if (resData.InsuredType == "Corporate") {
      this.insuredDetailForm.get('weight_empty')?.setValue(resData.WeightEmpty);
      this.insuredDetailForm.get('weight_full')?.setValue(resData.WeightFull);
    } 
    else {
      this.insuredDetailForm.get('weight_empty')?.setValidators(null);
      this.insuredDetailForm.get('weight_empty')?.updateValueAndValidity();
      this.insuredDetailForm.get('weight_full')?.setValidators(null);
      this.insuredDetailForm.get('weight_full')?.updateValueAndValidity();
      this.insuredDetailForm.get('vat_tl_location')?.setValidators(null);
      this.insuredDetailForm.get('vat_tl_location')?.updateValueAndValidity();
    }
    
    /************* Vehicle Details  *****/
    this.insuredDetailForm.get('rg_chassis_num')?.setValue(resData.ChassisNumber);
    this.checkChassisValidation = true;
    if (resData.VehicleMake == null || resData.VehicleModel == null || resData.BodyType == null) {
      this.referalStatus = true;
      Swal.fire('', 'We could not find Vehicle details for your renewal policy (' + resData.POL_NO + '). Please refer to the quote to  UW by clicking the "Refer a Quote" button.');
    }

    this.vehiyears = [];
    this.vehiyears.push({ value: resData.VehicleModelYear.toString(), label: resData.VehicleModelYear.toString() });
    this.insuredDetailForm.get("rg_model_year")?.setValue(this.vehiyears[0]);

    // Vehicle Make Binding 
    this.vhclMakeArr = [];
    this.vhclMakeArr.push({
      VehicleMakeId: 1,
      VehicleMakeName: resData.VehicleMake,
      Active: true,
      IsReferral: 0,
      CRS_VEH_CODE: 1
    });
    this.insuredDetailForm.get("rg_vhcl_make")?.setValue(this.vhclMakeArr[0]);

    // Vehicle Model Binding 
    this.vhclModelArr = [];
    this.vhclModelArr.push({
      VehicleModelId: 1,
      VehicleModelName: resData.VehicleModel,
      Active: true,
      SeatingCapacityExDriver: 0,
      BodyTypeId: 1,
      CRS_MODEL_CODE: 1,
      EDATA_MODEL_CODE: "No"
    });
    this.insuredDetailForm.get("rg_vhcl_model")?.setValue(this.vhclModelArr[0]);

    // Vehicle Body Type Binding 
    this.vhclBodyTypeArr = [];
    this.vhclBodyTypeArr.push({ id: 1, BodyTypeName: resData.BodyType });
    this.insuredDetailForm.get("adtnl_detail_bodyType")?.setValue(this.vhclBodyTypeArr[0]);

    // Vehicle Trim Binding 
    this.vehitrims = [];
    this.vehitrims.push({ Name: resData.TrimName });
    this.insuredDetailForm.get("adtnl_detail_trim")?.setValue(this.vehitrims[0]);

    // Vehicle Engine Binding 
    let engineData = resData.EngineSize;
    this.engineList = [];
    this.engineList.push({ Name: engineData, Code: engineData, Cylinders: engineData, Passengers: "4" });
    this.insuredDetailForm.get('adtnl_detail_engine').setValue(this.engineList[0]);

    // Vehicle Cylinders Binding 
    let vehcylinder = resData.VehicleCylinders;
    this.vehicylinders = [];
    this.vehicylinders = [{ Id: 1, CylinderName: resData.VehicleCylinders, CylinderCode: resData.VehicleCylinders }];
    this.insuredDetailForm.get("adtnl_detail_cylinder")?.setValue(this.vehicylinders[0]);

    // Vehicle repairtype Binding 
    this.repairtypes = [{ id: 1, RepairType: resData.RepairType }];
    this.insuredDetailForm.get("adtnl_detail_repairTye")?.setValue(this.repairtypes[0]);

    this.insuredDetailForm.get('e_name')?.setValue(resData.InsuredName);
    var countryIndex = this.countryArr.findIndex(function (obj, k) {
      return obj.CountryName.toLowerCase() === resData.Nationality.toLowerCase();
    });

    if (countryIndex >= 0)
      this.insuredDetailForm.get('e_nationality')?.setValue(this.countryArr[countryIndex]);
    this.insuredDetailForm.get('adtnl_detail_email')?.setValue(resData.InsuredEmail);
    this.insuredDetailForm.get('adtnl_detail_mobile')?.setValue(resData.InsuredMobile);
    this.insuredDetailForm.get('isChassisValidate')?.setValue('1');
    this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue(resData.IsGCCSpecified);
    if (resData.IsModified == "Not" || resData.IsGCCSpecified == "No" || resData.IsGCCSpecified == "" || resData.IsGCCSpecified == "N") {
      this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue("No");
      this.GCC.No = true;
    }
    else {
      this.insuredDetailForm.get('adtnl_detail_gccSpecified')?.setValue("Yes");
      this.GCC.Yes = true;
    }
    this.GCC.edata = true;
    this.insuredDetailForm.get('e_eid')?.setValue(resData.EmiratesIdNumber);
    this.insuredDetailForm.get('rg_engin_num')?.setValue(resData.EngineNumber);
    this.insuredDetailForm.get('adtnl_detail_poBoxNum')?.setValue(resData.POBox);
    this.insuredDetailForm.get('d_driv_lic_num')?.setValue(resData.DRV_LICN_NO);
    this.insuredDetailForm.get('v_value').setValue(Number(resData.MediumSI));
    this.vehicleValueLimit.startLimit = Number(resData.LowSI);
    this.vehicleValueLimit.endLimit = Number(resData.HighSI);
    this.insuredDetailForm.get('v_value').setValidators([Validators.required, Validators.min(this.vehicleValueLimit.startLimit), Validators.max(this.vehicleValueLimit.endLimit)]);
    this.insuredDetailForm.get('v_value').updateValueAndValidity();
    this.vehicleValueLimit.isSet = true;
    if (this.insuredDetailForm.value.adtnl_detail_brandNew == 1) {
      this.transactionTypeArray = [];
      this.transactionTypeArray.push(this.tempTransactionTypeArr[1]);
      this.insuredDetailForm.get('transaction_type')?.setValue(this.transactionTypeArray[1]);
    } else {
      this.transactionTypeArray = this.tempTransactionTypeArr;
      this.insuredDetailForm.get('transaction_type')?.setValue(this.transactionTypeArray[1]);
    }

    this.insuredDetailForm.get('TRN_num')?.setValue(resData.TaxRegNumber);
    this.insuredDetailForm.get('trade_lic_num')?.setValue(resData.VEH_TRD_LICN_NO);
    this.insuredDetailForm.get('deductible')?.setValue(resData.Deductible);
    this.insuredDetailForm.get('rg_engin_num')?.setValue(resData.EngineNumber);
    this.insuredDetailForm.get('loading_capacity')?.setValue(resData?.Tonnage);


    /***** Added extra field retrive 28-10-2022 *************/

    this.insuredDetailForm.get('po_box_number')?.setValue(resData.POBox);
    
    //HasGCCSpecification importEdata
    if (resData.VEH_MILEAGE != '' && resData.VEH_MILEAGE != null && resData.VEH_MILEAGE != "null") {
      this.insuredDetailForm.get("mileage")?.setValue(resData.VEH_MILEAGE);
    }
    else {
      this.insuredDetailForm.get("mileage")?.setValue(15000);
    }

    // CurrentInsurance
    this.engineDefaultValue = resData.EngineSize;
    this.isUpdateValuation = false;
    this.getPlateCode(resData.RegistrationPlace, resData.PlateCategory);
    if (resData.RegistrationNumber !== '' && resData.RegistrationNumber != null) {
      this.insuredDetailForm.get('rg_traffic_plate_num')?.setValue(resData.RegistrationNumber);
    }

    if (resData.InsuranceExpiryDate == null || resData.InsuranceExpiryDate == '1900-01-01 00:00:00.000') {
      this.insuredDetailForm.get('rg_ins_exp')?.setValue(null);
    } else {
      this.insuredDetailForm.get('rg_ins_exp')?.setValue(new Date(resData.InsuranceExpiryDate));
    }
    this.regExpDate = new Date(resData.InsuranceExpiryDate);
    //  console.log("Navin ",this.regExpDate.getTime() );
    if (resData.DrivingLicExpDate == null || resData.DrivingLicExpDate == '1900-01-01 00:00:00.000') {
      this.insuredDetailForm.get('d_expiry_date')?.setValue(null);
    } else {
      this.insuredDetailForm.get('d_expiry_date')?.setValue(new Date(resData.DrivingLicExpDate));
    }
    if (resData.InsuredDOB == null || resData.InsuredDOB == '1900-01-01 00:00:00.000') {
      this.insuredDetailForm.get('d_dob')?.setValue(null);
    } else {
      this.insuredDetailForm.get('d_dob')?.setValue(new Date(resData.InsuredDOB));
    }
    if (resData.DrivingLicenseIssueDate == null || resData.DrivingLicenseIssueDate == '1900-01-01 00:00:00.000') {
      this.insuredDetailForm.get('d_issue_date')?.setValue(null);
    } else {
      this.insuredDetailForm.get('d_issue_date')?.setValue(new Date(resData.DrivingLicenseIssueDate));
    }
    if (resData.NationalIdExpDate == null || resData.NationalIdExpDate == '1900-01-01 00:00:00.000') {
      this.insuredDetailForm.get('e_expiryDate')?.setValue(null);
    } else {
      this.insuredDetailForm.get('e_expiryDate')?.setValue(new Date(resData.NationalIdExpDate));
    }

    if (resData.CoverType.toUpperCase() == "CORPORATE") {
      if (resData.IsTaxReg == "Y" || resData.IsTaxReg == "Yes")
        this.insuredDetailForm.get('vat_register')?.setValue("Yes");
      else
        this.insuredDetailForm.get('vat_register')?.setValue("No");
    } 
    else {
      this.insuredDetailForm.get('weight_empty')?.setValidators(null);
      this.insuredDetailForm.get('weight_empty')?.updateValueAndValidity();
      this.insuredDetailForm.get('weight_full')?.setValidators(null);
      this.insuredDetailForm.get('weight_full')?.updateValueAndValidity();
      this.insuredDetailForm.get('vat_tl_location')?.setValidators(null);
      this.insuredDetailForm.get('vat_tl_location')?.updateValueAndValidity();
    }

    var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
      return obj.CityName.toLowerCase() === resData.driv_lic_issuePlace.toLowerCase();
    });
    let placelVal = this.cityArr[indexRegPlace];
    this.insuredDetailForm.get('d_place_issue')?.setValue(placelVal);

    if (resData.CoverType.toUpperCase() == "CORPORATE") {
      this.insuredDetailForm.get('adtnl_detail_vhclOwnBy')?.setValue(this.insvehibys[1]);
    }
    else {
      this.insuredDetailForm.get('adtnl_detail_vhclOwnBy')?.setValue(this.insvehibys[0]);
    }

    //NCD
    
    var indexNCD = this.NCDData.findIndex(function (obj, k) {
      return obj.NCDDescription == resData.NCD;
    });
    let NCDVal = this.NCDData[indexNCD];
    console.log(NCDVal)
    if (indexNCD != -1)
      this.insuredDetailForm.get('adtnl_detail_NCD')?.setValue(NCDVal);
    else
      this.insuredDetailForm.get('adtnl_detail_NCD')?.setValue(this.NCDData[0]);

    this.insuredDetailForm.get('weight_empty')?.setValue(resData.VEH_WT_CODE);

    this.insuredDetailForm.get('weight_full')?.setValue(resData.VEH_WT_FULL);



    // console.log(resData.VEH_WT_FULL)




    // this.insuredDetailForm.get('rg_model_year')?.setValue(yearVal);

    //  VEHICLE make - mode - mody type - trim - engine - sum insured - repair type binding start here

    this.insuredDetailForm.get("rg_TC_num")?.setValue(resData.TCFNumber);
    this.insuredDetailForm.get("d_TC_number")?.setValue(resData.TCFNumber);
    //  console.log(resData.VEH_NOOF_DOORS);
    this.insuredDetailForm.get("rg_noOfDoor")?.setValue(resData.VEH_NOOF_DOORS);
    this.insuredDetailForm.get("driver_occupation")?.setValue(resData.OccupationName);
    this.insuredDetailForm.get("vhclTPLCoverage")?.setValue(resData.PolicyType);

    this.insuredDetailForm.get("rg_place_issue")?.setValue(resData.RegistrationPlace);
    this.insuredDetailForm.get("license_no")?.setValue(resData.LicenceNumber);

    // if(resData.SchemeCode=="66A" || resData.SchemeCode=="60D") to


    this.quoteDetail.VehicleMake = resData.VehicleMake;
    this.quoteDetail.VehicleModel = resData.VehicleModel;
    this.quoteDetail.TrimCode = resData.TrimCode;
    this.quoteDetail.TrimName = resData.TrimName;
    this.quoteDetail.BodyType = resData.BodyType;
    this.retrieve_repair_type = resData.RepairType;
    this.quoteDetail.RepairType = resData.RepairType;

    // console.log("debug - 4");
    // this.getVhclMakeDataByRetrive(resData);


    //     //Gender
    var indexGender = this.genders.findIndex(function (obj, k) {
      return obj.value === resData.InsuredGender;
    });
    let gnderVal = this.genders[indexGender];
    this.insuredDetailForm.get('e_gender')?.setValue(gnderVal);

    // Business Type 

    if (resData.BusinessCategory) {
      var indexBusniesType = this.industryTypeArr.findIndex(function (obj, k) {
        return obj.IndustryName.toLowerCase() === resData.BusinessCategory.toLowerCase();
      });
      let bType = this.industryTypeArr[indexBusniesType];
      this.insuredDetailForm.get('industry_type')?.setValue(bType);
    }


    //     //Vehicle Cylinders
    var indexCylinder = this.vehicylinders.findIndex(function (obj, k) {
      return obj.CylinderCode === resData.VehicleCylinders;
    });
    let cylVal = this.vehicylinders[indexCylinder];
    this.insuredDetailForm.get('adtnl_detail_cylinder')?.setValue(this.vehicylinders[0]);
    this.vehiseatcaps = [];
    this.vehiseatcaps.push({ value: resData.PassengerCount, viewValue: resData.PassengerCount });

    this.insuredDetailForm.get("rg_num_passenger")?.setValue(this.vehiseatcaps[0]);


    //    //REG PLACE
    if (resData.RegistrationPlace != '' && resData.RegistrationPlace != null && resData.RegistrationPlace != undefined) {
      var indexPlace = this.cityArr.findIndex(function (obj, k) {
        return obj.CityName === resData.RegistrationPlace;
      });
      // console.log("Debug 1");
      let placeal = { CityName: '' };
      if (indexPlace == -1)
        placeal = this.cityArr[0];
      
      else
        placeal = this.cityArr[indexPlace];
        console.log(placeal);
      this.insuredDetailForm.get('rg_place_issue')?.setValue(placeal);
      
      
      //  this.quoteDetail.regplace = placeal.CityName;
      this.getPlateCodeRenew(this.quoteDetail.RegistrationPlace, resData.PlateCategory);
    }

    //Plate category
    this.vehPlate = [];
    if (resData.PlateCategory != null) {

      this.vehPlate = [{ CRS_VEH_CAT_CODE: 2001, PlateCategotyName: resData.PlateCategory, label: resData.PlateCategory, value: resData.PlateCategory }];

      this.insuredDetailForm.get('rg_type')?.setValue(this.vehPlate[0].value);

    }
    else {
      this.vehPlate = [{ CRS_VEH_CAT_CODE: 2001, PlateCategotyName: "PRIVATE", label: "PRIVATE", value: "PRIVATE" }];
      this.insuredDetailForm.get('rg_type')?.setValue(this.vehPlate[0].value);
    }

if(resData.FirstRegistrationDate != null ){
  let dataArray = resData.FirstRegistrationDate
  let nDate = new Date();
  nDate.setFullYear(dataArray[2]);
  nDate.setMonth(dataArray[1] - 1);
  nDate.setDate(dataArray[0]);
  console.log(nDate)
  this.insuredDetailForm.get('rg_reg_date')?.setValue(res.FirstRegistrationDate);
  this.onVehiclAgeChange(this.insuredDetailForm.value.rg_model_year.value);
}
if(resData.FirstRegistrationDate == null){
  this.insuredDetailForm.get('rg_reg_date').setValue('');
}


    setTimeout(() => {

      if (resData?.VEH_PLATE_CODE == null || resData?.VEH_PLATE_CODE == '') {

        this.insuredDetailForm.get("rg_plateCode")?.setValue('');
      } 
      else {
        this.plateCodeArray = [{ PlateCode: resData?.PlateCodeName, CRS_Plate_Code: resData?.VEH_PLATE_CODE }];
        this.insuredDetailForm.get("rg_plateCode")?.setValue(resData.PlateCodeName);
      }
      this.getPlateCode(this.insuredDetailForm.value.rg_place_issue.CityName, 2);

      this.getRrepairType();
    }, 2000);

    this.insuredDetailForm.get("rg_traffic_plate_num").setValue(resData?.VEH_PLATE_CODE);
    this.insuredDetailForm.get("rg_TC_num").setValue(resData?.VEH_REGN_NO);
    this.insuredDetailForm.get("rg_ins_exp").setValue(new Date(resData?.PreviousPolExpDate));

    if (this.convertDate(this.insuredDetailForm.value.rg_ins_exp) < this.convertDate(this.policyMinDate)) {
      this.polStartDate = new Date(new Date().setDate(new Date().getDate() + 14));
      this.showGapUploadDoc = true;
      this.referalStatus = true;
    }
    else {
      this.polStartDate = new Date(new Date(this.insuredDetailForm.value.rg_ins_exp).setDate(new Date(this.insuredDetailForm.value.rg_ins_exp).getDate() + 1));
      this.referalStatus = false;
      this.showGapUploadDoc = false;
    }




    //Vehicle Color
    if (resData.VehicleColour == null || resData.VehicleColour == '') {
      this.insuredDetailForm.get('vhclColor')?.setValue('');
    } else {
      var indexColor = this.vhclColorArr.findIndex(function (obj, k) {
        return obj.ColorName === resData.VehicleColour;
      });
      let clrVal = this.vhclColorArr[indexColor];
      this.insuredDetailForm.get('vhclColor')?.setValue(clrVal);
    }



    var indexRegType = this.plateCatArray.findIndex(function (obj, k) {
      return obj.value.toLowerCase() === resData.PlateCategory.toLowerCase();
    });
    let typelVal = this.plateCatArray[indexRegType];

    if (typelVal?.value)
      this.insuredDetailForm.get('rg_type')?.setValue(typelVal?.value);





  });






  /************ Insured Details  data ********************/




}
targetFile = '';
onBORUpload(event, docName, FiledName, files: FileList) {

  this.docNameType = FiledName;
//  this.showLoader.bor_card=true;
  const formData = new FormData();
  this.targetFile = event.target.files[0] ;
  formData.append('file', event.target.files[0]);
  formData.append('docName', docName);
  formData.append('source', 'B2B');
  formData.append('stage', 'QUOTE');
  formData.append('schemeCode',this.sideForm.value.schemeCode);

   this.bor_formData= formData;

   this.refer_type = 'BORQUOTE';
   this.refer_condtion_type = 6;
}

submitBOR(){

  this.motorQuoteService.uploadBOR(this.bor_formData).subscribe(res => {
    // console.log(res);
    if(res.response_message=='Success'){

      this.sendRefferMailToAdmin(6);

      this.motorQuoteService.proc_bor(this.insuredDetailForm.value.rg_chassis_num, this.getQuoteNumber).subscribe(res => {
// console.log(res);

      });

      this.showLoader.bor_card=false;

      this._route.navigate(['dashboards/project']);

      Swal.fire("BOR has been submitted for approval. Should you require any clarification please contact your relationship manager. ");

    }

  });
}

submitAdditionalDocs(){
  if(this.bor_formData){
  this.showLoader.bor_card=true;
  this.motorQuoteService.uploadBOR(this.bor_formData).subscribe(res => {
    this.showLoader.bor_card=false;
    this.hideImages.additionalDoc = true;
    // console.log(res);
    this.insuredDetailForm.get('additional_DocumentFilePath')?.setValue(res.FileDir);
    this.getUserAccessPermission( this.stepper,
      2,
      1);
  });
}else{

  Swal.fire('', 'Please fill all the mandatory data', 'error');
}
}


checkIsBorOrAddtionInfo(){

  if(this.quoteStatus=='ADDITIONALINFO'){

   this.insuredDetailForm.get('additional_DocumentFilePath')?.setValidators([Validators.required]);
   this.insuredDetailForm.get('additional_DocumentFilePath')?.updateValueAndValidity()
   
  }
}

engineSizeList(){
  this.showLoader.vhclEngine = true ;

  if(this.insuredDetailForm.value.rg_model_year?.label!='' && this.insuredDetailForm.value?.adtnl_detail_bodyType?.BodyTypeName!=''){
  this.motorQuoteService.getEngineSizeList(this.insuredDetailForm.value,this.sideForm.value.schemeCode).subscribe(res => {

    if(res.response_message?.LookupList!='')
    this.engineList = res.response_message?.LookupList;
    this.showLoader.vhclEngine = false ;
    if(!this.engineList) return false ;
   
    //  console.log(this.engineDefaultValue);

     if(this.vehicleData?.length!=0)
       this.engineDefaultValue = this.vehicleData?.Technical.EngineDisplacementNominal.Value;

     if(this.engineDefaultValue!=""){
      let engineValue = {} ;
      res.response_message?.LookupList?.forEach((item, index) => {

          if(this.engineDefaultValue == item.Name) engineValue = item ;
      });

      if(engineValue=="" && res.response_message.LookupList.length==1 ){

        this.insuredDetailForm.get('adtnl_detail_engine')?.setValue(res.response_message.LookupList[0]);

        
      }else
      this.insuredDetailForm.get('adtnl_detail_engine')?.setValue(engineValue);
      this.engineDefaultValue = "";
     }
  });}else{

    setTimeout(()=>{this.engineSizeList();},1000);   
  }

}

// drog drop

DragDropfiles(event) {
  // console.log(event)
      this.showLoader.multipleDoc = true;
      this.multilpleFile = [];
      for (var i = 0; i < event.length; i++) {
        this.showLoader.multipleDoc = true;
        const formData = new FormData();
        formData.append('file', event[i].file);
        formData.append('stage', 'QUOTE');
        formData.append('schemeCode', this.sideForm.value.schemeCode);
  
        this.motorQuoteService.uploadMultipleDocuments(formData).subscribe(res => {
 
          let updateMemResponse = res;
          this.document_data = updateMemResponse.Document_data;
          this.hideImages.multipleDoc = true;
           return false ;
          if (updateMemResponse.res_code == 1) {
            let fileType = updateMemResponse.File.split(".");
            fileType = fileType[fileType.length - 1];
            fileType = fileType == "pdf" ? "PDF" : "IMG";
  
  
            this.multilpleFile.push({
              "file": updateMemResponse.FileDir,
              "fileType": fileType,
              'file_name': 'Other',
              'file_dir': updateMemResponse.FileDir,
              'docName': updateMemResponse.File,
            });
  
            this.tempMultipleDocData = this.multilpleFile;
  
              this.showLoader.multipleDoc = false;
  
            // this.document_data.forEach((item, index) => {
  
            //   if (item.ErroCode == 'Null') {
  
            //     if (item.DocumentType == 'Emirates-Id' && item.DocumentSubType == 'Front') {
  
            //       this.getEmiratesIdData(1, item);
            //     }
            //     else if (item.DocumentType == 'Emirates-Id' && item.DocumentSubType == 'Back') {
  
            //       this.getEmiratesIdData(2, item);
            //     }
            //     else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Front') {
  
            //       this.getDrivingLicData(1, item);
            //     }
            //     else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Back') {
  
            //       this.getDrivingLicData(2, item);
            //     }
            //     else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Back' && updateMemResponse.vechile_data) {

                  
            //       if(updateMemResponse.vechile_data.length>0)
            //       this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
  
            //        this.getRegCardData(1, item);
            //       //}
  
            //     }
            //     else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Front') {
  
            //       this.getRegCardData(2, item);
            //     }
            //     else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Both') {
            //       this.getRegCardData(2, item);
            //       if(updateMemResponse.vechile_data.length>0)
            //       this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
            //       this.getRegCardData(1, item);
            //     }
            //     else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Both') {
            //       this.getDrivingLicData(2, item);
            //       this.getDrivingLicData(1, item);
            //     }
            //     else if (item.DocumentType == 'Emirates-Id' && item.DocumentSubType == 'Both') {
            //       this.getEmiratesIdData(2, item);
            //       this.getEmiratesIdData(1, item);
            //     }
            //   }
            // });
          }
          if (updateMemResponse.response_code == 5) {
  
            this.showLoader.multipleDoc = false;
  
            Swal.fire("Please select valid file format.", "only .pdf, .jpg, .png and .jpeg file formats allowed.", 'error');
  
          }
  
          if (updateMemResponse.response_code == 6) {
  
            this.showLoader.multipleDoc = false;
  
            Swal.fire(updateMemResponse.response_status);
          }
  
  
              // console.log((event.length-1),i);
  
  
  
        });
      }
      
    }

 
  tickDriver(benifitItem,i){

    if(this.PlanDataJson.planBenefitData.data[i].checked){
      if(benifitItem.BenefitId==319){

        this.PlanDataJson.planBenefitData.data[2].checked = true ;
        this.PlanDataJson.planBenefitData.data[2].disable = true;
        this.addOptionalBenigits(318,2);
        this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
      }
    }else{

      if(benifitItem.BenefitId==319)
      this.PlanDataJson.planBenefitData.data[2].disable = false;
    }

   }


   accountChange(){

    let branch = this.sideForm.value.branchID;

    this.sideForm.get("Accounting").setValue(branch);
   }

   modelYearRang(){
    //return false ;
    let  currentYear1 =  new Date();
    let currentYear:number = currentYear1.getFullYear();
    let currentMonth:number = currentYear1.getMonth()+1;
  
    let maxYear = currentYear ;
    let minYear = currentYear - 32;
    if(currentMonth>=6){

      maxYear = currentYear+1;
    }
    
    let moderYr = this.insuredDetailForm?.value?.rg_model_year;
    let yrIndex= 0;

    if(this.insuredDetailForm?.value?.adtnl_detail_insType){ 
      //  console.log("debug 488",this.insuredDetailForm.value.adtnl_detail_insType);

    if("THIRD PARTY LIABILITY"==this.insuredDetailForm.value.adtnl_detail_insType.ProductShortName) minYear = currentYear - 30;
    else if(this.sideForm.value.schemeCode=="60D") minYear = currentYear - 20;
    else minYear = currentYear - 12;
    }
    this.vehimodelyrs=[];
    let yrm = '';
    for(let i=maxYear;i>=minYear;i--){
      this.vehimodelyrs.push({ value: i.toString(), label: i.toString() });
    //  yrm = this.vehimodelyrs[i].label;
    if(this.insuredDetailForm?.value?.rg_model_year.label==i) yrIndex = this.vehimodelyrs.length-1 ;

    }
   // this.insuredDetailForm?.get("rg_model_year")?.setValue( this.vehimodelyrs[yrIndex]);
   }
   

   importEdata:any;
  fillFormWithEdataResponse(){


              //  console.log(this.importEdata);
              this.isClickChassisValidate = true ;
              this.insuredDetailForm.get('isChassisValidate')?.setValue('1');

              this.insuredDetailForm.get('rg_noOfDoor').setValue(Number(this.chassis_No_Details.General.NoOfDoors));
                /****  SET Edata Yr , Model , Make , Body , Trim , Engine , Capacity , Pagenger  */
                //JTEJU3FJ1FK081528


                const schemes = [ "66S","66RK"," 66Q","60D"];

                if(!schemes.includes(this.sideForm.value.schemeCode)){
                  this.modelYearRang();

                  this.vehimodelyrs.forEach((item, index) => {

                    if(item.value==this.chassis_No_Details.General.ModelYear)

                    this.insuredDetailForm.get("rg_model_year")?.setValue(item);



                  });
                 
                }else{
                // Model Year Binding 
                this.vehimodelyrs = [] ;
                this.vehimodelyrs.push({ value: this.chassis_No_Details.General.ModelYear.toString(), label: this.chassis_No_Details.General.ModelYear.toString() });
                this.insuredDetailForm.get("rg_model_year")?.setValue(this.vehimodelyrs[0]);

                }

                this.regMinDate = new Date(this.chassis_No_Details.General.ModelYear-1, 0, 1);
                // console.log(this.regMinDate)
                this.regMaxDate = new Date(this.chassis_No_Details.General.ModelYear+1, 0, 1);
               

                // Vehicle Make Binding 
                this.vhclMakeArr = [] ;
                this.vhclMakeArr.push({ VehicleMakeId:1,
                                        VehicleMakeName: this.chassis_No_Details.General.Make,
                                        Active: true ,
                                        IsReferral:0,
                                        CRS_VEH_CODE:1
                                       });
                this.insuredDetailForm.get("rg_vhcl_make")?.setValue(this.vhclMakeArr[0]);


                // Vehicle Model Binding 
                this.vhclModelArr = [] ;
                this.vhclModelArr.push({ VehicleModelId:1,
                                        VehicleModelName: this.chassis_No_Details.General.Model,
                                        Active: true ,
                                        SeatingCapacityExDriver:0,
                                        BodyTypeId:1,
                                        CRS_MODEL_CODE:1,
                                        EDATA_MODEL_CODE:"No"
                                       });
                // console.log(this.vhclModelArr);
                this.insuredDetailForm.get("rg_vhcl_model")?.setValue(this.vhclModelArr[0]);


                 // Vehicle Body Type Binding 
                this.vhclBodyTypeArr = [] ;
                this.vhclBodyTypeArr.push({id:1,BodyTypeName:this.chassis_No_Details.General.BodyType});
                this.insuredDetailForm.get("adtnl_detail_bodyType")?.setValue(this.vhclBodyTypeArr[0]);


                // Vehicle Trim Binding 
                this.vehitrims = [] ;
                this.vehitrims.push({ Name:this.chassis_No_Details.General.Trim });
                this.insuredDetailForm.get("adtnl_detail_trim")?.setValue(this.vehitrims[0]);


                // Vehicle Engine Binding 
                let engineData = this.chassis_No_Details.Technical.EngineDisplacementNominal.Value ;
                this.engineList= [  {Name:engineData , Code:engineData , Cylinders:engineData,Passengers:4} ] ;
                this.insuredDetailForm.get('adtnl_detail_engine')?.setValue(this.engineList[0]);

                // Vehicle Cylinders Binding 
                this.vehicylinders = [{Id	:1 , CylinderName	: this.chassis_No_Details.Technical.EngineCylinders ,  CylinderCode :	this.chassis_No_Details.Technical.EngineCylinder}];
                this.insuredDetailForm.get("adtnl_detail_cylinder")?.setValue(this.vehicylinders[0]);


                // Vehicle Number Of Passenger Binding 
                this.vehiseatcaps = [{value	:this.chassis_No_Details.General.NoOfSeats , viewValue	: this.chassis_No_Details.General.NoOfSeats}];
                // console.log(this.vehiseatcaps[0])
                this.insuredDetailForm.get("rg_num_passenger")?.setValue(this.vehiseatcaps[0]);

               //HasGCCSpecification importEdata
               if(this.chassis_No_Details.EstimatedMileage != ''){
                this.insuredDetailForm.get("mileage")?.setValue( this.chassis_No_Details.EstimatedMileage);
               }
              else{
                this.insuredDetailForm.get("mileage")?.setValue('0');
               }

                if(this.importEdata?.IsGccSpec==0){ 
              
                this.GCC.Yes = true; 
                this.GCC.No = false;
                this.insuredDetailForm.get("adtnl_detail_gccSpecified")?.setValue("Yes");
                    } 
               else{ 
                this.GCC.Yes = false; 
                this.GCC.No = true;
                 this.insuredDetailForm.get("adtnl_detail_gccSpecified")?.setValue("No");
                 this.GCC.edata  = true;
                }
                

                if(!this.isEditRetriveOnPageLoad){

                  let gccSpec = "No";
                  if(this.quoteDetailPrev.HasGCCSpecification=="Not" || this.quoteDetailPrev.HasGCCSpecification=="No" ){
                  gccSpec = "No";
                  this.GCC.Yes= false;
                  this.GCC.No= true;
                  }
                  else
                  {
                    gccSpec = "Yes";
                    this.GCC.Yes= true;
                    this.GCC.No= false;

                  }
                  
                  this.insuredDetailForm.get("adtnl_detail_gccSpecified")?.setValue(gccSpec); 
                }
                this.GCC.edata = true ;
                // console.log("--------navin----",this.insuredDetailForm.value.adtnl_detail_gccSpecified);
               /*

               //Plate COde
              let plateCode = this.chassis_No_Details.General.ColourEN;
              if (plateCode != undefined) {
                var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
                  return obj.PlateCode === plateCode;
                });

                if(indexPlCode>-1){
                let plCodeVal = this.plateCodeArray[indexPlCode];
                this.insuredDetailForm.get('rg_plateCode')?.setValue(plCodeVal);
                }
              }  */

              let plateCode = this.chassis_No_Details.General.ColourEN;
              var indexColor = this.vhclColorArr.findIndex(function (obj, k) {
                return obj.ColorName === plateCode;
              });

              if(indexColor!==-1){
              let clrVal = this.vhclColorArr[indexColor];
              this.insuredDetailForm.get('vhclColor')?.setValue(clrVal);
              }

              if(this.chassis_No_Details.General.EngineNo!="" && this.chassis_No_Details.General.EngineNo!=null)
              this.insuredDetailForm.get('rg_engin_num')?.setValue(this.chassis_No_Details.General.EngineNo);

              if (this.retrieveQuoteNumber == "" ||  typeof (this.retrieveQuoteNumber) == "undefined")
              this.updateValuation_new();
          //    this.onVehiclAgeChange(this.vehicalmodelyears[0]);

               this.isClickChassisValidate = false ;
              
               setTimeout(()=>{ 

                this.isEditRetriveOnPageLoad = true ;
               },5000);
               
  }
  


  // checkIscheassisBlank(event){
  //   if(this.vehicalmodelyears.length==1 && event==""){
  //     this.modelYearRang();
  //   }
  // }

  showGapUploadDoc = false ;
  tmp_rg_ins_exp ;
  onDateChange(modelyear){


    // console.log(this.policyMinDate)
    // console.log(this.insuredDetailForm.value.rg_ins_exp)
    if(this.convertDate(this.insuredDetailForm.value.rg_ins_exp) <= this.convertDate(this.policyMinDate))
  {

  let vhclPrevYear = Number(modelyear.value) - 1;
  this.mindate = new Date(vhclPrevYear, 4, 1);
 // this.mindate = 
  Swal.fire({
    title: 'Confirmation',
    text: 'There is a gap in insurance, are you sure you want to continue.',
    // type: "warning",
    showCancelButton: true,
    confirmButtonText: 'Yes',
  }).then((result) => {
    
    if(result.isConfirmed)
    {
      this.tmp_rg_ins_exp = this.insuredDetailForm.value.rg_ins_exp;
      this.showGapUploadDoc = true ;

    }else{
    //  this.insuredDetailForm.value.rg_ins_exp = this.tmp_rg_ins_exp;
      this.insuredDetailForm.get('rg_ins_exp').setValue(this.tmp_rg_ins_exp)

      this.showGapUploadDoc = false ;
    }

  });
    // cancelButtonText: 'No'
  

  //this.policyMinDate = new Date(new Date().setDate(new Date().getDate() - 180));


  }else{
    this.tmp_rg_ins_exp = this.insuredDetailForm.value.rg_ins_exp;

  }
}




/******* If scheme TPL and 60d 60a then hide and  remove validation */

hideRemoveEng= false;
hideRemoveTrim= false;

checkEngineValidation(){


  if(this.sideForm.value?.schemeCode){
  
  const schemes = ["65S" , "65Q4" ,  "65RK" , "66S" , "66Q" ,  "66RK","60A-MR"];

  if(schemes.includes(this.sideForm.value.schemeCode)){

    this.insuredDetailForm.get('adtnl_detail_engine')?.setValidators([Validators.required]);
    this.insuredDetailForm.get('adtnl_detail_engine')?.updateValueAndValidity();
    this.hideRemoveEng = false ;

  }
  else{

    this.insuredDetailForm.get('adtnl_detail_engine')?.setValidators(null);
    this.insuredDetailForm.get('adtnl_detail_engine')?.updateValueAndValidity();
    this.hideRemoveEng = true ;
 
  }
}
}

checkTrimValidation(){

  const schemes = ["65S" , "65Q4" , "65RK","60A-MR"];

  if(schemes.includes(this.sideForm.value.schemeCode)){

    this.insuredDetailForm.get('adtnl_detail_trim')?.setValidators([Validators.required]);
    this.insuredDetailForm.get('adtnl_detail_trim')?.updateValueAndValidity();
    this.hideRemoveTrim = false ;

  }
  else{

    this.insuredDetailForm.get('adtnl_detail_trim')?.setValidators(null);
    this.insuredDetailForm.get('adtnl_detail_trim')?.updateValueAndValidity();
    this.hideRemoveTrim = true ;
 
  }

  


}


callWhenTPL(event){  

  const schemes = ["65S" , "65Q4" ,  "65RK" ,  "66Q" ,  "66RK"];

  if(schemes.includes(this.sideForm.value.schemeCode)){


  }else{

   // this.engineSizeList();

  }


}

multiGap = [];
viewSupportingDocument = [];
submitGAP(event, docName, FiledName, files: FileList) {
  
  this.docNameType = FiledName;
  if (this.docNameType == 'supporting_Document_GAP') {
    this.showSupportingDoc = true;
  }

  // console.log(event);
  // console.log(event.target.files);

  

  this.multiGap = [];
  this.viewSupportingDocument = [];
  for (var i = 0; i < event.target.files.length; i++) {
    this.showLoader.multipleGAPDoc = true;
    const formData = new FormData();
    formData.append('file', event.target.files[i]);
    formData.append('docName', docName);
    formData.append('source', 'B2B');
    formData.append('stage', 'QUOTE');
    formData.append('schemeCode', this.SchemeCode);
    // console.log(formData);

    this.motorQuoteService.uploadGAPDocuments(formData).subscribe(res => {
      // console.log(res);
      // return;
      this.showLoader.bor_card = false;
      let updateMemResponse = res;
      this.showSupportingDoc = false;
      this.hideImages.multipleDoc = true;

      if (updateMemResponse.res_code == 1) {
        let fileType = updateMemResponse.FileUrl.split(".");
        fileType = fileType[fileType.length - 1];
        fileType = fileType == "pdf" ? "PDF" : "IMG";

        let formArrayValue: any = this.insuredDetailForm.value;


      formArrayValue[FiledName] = updateMemResponse.File;
      formArrayValue[FiledName + "FilePath"] = updateMemResponse.FileDir;
      let tempDocumentArray = {
        file_name: FiledName,
        file_dir: updateMemResponse.FileDir,
        docName: updateMemResponse.File,
      }

      if (FiledName == 'supporting_Document_GAP') {
        // this.hideImages.reg_card_front = true;
        this.insuredDetailForm.get('DocFilePath')?.setValue(updateMemResponse.FileDir);
        this.insuredDetailForm.get('supporting_Document_GAP')?.setValue(updateMemResponse.File);
        this.insuredDetailForm.get('fileType')?.setValue(fileType);
        this.tempDocArray[1] = tempDocumentArray;
      }

        // console.log(fileType)
        this.multiGap.push({
          "file": updateMemResponse.FileDir,
          "fileType": fileType,
          'file_name': 'supporting-gap-document',
          'file_dir': updateMemResponse.FileDir,
          'docName': updateMemResponse.File,

        });

        this.viewSupportingDocument.push({ DocFilePath: updateMemResponse.FileDir, fileType: fileType });
        // console.log(this.viewSupportingDocument)
      }
    });
  }
}


singleFileUpload(event){
  this.multiGap = [];
  this.viewSupportingDocument = [] ;
  for (var i = 0; i < event.target.files.length; i++) {
    this.showLoader.multipleGAPDoc = true;
    const formData = new FormData();
    formData.append('file', event.target.files[i]);
    formData.append('stage', 'QUOTE');
    formData.append('schemeCode', this.SchemeCode);

    this.motorQuoteService.uploadGAPDocuments(formData).subscribe(res => {

      let updateMemResponse = res;
    
      this.hideImages.multipleDoc = true;

      if (updateMemResponse.res_code == 1) {
        let fileType = updateMemResponse.FileUrl.split(".");
        fileType = fileType[fileType.length - 1];
        fileType = fileType == "pdf" ? "PDF" : "IMG";


        this.multiGap.push({
          "file": updateMemResponse.FileDir,
          "fileType": fileType,
          'file_name': 'Supporting Document',
          'file_dir': updateMemResponse.FileDir
          
        });

        this.viewSupportingDocument.push({DocFilePath:updateMemResponse.FileDir}); 

       }
    });
  }

}

adRemoveTradeValidation(event){

  if(event=="Yes"){
    this.insuredDetailForm.get('docTRNCertificate')?.setValidators([Validators.required]);
    this.insuredDetailForm.get('docTRNCertificate')?.updateValueAndValidity();

  }else{

    this.insuredDetailForm.get('docTRNCertificate')?.setValidators(null);
    this.insuredDetailForm.get('docTRNCertificate')?.updateValueAndValidity();

  }


}




}
