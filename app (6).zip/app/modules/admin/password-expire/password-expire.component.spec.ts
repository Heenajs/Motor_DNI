import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordExpireComponent } from './password-expire.component';

describe('PasswordExpireComponent', () => {
  let component: PasswordExpireComponent;
  let fixture: ComponentFixture<PasswordExpireComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PasswordExpireComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PasswordExpireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
