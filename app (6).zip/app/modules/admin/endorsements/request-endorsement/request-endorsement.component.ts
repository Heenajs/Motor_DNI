import { Component, OnInit,AfterViewInit, ViewChild, ɵConsole ,ElementRef,Directive, TemplateRef} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';
// import { MotorquoteService } from '../../../motorquote.service';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take ,takeUntil} from 'rxjs/operators';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { FuseDrawerMode, FuseDrawerService } from '@fuse/components/drawer';
import { GlobalService } from '../../../service/global.service';
import { ViewpolicyService } from '../../../service/viewpolicy.service';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { MatStepper } from '@angular/material/stepper';
interface Product {
   value: string;
   viewValue: string;
 }
 interface Nationality{
   value: string;
   viewValue: string;
 }
 interface Subendorsement{
   value: string;
   viewValue: string;
 }
 interface Endorsement{
  value: string;
  viewValue: string;
 }
 interface Branch{
  value: string;
  viewValue: string;
 }
 interface CoverType{
  value: string;
  viewValue: string;
 }

 interface Visa{
  value: string;
  viewValue: string;
 }

 interface Visarigion{
  value: string;
  viewValue: string;
 }
 interface Partner{
  value: string;
  viewValue: string;
 }


@Component({
  selector: 'app-request-endorsement',
  templateUrl: './request-endorsement.component.html',
  styleUrls: ['./request-endorsement.component.scss']
})
export class RequestEndorsementComponent implements OnInit {

  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('stepper') stepper : MatStepper;
  panelOpenState = false;

  horizontalStepperForm: FormGroup;
  Selectpolicy:FormGroup
  Endorsement:FormGroup
  formFieldHelpers: string[] = [''];
  Show: boolean=false;
  localStorageData: any;
  partnerId: any;
  PartyCode: any;
  businessSource: any;
  cedantId: any;
  userId: any;
  userRole: any;
  userType: any;
  partner_Id: any;
  EndorsementData: any;
  endtype: any;
  EndorsementDataSub: any;
  getEndorsementSubId: any;
  selection_id: any;
  sideForm: FormGroup;
  disabledStatus:boolean =false;
  nation=[];
  partnersArr=[];
  username;
  policyDetail:any = {};
  getPoliciesinputData: any;
  docNameType: any;
  schemecode: any;
  bor_formData: FormData;
  BranchId: any;
  AccountingBranch: any;
  partnerBranchArr:any=[];
  branchId: any;
  retrieveQuoteNumber: string;
  branchVal: any;
  constructor(public _route: Router,private _formBuilder: FormBuilder,public dialog: MatDialog, public motorQuoteService: MotorquoteService, public viewpolicyService:ViewpolicyService,
    public globalService: GlobalService, public _activatedroute: ActivatedRoute)
  {
  
  }


  ngOnInit(): void {

  this.localStorageData = this.globalService.getLocalStorageData();

     
         this.partnerId = this.localStorageData.PartnerId;
         this.UserId = this.localStorageData.UserId;
         this.BranchId=this.localStorageData.BranchId;
      
         this.AccountingBranch=this.localStorageData.AccountingBranch;
       
         this.username = this.localStorageData.EmailAddress;
         this.schemecode = this.localStorageData.EmailAddress;

         this.sideForm = this._formBuilder.group({
            schemeCode: ['', Validators.required],
            partnerID: ['', Validators.required],
            branchID:['',Validators.required],
            Accounting: ['']
         });
//

     // Horizontal stepper form
     this.horizontalStepperForm = this._formBuilder.group({



      
      Selectpolicy: this._formBuilder.group({
         //  basicfile   : [''],
         policyNo: ['', Validators.required],
         polDetail: ['', Validators.required]
      }),



      Endorsement: this._formBuilder.group({
        Polcy_1: ['', Validators.required],
        Clientname : ['', Validators.required],
        contactPerson: ['', Validators.required],
        mobileNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
        email: ['',[Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
        BoxNumber : ['',Validators.required],
        EndorsementType:['',Validators.required],
        EndorsementTypeTwo:['',],
        content:['', Validators.required],
        Documentone:['',Validators.required],
        upload1:['',],
        coverStartDate:['',Validators.required],
        coverEndDate:['',Validators.required]
      }),
      step3: this._formBuilder.group({
       //  fullName: ['', Validators.required],
       //  lastName : ['', Validators.required],
       //  userName : ['', Validators.required],
       //  dueDate    : ['']
    }),
   
  });
  this.getQuotationFormData()
  this.getEndorsement();
  this.getPartnerBranchList()

// this.getEndorsementSub();
  }



  getQuotationFormData(){

    this.motorQuoteService.getQuotationFormData().subscribe(response =>{
      // this.formDataRes = response;

       this.partnersArr = response.Partners;


    });
    this.sideForm.get("partnerID").setValue(this.partnerId);

  }



 
  getEndorsement (){
    this.motorQuoteService.getEndorsement(this.partnerId).subscribe((res)=>{
      this.EndorsementData=res.response_data
 

    })
  }

  getEndorsementSub()
  {
    this.motorQuoteService.getEndorsementSub(this.partnerId,this.endtype,).subscribe((res)=>{
      this.EndorsementDataSub=res.response_data


    })
  }

  getEndorsementevent(event){
   
    this.selection_id = event;
    this.motorQuoteService.getEndorsementSub(this.partnerId, this.selection_id).subscribe((res)=>{
    this.EndorsementDataSub=res.response_data
   

    })
  }

  getCustomerPolicyDetail(stepper){
    this.horizontalStepperForm.controls.Selectpolicy.get("polDetail")?.setValue("");
    // console.log(" check ",this.horizontalStepperForm.controls.Selectpolicy.get("policyNo")?.setValue("1111"));
    this.viewpolicyService.getCustomerPolicyDetails(this.partnerId,
                                                    this.username,
                                                    this.horizontalStepperForm.value.Selectpolicy.policyNo,
                                                    "MT").subscribe(res=>{

        this.horizontalStepperForm.controls.Selectpolicy.markAllAsTouched();

      if(res.res_code	==1){
        this.policyDetail = res.data[0]	;
        this.horizontalStepperForm.controls.Selectpolicy.get("polDetail")?.setValue(res.data);
        this.horizontalStepperForm.controls.Endorsement.get("Polcy_1")?.setValue( this.policyDetail.PolicyNumber);
        this.horizontalStepperForm.controls.Endorsement.get("coverStartDate")?.setValue(this.dateConvert(this.policyDetail.DateIssued));
        this.horizontalStepperForm.controls.Endorsement.get("coverEndDate")?.setValue(this.dateConvert(this.policyDetail.ExpiryDate));
        this.horizontalStepperForm.controls.Endorsement.get("Clientname")?.setValue( this.policyDetail.PolicyHolderName);
        this.horizontalStepperForm.controls.Endorsement.get("contactPerson")?.setValue( this.policyDetail.PolicyHolderName);
        this.horizontalStepperForm.controls.Endorsement.get("mobileNumber")?.setValue( this.policyDetail.MobileNumber);
        this.horizontalStepperForm.controls.Endorsement.get("email")?.setValue( this.policyDetail.EmailAddress);
        this.horizontalStepperForm.controls.Endorsement.get("BoxNumber")?.setValue( this.policyDetail.POBox);
        

        stepper.selectedIndex = 1;
        
      }else{
       

        this.horizontalStepperForm.controls.Selectpolicy.get("polDetail")?.setValue("");
      }

      

    })

    }

    dateConvert(inputFormat) {

      let vDOEntryArray = inputFormat.split('/');
      let DOEntry = new Date();
      DOEntry.setDate(vDOEntryArray[0]);
      DOEntry.setMonth(vDOEntryArray[1] - 1);
      DOEntry.setFullYear(vDOEntryArray[2]);
  
      return DOEntry;
  
    }
    submitdata()
    {
    //  this.getPoliciesinput()
    
      if(this.horizontalStepperForm.controls.Endorsement.valid){
        this.getPoliciesinput();
      }
      else{
        this.horizontalStepperForm.controls.Endorsement.markAllAsTouched()
      }
    }

    getPoliciesinput()
    {
   
    let endoType = this.horizontalStepperForm.value.Endorsement.EndorsementType
    let EndSubType = this.horizontalStepperForm.value.Endorsement.EndorsementTypeTwo
    let EndDesc = this.horizontalStepperForm.value.Endorsement.content
     
      this.motorQuoteService.getPoliciesinput(this.partnerId,this.UserId,this.horizontalStepperForm.value.Selectpolicy.policyNo,"MT",endoType,EndSubType,EndDesc).subscribe((res)=>{
        this.getPoliciesinputData=res.response_data
      
       if(res.res_code==1)
       { 
        this._route.navigate(['endorsement']);
       }
    })
    }
  UserId(UserId: any) {
    throw new Error('Method not implemented.');
  }


    // upload 
    onBORUpload(event, docName, FiledName, files: FileList) {

      this.docNameType = FiledName;
    //  this.showLoader.bor_card=true;
      const formData = new FormData();
      formData.append('file', event.target.files[0]);
      formData.append('docName', docName);
      formData.append('source', 'B2B');
      formData.append('stage', 'QUOTE');
   //   formData.append('schemeCode', this.SchemeCode);
    
    //   this.bor_formData= formData;

      this.motorQuoteService.uploadBOR(formData).subscribe(res => {
    
      });
    
    
    }
    //get 
    getPartnerBranchList() {
      this.partnerBranchArr = [];
  
      this.motorQuoteService
          .getpartnerBranch(this.partnerId)
          .subscribe((res) => {
              let updateRes: any = res;
  
              this.partnerBranchArr = updateRes.branchList;
              this.branchId = updateRes.branchList[0];
  
              //  branch
         
              // if (this.retrieveQuoteNumber == '') {
              //     this.partnerBranchArr.forEach((item, index) => {
              //         if (item.Id == this.branchId.Id) {
              //             this.branchVal = item;
  
              //         }
              //     });
            
              //       this.sideForm.get('branchID').setValue(this.branchVal.Id);
              //        this.sideForm.get('Accounting').setValue(this.branchVal.Id);
              // } else {
  
              
                  this.sideForm.get('Accounting').setValue(this.branchId.Id);
                  this.sideForm.get('branchID').setValue(this.branchId.Id);
  
              // }
          });
  }

}
