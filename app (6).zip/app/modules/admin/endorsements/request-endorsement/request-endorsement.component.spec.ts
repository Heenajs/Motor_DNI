import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestEndorsementComponent } from './request-endorsement.component';

describe('RequestEndorsementComponent', () => {
  let component: RequestEndorsementComponent;
  let fixture: ComponentFixture<RequestEndorsementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestEndorsementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestEndorsementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
