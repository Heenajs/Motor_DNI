import { Component, OnInit,ViewChild ,TemplateRef} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';
// import { MotorquoteService } from '../../../motorquote.service';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take ,takeUntil} from 'rxjs/operators';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { FuseDrawerMode, FuseDrawerService } from '@fuse/components/drawer';
import { GlobalService } from '../../../service/global.service';



@Component({
  selector: 'app-endorsement-history',
  templateUrl: './endorsement-history.component.html',
  styleUrls: ['./endorsement-history.component.scss']
})
export class EndorsementHistoryComponent implements OnInit {

   @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;

  panelOpenState = false;

  horizontalStepperForm: FormGroup;

  formFieldHelpers: string[] = [''];
  Show: boolean=false;
   localStorageData: any;
   partnerId: any;
 
   username: any;
   EndorsementDataSub: any;
   EmailAddress: any;
  constructor(private _formBuilder: FormBuilder,public dialog: MatDialog, 
   public motorQuote_s: MotorquoteService, 
    public globalService: GlobalService, public _activatedroute: ActivatedRoute)
  {
  
  }


  ngOnInit(): void {
   this.localStorageData = this.globalService.getLocalStorageData();
 
   //   const routeParams = this._activatedroute.snapshot.params;
       ;
            this.partnerId = this.localStorageData.PartnerId;
      
            this.EmailAddress = this.localStorageData.EmailAddress;
   //      //   this.PartyCode = this.localStorageData.PartyCode;
   //   
   //         this.cedantId = this.localStorageData.CedantId;
   //        // console.log(this.localStorageData.CedantId);
     // this.userId = this.localStorageData.UserId;
   
   //         this.businessSource = this.localStorageData.BusinessSource;
   // //console.log( this.businessSource);
      //  this.EmailAddress = this.localStorageData.EmailAddress;

   //         this.userType = this.localStorageData.UserType;
   //        // console.log( this.userType);
   
     // Horizontal stepper form
     this.horizontalStepperForm = this._formBuilder.group({
      step1: this._formBuilder.group({
         //  basicfile   : [''],
         //  country : ['', Validators.required],
         //  language: ['', Validators.required]
      }),
      step2: this._formBuilder.group({
         //  fullName: ['', Validators.required],
         //  lastName : ['', Validators.required],
         //  userName : ['', Validators.required],
         //  dueDate    : ['']
      }),
      step3: this._formBuilder.group({
       //  fullName: ['', Validators.required],
       //  lastName : ['', Validators.required],
       //  userName : ['', Validators.required],
       //  dueDate    : ['']
    }),
      step4: this._formBuilder.group({
              byEmail : this._formBuilder.group({
             //  companyNews     : [true],
             //  featuredProducts: [false],
             //  messages        : [true]
          }),

          pushNotifications: ['everything', Validators.required]
      })
  });
  this.getEndorsementhistory();

  }


  vehicalsearchClose() {
    this.dialog.closeAll();
  }
  
  searchVehicle() {
     this.dialog.open(this.callAPIDialog);     
  }

  getEndorsementhistory()
  {
    this.motorQuote_s.getEndorsementhistory(this.partnerId, this.EmailAddress).subscribe((res)=>{
      this.EndorsementDataSub=res.response_data


    })
  }
}