
import { Route, RouterModule } from '@angular/router';
import { ClaimNavComponent } from './claim-nav.component';
import { NgModule } from '@angular/core';
export const routes: Route[] = [
  {
      path     : '',
      component: ClaimNavComponent
  }
];



@NgModule({
  declarations: [
    
  ],
  imports: [
    RouterModule.forChild(routes),
   
  ]
})
export class ClaimTeamsdetailModule { }
