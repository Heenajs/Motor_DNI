import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-claim-nav',
  templateUrl: './claim-nav.component.html',
  styleUrls: ['./claim-nav.component.scss']
})
export class ClaimNavComponent implements OnInit {
  

  constructor( public _route: Router, public _activatedroute: ActivatedRoute) { }

  ngOnInit(): void {
  }
  getClaimDetailsByClaimrefno(){
    this._route.navigate(["claim-nav/claim-teams"]);
  }
}
