import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimNavComponent } from './claim-nav.component';

describe('ClaimNavComponent', () => {
  let component: ClaimNavComponent;
  let fixture: ComponentFixture<ClaimNavComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimNavComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
