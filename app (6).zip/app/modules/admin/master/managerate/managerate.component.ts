import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation,ViewChild, TemplateRef, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators,NgForm, FormControl } from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';
import { GlobalService } from '../../../service/global.service';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ViewpolicyService } from '../../../service/viewpolicy.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take ,takeUntil} from 'rxjs/operators';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { FuseDrawerMode, FuseDrawerService } from '@fuse/components/drawer';
interface Nationality{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-managerate',
  templateUrl: './managerate.component.html',
  styleUrls: ['./managerate.component.scss']
})
export class ManagerateComponent implements OnInit {
management:FormGroup
  localStorageData: any;
  partnerId: any;
  UserId: any;
  BranchId: any;
  AccountingBranch: any;
  username: any;
  schemecode: any;
  partnersArr=[];
constructor(public _route: Router,private formBuilder: FormBuilder,public dialog: MatDialog, public motorQuoteService: MotorquoteService, public viewpolicyService:ViewpolicyService,
  public globalService: GlobalService, public _activatedroute: ActivatedRoute)  { }

  ngOnInit(): void {
    this.localStorageData = this.globalService.getLocalStorageData();

   
    this.partnerId = this.localStorageData.PartnerId;
  
    this.UserId = this.localStorageData.UserId;
    this.BranchId=this.localStorageData.BranchId;
   
    this.AccountingBranch=this.localStorageData.AccountingBranch;
    this.username = this.localStorageData.EmailAddress;
    this.schemecode = this.localStorageData.EmailAddress;
    this.management=this.formBuilder.group({
      lineBusiness:['',Validators.required],
      partnerID:['',Validators.required],
      selectProduct:['',Validators.required],
      selecttype:['',]
    })
    this.getQuotationFormData()
  }
  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];

  savedata()
  {
   
    if(this.management.valid){
      this.motorQuoteService.addrate(this.management.value).subscribe(response =>{
        // this.formDataRes = response;
    
         this.partnersArr = response.Partners;
    
    
      });

    }
    else{
      this.management.markAllAsTouched()
    }
  }
  
  getQuotationFormData(){

    this.motorQuoteService.getQuotationFormData().subscribe(response =>{
      // this.formDataRes = response;

       this.partnersArr = response.Partners;


    });
    this.management.get("partnerID").setValue(this.partnerId);

  }

}
