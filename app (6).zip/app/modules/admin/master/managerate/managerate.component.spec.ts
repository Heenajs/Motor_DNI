import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerateComponent } from './managerate.component';

describe('ManagerateComponent', () => {
  let component: ManagerateComponent;
  let fixture: ComponentFixture<ManagerateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagerateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
