import { Component, OnInit, AfterViewInit, ViewChild, ɵConsole, ElementRef, Directive, TemplateRef } from '@angular/core';
import { MotorquoteService } from '../../../../modules/service/motorquote.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { GlobalService } from '../../../service/global.service';
import Swal from 'sweetalert2';
// import { AppDateAdapter, APP_DATE_FORMATS } from '../motorquote/date.adapter';
import { Router, ActivatedRoute } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { Observable, Subscription, fromEvent } from 'rxjs';

import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'app/core/auth/auth.service';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { MatStepper } from '@angular/material/stepper';
import { items } from 'app/mock-api/apps/file-manager/data';
interface Nationality {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-mangepartners',
  templateUrl: './mangepartners.component.html',
  styleUrls: ['./mangepartners.component.scss']
})
export class MangepartnersComponent implements OnInit {
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  localStorageData: any;
  partnerId: any;
  formDataRes: any;
  manage_partner: FormGroup;
  partnersArr: any;
  formDataRes1: any;
  partnertype: any;
  city: any;
  bsource: any;
  btype: any;
  blocation: any;
  dataTable: any;
  partnerBranchArr: any[];
  branchId: any;
  searchData: any;
  editData: any;
  showLoaderEdit: boolean = false;
  buttonName: string = 'Save';
  eventtype: string;
  searchLoad: boolean = false;
  products: any;
  scheme_list: any;
  buisnesssource: any;
  businesstype: any;
  businesslocation: any;
  editId: any;
  logoData: string | ArrayBuffer;
  logo:any;
  activate:any;
  Image: boolean = true;
  check: boolean = true;
  landing_img: any;
  image: any;

  statusData = [
    { value: 1, statusName: 'Active' },
    { value: 0, statusName: 'De-Active' },
  ];


  constructor(public dialog: MatDialog,public GlobalService: GlobalService, public MotorquoteService: MotorquoteService,public formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.getQuotationFormData();
    this.getPartnerData();
    this.getPartnerDetails();
    this.retrieveQuoteFormData();
    this.getSchemeCode();
    this.localStorageData = this.GlobalService.getLocalStorageData();
    this.partnerId = this.localStorageData.PartnerId;
    this.manage_partner = this.formBuilder.group({
      schemecodee:['',Validators.required],
      product: ['', Validators.required],
      partner_name: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      party_code: ['', Validators.required],
      party_name: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      parent_partner: ['', Validators.required],
      partner_type: ['', Validators.required],
      city: ['', Validators.required],
      trn_number: ['', Validators.required],
      bsource: ['', Validators.required],
      blocation: ['', Validators.required],
      address: ['', Validators.required],
      firstName: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      lastName: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      emailAddress: ['', [Validators.required, Validators.email,Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      OfficeNumber: ['', Validators.required],
      mobileNumber: ['', Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
      branchName: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      branchType: ['', Validators.required],
      activate: ['1', Validators.required],
      search: [''],
      logo: [''],
      logo_FrontFilePath: '',
      logo_FrontFileType: ''
    });
     this.getPartnerBranchList();

  }
  public showLoader = {
    img_logo: false
  }
  public hideImages = {
    img_logo: false
  }
  nation: Nationality[] = [
    { value: 'steak-0', viewValue: 'Dubai' },
    { value: 'pizza-1', viewValue: 'China' },
    { value: 'tacos-2', viewValue: 'France' },
  ];

  getQuotationFormData() {
    this.MotorquoteService.getQuotationFormData().subscribe(response => {
      this.formDataRes = response;
      this.partnersArr = this.formDataRes.Partners;
      //  this.manage_partner.get("parent_partner").setValue(this.partnerId);
    });
  }
  
  openImgDialog(img) {
    
    const dialogRef = this.dialog.open(this.callAPIDialog);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }
  getPartnerDetails() {
    this.MotorquoteService.getPartnerTable('').subscribe(response => {
      this.dataTable = response.res_data;
    });
  }

  getPartnerData() {
    this.MotorquoteService.getPartnerData(this.partnerId).subscribe(response => {
      this.partnertype = response.partnertype;
      this.city = response.city;
      this.buisnesssource = response.businessSource;
      this.businesstype = response.businessType;
      this.businesslocation = response.businessLocation;
    });
  }

  savedata() {
    if (this.manage_partner.status == 'INVALID') {
      Swal.fire('', 'Please fill all mandatory data', 'error');
      this.manage_partner.markAllAsTouched();
      this.Image = false;
      this.check = false;
      return false;
    }
    else if (this.manage_partner.value.logo_FrontFilePath == '') {
      Swal.fire("", "Please upload logo copy", 'error');
      return false;
    }
    else {
      this.savePartners();
    }
  }

  retrieveQuoteFormData() {
    this.MotorquoteService.retrieveQuoteFormData().subscribe(res => {
      let retrieveRes = res;
      this.products = retrieveRes.Products;
    });
  }

  checkValidInputData(event: any, type) {
    this.GlobalService.checkValidInputData(event, type);
  }
  
  imgLoading:boolean = false;

  onFileChange(event, docName, files: FileList) {
 this.showLoader.img_logo = true;
  var reader = new FileReader();
  reader.readAsDataURL (event.target.files[0]);
  reader.onload = (_event) =>{
    this.logoData = reader.result;
    if(this.logoData!=null){
      this.imgLoading = false;
    }
  }
  const formData = new FormData();
  formData.append('file', event.target.files[0]);
  formData.append('docName', docName);
  formData.append('source', 'B2B');
  formData.append('stage', 'QUOTE');
    formData.append('schemeCode', this.manage_partner.value.schemecodee);
    this.MotorquoteService.uploadDocuments(formData).subscribe(res => { 
      this.showLoader.img_logo = false;
      this.landing_img = res.File;
      let fileType = res.File.split(".");
      fileType = fileType[fileType.length - 1];
      fileType = fileType == "pdf" ? "PDF" : "IMG";
      let formArrayValue: any = this.manage_partner.value;
      formArrayValue[docName] = res.File;
      formArrayValue[docName + "FilePath"] = res.FileDir;
      let tempDocumentArray = {
        file_name: docName,
        file_dir: res.FileDir,
        docName: res.File,
      }
      if (docName == 'landing-logo') {
      
        this.manage_partner.get('logo_FrontFilePath')?.setValue(res.FileDir);
        this.manage_partner.get('logo_FrontFileType')?.setValue(fileType);

        // this.tempDocArray[0] = tempDocumentArray;
      }
    });
  }
  

  savePartners() {
    if (this.buttonName == 'Update') {
      this.eventtype = 'UPDATE'
      this.partnerId= this.editId
    }
    else {
      this.eventtype = 'INSERT'
      this.partnerId= this.partnerId
    }
    let formData = {
      product: this.manage_partner.value.product,
      schemecodee: this.manage_partner.value.schemecodee,
      partner_name: this.manage_partner.value.partner_name,
      cust_code: this.manage_partner.value.party_code,
      cust_name: this.manage_partner.value.party_name,
      partner_type: this.manage_partner.value.partner_type,
      City: this.manage_partner.value.city,
      trn_number: this.manage_partner.value.trn_number,
      bus_src_code: this.manage_partner.value.bsource.Id,
      bus_src_name: this.manage_partner.value.bsource.Value,
      busloc_code: this.manage_partner.value.blocation.Id,
      busloc_name: this.manage_partner.value.blocation.Value,
      address: this.manage_partner.value.address,
      firstName: this.manage_partner.value.firstName,
      lastName: this.manage_partner.value.lastName,
      emailAddress: this.manage_partner.value.emailAddress,
      OfficeNumber: this.manage_partner.value.OfficeNumber,
      mobileNumber: this.manage_partner.value.mobileNumber,
      branchname: this.manage_partner.value.branchName,
      activate: this.manage_partner.value.activate,
      parentptrid: this.manage_partner.value.parent_partner,
      landingpage: this.manage_partner.value.branchName,
      payterm: this.manage_partner.value.branchName,
      eventtype: this.eventtype,
      branchtype: this.manage_partner.value.branchType.BranchName,
      branchid: this.manage_partner.value.branchType.Id,
      logo: this.landing_img,
    };
    console.log(formData);
   
    this.MotorquoteService.AddDeletePartner(formData, this.partnerId).subscribe(response => {
      let resp = response.endorsementHistoryData[0]
      if (resp.StatusCode == "400") {
        Swal.fire("", resp.StatusMsg, 'error');
      }
      else {
        Swal.fire("", "Data saved Successfully", 'success');
        this.imgLoading = false;
        this.manage_partner.reset();
        this.clearFormErrors(this.manage_partner)
      }
      this.getPartnerDetails();
    });
  }
  clearFormErrors(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((key) => {
      const control = formGroup.get(key);
      control.setErrors(null); // Clear validation errors
    });
  }

  getPartnerBranchList() {
    this.partnerBranchArr = [];
    this.MotorquoteService
      .getpartnerBranch(this.manage_partner.value.parent_partner)
      .subscribe((res) => {
        let updateRes: any = res;
        this.partnerBranchArr = updateRes.branchList;
        this.branchId = updateRes.branchList[0];
        // this.manage_partner.get('branchType').setValue(this.branchId.Id);
      }
      );
  }

  //get SchemeCode
  getSchemeCode() {
    this.MotorquoteService.getSchemesByProduct('MT').subscribe(response => {
      this.scheme_list = response.getSchemesByProduct;
    })
  }

  getDetailsbySearch() {
    this.searchLoad = true;
    this.clearFormErrors(this.manage_partner)
    this.MotorquoteService.getDetailsBySearch(this.manage_partner.value.search).subscribe(response => {
      this.searchLoad = false;
      this.dataTable = response.vehicleMakeCode;
     
    });
  }

  EditForm(id) {
    this.buttonName = 'Update';
    this.showLoaderEdit = true;
    this.MotorquoteService.getPartnerTable(id).subscribe(response => {
      this.showLoaderEdit = false;
      this.editData = response.res_data[0];
      this.editId = id;
      // this.manage_partner.get('branchType').setValue(this.editData.BranchCategory);



     //product
      var indexProduct;
      this.products.forEach((item, index) => {
        if (item.ProductName == this.editData.ProductName) {
          indexProduct = item;
        }
      })
      this.manage_partner.get('product').setValue(indexProduct);
      this.manage_partner.get('schemecodee').setValue(this.editData.SchemeCode);
      this.manage_partner.get('partner_name').setValue(this.editData.PartnerName);
      this.manage_partner.get('party_code').setValue(this.editData.CRS_Cust_Map_Code);
      this.manage_partner.get('party_name').setValue(this.editData.CRS_Cust_Map_Name);
      this.manage_partner.get('parent_partner').setValue(this.editData.ParentPartnerId);
      this.MotorquoteService.getpartnerBranch(this.editData.ParentPartnerId).subscribe((res) => {
        let updateRes: any = res;
        this.partnerBranchArr = updateRes.branchList;
        //business type
      var indexBusinessType;
      this.partnerBranchArr.forEach((item, index) => {
        if (item.BranchName == this.editData.BranchCategory) {
          indexBusinessType = item;
        }
      })
        this.manage_partner.get('branchType').setValue(indexBusinessType);
      })
      this.manage_partner.get('partner_type').setValue(this.editData.PartnerType);
      this.manage_partner.get('city').setValue(this.editData.City);
      this.manage_partner.get('trn_number').setValue(this.editData.PartnerTRNNumber);
      //business source
      var indexBusinessSrc;
      this.buisnesssource.forEach((item, index) => {
        if (item.Value == this.editData.CRS_BusSrc_Map_Name) {
          indexBusinessSrc = item;
        }
      })
      this.manage_partner.get('bsource').setValue(indexBusinessSrc);
      //business location
      var indexBusinessLoc;
      this.businesslocation.forEach((item, index) => {
        if (item.Value == this.editData.CRS_BusLoc_Map_Name) {
          indexBusinessLoc = item;
        }
      })
      this.manage_partner.get('blocation').setValue(indexBusinessLoc);
      this.manage_partner.get('address').setValue(this.editData.Address);
      this.manage_partner.get('firstName').setValue(this.editData.PartnerName);
      this.manage_partner.get('lastName').setValue(this.editData.PartnerNameL2);
      this.manage_partner.get('emailAddress').setValue(this.editData.EmailAddress);
      this.manage_partner.get('OfficeNumber').setValue(this.editData.OfficeNumber);
      this.manage_partner.get('mobileNumber').setValue(this.editData.MobileNumber);
      this.manage_partner.get('branchName').setValue(this.editData.LandingPage);
      var indexStatus;
      this.statusData.forEach((item, index) => {
        if (item.value == this.editData.Active) {
          indexStatus = item;
        }
      })
      this.manage_partner.get('activate').setValue(indexStatus);
      this.manage_partner.get('logo_FrontFilePath').setValue(this.editData.CompanyLogoURL);
     
    });
  }
  close() { this.dialog.closeAll(); }

  canceldata() {
    this.manage_partner.reset();
    //  this.manage_partner.markAsUntouched();
    this.buttonName = 'Save';
    // this.getPartnerDetails();
  }

}
