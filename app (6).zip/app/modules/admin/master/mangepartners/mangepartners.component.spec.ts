import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MangepartnersComponent } from './mangepartners.component';

describe('MangepartnersComponent', () => {
  let component: MangepartnersComponent;
  let fixture: ComponentFixture<MangepartnersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MangepartnersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MangepartnersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
