import { Component, OnInit } from '@angular/core';
interface Nationality{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-claimhandler',
  templateUrl: './claimhandler.component.html',
  styleUrls: ['./claimhandler.component.scss']
})
export class ClaimhandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];
}
