import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimhandlerComponent } from './claimhandler.component';

describe('ClaimhandlerComponent', () => {
  let component: ClaimhandlerComponent;
  let fixture: ComponentFixture<ClaimhandlerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimhandlerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimhandlerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
