import { Component, OnInit } from '@angular/core';
interface Nationality{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-manageproduct',
  templateUrl: './manageproduct.component.html',
  styleUrls: ['./manageproduct.component.scss']
})
export class ManageproductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];
}
