import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation,ViewChild, TemplateRef, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators,NgForm, FormControl } from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';

import { ActivatedRoute, Router } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take ,takeUntil} from 'rxjs/operators';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { FuseDrawerMode, FuseDrawerService } from '@fuse/components/drawer';
interface Nationality{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-productconfig',
  templateUrl: './productconfig.component.html',
  styleUrls: ['./productconfig.component.scss']
})
export class ProductconfigComponent implements OnInit {
   
  constructor() { }

  ngOnInit(): void {
  }
  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];
}
