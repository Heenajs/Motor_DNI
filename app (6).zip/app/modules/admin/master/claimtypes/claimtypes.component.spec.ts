import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimtypesComponent } from './claimtypes.component';

describe('ClaimtypesComponent', () => {
  let component: ClaimtypesComponent;
  let fixture: ComponentFixture<ClaimtypesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimtypesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimtypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
