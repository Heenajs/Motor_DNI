import { Component, OnInit } from '@angular/core';
interface Nationality{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-claimtypes',
  templateUrl: './claimtypes.component.html',
  styleUrls: ['./claimtypes.component.scss']
})
export class ClaimtypesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];
}
