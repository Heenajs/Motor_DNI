import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation,ViewChild, TemplateRef, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators,NgForm, FormControl } from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';
import { GlobalService } from '../../../service/global.service';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ViewpolicyService } from '../../../service/viewpolicy.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take ,takeUntil} from 'rxjs/operators';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { FuseDrawerMode, FuseDrawerService } from '@fuse/components/drawer';

interface Partner {
  value: string;
  viewValue: string;
}
interface Nationality{
  value: string;
  viewValue: string;
}
interface Renewstatus{
 value: string;
 viewValue: string;
}
interface Claimstatus{
 value: string;
 viewValue: string;
}

@Component({
  selector: 'app-manageusers',
  templateUrl: './manageusers.component.html',
  styleUrls: ['./manageusers.component.scss']
})
export class ManageusersComponent implements OnInit {
  Managerusers:FormGroup
  localStorageData: any;
  partnerId: any;
  UserId: any;
  BranchId: any;
  AccountingBranch: any;
  username: any;
  schemecode: any;
  partnersArr=[];
  partnerBranchArr:any=[];
  branchId: any;
  disabledStatus:boolean =false;
  retrieveQuoteNumber: any;
  constructor(public _route: Router,private formBuilder: FormBuilder,public dialog: MatDialog, public motorQuoteService: MotorquoteService, public viewpolicyService:ViewpolicyService,
    public globalService: GlobalService, public _activatedroute: ActivatedRoute) { }

  ngOnInit(): void {

    this.localStorageData = this.globalService.getLocalStorageData();

    this.partnerId = this.localStorageData.PartnerId;
   
    this.UserId = this.localStorageData.UserId;
    this.BranchId=this.localStorageData.BranchId;
    this.AccountingBranch=this.localStorageData.AccountingBranch;
    
    this.username = this.localStorageData.EmailAddress;
    this.schemecode = this.localStorageData.EmailAddress;
    this.Managerusers=this.formBuilder.group({
      insert:['',Validators.required],
      partnerID:['',Validators.required],
      firstname:['',Validators.required],
      lastname:['',Validators.required],
      email: ['',[Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      useroffice:['',Validators.required],
      Dateofbirth:['',Validators.required],
      mobileNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      branchID:['',Validators.required],
      DistributionChannel:['',Validators.required],
      active:['active',],
      OnlinePayment:[''],
      NonPay:[''],
      Reset:['']
    })
    this.getQuotationFormData()
    this.getPartnerBranchList()
  }

  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];
  renewstatus: Renewstatus[] = [
    {value: 'steak-0', viewValue: 'All'},
    {value: 'pizza-1', viewValue: 'Expired Policies'},
    {value: 'tacos-2', viewValue: 'Non Expired Policies'},
  ];

  claimstatus: Claimstatus[] = [
    {value: 'steak-0', viewValue: 'No Claims'},
    {value: 'pizza-1', viewValue: 'Has Claims'},
  ];
  savedata()
  {
   
    if(this.Managerusers.valid){
      this.motorQuoteService.adduser(this.Managerusers.value).subscribe(response =>{
        // this.formDataRes = response;
    
         this.partnersArr = response.Partners;
    
    
      });

    }
    else{
      this.Managerusers.markAllAsTouched()
    }
  }
  //partner details
  getQuotationFormData(){

    this.motorQuoteService.getQuotationFormData().subscribe(response =>{
      // this.formDataRes = response;

       this.partnersArr = response.Partners;


    });
    this.Managerusers.get("partnerID").setValue(this.partnerId);

  }
  // branch type
  getPartnerBranchList() {
    this.partnerBranchArr = [];

    this.motorQuoteService
        .getpartnerBranch(0)
        .subscribe((res) => {
            let updateRes: any = res;

            this.partnerBranchArr = updateRes.branchList;
            this.branchId = updateRes.branchList[0];

            //  branch
          
            // if (this.retrieveQuoteNumber == '') {
            //     this.partnerBranchArr.forEach((item, index) => {
            //         if (item.Id == this.branchId.Id) {
            //             this.branchVal = item;

            //         }
            //     });
            //    
            //       this.sideForm.get('branchID').setValue(this.branchVal.Id);
            //        this.sideForm.get('Accounting').setValue(this.branchVal.Id);
            // } else {

               
                // this.Managerusers.get('Accounting').setValue(this.branchId.Id);
                this.Managerusers.get('branchID').setValue(this.branchId.Id);

            // }
        });
}
adduser()
{
 
}
  
}
