import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation,ViewChild, TemplateRef, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators,NgForm, FormControl } from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';
import { GlobalService } from '../../../service/global.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take ,takeUntil} from 'rxjs/operators';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { FuseDrawerMode, FuseDrawerService } from '@fuse/components/drawer';
import { MotorquoteService } from 'app/modules/service/motorquote.service';
interface Nationality{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-managebranches',
  templateUrl: './managebranches.component.html',
  styleUrls: ['./managebranches.component.scss']
})
export class ManagebranchesComponent implements OnInit {
 Managebranch:FormGroup
  partnerBranchArr: any[];
  localStorageData: any;
  partnerId: any;
  branchId: any;
  partnertype: any;
  city: any;
  bsource: any;
  btype: any;
  blocation: any;
  branchtable: any;
  formDataRes: any;
  partnersArr: any;
  buttonName: string ='Save';
  eventtype: string;
  showLoaderEdit: boolean;
  editData: any;
  BranchId: any;
  
  constructor(public formBuilder:FormBuilder , public motorQuoteService: MotorquoteService,
    public GlobalService:GlobalService) { }

  ngOnInit(): void {


    this.localStorageData = this.GlobalService.getLocalStorageData();
  
  //  const routeParams = this._activatedroute.snapshot.params;

          this.partnerId = this.localStorageData.PartnerId;

    this.Managebranch=this.formBuilder.group({
      partnerName:['',Validators.required],
      City:['',Validators.required],
      BranchName:['',Validators.required],
      BranchType:['',Validators.required],
      bussinessLocation:['',Validators.required],
      Address:['',Validators.required],
      PartyCodeByBranch:['',Validators.required],
    })
    this.getPartnerData();
    this.getPartnerBranchList();
  this.getpartnerBranches();
  this.getQuotationFormData();
  }
  nation: Nationality[] = [ ];
  savedata()
  {
   if(this.Managebranch.valid)
    {
    
      this.addupdateBranch();
    }
    else{
       this.Managebranch.markAsTouched()
    }
  }

  getPartnerBranchList() {
    this.partnerBranchArr = [];

    this.motorQuoteService
        .getpartnerBranch(this.Managebranch.value.partnerName)
        .subscribe((res) => {
            let updateRes: any = res;

            this.partnerBranchArr = updateRes.branchList;
            this.branchId = updateRes.branchList[0];

       
              //  this.sideForm.get('Accounting').setValue(this.branchId.Id);
                this.Managebranch.get('BranchType').setValue(this.branchId.Id);

            }
        );
}

  getBranchData(){

    this.motorQuoteService.branchData().subscribe((res)=>{
   
      
      });
  }

  getPartnerData(){
    this.motorQuoteService.getPartnerData(this.partnerId).subscribe(response =>{
      this.partnertype = response.partnertype;
      this.city = response.city;
      this.bsource = response.businessSource;
      this.btype = response.businessType;
      this.blocation = response.businessLocation;
// console.log(this.formDataRes1);
    });
  }

  addupdateBranch(){


    if(this.buttonName=='Update'){
      this.eventtype='UPDATE'
    }else{
      this.eventtype='INSERT'
    }

    let formData = {
      eventtype :this.eventtype,
      partnerId : this.partnerId,
      City : this.Managebranch.value.City,
      branchname :  this.Managebranch.value.BranchName,
      busloc_code :  this.Managebranch.value.bussinessLocation.Id,
      busloc_name :  this.Managebranch.value.bussinessLocation.Value,
      address :  this.Managebranch.value.Address,
      branchtype :  this.Managebranch.value.BranchType.BranchName,
      branchid : this.BranchId,
      partycode :  this.Managebranch.value.PartyCodeByBranch
    };

    this.motorQuoteService.addupdateBranch(formData,'','').subscribe(response =>{
   

     if(response.response_code != "1")
{
  Swal.fire("", "Error processing your request", 'error');
}
else{
  Swal.fire("", "Data saved Successfully", 'success');
}
   this.getpartnerBranches();
    });
  }

  getpartnerBranches(){

    this.motorQuoteService.getpartnerBranches(this.partnerId).subscribe(response =>{
    

      this.branchtable = response.res_data
     });
  }

  getQuotationFormData(){
    this.motorQuoteService.getQuotationFormData().subscribe(response =>{
        this.formDataRes = response;
  
        this.partnersArr = this.formDataRes.Partners;
    
        this.Managebranch.get("partnerName").setValue(this.partnerId);
   });
  
    }

    EditForm(id){
      this.buttonName = 'Update';
      this.showLoaderEdit = true;


     this.motorQuoteService.getPartnerTable(id).subscribe(response =>{
      this.showLoaderEdit = false;
      this.editData = response.res_data[0];
 
    
    this.Managebranch.get('partnerName').setValue(this.editData.PartnerId);
    this.Managebranch.get('City').setValue(this.editData.City);
    // this.Managebranch.get('BranchName').setValue(this.editData.CRS_BusSrc_Map_Name);
    // this.Managebranch.get('BranchType').setValue(this.editData.ParentPartnerId);
    this.Managebranch.get('Address').setValue(this.editData.Address);
    this.Managebranch.get('bussinessLocation').setValue(this.editData.CRS_BusLoc_Map_Name);
    this.Managebranch.get('PartyCodeByBranch').setValue(this.editData.CRS_Cust_Map_Code);
//this.BranchId= this.editData.
    
    });
    }

    canceldata(){
      this.Managebranch.reset();
    //  this.manage_partner.markAsUntouched();
      this.buttonName='Save';
     // this.getPartnerDetails();
    }

    onSearchChange(event){


     
    }

}
