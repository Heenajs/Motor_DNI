import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagebranchesComponent } from './managebranches.component';

describe('ManagebranchesComponent', () => {
  let component: ManagebranchesComponent;
  let fixture: ComponentFixture<ManagebranchesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagebranchesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagebranchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
