import { Component, OnInit } from '@angular/core';
interface Nationality{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-managecreditlimit',
  templateUrl: './managecreditlimit.component.html',
  styleUrls: ['./managecreditlimit.component.scss']
})
export class ManagecreditlimitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];
}
