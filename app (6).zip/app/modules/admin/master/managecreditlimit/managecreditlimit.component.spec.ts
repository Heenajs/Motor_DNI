import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagecreditlimitComponent } from './managecreditlimit.component';

describe('ManagecreditlimitComponent', () => {
  let component: ManagecreditlimitComponent;
  let fixture: ComponentFixture<ManagecreditlimitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagecreditlimitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagecreditlimitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
