import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MarineCargoService } from 'app/modules/service/marine-cargo.service';
import { nation } from '../marine-cargo/config';
import { forkJoin } from 'rxjs';
import { GlobalService } from 'app/modules/service/global.service';
import { MotorquoteService } from 'app/modules/service/motorquote.service';
@Component({
  selector: 'app-vertial-form',
  templateUrl: './vertial-form.component.html',
  styleUrls: ['./vertial-form.component.scss'],

})
export class VertialFormComponent implements OnInit {
  
  @Input() type:any;
  verticalForm:FormGroup;
  nation = nation;
  product_list: any;
  partnerBranch: any;
  partner: any;
  partnersArr: any;
  localStorageData: any;

 
  constructor(
    public _fb: FormBuilder,
    public _service: MarineCargoService,
    public globalService: GlobalService,
    public motorQuoteService: MotorquoteService
  ) {
    console.log()
   }

  ngOnInit(): void {
   
    this.localStorageData = this.globalService.getLocalStorageData();



    this.verticalForm = this._fb.group({
      selectScheme:'',
      promocode:'',
      selectPartner:'',
      selectBranch:'',
      accountingBranch:'',
      salesPerson:'',    
    });
    
  
    forkJoin(
     {
     requestOne:  this._service.post( 'Webservice/getSchemesByProduct', {lob:'MT'}),
     requestTwo:  this._service.post( 'Webservice/partnerBranch',{partnerID:this.localStorageData.PartnerId}),
     requestThree:  this._service.post('Webservice/getQuotationFormData', {lob:''}),
     requestFour: this._service.post( 'Webservice/partnerBranch', {partnerID:this.localStorageData.PartnerId})
     }).subscribe(({requestOne, requestTwo, requestThree, requestFour})=>{
      
    this.product_list = requestOne.getSchemesByProduct
    this.partnersArr = requestThree.Partners;
    this.partnerBranch = requestTwo.branchList;
 
    this.verticalForm.get("selectBranch").setValue(requestFour.branchList[0].Id);
    this.verticalForm.get("accountingBranch").setValue(requestFour.branchList[0].Id);
     })
     this.verticalForm.get("selectPartner").setValue(this.localStorageData.PartnerId);
    
    
     
    // this.onChanges();

  }

  onChanges(): void {
    this.verticalForm.valueChanges.subscribe(val => {
      console.log(val)
    });
  }


}
