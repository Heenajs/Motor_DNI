import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VertialFormComponent } from './vertial-form.component';

describe('VertialFormComponent', () => {
  let component: VertialFormComponent;
  let fixture: ComponentFixture<VertialFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VertialFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VertialFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
