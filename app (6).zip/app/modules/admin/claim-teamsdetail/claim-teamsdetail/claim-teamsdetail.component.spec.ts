import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimTeamsdetailComponent } from './claim-teamsdetail.component';

describe('ClaimTeamsdetailComponent', () => {
  let component: ClaimTeamsdetailComponent;
  let fixture: ComponentFixture<ClaimTeamsdetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimTeamsdetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimTeamsdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
