import { Component, OnInit } from '@angular/core';
interface Partner {
  value: string;
  viewValue: string;
}
interface Nationality{
  value: string;
  viewValue: string;
}
interface Renewstatus{
 value: string;
 viewValue: string;
}
interface Claimstatus{
 value: string;
 viewValue: string;
}

@Component({
  selector: 'app-quoteapproval',
  templateUrl: './quoteapproval.component.html',
  styleUrls: ['./quoteapproval.component.scss']
})
export class QuoteapprovalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  partner: Partner[] = [
    {value: 'steak-0', viewValue: 'Product A'},
    {value: 'pizza-1', viewValue: 'Product B'},
    {value: 'tacos-2', viewValue: 'Product C'},
  ];
  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];
  renewstatus: Renewstatus[] = [
    {value: 'steak-0', viewValue: 'All'},
    {value: 'pizza-1', viewValue: 'Expired Policies'},
    {value: 'tacos-2', viewValue: 'Non Expired Policies'},
  ];

  claimstatus: Claimstatus[] = [
    {value: 'steak-0', viewValue: 'No Claims'},
    {value: 'pizza-1', viewValue: 'Has Claims'},
  ];
  
}
