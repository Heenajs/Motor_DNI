import { Component, OnInit,ViewChild ,TemplateRef} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MarineCargoService } from 'app/modules/service/marine-cargo.service';
import { StepFourComponent } from './step-four/step-four.component';
import { StepOneComponent } from './step-one/step-one.component';
import { StepThreeComponent } from './step-three/step-three.component';
import { StepTwoComponent } from './step-two/step-two.component';
import { nation } from './config';

@Component({
  selector: 'app-marine-cargo',
  templateUrl: './marine-cargo.component.html',
  styleUrls: ['./marine-cargo.component.scss']
})
export class MarineCargoComponent implements OnInit {

  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild(StepOneComponent) stepOneComponent: StepOneComponent;
  @ViewChild(StepTwoComponent) stepTwoComponent: StepTwoComponent;
  @ViewChild(StepThreeComponent) stepThreeComponent: StepThreeComponent;
  @ViewChild(StepFourComponent) stepFourComponent: StepFourComponent;

  formGroup:FormGroup;
  nation = nation
  optional: boolean = false;
  isLinear = true;
  get frmStepOne() {
   
    return this.stepOneComponent ? this.stepOneComponent.frmStepOne : null;
  }

  get frmStepTwo() {
  
    
    return this.stepTwoComponent ? this.stepTwoComponent.frmStepTwo: null ;
  }
  get frmStepThree() {
  
    return this.stepThreeComponent ? this.stepThreeComponent.frmStepThree : null ;
  }
  get frmStepFour() {
    return this.stepThreeComponent ;
  }



 
  panelOpenState = true;
  verticalForm:FormGroup
  horizontalStepperForm: FormGroup;

  formFieldHelpers: string[] = [''];
  Show: boolean=false;
  constructor(private _formBuilder: FormBuilder,
    public dialog: MatDialog,
    public service: MarineCargoService,
    )
  {
  
  }


  ngOnInit(): void {

  this.verticalForm = this._formBuilder.group({
    selectScheme:'',
    promocode:'',
    selectPartner:'',
    selectBranch:'',
    accountingBranch:'',
    salesPerson:'',
  })

  }

  vehicalsearchClose() {
    this.dialog.closeAll();
  }
  
  searchVehicle() {
     this.dialog.open(this.callAPIDialog);     
  }
  test(){
    let data = {data:'data'}
    let url = 'marineQuote'
    this.service.post( url, data).subscribe((res)=>{

    })
  }
}
