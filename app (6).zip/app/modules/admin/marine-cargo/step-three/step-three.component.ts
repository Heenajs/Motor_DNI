import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { nation, plan, gender, pepstauts, product, Mstatus, relationship, visa, visaregion, branch, partner, coverTypes} from '../config';


@Component({
  selector: 'app-step-three',
  templateUrl: './step-three.component.html',
  styleUrls: ['./step-three.component.scss']
})
export class StepThreeComponent implements OnInit {
  frmStepThree: FormGroup;
  nation = nation;  plan = plan; gender = gender; Mstatus = Mstatus; pepstauts = pepstauts;
  relationship=relationship; visa = visa; visaregion = visaregion; product = product;
  branch = branch; partner = partner; coverTypes = coverTypes; 
 
  constructor(public _formBuilder:FormBuilder) { }

  ngOnInit(): void {

    this.frmStepThree = this._formBuilder.group({
      clientName:['',Validators.required],
      holderName:['',Validators.required],
      tradeLicense:'',
      tradeLicenseExpiryDate:['',Validators.required],
      poBoxNum:'',
      emiratesOfRegistration:['',Validators.required],
      contactPersonName:['',Validators.required],
      
      emailAddress: ['',Validators.compose([Validators.required,Validators.pattern('[a-zA-Z0-9.-_-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}'),
        ]),
    ],
      mobileNumber:[
        '',
        [
            Validators.required,
            Validators.maxLength(10),
            Validators.pattern(
                '^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$'
            ),
        ],
    ],
      officeNumber:[
        '',
        [
            Validators.required,
            Validators.maxLength(9),
            Validators.pattern(
                '^((04){1}([0-9]{7}))$'
            ),
        ],
      ],
      trnNumber:'',
      address:['',Validators.required],
    })

  }

}
