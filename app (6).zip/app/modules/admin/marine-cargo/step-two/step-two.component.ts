import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { product } from '../config';




@Component({
  selector: 'app-step-two',
  templateUrl: './step-two.component.html',
  styleUrls: ['./step-two.component.scss']
})
export class StepTwoComponent implements OnInit {
  frmStepTwo:FormGroup;
  product = product;
  constructor(public _formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.frmStepTwo = this._formBuilder.group({
      quoteWithoutPremium:'',
      quoteWithoutClientName:'',
      quoteInAde:'',
      quoteInSelectedCurrency:'',
      calculationType:'',
      byAmount:['',Validators.required],
      enterValue:''
    })

  }

}
