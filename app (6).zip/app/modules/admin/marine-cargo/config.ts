

export const  product = [
        {value: 'steak-0', viewValue: 'Product A'},
        {value: 'pizza-1', viewValue: 'Product B'},
        {value: 'tacos-2', viewValue: 'Product C'},
      ];
     
export const nation = [
        {value: 'steak-0', viewValue: 'Dubai'},
        {value: 'pizza-1', viewValue: 'China'},
        {value: 'tacos-2', viewValue: 'France'},
      ];
 
export const    pepstauts = [
        {value: 'steak-0', viewValue: 'Yes'},
        {value: 'pizza-1', viewValue: 'No'},
      ];

export const  plan = [
        {value: 'steak-0', viewValue: 'Plan A'},
        {value: 'pizza-1', viewValue: 'Plan B'},
        {value: 'tacos-2', viewValue: 'Plan C'},
      ];     
      
export const  gender = [
        {value: 'steak-0', viewValue: 'Male'},
        {value: 'pizza-1', viewValue: 'Female'},
      ];

export const Mstatus= [
        {value: 'steak-0', viewValue: 'Single'},
        {value: 'pizza-1', viewValue: 'Married'},
      ];

export const relationship = [
        {value: 'steak-0', viewValue: 'Mother'},
        {value: 'pizza-1', viewValue: 'Father'},
      ];
export const visa = [
        {value: 'steak-0', viewValue: 'Visa Old'},
        {value: 'pizza-1', viewValue: 'Visa New'},
      ];
export const  visaregion = [
        {value: 'steak-0', viewValue: 'Dubai'},
        {value: 'pizza-1', viewValue: 'Abi Dhabi'},
        {value: 'steak-0', viewValue: 'Ajman'},
        {value: 'steak-0', viewValue: 'Sharjah'},
      ];
    
export const branch = [
        {value: 'steak-0', viewValue: 'Dubai'},
        {value: 'pizza-1', viewValue: 'England'},
        {value: 'tacos-2', viewValue: 'India'},
        {value: 'tacos-2', viewValue: 'Japan'},
      ];
export const partner = [
        {value: 'steak-0', viewValue: 'ABC Travel Agency'},
        {value: 'pizza-1', viewValue: 'AL Sayegh'},
        {value: 'tacos-2', viewValue: 'AL Sayegh insurance Broker'},
        {value: 'tacos-2', viewValue: 'Links insurance Broker'},
      ];
      
export const coverTypes = [
        {value: 'steak-0', viewValue: 'Self'},
        {value: 'pizza-1', viewValue: 'Self and Dependent'},
        {value: 'tacos-2', viewValue: 'Domestic Helper'},
        {value: 'tacos-3', viewValue: 'Parent'},
        {value: 'tacos-4', viewValue: 'Self Investor'}
      ];
    