import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { nation, plan, gender, pepstauts, product, Mstatus, relationship, visa, visaregion, branch, partner, coverTypes} from '../config';


@Component({
  selector: 'app-step-one',
  templateUrl: './step-one.component.html',
  styleUrls: ['./step-one.component.scss']
})
export class StepOneComponent implements OnInit {
  frmStepOne:FormGroup; 
  nation = nation;  plan = plan; gender = gender; Mstatus = Mstatus; pepstauts = pepstauts;
  relationship=relationship; visa = visa; visaregion = visaregion; product = product;
  branch = branch; partner = partner; coverTypes = coverTypes; 
 
  constructor(public _fb: FormBuilder) { }

  ngOnInit(): void {
    this.frmStepOne = this._fb.group({
      policyType:['',Validators.required],
      clientType:['',Validators.required],
      clientName:['',Validators.required],
      shipmentType:['',Validators.required],
      commodityGoods:['',Validators.required],
      coverType:['',Validators.required],
      uaeIntrest:['',Validators.required],
      warAndStrikeCover:['',Validators.required],
      goodsDiscription:['',Validators.required],
      //.................................................. Packaging/Shipment Type*.............................................
      lcl:'',
      fcl:'',
      professionallyPacked:'',
      originalManufactured:'',
      boxesAndCartons:'',
      palletizedCargo:'',
      woddenBox:'',
      drunAndPlasticCans:'',
      stretchWrapping:'',
      bundle:'',
   
      // .................................................. Sum Insured Details ............................................................
      tradetype:['',Validators.required],
      termsOfSale:['',Validators.required],
      loading:['',Validators.required],
      invoiceCurrency:['',Validators.required],
      invoiceValue:['',Validators.required],
      invoiceNumber:['',Validators.required],
      invoiceDate:['',Validators.required],
      //.................................................... Voyage Details..........................................
     
      voyageForm:['',Validators.required],
      voyageTo:['',Validators.required],
      sourceWarehouseCover:['',Validators.required],
      destinationWarehouseCover:['',Validators.required],
      loadPort:['',Validators.required],
      DestinationPort:['',Validators.required],
      surveyAgent:['',Validators.required],
      voyageArea:['',Validators.required],
      billOfLanding:['',Validators.required],
      billDate:['',Validators.required],
      shipmentDate:['',Validators.required],
      expectedArrivalDate:['',Validators.required],
      modeOfTransport:['',Validators.required],
      detailsOfTransitShipments:['',Validators.required],
      conveyanceType:['',Validators.required],
      vesselName:['',Validators.required],
      classificationSociety:['',Validators.required],
      yearOfbuilt:['',Validators.required],
      lcBankName:['',Validators.required],
      lcNumber:['',Validators.required],
      lcDate:['',Validators.required],
      lcRemark:'',
    })
 
  }

}
