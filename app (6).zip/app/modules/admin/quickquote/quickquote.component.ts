import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MotorquoteService } from '../../service/motorquote.service';
import { QuickquoteService } from '../../service/quickquote.service';
import { VehiModelYear } from '../motorquote/VehiModelYr';
import { vehimodelyrs } from '../motorquote/motoryear';
import Swal from 'sweetalert2';
import { of, ReplaySubject, Subject } from 'rxjs';
import { GlobalService } from '../../service/global.service';
import { take, takeUntil } from 'rxjs/operators';
import { registerLocaleData } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'app/core/auth/auth.service';
import { MatStepper } from '@angular/material/stepper';
import { ApexYAxis } from 'ng-apexcharts';
import { toUpper, upperCase } from 'lodash';
// import { Console } from 'console';

interface Make {
  VehicleMakeId: number;
  VehicleMakeName: string;
  Active: boolean;
  IsReferral: number;
  CRS_VEH_CODE: number;
}
interface Country {
  id: number;
  CountryName: string;
  Active: boolean;
  CountryCode: string;
  CurrencyCode: string;
  CRS_NATION_CODE: number;
  CRS_Country_Map_Code: number;
}
interface PlateCategory {
  label: string;
  value: string;
}

interface Model {
  VehicleModelId: number;
  VehicleModelName: string;
  Active: boolean;
  SeatingCapacityExDriver: number;
  BodyTypeId: number;
  CRS_MODEL_CODE: number;
  EDATA_MODEL_CODE: string;
}

interface Nationality {
  value: string;
  viewValue: string;
}

interface Gender {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-quickquote',
  templateUrl: './quickquote.component.html',
  styleUrls: ['./quickquote.component.scss'],
})



export class QuickquoteComponent implements OnInit {
  //  selected_motor: FormControl;
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('callAPIDialoginvalid') callAPIDialoginvalid: TemplateRef<any>;
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  @ViewChild('stepper') stepper: MatStepper;
  @ViewChild('myFileInput', { static: false }) myFileInput;
  @ViewChild('termsandconditions') termsandconditions: TemplateRef<any>;
  @ViewChild('referaquote') referaquote: TemplateRef<any>;
  deductibleControl = new FormControl('', [
    Validators.required,
    Validators.minLength(3),
    Validators.maxLength(4)
  ])

  public nationalFilterCtrl: FormControl = new FormControl();
  public plateFilterCtrl: FormControl = new FormControl();

  public filteredMakes: ReplaySubject<Make[]> = new ReplaySubject<Make[]>(1);
  public filteredModels: ReplaySubject<Model[]> = new ReplaySubject<Model[]>(1);
  public filteredPlateCat: ReplaySubject<PlateCategory[]> = new ReplaySubject<PlateCategory[]>(1);
  public filteredCountries: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);

  public filteredNationCountries: ReplaySubject<Country[]> = new ReplaySubject<Country[]>(1);

  vehicleValueLimit = {
    isSet: false,
    startLimit: 0,
    mediumLimit: 0,
    endLimit: 0,
  };
  sideForm: FormGroup;
  // childmessage = true;
  quickquoteinfo: FormGroup;
  step2: FormGroup;
  sessionData: FormGroup;
  formDataRes: any;
  vehicalmodelyears = vehimodelyrs;
  language_code = 'ENG';
  SchemeCode: any;
  country = 'United Arab Emirates';
  vhclMakeArr: Make[];
  vhclModelArr: Model[];
  vehicleData: any = [];
  partnersArr: any = [];
  quoteDetail: any;
  retrieveQuoteNumber: any = '';
  vhcleValueFlag: boolean = false;
  existVehiclevalue: any;
  tempTransactionTypeArr: any = [];
  referalStatus: boolean = false;
  vehitrims: any = [];
  vhclBodyTypeArr: any = [];
  vehicylinders: any = [];
  retrieveData: any = [];
  webQuoteNumber: any = '';
  quoteNumber: any;
  quoteDetailArr: any = [];
  benfPremIdArray: any = [];
  tempBenefitData: any = [];
  tempMultipleDocData: any = [];
  partnerBranchArr: any = [];
  emailId: any;
  emailadd: any;
  PlanDataJson: any = { planBenefitData: [] };
  referral_reason: any;
  initial_benefit_data: any;
  totalVariablePremium: number = 0;
  totalFixPremium: number = 0;
  public policyFee: number;
  NCDPerData = [];
  tempTotalFixPremium: number;
  tempTotalLoadFixPrem = 0;
  validtnMsg: boolean = false;
  public policyStatus: any;
  minyear = new Date().getFullYear() - 1;
  maxYear = new Date().getFullYear() + 1;
  RoleDesc: any;
  referalModel: boolean = false;
  issuePolicyBtnAccess: boolean = false;
  onlinePayBtnAccess: boolean = false;
  confirmBtnAccess: boolean = false;
  partnerId: any;
  branchId: any;
  notCallMake = false;
  planName: any;
  cedantId: any;
  userId: any;
  localStorageData: any;
  plan_Name: any;
  plan_Id: any;
  mulOption: any;
  discount: any;
  VATAMT: any;
  Total_Primium: number;
  loadingBy: string;
  referalDescription: any = '';
  accept_terms: boolean = false;
  myModel = false;
  myModel1 = false;
  myModel3 = false;
  myModel2 = false;
  total_premium: any;
  calculBy: any = '0';
  loadByAmount: any = 0;
  savePlanDetailArr: any = [];
  plateCodeArray: any = [];
  cityArr: any = [];
  regType: any = [];
  repairLoadingAmt: number;
  checkStepper: boolean = false;
  instypes: any;
  product_list: any;
  branchVal: any;
  vatAMt: any;
  loading_rate: any;
  quotationHistoryArr: any = [];
  PaymentMode: string;
  partnerDataRes: any;
  plate_code: any;
  document_data: any;
  plateCatArray: any = [];
  repairtypes = [];
  GCC_Specification: any = '';
  onModelChange: boolean = false;
  nofDoors: any;
  searchData: any;
  FilterVehicleData: any;
  isLoading = false;
  getAllData: any;
  checkChassisValidation: boolean = false;
  countryArr: Country[];
  tempRepairTypeArr: any = [];
  vehicle_age: any;
  quoteStatus: any;
  minDOB = new Date(new Date().setFullYear(new Date().getFullYear() - 99));
  maxDOB = new Date(new Date().setFullYear(new Date().getFullYear() - 18));
  policyMinDate = new Date(Date.now());
  policyMaxDate = new Date(new Date().setDate(new Date().getDate() + 30));
  regMinDate = new Date(2000, 0, 2);
  regMaxDate = new Date(2020, 0, 2);
  year = new Date().getFullYear();
  licIssueMaxDate = new Date(Date.now());
  repairs: any[];
  retrieve_repair_type = '';
  searchDataDetail: any;

  id: number;
  selectedData: any;
  model_year: any;
  multilpleFile: any = [];
  email: any;
  psw: any;
  selectedId: any;
  tempdata = 1;
  invalidData: FormGroup;
  tempDocArray: any = []; public termsAndCondition: any = []; additionalDocFile: any = [];
  isEditable = true;
  public showTerms: boolean = false;
  public isHideChassisNo = false;
  public showLoader = {
    reg_card_front: false,
    reg_card_back: false,
    emirates_Id_front: false,
    emirates_Id_back: false,
    driving_Lic_front: false,
    driving_Lic_back: false,
    Quotation: true,
    VehicleValue: false,
    vhclMake: false,
    vhclModel: false,
    vhclTrim: false,
    vhclBodyType: false,
    retrieveQuote: false,
    multipleDoc: false,
    supporting_Document: false,
    chasisNoButton: false,
    additionalDoc: false,
    referal: false,
    trade_Licence: false,
    TRN_Certificate: false,
    vhclEngine: false,
    bor_card: false

  }

  public hideImages = {
    reg_card_front: false,
    reg_card_back: false,
    emirates_Id_front: false,
    emirates_Id_back: false,
    driving_Lic_front: false,
    driving_Lic_back: false,
    supporting_Document: false,
    multipleDoc: false,
    additionalDoc: false,
    trade_Licence: false,
    TRN_Certificate: false
  }

  insvehibys: any = [
    { value: 'Individual', viewValue: 'Individual', code: '100' },
    { value: 'Corporate', viewValue: 'Corporate', code: '200' },
  ];

  activePolicyTypeArr = [
    { value: 'Yes', label: 'No  Insurance' },
    { value: 'No', label: 'Comprehensive' },
    { value: 'Yes', label: 'Third Party Liability' },
  ];

  nation: Nationality[] = [
    { value: 'steak-0', viewValue: 'Dubai' },
    { value: 'pizza-1', viewValue: 'China' },
    { value: 'tacos-2', viewValue: 'France' },
  ];

  vehiseatcaps: any = [
    { value: 2, viewValue: 2 },
    { value: 3, viewValue: 3 },
    { value: 4, viewValue: 4 },
    { value: 5, viewValue: 5 },
    { value: 6, viewValue: 6 },
    { value: 7, viewValue: 7 },
    { value: 8, viewValue: 8 },
  ];
  reasons = [
    { value: 'E-data missing' },
    { value: 'Invalid Data' }
  ]

  transactionTypeArray = [
    { value: '0', label: 'New Vehicle' },
    { value: '1', label: 'Renewal' },
    { value: '2', label: 'Change in Ownership' },
  ]
  calculationby = [
    { label: "By Amount", value: "0" },
    { label: "By Percent", value: "1" }
  ];

  public chnageData = {
    rg_vhcl_make: '',
  };

  genders: Gender[] = [
    { value: 'M', viewValue: 'Male' },
    { value: 'F', viewValue: 'Female' },
  ];

  bor_formData: FormData;
  indexOfMake: any;
  public modelFilterCtrl: FormControl = new FormControl();
  private _onDestroy = new Subject<void>();
  indexOfModel: any;
  chassis_No_Details: any;
  modelId: any;
  Sujbectdata: any;
  Description: any;
  username: any;
  chassisNumber: any;
  NCDData: any;
  optionalBenefit: any;
  isRenewal: any;
  LDAmount: any;
  disabledStatus: boolean = false;
  LDType: any;
  LDRate: any;
  getVechileDetailData: any;
  Search_vehicle: FormGroup;
  editQuoteDocs: any;
  fileType: any;
  docNameType: any;
  chassisStatus: boolean = true;
  // multilpleFile: any = [];
  planBenefitIDforBronze: any;
  engineList = [];
  showBor: boolean = false;
  unauthorizedAccess: boolean = false;
  headerDesclaimer: any;
  Desclaimer: boolean = false;
  userRole: any;
  refDescription: any = ''; refer_condtion_type: any; refer_type: any;
  premium: any;
  SchemeCodeClick:boolean =  false;
  calRefNo: any;
  BaseRate: any;
  isvisited: boolean = true;
  Deductible: any;
  onRetirveEngineCall: boolean = true;
  minCount: number;
  maxCount: any;
  milageData: any;
  color: any;
  noOfSeats: any;
  NCDPerDataF: any = [];
  
  noOfDoors: any;
  showReferbutton: boolean = true;;

  constructor(
    private _formBuilder: FormBuilder,
    public motorQuoteService: MotorquoteService,
    private quickQuoteService: QuickquoteService,
    private globalService: GlobalService,
    private _router: Router,
    public dialog: MatDialog,
    private _authService: AuthService,
    private _activatedRoute: ActivatedRoute
  ) { }
  businessSource;
  userType: any;

  public mask = {
    guide: true,
    showMask: true,
    mask: [/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/]
  };
  panelOpenState = true;
  ngOnInit(): void {


    this.localStorageData = this.globalService.getLocalStorageData();

    const routeParams = this._activatedRoute.snapshot.params;
    this.partnerId = this.localStorageData.PartnerId;
    this.branchId = this.localStorageData.BranchId;
    this.cedantId = this.localStorageData.CedantId;
    this.userId = this.localStorageData.UserId;
    this.userRole = this.localStorageData.UserRole;
    this.businessSource = this.localStorageData.BusinessSource;
    console.log(this.businessSource);
    this.userType = this.localStorageData.UserType;
    this.RoleDesc = this.localStorageData.RoleDesc;
    if (routeParams.quoteNum) {
      this.retrieveQuoteNumber = routeParams.quoteNum;

    }
    this.getCylinder();
    this.getVhclNCD();
    this.getQuotationHistory(this.retrieveQuoteNumber);
    this.CheckAccessOnLoad();
    this.sideForm = this._formBuilder.group({
      schemeCode: ['', Validators.required],
      partnerID: ['', Validators.required],
      branchID: [24, Validators.required],
      Accounting: [''],
      promoCode: ['']

    });

    this.Search_vehicle = this._formBuilder.group({
      selected_motor: [''],
      license_no: [''],
      reg_tc_no: [''],
      chassis_no: ['', Validators.required],
    });

    this.invalidData = this._formBuilder.group({
      subjectData: [''],
      reason: [''],
      description: [''],
      chassisnumber: ['']
    });

    this.quickquoteinfo = this._formBuilder.group({


      docRegCardFront: [''],
      reg_Card_Front: [''],
      reg_Card_FrontFilePath: '',
      reg_Card_FrontFileType: '',
      additional_DocumentFilePath: '',
      docSupporting: [''],
      supporting_Document: [''],
      supporting_DocumentFilePath: '',
      supporting_DocumentFileType: '',

      docRegCardBack: [''],
      reg_Card_Back: [''],
      reg_Card_BackFilePath: '',
      reg_Card_BackFileType: '',

      docEmiratedIdFront: [''],
      emirated_ID_Front: [''],
      emirated_ID_FrontFilePath: '',
      emirated_ID_FrontFileType: '',

      docEmiratedIdBack: [''],
      emirated_ID_Back: [''],
      emirated_ID_BackFilePath: '',
      emirated_ID_BackFileType: '',

      docDrivingLicFront: [''],
      driving_Lic_Front: [''],
      driving_Lic_FrontFilePath: '',
      driving_Lic_FrontFileType: '',

      docDrivingLicBack: [''],
      driving_Lic_Back: [''],
      driving_Lic_BackFilePath: '',
      driving_Lic_BackFileType: '',
      adtnl_detail_brandNew: [''],
      docTradeLicence: [''],
      trade_Licence: [''],
      trade_LicenceFilePath: '',
      trade_LicenceFileType: '',

      docTRNCertificate: [''],
      TRN_Certificate: [''],
      TRN_CertificateFilePath: '',
      TRN_CertificateFileType: '',
      descCheckbox: [''],

      MulkhiyaStatus: [true],

      // reg card front form fields

      selected_motor: [''],
      chassisno: [''],
      m_year: ['', Validators.required],
      v_make: ['', Validators.required],
      v_model: ['', Validators.required],
      v_specification: ['', Validators.required],
      bodytype: ['', Validators.required],
      adtnl_detail_engine: ['', Validators.required],
      cylinder: ['', Validators.required],
      capacity: ['', Validators.required],
      rg_type: [''],
      v_value: ['', Validators.required],
      // mileage:['0',Validators.required],
      r_place: [''],
      isChassisValidate: [''],
      adtnl_detail_NCD: ['', Validators.required],
      adtnl_detail_NCD_Perc: [''],
      lic_issue_date: ['', Validators.required],
      i_name: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      emailaddress:
        ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      mobileno: [
        '',
        [
          Validators.required,
          Validators.maxLength(10),
          Validators.pattern(
            '^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$'
          ),
        ],
      ],
      nationality: ['', Validators.required],
      brith_date: ['', Validators.required],
      SDate: [new Date(new Date().setDate(new Date().getDate())), Validators.required],
      //  years: ['', Validators.required],
      adtnl_detail_insType: ['', [Validators.required]],
      agencyrepair: ['', [Validators.required]],
      rg_policy_num: [''],
      rg_plateCode: [''],
      rg_gvm: [''],
      adtnl_detail_vhclOwnBy: ['', Validators.required],
      rg_origin: [''],

      CC: [''],
      loading_capacity: [''],
      validate_respons: [''],
      adtnl_detail_gccSpecified: ['', Validators.required],
      rg_reg_date: ['', [Validators.required]],

      /***************  data not show in form but captured ********/

      e_gender: [''],
      e_cardNumber: [''],
      e_expiryDate: [''],
      e_eid: [''],
      e_arabic_name: [''],
      d_dob: [''],
      trade_lic_num: [''],
      d_place_issue: [''],
      d_issue_date: [''],
      d_expiry_date: [''],
      d_TC_number: [''],
      //  rg_place_issue: [ ''],
      rg_TC_num: [''],
      rg_ins_exp: [''],
      d_driv_lic_num: [''],
      rg_traffic_plate_num: ['']

    });
    this.step2 = this._formBuilder.group({
      adminDeductible: ['']

    })

    this.sessionData = this._formBuilder.group({
      password: ['', Validators.required],
    });
    this.quickquoteinfo.get('adtnl_detail_brandNew')?.setValue('0');
    this.getSchemesByProduct();
    this.getAllFormData();
    this.getQuotationFormData();
    this.nationalFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterNationalCountry();
      });

    this.plateFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterPlateCat();
      });

    if (this.retrieveQuoteNumber == "") {
      this.modelYearRang();



    } else {

      this.isClickChassisValidate = true;
    }

    this.quickquoteinfo.get('bodytype')?.valueChanges.subscribe((obj) => {
      if (this.isClickChassisValidate) return false;  // if validate chassis no called 
      // if bodytye is motorcycle 'CC' is mandatory --------------- 02 Nov 20
      if (obj?.BodyTypeName == 'MOTORCYCLE') {
        this.quickquoteinfo?.get('CC')?.setValidators([Validators.required]);
        this.quickquoteinfo.get('loading_capacity')?.setValidators(null);
      }
      // if bodytye is Pickup 'loading_capacity' is mandatory ------------- 02 Nov 20
      else if (obj?.BodyTypeName == 'PICKUP') {
        this.quickquoteinfo.get('CC')?.setValidators(null);
        this.quickquoteinfo.get('loading_capacity')?.setValidators([Validators.required]);
      }
      else {
        this.quickquoteinfo.get('CC')?.setValidators(null);
        this.quickquoteinfo.get('loading_capacity')?.setValidators(null);
      }
      this.quickquoteinfo.get('CC')?.updateValueAndValidity();
      this.quickquoteinfo.get('loading_capacity')?.updateValueAndValidity();
    });

    this.tempRepairTypeArr = this.repairtypes;

    this.modelFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterModel();
      });
    this.getPartnerCreditLimit();


    this.quickquoteinfo.get('v_model').valueChanges.subscribe(value => {

      if (this.isClickChassisValidate) return false;  // if validate chassis no called 

      this.showLoader.vhclTrim = true;
      this.motorQuoteService.getTrimList(
        this.quickquoteinfo.value.m_year.label,
        value.VehicleModelName,
        this.quickquoteinfo.value.v_make.VehicleMakeName,
        this.sideForm.value.schemeCode

      ).subscribe(res => {
        this.showLoader.vhclTrim = false;

        if (res.response_message == null) return false;
        let trimName = '';

        if (this.retrieveData.length != 0) {

          trimName = this.retrieveData[0].TrimName;
        }
        if (this.vehicleData.length > 0) {

          trimName = this.vehicleData.General.Trim;
        }
        if (res.response_message?.LookupList?.length != 0) {
          this.vehitrims = res.response_message?.LookupList;
          let trimElem = '';
          if ((trimName != "") || (this.vehicleData && this.vehicleData.General) || this.getVechileDetailData?.VehicleDetails?.General.Trim)

            if (trimName == "" && this.vehicleData?.General?.Trim) trimName = this.vehicleData.General.Trim

          if (this.getVechileDetailData?.VehicleDetails.General.Trim) trimName = this.getVechileDetailData.VehicleDetails.General.Trim
          this.vehitrims?.forEach((item, index) => {

            if (item.Name == trimName) {
              trimElem = item;
            }
          });

          if (trimElem != '')
            this.quickquoteinfo.get('v_specification').setValue(trimElem);




          if (this.vehitrims?.length == 1) this.quickquoteinfo.get('v_specification').setValue(this.vehitrims[0]);


        } else {

          this.vehitrims = [{ "Name": value.VehicleModelName, "Code": "" }];
          this.quickquoteinfo.get('v_specification').setValue(this.vehitrims[0]);

        }

      });

    });



    this.quickquoteinfo.get('v_specification')?.valueChanges.subscribe(value => {



      if (this.isClickChassisValidate) return false;  // if validate chassis no called 
      if (this.quickquoteinfo.value.bodytype) {
        setTimeout(() => {
          this.engineSizeList(); // gives the correct value.
        }, 500);
      }
      // this.updateValuation_new(value);
    });


    this.quickquoteinfo.get('bodytype')?.valueChanges.subscribe(value => {
      if (this.isClickChassisValidate) return false;  // if validate chassis no called 
      if (this.quickquoteinfo.value.v_specification) {
        setTimeout(() => {
          // gives the correct value.
        }, 500);
      }
    });



    this.quickquoteinfo.get('adtnl_detail_engine')?.valueChanges.subscribe(value => {

      if (this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName == "THIRD PARTY LIABILITY") {
        this.quickquoteinfo.get('v_value').setValue(0);
        this.quickquoteinfo.get('v_value').setValidators([]);
        this.quickquoteinfo.get('v_value').updateValueAndValidity()

        this.quickquoteinfo.get('agencyrepair').setValidators([]);
        this.quickquoteinfo.get('agencyrepair').updateValueAndValidity()


      }


      if (this.isClickChassisValidate) return false;  // if validate chassis no called 

      if (this.isUpdateValuation == true) {
        setTimeout(() => {


          let Cylinders = value.Cylinders
          let Passengers = value.Passengers;


          if (Cylinders) {
            this.vehicylinders = [{ Id: 1, CylinderName: Cylinders, CylinderCode: "2" }];
            this.quickquoteinfo.get("cylinder")?.setValue(this.vehicylinders[0]);
          }

          if (Cylinders) {

            let passengerVal: any = {};

            if (Passengers < 8) {

              let minCount = Passengers - 1;
              let maxCount = Number(Passengers) + 2;
              if (minCount <= 0) minCount = 1;

              if (maxCount >= 8) maxCount = 8;
              this.vehiseatcaps = [];
              for (let i = minCount; i <= maxCount; i++) {
                this.vehiseatcaps.push({ value: i, viewValue: i });
                if (Passengers == i) { passengerVal = { value: i, viewValue: i }; }
              }
            }

            this.quickquoteinfo.get("capacity")?.setValue(passengerVal.viewValue);
          }


          if (!this.isClickChassisValidate)
            this.updateValuation_new(); // gives the correct value.


          let modelData = this.quickquoteinfo.value.v_make;
          //  this.vehicylinders = [{Id	:1 , CylinderName	: modelData. ,  CylinderCode :	"2"}];

          // this.onVehiclAgeChange(1);

        }, 500);



      } else {

        this.isUpdateValuation = false;
      }

    });

    this.quickquoteinfo.get('adtnl_detail_NCD')?.valueChanges.subscribe(obj => {
      setTimeout(() => {
        if (obj != undefined) {

          this.motorQuoteService.getNCDPercentage(this.sideForm.value.partnerID, this.sideForm.value.schemeCode, obj.NCDCode).subscribe(res => {
            this.NCDPerData = res.res_data;
            this.quickquoteinfo.get('adtnl_detail_NCD_Perc')?.setValue(this.NCDPerData[0].NCDDiscPer);
          })
        }

      }), 100
    });


    this.CheckAccessOnLoad();
    //65S, 65Q4, 66S, 65RK, 66RK, 66Q

    setTimeout(() => {
      const schemes = ["65S", "65Q4", "66S", "65RK", "66RK", " 66Q"];
      const schemeCoTPL = ["66A", "60D", "64F"]

      let event = this.sideForm.value.schemeCode;
      if (schemes.includes(event)) { this.chassisMin = 17; this.chassisMax = 17; }
      if (schemeCoTPL.includes(event)) { this.chassisMin = 6; this.chassisMax = 17; }
      //  else {  this.chassisMin = 10 ; this.chassisMax = 17 ; }
    }, 2000);

    //  if(this.referalDescription != '' || this.others != '' || this.sumInc != ''){
    //   this.myModel = true;
    // }

    this.setDefaultValueForComm();
  }
  
  getVhclNCD() {
    this.motorQuoteService.getVehicleNcd(this.language_code, 'MOTOR').subscribe(res => {
      this.NCDData = res.vechileNCDData;
      this.NCDPerDataF =  this.NCDData ;
      if ((this.retrieveQuoteNumber != '' || this.retrieveQuoteNumber != undefined) && res.response_code == 1) {
        setTimeout(() => { this.getRetrieveQuoteDataUpgrade(); }, 1000);
      }
    });
  }
  
  
  
  

  setDefaultValueForComm() {


    if (this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66Q") {

      this.quickquoteinfo.get('brith_date').setValue(new Date("01/01/1980"));
      this.quickquoteinfo.get('lic_issue_date').setValue(new Date("01/01/2015"));

    }


    if (this.sideForm.value.schemeCode == "") {

      setTimeout(() => { this.setDefaultValueForComm(); }, 1000);
    }
  }
  //mat autocomplete

  private filterModel() {
    if (!this.vhclModelArr) {
      return;
    }
    // get the search keyword
    let search = this.modelFilterCtrl.value;
    if (!search) {
      this.filteredModels.next(this.vhclModelArr.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredModels.next(
      this.vhclModelArr.filter(bank => bank.VehicleModelName.toLowerCase().indexOf(search) > -1)
    );
  }

  getPartnerBranchList() {
    this.partnerBranchArr = [];

    this.motorQuoteService
      .getpartnerBranch(this.sideForm.value.partnerID)
      .subscribe((res) => {
        let updateRes: any = res;

        this.partnerBranchArr = updateRes.branchList;
        this.branchId = updateRes.branchList[0];

        //  branch
        if (this.retrieveQuoteNumber == '') {
          this.partnerBranchArr.forEach((item, index) => {
            if (item.Id == this.branchId.Id) {
              this.branchVal = item;

            }
          });

          this.sideForm.get('branchID').setValue(this.branchVal.Id);
          this.sideForm.get('Accounting').setValue(this.branchVal.Id);
        } else {

          this.sideForm.get('Accounting').setValue(this.branchId.Id);
          this.sideForm.get('branchID').setValue(this.branchId.Id);

        }
      });

  }

  chassisMin = 6;
  chassisMax = 17;
  keyFunc(event: any) {

    var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
      return false;

    if (event.target.value.length >= 7) return false;
    if (event.target.value != '') {
      this.myModel = true;
    }
    if (event.target.value == '') {
      this.myModel = false;
    }

  }
  keyFunc1(event: any) {

    var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
      return false;

    if (event.target.value.length >= 3) return false;


    if (event.target.value != '') {
      this.myModel1 = true;
    }
    if (event.target.value == '') {
      this.myModel1 = false;
    }

  }
  keyFunc2(event: any) {

    var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
      return false;

    if (event.target.value.length >= 4) return false;

    if (event.target.value != '') {
      this.myModel2 = true;
    }
    if (event.target.value == '') {
      this.myModel2 = false;
    }

  }
  keyFunc3(event: any) {

    if (event.target.value != '') {
      this.myModel3 = true;
    }
    if (event.target.value == '') {
      this.myModel3 = false;
    }

  }
  keyFunc4(event) {

    //   if( event.target.value  < this.minDeductibleVal){
    //     const dialogRef1 = this.dialog.open(this.callDeductbleValue);
    // }
  }
  getinsuredType1(event) {
    

    this.checkEngineValidation();
    this.checkTrimValidation();
    this.insvehibys = [];
    this.motorQuoteService.getInsuredType(event).subscribe(result => {
      this.instypes = result.insuredType;

      this.quickquoteinfo.get('adtnl_detail_insType')?.setValue(this.instypes[0]);

      var policyType;
      this.instypes.forEach((item, index) => {

        this.insvehibys.push({ viewValue: item.PolicyType, value: item.PolicyType, code: 200 });

      });

      this.quickquoteinfo.get('adtnl_detail_vhclOwnBy')?.setValue(this.insvehibys[0]);
      this.modelYearRang();

    })
    //65S, 65Q4, 66S, 65RK, 66RK, 66Q


    const schemes = ["65S", "65Q4", "66S", "65RK", "66RK", " 66Q"];
    const schemeCoTPL = ["66A", "60D", "64F"]

    if (schemes.includes(event)) {
      this.chassisMin = 17; this.chassisMax = 17;
    }
   else if (schemeCoTPL.includes(event)) {
      this.chassisMin = 6; this.chassisMax = 17;
    }
    else {
      // this.chassisMin = 10 ; this.chassisMax = 17 ; 
    }


  }
  addOptionalBenigits(id, event) {




    this.totalVariablePremium = 0;
    this.optionalBenefit = "";
    this.totalVariablePremium = 0;
    this.optionalBenefit = "";
    this.PlanDataJson.planBenefitData?.data?.forEach((item, index) => {

      //admin this.accessGroup == 'ADMIN
      if (this.businessSource == 'DIRECT' && this.partnerId == 1 && this.userRole == 'TELEMARKETING' && this.userType == 'POS') {

        if (item.offerChecked == true) {
          //this.PlanDataJson.planBenefitData.data[index].checked = true;
          this.totalVariablePremium = Number(this.totalVariablePremium + 1);
        }
        if (item.checked == false) {
          //this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
        }
        if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1 && item.offerChecked == false) {

          if (id == 321) {
            if (item.BenefitId == this.planBenefitIDforBronze && item.checked == true) {

              this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
              item.checked = false;
            }
          }
          // 477 for production & 509 for online test - Roadside Assistance - Bronze
          if (id == this.planBenefitIDforBronze) {

            if (item.BenefitId == 321 && item.checked == true) {
              this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
              item.checked = false;
            }
          }
          this.optionalBenefit = this.optionalBenefit + "," + item.BenefitId;
          this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);

        }

        if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1 && item.offerChecked == false) {
          this.optionalBenefit = this.optionalBenefit + "," + this.mulOption.BenefitId;
          this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);

        }


      } else {

        //USER

        if (item.offerChecked == true) {
          this.PlanDataJson.planBenefitData.data[index].checked = true;
          this.totalVariablePremium = Number(this.totalVariablePremium + 1);
        }
        if (item.checked == false) {
          this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
        }

        if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1 && item.offerChecked == false) {

          if (id == 321) {

            if (item.BenefitId == this.planBenefitIDforBronze && item.checked == true) {

              this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
              item.checked = false;
            }
          }
          // 477 for production & 509 for online test
          if (id == this.planBenefitIDforBronze) {

            if (item.BenefitId == 321 && item.checked == true) {
              this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
              item.checked = false;
            }
          }
          this.optionalBenefit = this.optionalBenefit + "," + item.BenefitId;
          this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);

        }

        if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1 && item.offerChecked == false) {

          this.optionalBenefit = this.optionalBenefit + "," + this.mulOption.BenefitId;
          this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);

        }


      }

    });

    //  this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);

  }
  tickDriver(benifitItem, i) {

    if (this.PlanDataJson.planBenefitData.data[i].checked) {
      if (benifitItem.BenefitId == 319) {

        this.PlanDataJson.planBenefitData.data[2].checked = true;
        this.PlanDataJson.planBenefitData.data[2].disable = true;
        //  this.addOptionalBenigits(318,2);
        this.calculateDiscount(this.loadingBy, this.loadByAmount, this.calculBy);
      }
    } else {

      if (benifitItem.BenefitId == 319)
        this.PlanDataJson.planBenefitData.data[2].disable = false;
    }

  }

  getinsuredTypeOnRetrieve(event, type) { 
    this.motorQuoteService.getInsuredType(event).subscribe(result => {

      this.instypes = result.insuredType;

      let insTypeArr = [];
      if (result.response_code != "2") {
        this.instypes.forEach((item, index) => {

          insTypeArr.push({ viewValue: item.PolicyType, value: item.PolicyType, code: 200 });


        });

         this.insvehibys = insTypeArr;
        let InsuredType = this.retrieveData[0]?.InsuredType ;

        let indexOwnBy = this.insvehibys.findIndex(function (obj, k) {
          return obj.value.toLowerCase() === InsuredType.toLowerCase();
        });
      
        if(indexOwnBy=>0){
        this.quickquoteinfo.get('adtnl_detail_vhclOwnBy')?.setValue(this.insvehibys[indexOwnBy]);

        } else {
          this.quickquoteinfo.get('adtnl_detail_vhclOwnBy')?.setValue(this.insvehibys[0]);


        }

        
        this.quickquoteinfo.get('adtnl_detail_insType')?.setValue(this.instypes[0]);
      }

    });

  }
  // isSchmeCodeSelect = false ;
  getinsuredType(event, type) {
    

    setTimeout(() => {
      this.checkTrimValidation();
    }, 2000);
    this.checkEngineValidation();
    if (!this.isUpdateValuation) return false;
    this.SchemeCodeClick = false;



    this.motorQuoteService.getInsuredType(event).subscribe(result => {
      setTimeout(() => {
        this.instypes = result.insuredType;

        let insTypeArr = [];
        if (result.response_code != "2") {
          this.instypes.forEach((item, index) => {

            insTypeArr.push({ viewValue: item.PolicyType, value: item.PolicyType, code: 200 });

          });
          this.insvehibys = insTypeArr;
          this.quickquoteinfo.get('adtnl_detail_insType')?.setValue(this.instypes[0]);
          this.quickquoteinfo.get('adtnl_detail_vhclOwnBy')?.setValue(this.insvehibys[0]);
          // if(type==0){
          //   this.quickquoteinfo.get('v_make').setValue('');
          //   this.quickquoteinfo.get('v_model').setValue('');
          //   this.quickquoteinfo.get('v_specification').setValue('');
          //   this.quickquoteinfo.get('bodytype').setValue('');
          //   this.quickquoteinfo.get('cylinder').setValue('');
          //   this.quickquoteinfo.get('chassisno').setValue('');
          // }

        }

        //  this.modelYearRang();
      }, 100);
    })
    if (this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "64F" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66RK") { 
      this.quickquoteinfo.get('cylinder').setValidators(null);
    }
    this.quickquoteinfo.get('cylinder').updateValueAndValidity();

  }


  async uploadMultipleDocuments(event) {
    this.formDataRes = this.tmpCountryList;
    this.showLoader.multipleDoc = true;
    this.multilpleFile = [];
    for (var i = 0; i < event.target.files.length; i++) {
      this.showLoader.multipleDoc = true;
      const formData = new FormData();
      formData.append('file', event.target.files[i]);
      formData.append('stage', 'QUOTE');
      formData.append('schemeCode', this.sideForm.value.schemeCode);

      this.motorQuoteService.uploadMultipleDocuments(formData).subscribe(res => {

        let updateMemResponse = res;
        this.document_data = updateMemResponse.Document_data;
        this.hideImages.multipleDoc = true;

        if (updateMemResponse.res_code == 1) {
          let fileType = updateMemResponse.File.split(".");
          fileType = fileType[fileType.length - 1];
          fileType = fileType == "pdf" ? "PDF" : "IMG";

          this.multilpleFile.push({
            "file": updateMemResponse.FileDir,
            "fileType": fileType,
            'file_name': 'Other',
            'file_dir': updateMemResponse.FileDir,
            'docName': updateMemResponse.File,
          });

          this.tempMultipleDocData = this.multilpleFile;

          this.showLoader.multipleDoc = false;

          this.document_data.forEach((item, index) => {

            if (item.ErroCode == 'Null') {

              if (item.DocumentType == 'Emirates-Id' && (item.DocumentSubType == 'Front' || item.DocumentSubType == 'Front_Old')) {

                this.getEmiratesIdData(1, item);
              }
              else if (item.DocumentType == 'Emirates-Id' && (item.DocumentSubType == 'Back' || item.DocumentSubType == 'Back_Old' || item.DocumentSubType == 'Back_New')) {

                this.getEmiratesIdData(2, item);
              }
              else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Front') {

                this.getDrivingLicData(1, item);
              }
              else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Back') {

                this.getDrivingLicData(2, item);
              }
              else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Back') {

                if (updateMemResponse?.vechile_data?.Message != "Validation errors")
                  this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;


                this.getRegCardData(1, item);
                //   await this.sleep(2000);
              }
              else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Front') {

                this.getRegCardData(2, item);

              }
              else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Both') {
                this.getRegCardData(2, item);
                this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
                this.getRegCardData(1, item);
              }
              else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Both') {
                this.getDrivingLicData(2, item);
                this.getDrivingLicData(1, item);
              }
              else if (item.DocumentType == 'Emirates-Id' && item.DocumentSubType == 'Both') {
                this.getEmiratesIdData(2, item);
                this.getEmiratesIdData(1, item);
              }
            }
          });
        }
        if (updateMemResponse.response_code == 5) {

          this.showLoader.multipleDoc = false;

          Swal.fire("Please select valid file format.", "only .pdf, .jpg, .png and .jpeg file formats allowed.", 'warning');

        }

        if (updateMemResponse.response_code == 6) {

          this.showLoader.multipleDoc = false;

          Swal.fire(updateMemResponse.response_status);
        }






      });
      //await this.sleep(5000);
      //wait(7000);  //7 seconds in milliseconds
    }


  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  getDrivingLicData(type, docData) {
    if (type == 1) {

      this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;

      let dateDob: string = this.document_data.Data['Date of Birth'];
      dateDob = dateDob.replace(/-/gi, "/");
      let dateIssue: string = this.document_data.Data['Issue Date'];
      dateIssue = dateIssue.replace(/-/gi, "/");
      let dateExp: string = this.document_data.Data['Expiry Date'];
      dateExp = dateExp.replace(/-/gi, "/");


      if (this.document_data.Data['License No.'] != 'Not Found') {
        this.quickquoteinfo.get('d_driv_lic_num')?.setValue(this.document_data.Data['License No.']);
      } else {
        this.quickquoteinfo.get('d_driv_lic_num')?.setValue('');
      }



      if (this.document_data.Data['Issue Date'] != "Not Found")

        this.quickquoteinfo.get('lic_issue_date').setValue(this.dateConvert(dateIssue));

      else {
        this.quickquoteinfo.get('lic_issue_date').setValue('');

      }


      if (this.document_data.Data['Issue Date'] != "Not Found")
        this.quickquoteinfo.get('d_issue_date')?.setValue(this.dateConvert(dateIssue));
      else {
        this.quickquoteinfo.get('d_issue_date')?.setValue('');
      }




      if (this.document_data.Data['Expiry Date'] != "Not Found")
        this.quickquoteinfo.get('d_expiry_date')?.setValue(this.dateConvert(dateExp));
      else {
        this.quickquoteinfo.get('d_expiry_date')?.setValue('');
      }


      if (this.quickquoteinfo.value.d_TC_number == '') {
        this.quickquoteinfo.get('d_TC_number')?.setValue(this.quickquoteinfo.value.rg_TC_num);
      }


      // Driving Reg. Place

      let regPlace = this.document_data.Data['Place of Issue'];

      if (regPlace != 'Not Found' && regPlace != '' && regPlace != null) {
        var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
          return obj.CityName.toLowerCase() === regPlace.toLowerCase();
        });
        let placelVal = this.cityArr[indexRegPlace];
        this.quickquoteinfo.get('d_place_issue')?.setValue(placelVal);
        //   this.getIssuePlace(placelVal.CityName);
      }


      // 11 - 02 -2021 : If emirates id file not uploaded then name should be taken from driving lic file
      if (this.quickquoteinfo.value.e_name == '') {
        if (this.document_data.Data['Name'] == "Not Found") {
          this.quickquoteinfo.get('i_name').setValue('');
        } else {
          this.quickquoteinfo.get('i_name').setValue(this.document_data.Data['Name']);
        }
      }

    }

  }

  onFileChange(event, docName, FiledName, files: FileList) {

    this.docNameType = FiledName;

    if (this.docNameType == 'reg_Card_Front') {
      this.showLoader.reg_card_front = true;
    }

    if (this.docNameType == 'reg_Card_Back') {
      this.showLoader.reg_card_back = true;
    }

    if (this.docNameType == 'emirated_ID_Front') {
      this.showLoader.emirates_Id_front = true;
    }

    if (this.docNameType == 'emirated_ID_Back') {
      this.showLoader.emirates_Id_back = true;
    }

    if (this.docNameType == 'driving_Lic_Front') {
      this.showLoader.driving_Lic_front = true;
    }

    if (this.docNameType == 'driving_Lic_Back') {
      this.showLoader.driving_Lic_back = true;
    }

    if (this.docNameType == 'supporting_Document') {
      this.showLoader.supporting_Document = true;
    }

    if (this.docNameType == 'trade_Licence') {
      this.showLoader.trade_Licence = true;
    }

    if (this.docNameType == 'TRN_Certificate') {
      this.showLoader.TRN_Certificate = true;
    }

    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('docName', docName);
    formData.append('source', 'B2B');
    formData.append('stage', 'QUOTE');
    formData.append('schemeCode', this.sideForm.value.schemeCode);
    // Array.from(files).forEach(f => formData.append('file', f))

    this.motorQuoteService.uploadDocuments(formData).subscribe(res => {

      let updateMemResponse = res;
      this.document_data = updateMemResponse.Document_data;


      if (updateMemResponse.res_code == 1) {

        this.showLoader.reg_card_front = false;
        this.showLoader.reg_card_back = false;
        this.showLoader.emirates_Id_front = false;
        this.showLoader.emirates_Id_back = false;
        this.showLoader.driving_Lic_front = false;
        this.showLoader.driving_Lic_back = false;
        this.showLoader.supporting_Document = false;
        this.showLoader.trade_Licence = false;
        this.showLoader.TRN_Certificate = false;

        let fileType = updateMemResponse.File.split(".");
        fileType = fileType[fileType.length - 1];
        fileType = fileType == "pdf" ? "PDF" : "IMG";


        let formArrayValue: any = this.quickquoteinfo
          .value;


        formArrayValue[FiledName] = updateMemResponse.File;
        formArrayValue[FiledName + "FilePath"] = updateMemResponse.FileDir;
        let tempDocumentArray = {
          file_name: FiledName,
          file_dir: updateMemResponse.FileDir,
          docName: updateMemResponse.File,
        }


        if (FiledName == 'reg_Card_Front') {
          this.hideImages.reg_card_front = true;
          this.quickquoteinfo.get('reg_Card_FrontFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('reg_Card_Front').setValue(updateMemResponse.File);
          this.quickquoteinfo.get('reg_Card_FrontFileType').setValue(fileType);
          this.tempDocArray[1] = tempDocumentArray;
        }
        if (FiledName == 'reg_Card_Back') {
          this.hideImages.reg_card_back = true;
          this.quickquoteinfo.get('reg_Card_BackFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('reg_Card_BackFileType').setValue(fileType);
          this.tempDocArray[0] = tempDocumentArray;
        }
        if (FiledName == 'emirated_ID_Front') {
          this.hideImages.emirates_Id_front = true;
          this.quickquoteinfo.get('emirated_ID_FrontFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('emirated_ID_FrontFileType').setValue(fileType);
          this.tempDocArray[2] = tempDocumentArray;
        }
        if (FiledName == 'emirated_ID_Back') {
          this.hideImages.emirates_Id_back = true;
          this.quickquoteinfo.get('emirated_ID_BackFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('emirated_ID_BackFileType').setValue(fileType);
          this.tempDocArray[3] = tempDocumentArray;
        }
        if (FiledName == 'driving_Lic_Front') {
          this.hideImages.driving_Lic_front = true;
          this.quickquoteinfo.get('driving_Lic_FrontFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('driving_Lic_FrontFileType').setValue(fileType);
          this.tempDocArray[4] = tempDocumentArray;
        }

        if (FiledName == 'driving_Lic_Back') {
          this.hideImages.driving_Lic_back = true;
          this.quickquoteinfo.get('driving_Lic_BackFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('driving_Lic_BackFileType').setValue(fileType);
          this.tempDocArray[5] = tempDocumentArray;
        }

        if (FiledName == 'supporting_Document') {
          this.hideImages.supporting_Document = true;
          this.quickquoteinfo.get('supporting_DocumentFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('supporting_DocumentFileType').setValue(fileType);
          this.tempDocArray[6] = tempDocumentArray;
        }

        if (FiledName == 'trade_Licence') {
          this.hideImages.trade_Licence = true;
          this.quickquoteinfo.get('trade_LicenceFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('trade_LicenceFileType').setValue(fileType);
          this.tempDocArray[7] = tempDocumentArray;
        }

        if (FiledName == 'TRN_Certificate') {
          this.hideImages.TRN_Certificate = true;
          this.quickquoteinfo.get('TRN_CertificateFilePath').setValue(updateMemResponse.FileDir);
          this.quickquoteinfo.get('TRN_CertificateFileType').setValue(fileType);
          this.tempDocArray[8] = tempDocumentArray;
        }

        if (fileType == "pdf") {
          formArrayValue[FiledName + "FileType"] = "PDF";
        } else {
          formArrayValue[FiledName + "FileType"] = "IMG";
        }
        formArrayValue["docRegCardFront"] = "";
        formArrayValue['docRegCardBack'] = "";
        formArrayValue["docEmiratedIdFront"] = "";
        formArrayValue['docEmiratedIdBack'] = "";
        formArrayValue["docDrivingLicFront"] = "";
        formArrayValue["docDrivingLicBack"] = "";
        formArrayValue["docSupporting"] = "";
        formArrayValue["docTradeLicence"] = "";
        formArrayValue["docTRNCertificate"] = "";

        if (this.document_data.Errocode == 106) {
          if (FiledName == 'reg_Card_Front') {

            this.hideImages.reg_card_front = false;
          }
          if (FiledName == 'reg_Card_Back') {
            this.hideImages.reg_card_back = false;
          }
          if (FiledName == 'emirated_ID_Front') {
            this.hideImages.emirates_Id_front = false;
          }
          if (FiledName == 'emirated_ID_Back') {
            this.hideImages.emirates_Id_back = false;
          }
          if (FiledName == 'driving_Lic_Front') {
            this.hideImages.driving_Lic_front = false;
          }
          if (FiledName == 'driving_Lic_back') {
            this.hideImages.driving_Lic_back = false;
          }
          if (FiledName == 'supporting_Document') {
            this.hideImages.supporting_Document = false;
          }
          if (FiledName == 'trade_Licence') {
            this.hideImages.trade_Licence = false;
          }
          if (FiledName == 'TRN_Certificate') {
            this.hideImages.TRN_Certificate = false;
          }

          //  Swal.fire("", this.document_data.ErrorDescription, "error");
          // Invalid document type selected or the document resolution is very low to read the data. Please upload another clean copy and try. Sorry for the inconvenience.
          Swal.fire("Invalid document type selected or the document resolution is very low to read the data.", "Please upload another clean copy and try. Sorry for the inconvenience.", "error");
          return false;
        }

        if (this.document_data.DocumentType == 'Emirates-Id' && (this.document_data.DocumentSubType == 'Front' || this.document_data.DocumentSubType == 'Front_Old' || this.document_data.DocumentSubType == 'Front_New')) {

          this.getEmiratesIdData(1, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Emirates-Id' && (this.document_data.DocumentSubType == 'Back' || this.document_data.DocumentSubType == 'Back_Old' || this.document_data.DocumentSubType == 'Back_New')) {

          this.getEmiratesIdData(2, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Driving License' && this.document_data.DocumentSubType == 'Front') {

          this.getDrivingLicData(1, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Driving License' && this.document_data.DocumentSubType == 'Back') {

          this.getDrivingLicData(2, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Vehicle License' && this.document_data.DocumentSubType == 'Back') {

          this.quickquoteinfo.get('v_make').setValue('');
          this.quickquoteinfo.get('v_model').setValue('');
          this.quickquoteinfo.get('v_specification').setValue('');
          this.quickquoteinfo.get('bodytype').setValue('');

          this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;

          this.getRegCardData(1, this.document_data);
        }
        else if (this.document_data.DocumentType == 'Vehicle License' && this.document_data.DocumentSubType == 'Front') {

          this.getRegCardData(2, this.document_data);

        }

        else if (this.document_data.DocumentType == 'Vehicle License' && this.document_data.DocumentSubType == 'Both') {

          this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
          this.getRegCardData(1, this.document_data);
          this.getRegCardData(2, this.document_data);
        }

        else if (this.document_data.DocumentType == 'Driving License' && this.document_data.DocumentSubType == 'Both') {

          this.getDrivingLicData(1, this.document_data);
          this.getDrivingLicData(2, this.document_data);
        }

        else if (this.document_data.DocumentType == 'Emirates-Id' && this.document_data.DocumentSubType == 'Both') {

          this.getEmiratesIdData(1, this.document_data);
          this.getEmiratesIdData(2, this.document_data);
        }

        else if (this.document_data.DocumentType == 'Other-Document') {
          this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
          this.getRegCardData(1, this.document_data);
        }


      }

      if (updateMemResponse.response_code == 5) {

        this.showLoader.reg_card_front = false;
        this.showLoader.reg_card_back = false;
        this.showLoader.emirates_Id_front = false;
        this.showLoader.emirates_Id_back = false;
        this.showLoader.driving_Lic_front = false;
        this.showLoader.driving_Lic_back = false;
        this.showLoader.supporting_Document = false;
        this.showLoader.trade_Licence = false;
        this.showLoader.TRN_Certificate = false;

        Swal.fire("Please select valid file format.", "only .pdf, .jpg, .png and .jpeg file formats allowed.", 'warning');

      }

      if (updateMemResponse.response_code == 6) {
        this.showLoader.reg_card_front = false;
        this.showLoader.reg_card_back = false;
        this.showLoader.emirates_Id_front = false;
        this.showLoader.emirates_Id_back = false;
        this.showLoader.driving_Lic_front = false;
        this.showLoader.driving_Lic_back = false;
        this.showLoader.supporting_Document = false;
        this.showLoader.trade_Licence = false;
        this.showLoader.TRN_Certificate = false;

        Swal.fire(updateMemResponse.response_status);
      }

      setTimeout(() => {
        this.onModelChange = true;
      }, 30000);
      this.onFileChange1(event)
    });
  }

  getQuotationFormData() {
    this.motorQuoteService.getQuotationFormData().subscribe((response) => {
      this.partnerDataRes = response;
      //     this.formDataRes = response.countryData;
      this.partnersArr = this.partnerDataRes.Partners;

      if (this.retrieveQuoteNumber == '') {


        this.sideForm.get('partnerID').setValue(this.partnerId);

        this.getPartnerBranchList();
      }
    });
  }

  getSchemesByProduct() {
    this.motorQuoteService.getSchemesByProduct('MT').subscribe((result) => {
      this.product_list = result.getSchemesByProduct;
      this.sideForm
        .get('schemeCode')
        .setValue(localStorage.getItem('Schemecode'));
      this.SchemeCode = localStorage.getItem("Schemecode")

      if (this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "64F" || this.sideForm.value.schemeCode == "66S"  ) {
        this.quickquoteinfo.get('loading_capacity').setValidators(null);
        
        console.log(this.quickquoteinfo)

      }
    });
  }
  checkIsSchmeForHeavyVeh() {
    if (this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "64F") {   // if heavy vehical selected
      this.quickquoteinfo.get('loading_capacity').setValidators([Validators.required]);
      this.quickquoteinfo.get('v_specification')?.setValidators(null);
      this.quickquoteinfo.get('adtnl_detail_engine')?.setValidators(null);
      this.quickquoteinfo.get('cylinder')?.setValidators(null);
    }
    else if( this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66RK" || this.sideForm.value.schemeCode == "66Q") {
      this.quickquoteinfo.get('cylinder').setValidators([Validators.required]);
      this.quickquoteinfo.get('loading_capacity').setValidators(null);
      this.quickquoteinfo.get('v_specification').setValidators(null);
      this.quickquoteinfo.get('adtnl_detail_engine').setValidators([Validators.required]);
    }
    this.quickquoteinfo.get('cylinder').updateValueAndValidity();
    this.quickquoteinfo.get('v_specification').updateValueAndValidity();
    this.quickquoteinfo.get('loading_capacity').updateValueAndValidity();
    this.quickquoteinfo.get('adtnl_detail_engine').updateValueAndValidity();

    // else {
    //   if (this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "66Q" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemCode == "66RK") {
    //     alert(2);
    //     this.quickquoteinfo.get('v_specification')?.setValidators(null);
    //     this.quickquoteinfo.get('adtnl_detail_engine')?.setValidators(null);
    //     this.quickquoteinfo.get('cylinder')?.setValidators(null);
    //   }
    //   else if (this.sideForm.value.schemeCode != "60D" || this.sideForm.value.schemeCode != "66A" || this.sideForm.value.schemeCode != "66Q" || this.sideForm.value.schemeCode != "66S" || this.sideForm.value.schemCode != "66RK") {
    //     alert(3)
    //     this.quickquoteinfo.get('loading_capacity').setAsyncValidators(null);
    //     this.quickquoteinfo.get('v_specification')?.setValidators([Validators.required]);
    //     this.quickquoteinfo.get('adtnl_detail_engine')?.setValidators([Validators.required]);
    //     this.quickquoteinfo.get('cylinder')?.setValidators([Validators.required]);
    //   }
    //   this.quickquoteinfo.get('v_specification').updateValueAndValidity()
    //   this.quickquoteinfo.get('adtnl_detail_engine').updateValueAndValidity()
    //   this.quickquoteinfo.get('cylinder').updateValueAndValidity()
    //   this.quickquoteinfo.get('loading_capacity').updateValueAndValidity()
    // }
    // this.quickquoteinfo.get('loading_capacity')?.setValidators(null);
    // this.quickquoteinfo.get('loading_capacity')?.updateValueAndValidity();
  }
  //---------------------------------------- GET PLATE CODE ARRAY -----------------------------//
  getPlateCode(regPlaceId, type) {

    if (this.isClickChassisValidate) return false;  // if validate chassis no called 
    let plateSource = regPlaceId;

    if (
      typeof plateSource != undefined &&
      typeof plateSource != 'undefined'
    ) {
      this.motorQuoteService
        .getPlateCode(this.language_code, plateSource, this.quickquoteinfo.value.agencyrepair)
        .subscribe((res) => {
          this.plateCodeArray = res.plateCodeData;

          if (
            this.quickquoteinfo.value.adtnl_detail_brandNew == 1 &&
            typeof this.plateCodeArray != undefined &&
            typeof this.plateCodeArray != 'undefined'
          ) {
            
            var indexPlCode = this.plateCodeArray.findIndex(
              function (obj, k) {
                return obj.PlateCode == 'NEW NUMBER';
              }
            );
            let plCodeVal = this.plateCodeArray[indexPlCode];
            this.quickquoteinfo
              .get('rg_plateCode')
              .setValue(plCodeVal);
          }
          if (
            type == 3 &&
            typeof this.plateCodeArray != undefined &&
            typeof this.plateCodeArray != 'undefined'
          ) {
            //Plate COde
            let plateCode = this.plate_code;
            if (plateCode != undefined) {
              var indexPlCode = this.plateCodeArray.findIndex(
                function (obj, k) {
                  return obj.PlateCode === plateCode;
                }
              );
              let plCodeVal = this.plateCodeArray[indexPlCode];
              this.quickquoteinfo
                .get('rg_plateCode')
                .setValue(plCodeVal);
            }
          }
        });
    }
  }

  promise1 = new Promise((resolve, reject) => {
    setTimeout(() => {
      const newValue = Math.floor(Math.random() * 20);
      resolve(newValue);
    }, 5000);
  });

  promise2 = new Promise((resolve, reject) => {
    setTimeout(() => {
      const newValue = Math.floor(Math.random() * 20);
      resolve(newValue);
    }, 3000);
  });

  promise3 = new Promise((resolve, reject) => {
    setTimeout(() => {
      const newValue = Math.floor(Math.random() * 20);
      resolve(newValue);
    }, 2000);
  });

  // getIssuePlace(place) {
  //     this.quickquoteinfo.get('adtnl_detail_address').setValue(place);
  //   }

  sendEmail() {

    this.Sujbectdata = this.invalidData.value.subjectData;
    this.Description = this.invalidData.value.description;
    this.username = this.localStorageData.UserName;
    this.chassisNumber = this.invalidData.value.chassisnumber;


    this.motorQuoteService.sendEmailToAdmin(this.Sujbectdata, this.Description, this.username, this.chassisNumber).subscribe(res => {

    })
    this.close();
  }

  getVhclMakeData(vhcleMake, year, type) {

    if (this.notCallMake) { return false; }

    if (!this.isUpdateValuation) return false;
    if (!this.SchemeCodeClick) return false;

    if (this.isClickChassisValidate) return false;  // if validate chassis no called 


    let yearmod = '';
    if (year.value !== undefined) {
      yearmod = year.value;
    }
    else {
      yearmod = year;
    }

    if (yearmod == "") return false;


    this.showLoader.vhclMake = true;

    // let CoverType = this.instypes[0]?.ProductName;

    this.quickquoteinfo.get("adtnl_detail_brandNew").setValue("0");
    let yearmodNo: number = Number(yearmod);
    this.regMinDate = new Date(yearmodNo - 2, 0, 1);
    let currDate = new Date();
    if (yearmodNo + 2 >= currDate.getFullYear()) {
      this.regMaxDate = new Date();
    } 
    else
      this.regMaxDate = new Date(yearmodNo + 2, 11, 31);
    let CoverType = '';
    if (this.quickquoteinfo.value.adtnl_detail_insType?.ProductName) {
      CoverType = this.quickquoteinfo.value.adtnl_detail_insType?.ProductName;

    }
    let PolicyType = this.insvehibys[0].viewValue;
    if (this.quickquoteinfo.value.adtnl_detail_vhclOwnBy?.viewValue) {

      PolicyType = this.quickquoteinfo.value.adtnl_detail_vhclOwnBy?.viewValue;
    }
    if (yearmod != '')
      this.motorQuoteService.getVhclMake(CoverType, PolicyType, this.language_code, yearmod, this.sideForm.value.schemeCode).subscribe(async res => {
        // this.quickquoteinfo.get("rg_reg_date").setValue('');

        this.checkEngineValidation();
        this.checkTrimValidation();
        this.vhclMakeArr = res.vechileMakeValuesData;

        this.showLoader.vhclMake = false;

        if ((type == 2 || type == 1) && typeof (this.vhclMakeArr) != undefined && typeof (this.vhclMakeArr) != "undefined") {
          //VEHICLE Make ----- filter
          let makeVal;
          vhcleMake = this.quickquoteinfo.value.v_make;
          this.vhclMakeArr.forEach((item, index) => {
            if (item.VehicleMakeName == vhcleMake) {
              makeVal = item;
            }
          });
          this.modelId = makeVal.VehicleMakeId;
          this.quickquoteinfo.get('v_make').setValue(vhcleMake);
          await this.sleep(3000);


          if (type == 2)
            this.getVhclModel(makeVal.VehicleMakeId, 2, year);
          else
            this.getVhclModel(makeVal.VehicleMakeId, 1, year);
        }

        if (type == 3 && typeof (this.vhclMakeArr) != undefined && typeof (this.vhclMakeArr) != "undefined") {
          //VEHICLE Make ----- filter
          let makeVal;
          this.vhclMakeArr.forEach((item, index) => {
            if (item.VehicleMakeName == vhcleMake) {
              makeVal = item;
            }
          });

          this.quickquoteinfo.get('v_make').setValue(makeVal);
          this.chassis_No_Details.General.Make = makeVal.VehicleMakeId;
          this.getVhclModel(makeVal.VehicleMakeId, 3, year);
        }

        if (res.response_code == 1) {
          // this.onVehiclAgeChange(year);
          this.filteredMakes.next(this.vhclMakeArr.slice());
        }
        this.showLoader.vhclMake = false;
        // this.onVehiclAgeChange(this.quickquoteinfo.value.m_year);
      });
      // this.onVehiclAgeChange(this.quickquoteinfo.value.m_year);



  }


  private filterNationalCountry() {
    if (!this.formDataRes) {
      return;
    }

    let search = this.nationalFilterCtrl.value;
    if (!search) {
      this.filteredNationCountries.next(this.formDataRes.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredNationCountries.next(
      this.formDataRes.filter(bank => bank.CountryName.toLowerCase().indexOf(search) > -1)
    );
  }

  private filterPlateCat() {
    if (!this.plateCatArray) {
      return;
    }

    // get the search keyword
    let search = this.plateFilterCtrl.value;
    if (!search) {
      this.filteredPlateCat.next(this.plateCatArray.slice());
      return;
    } else {
      search = search.toLowerCase();
    }


    // filter the banks
    this.filteredPlateCat.next(
      this.plateCatArray.filter(bank => bank.label.toLowerCase().indexOf(search) > -1)
    );
  }


  getVhclModel(vehclMkId, type, year) {

    if (this.isClickChassisValidate) return false;  // if validate chassis no called \\\\

    // this.onVehiclAgeChange(year);

    let yearmod = '';
    if (year.value !== undefined) {
      yearmod = year.value;
    }
    else {
      yearmod = year;
    }


    this.showLoader.vhclModel = true;
    if (this.notCallMake == true) return false;
    this.motorQuoteService.getVehicleModel('P', this.quickquoteinfo.value.v_make, this.language_code, null, yearmod, this.sideForm.value.schemeCode).subscribe(res => {

      this.vhclModelArr = res.vechileModelData;
      if (res.response_code == 1) {

        this.filteredModels.next(this.vhclModelArr.slice()); // FOr ng select search
      }

      if ((type == 2 || type == 1) && typeof (this.vhclModelArr) != undefined && typeof (this.vhclModelArr) != "undefined") {
        let trim = type == 2 ? this.vehicleData.General.Trim : this.quoteDetail.TrimCode;
        let model = type == 2 ? this.vehicleData.General.Model : this.quoteDetail.VehicleModel;
        let ModalName = (vehclMkId == 34 || vehclMkId == 7) ? trim : model;

        var indexModel = this.vhclModelArr.findIndex(function (obj, k) {
          return obj.VehicleModelName === ModalName;
        });
        if (indexModel != -1) {
          let modelVal = this.vhclModelArr[indexModel];
          if (modelVal) {
            this.quickquoteinfo.get('v_model').setValue(modelVal);
            this.showLoader.vhclModel = false;

          }

          if (modelVal?.VehicleModelId) {
            if (type == 2)
              this.getMotorBodyType(modelVal.VehicleModelId, 2, year, modelVal.VehicleModelName);
            else
              this.getMotorBodyType(modelVal.VehicleModelId, 1, year, modelVal.VehicleModelName);
          }
        }

      }

      if (type == 3 && typeof (this.vhclModelArr) != undefined && typeof (this.vhclModelArr) != "undefined") {

        let ModalName = (this.chassis_No_Details.General.Make == 34 || this.chassis_No_Details.General.Make == 7) ? this.chassis_No_Details.General.Trim : this.chassis_No_Details.General.Model;

        if (ModalName != '' && ModalName != null) {
          var indexModel = this.vhclModelArr.findIndex(function (obj, k) {
            return obj.VehicleModelName === ModalName;
          });
          /*******  Commented due to  innsert manula new quote gives errot check later */
          //  let modelVal = this.vhclModelArr[indexModel];
          //  this.quickquoteinfo.get('v_model').setValue(modelVal);
          //  this.getMotorBodyType(modelVal.VehicleModelId, 3, year, modelVal.VehicleModelName);
        }



      }

      if (this.vhclModelArr && this.getVechileDetailData?.VehicleDetails?.General.Model) {
        let ModelName = this.getVechileDetailData.VehicleDetails.General.Model;
        var indexModel = this.vhclModelArr.findIndex(function (obj, k) {
          return obj.VehicleModelName === ModelName;
        });


        if (indexModel > -1) {
          let modelVal = this.vhclModelArr[indexModel];
          this.quickquoteinfo.get('v_model').setValue(modelVal);
          this.getMotorBodyType(modelVal.VehicleModelId, 3, year, modelVal.VehicleModelName);
        }

      } else if (this.getVechileDetailData?.VehicleDetails?.General.Model) {

        this.vhclModelArr = [];
        this.vhclModelArr.push({
          VehicleModelId: 1,
          VehicleModelName: this.getVechileDetailData?.VehicleDetails?.General.Model,
          Active: true,
          SeatingCapacityExDriver: 0,
          BodyTypeId: 1,
          CRS_MODEL_CODE: 1,
          EDATA_MODEL_CODE: "No"
        });


        this.quickquoteinfo.get("v_model").setValue(this.vhclModelArr[0]);
        let modelVal = this.vhclModelArr[0];
        this.getMotorBodyType(modelVal.VehicleModelId, 3, year, modelVal.VehicleModelName);

      }
      this.showLoader.vhclModel = false;

      var d = new Date(this.quickquoteinfo.value.rg_reg_date);
      let firstRegYear: number = d.getFullYear();

      var p = new Date(this.quickquoteinfo.value.SDate);
      let policyStartDateYear: number = p.getFullYear();
      let vhclYear = this.quickquoteinfo.value.m_year;

      let timeDiff = Math.abs(this.quickquoteinfo.value.rg_reg_date - this.quickquoteinfo.value.SDate);
      let days_difference = Math.floor(timeDiff / (1000 * 60 * 60 * 24));

      let D1 = Math.ceil(1 + (days_difference / 397)); //this will give you years
      let D2 = (Number(policyStartDateYear) - Number(vhclYear.value)) + 1;
      let vehicle_age = Math.max(D2, D1);
      let D3 = Math.abs(D2 - D1);
      if (D3 == 1) {
        vehicle_age = D1;
      }
      else {
        vehicle_age = Math.max(D2, D1);
      }
      this.vehicle_age = vehicle_age;

    });
  }

  getVhclModel2(vehclMkId, type, year, vhclmodel) {

    // this.onVehiclAgeChange(year);

    this.showLoader.vhclModel = true;

    this.motorQuoteService.getVehicleModel('P', this.quickquoteinfo.value.v_make, this.language_code, null, year.value, this.sideForm.value.schemCode).subscribe(res => {


      this.vhclModelArr = res.vechileModelData;
      if (res.response_code == 1) {

        this.filteredModels.next(this.vhclModelArr.slice()); // FOr ng select search
      }

      if ((type == 2 || type == 1) && typeof (this.vhclModelArr) != undefined && typeof (this.vhclModelArr) != "undefined") {


        var indexModel = this.vhclModelArr.findIndex(function (obj, k) {

          return obj.VehicleModelName === vhclmodel;
        });
        let modelVal = this.vhclModelArr[indexModel];

        this.quickquoteinfo.get('v_model').setValue(modelVal);
        if (type == 2)
          this.getMotorBodyType(modelVal.VehicleModelId, 2, year, modelVal.VehicleModelName);
        else
          this.getMotorBodyType(modelVal.VehicleModelId, 1, year, modelVal.VehicleModelName);
      }

      if (type == 3 && typeof (this.vhclModelArr) != undefined && typeof (this.vhclModelArr) != "undefined") {

        let ModalName = (this.chassis_No_Details.General.Make == 34 || this.chassis_No_Details.General.Make == 7) ? this.chassis_No_Details.General.Trim : this.chassis_No_Details.General.Model;

        if (ModalName != '' && ModalName != null) {
          var indexModel = this.vhclModelArr.findIndex(function (obj, k) {
            return obj.VehicleModelName === ModalName;
          });
          let modelVal = this.vhclModelArr[indexModel];
          if (indexModel > -1) {
            this.quickquoteinfo.get('v_model').setValue(modelVal);
            this.getMotorBodyType(modelVal.VehicleModelId, 3, year, modelVal.VehicleModelName);
          }
        }
      }
      this.showLoader.vhclModel = false;
      var p = new Date(this.quickquoteinfo.value.SDate);
      let policyStartDateYear: number = p.getFullYear();
      let vhclYear = this.quickquoteinfo.value.m_year;


    });
  }
  //get specification/trim data
  updateValuation() {
    
    if (this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName == "THIRD PARTY LIABILITY") {
      this.quickquoteinfo.get('v_value').setValue(0);
      this.quickquoteinfo.get('v_value').setValidators([]);
      this.quickquoteinfo.get('v_value').updateValueAndValidity()

      this.quickquoteinfo.get('agencyrepair').setValidators([]);
      this.quickquoteinfo.get('agencyrepair').updateValueAndValidity()
    }
    if (
      (this.quickquoteinfo.value.v_make != '' && this.quickquoteinfo.value.v_model != '' && this.quickquoteinfo.value.v_specification != '' && this.quickquoteinfo.value.bodytype != '' && this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName == 'INDIVIDUAL') ||
      (this.quickquoteinfo.value.v_make != '' && this.quickquoteinfo.value.v_model != '' && this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName == 'COMPREHENSIVE')
    )
    {
      this.showLoader.VehicleValue = true;

      let vehicleDetailArray = {
        chassisNum: this.quickquoteinfo.value.chassisno,
        insType: this.quickquoteinfo.value.adtnl_detail_insType,
        repairType: this.quickquoteinfo.value.v_make,
        vhclBodyType: this.quickquoteinfo.value.bodytype,
        vhclCylinder: this.quickquoteinfo.value.cylinder,
        vhclGCCSpecifird: this.quickquoteinfo.value.adtnl_detail_gccSpecified,
        vhclMake: this.quickquoteinfo.value.v_make,
        vhclModel: this.quickquoteinfo.value.v_model,
        vhclModelYr: this.quickquoteinfo.value.m_year,
        vhclSeatCapcity: this.quickquoteinfo.value.capacity,
        vhclTrim: this.quickquoteinfo.value.v_specification,
        SchemeCode: this.sideForm.value.schemeCode,
        PartnerId: this.sideForm.value.partnerID,
        engineSize: this.quickquoteinfo.value.adtnl_detail_engine,
      };
      if(vehicleDetailArray.vhclCylinder=='' || vehicleDetailArray.engineSize=='') return false ;
      this.motorQuoteService
        .getMotorValuation(vehicleDetailArray)
        .subscribe((res) => {
          

          if (res.StatusCode == 200) {
          
            this.existVehiclevalue = 0;
            this.referalStatus = false;
            this.vehicleValueLimit.isSet = true;
            this.vehicleValueLimit.startLimit = res.Valuation.Low;
            this.vehicleValueLimit.mediumLimit = res.Valuation.Medium;
            this.vehicleValueLimit.endLimit = res.Valuation.High;
            this.quickquoteinfo.get('v_value').setValue(res.Valuation.Medium);
          } else {
            if (vehicleDetailArray.vhclModelYr == '' || vehicleDetailArray.vhclMake == '' || vehicleDetailArray.vhclModel == '') {
            } else
              //Swal.fire("--1845--"+res.Message);
              this.existVehiclevalue = 1;
            this.referalStatus = true;
            this.vehicleValueLimit.startLimit = 0;
            this.vehicleValueLimit.endLimit = 0;
            this.quickquoteinfo.get('v_value').setValidators([Validators.required]);
            this.quickquoteinfo.get('v_value').updateValueAndValidity();
            this.quickquoteinfo.get('v_value').setValue('');
            // this.quickquoteinfo.value.vehicleValueLimit.isSet = false;
          }

          this.showLoader.VehicleValue = false;
        });
    } else {
      this.vhcleValueFlag = false;
    }
  }
  //getBodyType
  getMotorBodyType(vhclModelId, type, year, modelName) {

    if (this.isClickChassisValidate) return false;  // if validate chassis no called 

    let yearmod = '';
    if (year.value !== undefined) {
      yearmod = year.value;
    }
    else {
      yearmod = year;
    }
    if (yearmod == "") return false;

    if (typeof vhclModelId == 'undefined' || typeof vhclModelId == undefined)
      return false;

    this.showLoader.vhclTrim = true;
    this.showLoader.vhclBodyType = true;
    if (this.notCallMake == true) return false;
    this.motorQuoteService
      .getMotorSpecification(
        'Comprehensive',
        vhclModelId,
        this.language_code,
        yearmod,
        modelName
      )
      .subscribe((res) => {
        this.vhclBodyTypeArr = res.vechileMotoBodyTypeData;
        // this.vehitrims = res.vechil sSpecificationData;

        this.quickquoteinfo.get("cylinder").setValue("");
        if (res.response_code == 1 || res.response_code == 2) {
          this.showLoader.vhclTrim = false;
          this.showLoader.vhclBodyType = false;
        }
        if (this.vhclBodyTypeArr?.length == 1) {
          this.quickquoteinfo.get('bodytype').setValue(this.vhclBodyTypeArr[0].BodyTypeName);

        } else {

          if ((type == 2 || type == 1) && typeof this.vhclBodyTypeArr != undefined && typeof this.vhclBodyTypeArr != 'undefined') {
            //VEHICLE TRIM

            let trimName =
              type == 2
                ? this.vehicleData.General.Trim +
                ' ' +
                '-' +
                ' ' +
                this.vehicleData.Technical.EngineDisplacementNominal.Value.trim()
                : this.quoteDetail.TrimCode;
            let bodyType =
              type == 2
                ? this.vehicleData.General.BodyType
                : this.quoteDetail.BodyType;
            // if (this.vehicleData.General.Trim == null) {
            // } else {


            var indexTrim = this.vehitrims.findIndex(function (
              obj,
              k
            ) {

              return obj.VehicleSpecName === trimName;
            });
            let trimVal = this.vehitrims[indexTrim];

            //BODY TYPE

            var indexbodyType = this.vhclBodyTypeArr.findIndex(
              function (obj, k) {
                return obj.BodyTypeName === bodyType;
              }
            );
            let bdTyVal = this.vhclBodyTypeArr[indexbodyType];

            this.quickquoteinfo.get('bodytype').setValue(bdTyVal.BodyTypeName);

          }

          if (type == 3 && typeof this.vhclBodyTypeArr != undefined && typeof this.vhclBodyTypeArr != 'undefined') {
            //VEHICLE TRIM ------- not given

            //BODY TYPE

            let bdTyVal = this.vhclBodyTypeArr[indexbodyType];
            this.quickquoteinfo.get('bodytype').setValue(bdTyVal);
          }

        }
        //  this.getRrepairType();
      });


  }

  getCylinder() {
    this.motorQuoteService.getCylinderData1().subscribe(res => {
      this.vehicylinders = res.cylinder;

    });
  }


  tmpCountryList;
  getEmiratesIdData(type, docData) {

    if (type == 1) {

      this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;

      if (this.document_data.Data['Name'] == "Not Found") {

        this.quickquoteinfo.get('i_name').setValue('');

      } else { this.quickquoteinfo.get('i_name').setValue(this.document_data.Data['Name']); }


      this.quickquoteinfo.get('e_arabic_name')?.setValue(this.document_data.Data['NameInArabic']);

      if (this.document_data.Data['ID Number'] == "Not Found") {
        this.quickquoteinfo.get('e_eid')?.setValue('');
      } else {
        this.quickquoteinfo.get('e_eid')?.setValue(this.document_data.Data['ID Number'].replaceAll("-", ""));
      }

      this.formDataRes = this.tmpCountryList;
      // Nationality
      let nationality = this.document_data.Data['Nationality'];
      var indexNationality = this.formDataRes.findIndex(function (obj, k) {

        return obj.CountryName === nationality;
      });

      //  this.formDataRes[indexNationality]
      let nationalVal = this.formDataRes[indexNationality];


      this.quickquoteinfo.get('nationality').setValue(nationalVal.CountryName);

      if (!isNaN(indexNationality) && indexNationality != -1) {
        this.formDataRes = [];
        this.formDataRes.push(nationalVal);
        this.quickquoteinfo.get('nationality').setValue(nationalVal.CountryName);

      } else {
        if (this.quickquoteinfo.value.nationality == '') {
          this.formDataRes = this.tmpCountryList;

        }

      }

      //  this.quickquoteinfo.get('nationality').disable();

    }

    if (type == 2) {
      this.document_data.Data = docData.Data != '' ? docData.Data : this.document_data.Data;


      let gender = this.document_data.Data['Sex']
      //Gender
      var indexGender = this.genders.findIndex(function (obj, k) {
        return obj.value === gender;
      });
      let gnderVal = this.genders[indexGender];

      this.quickquoteinfo.get('e_gender')?.setValue(gnderVal);

      let dateDob: string = this.document_data.Data['Date of Birth'];
      dateDob = dateDob.replace(/-/gi, "/");

      let dateExp: string = this.document_data.Data['Expiry Date'];
      dateExp = dateExp.replace(/-/gi, "/");

      this.quickquoteinfo.get('e_cardNumber')?.setValue(this.document_data.Data['Card Number']);
      this.quickquoteinfo.get('e_expiryDate')?.setValue(this.dateConvert(dateExp));



      if (this.document_data.Data['Date of Birth'] != "Not Found" && this.document_data.Data['Date of Birth'] != "") {

        this.quickquoteinfo.get('birth_date')?.setValue(this.dateConvert(dateDob));
      }
    }

  }

  get f() { return this.quickquoteinfo.get; }
  onFileChange1(event) {
    this.myFileInput.nativeElement.value = '';
  }

  updateValuation_new() {

    if (this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName == "THIRD PARTY LIABILITY") {

      this.quickquoteinfo.get('v_value').setValue(0);
      this.quickquoteinfo.get('v_value').setValidators([]);
      this.quickquoteinfo.get('v_value').updateValueAndValidity()

      this.quickquoteinfo.get('agencyrepair').setValidators([]);
      this.quickquoteinfo.get('agencyrepair').updateValueAndValidity()

      return false;
    }
    let vehicleDetailArray = {
      chassisNum: this.quickquoteinfo.value.chassisno,
      promo_code: this.sideForm.value.promoCode,
      insType: this.quickquoteinfo.value.adtnl_detail_insType,
      repairType: this.quickquoteinfo.value.agencyrepair,
      vhclBodyType: this.quickquoteinfo.value.bodytype,
      vhclCylinder: this.quickquoteinfo.value.cylinder,
      vhclGCCSpecifird: this.quickquoteinfo.value.v_specification,
      vhclMake: this.quickquoteinfo.value.v_make,
      vhclModel: this.quickquoteinfo.value.v_model,
      vhclModelYr: this.quickquoteinfo.value.m_year,
      vhclSeatCapcity: this.quickquoteinfo.value.capacity,
      vhclTrim: this.quickquoteinfo.value.v_specification,
      engineSize: this.quickquoteinfo.value.adtnl_detail_engine,
      SchemeCode: this.sideForm.value.schemeCode,
      PartnerId: this.sideForm.value.partnerID,
      isBrandNew: this.quickquoteinfo.value.adtnl_detail_brandNew
    }


    if (
      this.quickquoteinfo.value.adtnl_detail_insType == '' ||
      this.quickquoteinfo.value.m_year == '' ||
      this.quickquoteinfo.value.v_make == '' ||
      this.quickquoteinfo.value.v_model == '' ||
      this.quickquoteinfo.value.bodytype == '' || (this.quickquoteinfo?.value?.adtnl_detail_engine =='' &&  this.sideForm.value.schemeCode != "60D" ) 
    ) return false;


    this.motorQuoteService.getMotorValuation(vehicleDetailArray).subscribe(res => {
    

      if (res.StatusCode == 200) {
        this.existVehiclevalue = 0;
        this.referalStatus = false;
        this.vehicleValueLimit.isSet = true;

        this.vehicleValueLimit.startLimit = res.Valuation.Low;
        this.vehicleValueLimit.mediumLimit = res.Valuation.Medium;
        this.vehicleValueLimit.endLimit = res.Valuation.High;



        this.quickquoteinfo.get('v_value').setValidators([Validators.required, Validators.min(this.vehicleValueLimit.startLimit), Validators.max(this.vehicleValueLimit.endLimit)]);
        this.quickquoteinfo.get('v_value').updateValueAndValidity();
        this.quickquoteinfo.get('v_value').setValue(res.Valuation.Medium);

      } else {

        this.existVehiclevalue = 1;
        this.referalStatus = true;
        this.vehicleValueLimit.startLimit = 0;
        this.vehicleValueLimit.endLimit = 0;
        this.quickquoteinfo.get('v_value').setValidators([Validators.required, Validators.min(this.vehicleValueLimit.startLimit), Validators.max(this.vehicleValueLimit.endLimit)]);
        this.quickquoteinfo.get('v_value').updateValueAndValidity();
        this.quickquoteinfo.get('v_value').setValue('');
        this.vehicleValueLimit.isSet = false;

      }
      this.showLoader.VehicleValue = false;
    });
  }

  //cpnvert Date
  convertDate(inputFormat) {
    function pad(s) {
      return s < 10 ? '0' + s : s;
    }
    var d = new Date(inputFormat);
    return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('-');
  }

  //for calculate age
  lic_issue_min;
  calucateAge(inputData, type) {

    //  policyMaxDate = new Date(new Date().setDate(new Date().getDate() + 30));
    const d = new Date(inputData);

    // this.lic_issue_min = new Date(new Date(d).setDate(365*18));

    if (inputData != '') {
      let timeDiff = Math.abs(Date.now() - inputData);
      if (type == 1) {
        return Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
      }

      if (type == 2) {
        return Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
      }
    } else {
      return '';
    }
  }

  //openDialog for session expired
  close() {
    this.dialog.closeAll();
  }

  saveData() {
    this.email = this.localStorageData.EmailAddress;
    this.psw = this.sessionData.value.password;
    if (this.email == '') {
      this._router.navigate(['/sign-in']);
    } else {
      this._authService
        .validateuser(this.email, this.psw)
        .subscribe(() => {
        });
    }
    this._router.navigate(['/quickquote']);
    this.close();
  }

  //REPORT AND ISSUE MODAL
  openReportModal() {
    const dialogRef = this.dialog.open(this.callAPIDialoginvalid);
  }

  //policy start Date

  //save quickquote data
  saveQuatationData() {
    console.log(this.quickquoteinfo);
    
    // this.childmessage = false;
    this.checkIsSchmeForHeavyVeh();

    if (this.quickquoteinfo.value.v_value != "" && this.quickquoteinfo.value.v_value <= 0) {
      Swal.fire("Please enter Sum Insured Value");
      return false;
    }
    this.quickquoteinfo.get('validate_respons').setValue(1);
    if (this.quickquoteinfo.status == 'INVALID') {
      this.quickquoteinfo.markAllAsTouched();
      Swal.fire('', 'Please fill all the mandatory data', 'warning');
    }
    else {
      this.quickquoteinfo.get('validate_respons').setValue('');
      this.insertquote('');
    }
  }
  checkOptionalBenefit(benefitId) {

    if (typeof (benefitId) != undefined && typeof (benefitId) != "undefined") {

      let benefitIdArray = benefitId.split(',');

      this.totalVariablePremium = 0;

      benefitIdArray.forEach((item1, index1) => {

        this.PlanDataJson.planBenefitData.data.forEach((item, index) => {
          if (item.BenefitId == item1) {

            this.PlanDataJson.planBenefitData.data[index].checked = true;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
          }

        });

        this.PlanDataJson.planBenefitData.data.forEach((item, index) => {

          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1) {

            item.multipleOptionData.forEach((multiItem, multiIndex) => {
              if (multiItem.BenefitId == item1) {

                this.mulOption = item.multipleOptionData[multiIndex];
                this.PlanDataJson.planBenefitData.data[index].checked = true;
                this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
                this.PlanDataJson.planBenefitData.data[index].multiOptID = item.multipleOptionData[multiIndex].BenefitId;
                this.PlanDataJson.planBenefitData.data[index].Price = item.multipleOptionData[multiIndex].Price;

              }

            });

          }

        });

      });

    }
    // this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
  }
  applyLoadingOnChangeRepairType() {

    this.repairLoadingAmt = Math.round(((20 * Number(this.totalFixPremium)) / 100));   //FOR BY PERCENT
    this.totalFixPremium += this.repairLoadingAmt;
  }

  contrinutionData = { "ODPremium": 0, "TPPremium": 0 }
  tempOption: any = [];
  insertquote(type) {

    this.tempOption = [];
    this.stepper.next();

    this.quickquoteinfo.get('validate_respons').setValue('');
    let motorArrayQuote = {
      motor_quote_type: "QUICKQUOTE",
      promo_code: this.sideForm.value.promoCode,
      webQuoteNumber: this.webQuoteNumber,
      policy_type: this.quickquoteinfo.value.adtnl_detail_insType.ProductName,
      // RepairType:this.quickquoteinfo.value.agencyrepair.RepairType,
      cedant_broker_id: this.sideForm.value.partnerID,
      broker_branch_id: this.quickquoteinfo.value.branchID,
      insured_type: this.quickquoteinfo.value.adtnl_detail_vhclOwnBy,
      NCDDoc: "NO",
      gender: this.quickquoteinfo.value.e_gender,
      eid_card_num: this.quickquoteinfo.value.e_cardNumber,
      eid_exp_date: this.convertDate(this.quickquoteinfo.value.e_expiryDate),
      name_in_arabic: this.quickquoteinfo.value.e_arabic_name,
      trade_Lic_number: this.quickquoteinfo.value.trade_lic_num,
      driv_lic_issuePlace: this.quickquoteinfo.value.d_place_issue,
      UAE_lic_age: this.convertDate(this.quickquoteinfo.value.lic_issue_date),
      driv_lic_exp_date: this.convertDate(this.quickquoteinfo.value.d_expiry_date),
      traffic_code: this.quickquoteinfo.value.rg_TC_num,
      reg_ins_exp_date: this.convertDate(this.quickquoteinfo.value.rg_ins_exp),
      license: this.quickquoteinfo.value.d_driv_lic_num,
      plateNumber: this.quickquoteinfo.value.rg_traffic_plate_num,
      product_code: this.quickquoteinfo.value.adtnl_detail_insType.ProductCode,
      insured_name: this.quickquoteinfo.value.i_name,
      dob: this.convertDate(this.quickquoteinfo.value.brith_date),
      driv_lic_issue_date: this.convertDate(this.quickquoteinfo.value.lic_issue_date),
      prospect_age: this.calucateAge(this.quickquoteinfo.value.brith_date, 1),
      nationality: this.quickquoteinfo.value.nationality,
      email: this.quickquoteinfo.value.emailaddress,
      mobile: this.quickquoteinfo.value.mobileno,
      model_year: this.quickquoteinfo.value.m_year,
      make: this.quickquoteinfo.value.v_make,
      model: this.quickquoteinfo.value.v_model,
      trim: this.quickquoteinfo.value.v_specification,
      body_type: this.quickquoteinfo.value.bodytype,
      engineSize: this.quickquoteinfo.value.adtnl_detail_engine,
      registered_date: this.convertDate(this.quickquoteinfo.value.rg_reg_date),
      cylinders: this.quickquoteinfo.value.cylinder,
      passenger: this.quickquoteinfo.value.capacity,
      registered_place: this.quickquoteinfo.value.r_place,
      chassis_no: this.quickquoteinfo.value.chassisno,
      milage: this.milageData,
      vehicleColor: this.color,
      rg_noOfDoor: this.noOfDoors,
      //   driv_lic_TC_number: this.quickquoteinfo.value.tcno,
      sum_insured: this.quickquoteinfo.value.v_value,
      low_sum_insured: this.vehicleValueLimit.startLimit,
      medium_sum_insured: this.vehicleValueLimit.mediumLimit,
      high_sum_insured: this.vehicleValueLimit.endLimit,
      UAELicAge: this.calucateAge(this.quickquoteinfo.value.lic_issue_date, 2),
      NCD_docs: 'No',
      NCD: this.quickquoteinfo.value.adtnl_detail_NCD,
      NCDPerc: this.quickquoteinfo.value.adtnl_detail_NCD_Perc,

      repair_type: this.quickquoteinfo.value.agencyrepair.RepairType,
      loading_capacity: this.quickquoteinfo.value.loading_capacity,
      isBrandNew: this.quickquoteinfo.value?.adtnl_detail_brandNew,

      // brand_new: brand_new,
      customer_id: '0',
      lead_id: '0',
      // registration_type: vehicleType,
      VEHENGINESIZE: '1',
      source: 'B2B',
      // document_data: this.tempDocArray,
      multiple_doc_data: this.tempMultipleDocData,
      GVM: this.quickquoteinfo.value.rg_gvm,
      origin: this.quickquoteinfo.value.rg_origin,
      policy_num: this.quickquoteinfo.value.rg_policy_num,
      // eid_card_num: this.horizontalStepperForm.value.quickquoteinfo.e_cardNumber,

      plate_code: this.quickquoteinfo.value.rg_plateCode,
      plate_category: this.quickquoteinfo.value.rg_type,
      SchemeCode: this.sideForm.value.schemeCode,
      GCCSpecified: this.quickquoteinfo.value.adtnl_detail_gccSpecified,
      BranchId: this.sideForm.value.branchID,
      BrokerBranchId: this.sideForm.value.Accounting,
      additional_DocumentFilePath: this.quickquoteinfo.value.additional_DocumentFilePath,
      vehicleValueLimit: this.vehicleValueLimit
    };


    let policyDetail = {
      quotation_number: this.webQuoteNumber,
      CRS_quotation_number: this.quoteNumber,
      start_date: this.convertDate(this.quickquoteinfo.value.SDate),
      chassis_no: this.quickquoteinfo.value.chassisno,
      mobile: this.quickquoteinfo.value.mobileno,
      nationality: this.quickquoteinfo.value.nationality,
      engine: this.quickquoteinfo.value.engine_num,
      plate: '54687',
      payment_mode: 'ONLINE',
      dealer_quote: '',
      noOfDoors: this.nofDoors,
      source: 'B2B',
      promocode: this.quickquoteinfo.value.promoCode,
      national_id: this.quickquoteinfo.value.e_eid,
    };
    console.log(motorArrayQuote);
    this.quoteDetailArr = motorArrayQuote;
    this.emailId = this.quickquoteinfo.value.emailaddress;

    this.showLoader.Quotation = true;

    this.quickQuoteService.getInsertQuickQuote(

      motorArrayQuote,
      policyDetail,
      this.userId,
      this.partnerId,
      this.cedantId,
      this.branchId

    ).subscribe((res) => {




      //  if (res.response_code == 6){
      //   Swal.fire("", res.reason, "error");
      //   // stepper.previ
      // }
      if (res.response_code == 1000) {
        const dialogRef = this.dialog.open(this.callAPIDialog);
      }
      

      if (res.response_code == 0) {
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        Swal.fire('Sorry! Plan not available.', ' ', 'warning');

        this.stepper.previous();
      }
      else if (res.totalPremium == 0) {
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        this.webQuoteNumber = res.webQuotationNumber;
        this.referral_reason = res.referral_reason;
        this.referalStatus = true;

        Swal.fire(
          'Referral.',
          "No premium found based on the data entered. Please verify or contact DNI IT",
          'warning'
        );

        this.stepper.previous();
      }

      else if (res.response_code == 4) {
        this.webQuoteNumber = res.webQuotationNumber;
        this.showLoader.Quotation = false;
        this.showLoader.retrieveQuote = false;
        this.referalStatus = true;
        this.referral_reason = res.referral_reason;
        //   this.savePolicyDetail(1);

        if (res.response_message) {

          Swal.fire(res.response_message,
            'Please click Refer button to refer the quote to UW. Your Quotation Ref# is: ' + this.webQuoteNumber,
            'warning'
          )

        } else
          Swal.fire(
            'Thank you for you request, based on your application details, the case needs to be referred for further review.',
            'Please click Refer button to refer the quote to UW. Your Quotation Ref# is: ' + this.webQuoteNumber,
            'warning'
          );

        this.stepper.previous();
      }
      if (res.response_code == 300) {
        this.showReferbutton = false;
        this.referral_reason = res.response_message_r;
        Swal.fire(this.referral_reason, 'You will be notified soon after the review. Your Quotation Reference# ' +
        this.webQuoteNumber, "warning");
      this.stepper.previous();
      return false;
        }
      else
        if (res.response_code == 2) {

          this.webQuoteNumber = res.webQuotationNumber;
          this.showLoader.Quotation = false;
          this.showLoader.retrieveQuote = false;
          this.referalStatus = true;
          this.referral_reason = res.referral_reason;
          //   this.savePolicyDetail(1);

          if (res.referral_reason) {

            Swal.fire("", res.referral_reason, 'warning'
            )

          }
          else {

            if (this.quoteStatus == "ADDITIONALINFO") {
              Swal.fire('Your details have been submitted to our team of UWs for review. ',
                'You will be notified soon after the review. Your Quotation Reference# ' +
                this.webQuoteNumber,
                'warning'
              );

              this._router.navigate(['motorscheme']);

            } else
              Swal.fire(
                'Thank you for you request, based on your application details, the case needs to be referred for further review.',
                'Please click Refer button to refer the quote to UW. Your Quotation Ref# is: ' + this.webQuoteNumber,
                'warning'
              );


          }

          this.stepper.previous();
        }
        else if (
          res.response_code_ == 400 ||
          res.response_code == 5
        ) {
          this.showLoader.Quotation = false;
          this.showLoader.retrieveQuote = false;
          this.webQuoteNumber = res.webQuotationNumber;
          this.referral_reason = res.referral_reason;
          this.referalStatus = true;
          //   this.savePolicyDetail(1);

          if (res.response_message) {

            Swal.fire(res.referral_reason,
              'Please click Refer button to refer the quote to UW. Your Quotation Ref# is: ' + this.webQuoteNumber,
              'warning'
            )

          } else
            Swal.fire(
              'Thank you for you request, based on your application details, the case needs to be referred for further review.',
              'Please click Refer button to refer the quote to UW. Your Quotation Ref# is: ' + this.webQuoteNumber,
              'warning'
            );
          this.stepper.previous();
        }
        else if (res.response_code == 6) {
          this.showLoader.Quotation = false;
          this.showLoader.retrieveQuote = false;
          this.webQuoteNumber = res.webQuotationNumber;
          this.referral_reason = res.referral_reason;
          this.referalStatus = true;
          //   this.savePolicyDetail(1);
          Swal.fire(res.response_message,
            'Please click Refer button to refer the quote to UW. Your Quotation Ref# is: ' + this.webQuoteNumber,
            'warning'
          );
          this.stepper.previous();
        }

        else if (res.response_code_r == 7) {
          this.webQuoteNumber = res.webQuotationNumber;
          this.referral_reason = res.response_message_r;
          this.showLoader.Quotation = false;
          this.showLoader.retrieveQuote = false;
          this.referalStatus = true;

          // this.savePolicyDetail(1);
          if (res.response_message) {

            Swal.fire(
              res.response_message,
              'warning'
            )

          } else
            Swal.fire(
              'Thank you for you request, based on your application details, the case needs to be referred for further review.',
              'Please click Refer button to refer the quote to UW. Your Quotation Ref# is: ' + this.retrieveQuoteNumber,
              'warning'
            )

          this.stepper.previous();
        } else {
          this.quickquoteinfo.get('validate_respons').setValue('1');
          this.disabledStatus = true;
          // this.childmessage = true;
          // this.sideForm.get('promoCode').setValue("DNI01");
          //  this.showLoader.Quotation = false;
          // this.showLoader.retrieveQuote = false;


          /************ Add Contribution data ***********/
          this.contrinutionData = {
            "ODPremium": res.contribution[0].ODPremium,
            "TPPremium": res.contribution[0].TPPremium

          }
          this.Deductible = res.contribution[0].Deductible;
          this.calRefNo = res.contribution[0].CalRefNumber;
          this.BaseRate = res.contribution[0].BaseRate;

          this.MaxLDPer = res.contribution[0].MaxLDPer;
          this.MaxLDAmt = res.contribution[0].MaxLDAmt;
          this.MaxDSPer = res.contribution[0].MaxDSPer;
          this.MaxDSAmt = res.contribution[0].MaxDSAmt;


          this.showLoader.Quotation = false;

          this.webQuoteNumber = res.webQuotationNumber;
          this.referalStatus = true;
          this.initial_benefit_data = res.planBenefitData.benefit_data;
          // this.policyFee = 1;
          this.planName = res.planName;
          this.policyFee = 0;
          this.totalVariablePremium = 0;
          this.PlanDataJson = res;
          this.totalFixPremium = res.BasePremium;
          this.plan_Name = this.PlanDataJson.planBenefitData.data[0].PlanName;
          this.plan_Id = this.PlanDataJson.planBenefitData.data[0].PlanId;
          this.benfPremIdArray = this.PlanDataJson.planBenefitData.data;
          this.webQuoteNumber = this.PlanDataJson.webQuotationNumber;
          this.quoteNumber = this.PlanDataJson.quotationNumber;
          this.PlanDataJson.planBenefitData.benefit_data = this.PlanDataJson.planBenefitData.data;
          this.tempBenefitData = this.PlanDataJson.planBenefitData.data;






          if (this.webQuoteNumber == '' || this.webQuoteNumber == null) {
            this.stepper.previous();
          } if (this.webQuoteNumber != '' || this.webQuoteNumber != null) {

            this.referalStatus = true;
          }

          this.PlanDataJson.planBenefitData.data.forEach((item, index) => {

            if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1) {
              this.mulOption = item.multipleOptionData[0];
              this.PlanDataJson.planBenefitData.data[index].benefitSelectedData = item.multipleOptionData[0];
              this.PlanDataJson.planBenefitData.data[index].multiOptID = item.multipleOptionData[0].BenefitId;
              this.PlanDataJson.planBenefitData.data[index].Price = item.multipleOptionData[0].Price;
              this.PlanDataJson.planBenefitData.data[index].checked = false;
              this.PlanDataJson.planBenefitData.data[index].offerChecked = false;

            }

            if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1) {

              this.PlanDataJson.planBenefitData.data[index].checked = false;
              this.PlanDataJson.planBenefitData.data[index].offerChecked = false;

            }


            if ((this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "64F")
              && (toUpper(this.quickquoteinfo.value.bodytype) == 'TRUCK' || toUpper(this.quickquoteinfo.value.bodytype) == 'BUS' || toUpper(this.quickquoteinfo.value.bodytype) == 'TRAILER')
              && (item.CRS_BENEFIT_CODE == '6721' || item.CRS_BENEFIT_CODE == '6722')) {
              this.PlanDataJson.planBenefitData.data[index].disable = true;
              this.PlanDataJson.planBenefitData.data[index].checked = true;

              this.tempOption.push(item);

            }

          });
          this.checkOptionalBenefit(this.optionalBenefit);
          this.discount = 0;


          this.tempTotalFixPremium = this.totalFixPremium;

          //  this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.tempTotalFixPremium * discount);
          this.tempTotalFixPremium = this.totalFixPremium;

          //  this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.tempTotalFixPremium * discount);
          this.totalFixPremium = Math.round(this.tempTotalFixPremium - this.discount);

          this.totalFixPremium = Math.round(this.totalFixPremium + this.policyFee);
          this.tempTotalLoadFixPrem = this.totalFixPremium;
          this.totalVariablePremium = 0;
          this.VATAMT = Math.round((this.totalFixPremium + this.totalVariablePremium) * 0.05).toFixed(2);
          this.Total_Primium = Math.round(this.totalFixPremium + this.totalVariablePremium + this.VATAMT);

          if (Number(this.loadingBy) != 2)
            this.loadingBy = '1';
          //this.savePolicyDetail(1);
          this.premium = this.PlanDataJson.premium - this.discount;
          this.checkAccessForPolicyIssueButtons();
        }

      this.tempOption.forEach((benifitItem, index) => {

        this.addOptionalBenigits(benifitItem.BenefitId, '');


      });

      //this.addOptionalBenigits(321, '');
      this.addOptionalBenigits(318, 2);
      this.calculateDiscount(this.loadingBy, this.loadByAmount, this.calculBy);

      this.addOptionalBenigits(318, 2);
      this.calculateDiscount(this.loadingBy, this.loadByAmount, this.calculBy);
    });


  }



  closeDesclaimer() {
    this.Desclaimer = false;
  }

  //getplan
  getQuotePlan(frame) {
    if (frame != '') {
      if (this.accept_terms == false) {
        return;
      }

      frame.hide();
    }

    this.showLoader.Quotation = true;
    this.showLoader.referal = false;
    let vatAMt =
      Math.round(this.totalFixPremium + this.totalVariablePremium) * 0.05;
    this.vatAMt = vatAMt;
    let total_premium =
      this.totalFixPremium + this.totalVariablePremium + vatAMt;
    this.total_premium = total_premium;
    let loadingAmt = this.loadByAmount;
    //   this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData
    let deductAmt = 0;
    if (this.RoleDesc == 'ADMIN' || this.RoleDesc == 'UNDERWRITER') {
      deductAmt = this.Deductible;

    } else {

      deductAmt = this.retrieveData[0]?.Deductible;
    }
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      total_premium: total_premium,
      base_premium: Math.round(this.premium),
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_name: this.quickquoteinfo.value.adtnl_detail_insType,
      VAT: vatAMt,
      benefitPreId: this.benfPremIdArray,
      calculation_type: this.calculBy,
      loading_by: this.loadingBy,
      loading_amount: loadingAmt,
      loadis_rate: this?.loading_rate,
      deductible: deductAmt,
      premiumGarageAmount: this?.repairLoadingAmt,
      // deductible: this.retrieveData[0]?.Deductible
      // deductible: this.step2.value.adminDeductible
    };

    this.motorQuoteService
      .insertPlanData(
        this.PlanDataJson.quotationNumber,
        this.PlanDataJson.PlanDataJson,
        Math.round(this.totalFixPremium),
        this.totalVariablePremium,
        this.policyFee,
        total_premium,
        this.PlanDataJson.planBenefitData.data,
        this.PlanDataJson.planBenefitData.benefit_data,
        this.quickquoteinfo.value.rep_type,
        this.savePlanDetailArr,
        // this.step2.value.adminDeductible,
        this.quickquoteinfo.value.adtnl_detail_insType
          .viewValue,
        'B2B',
        this.sideForm.value.schemeCode,
        '',
        '',
        '',
        '',
        this.contrinutionData
      )
      .subscribe((res) => {
        if (this.policyStatus == 'ISSUEPOLICY') {
          this.PaymentMode = 'CRD';
          localStorage.setItem('pageStatus', 'ISSUPOLICY');
          this.saveAdditionalInfo(3);
        }

        if (this.policyStatus == 'PAYMENT') {
          this.PaymentMode = 'ONL';
          localStorage.setItem('pageStatus', 'PAYMENT');
          Swal.fire(
            'Your details will be saved and you will be re-directed to Payment gateway page',
            ' Do not click back or click any button',
            'success'
          );
          this.saveAdditionalInfo(2);
        }

        if (this.policyStatus == 'SENDPAYMENTLINK') {
          this.saveAdditionalInfo(4);
        }

        // if (this.policyStatus == 'REFERED') {
        //   this.showLoader.Quotation = false;
        //   Swal.fire('Your quote has been referred to  UWs for review.', 'You will be notified soon after the review. Your Quotation Reference# ' + this.webQuoteNumber, 'success');
        //   this._router.navigate(['motorscheme']);
        // }

        if (this.policyStatus == 'REJECTED') {
          this.showLoader.Quotation = false;
          Swal.fire(
            '',
            'Quotation ' +
            this.webQuoteNumber +
            ' has been rejected and a notification is sent to the user.',
            'success'
          );
          this._router.navigate(['motorscheme']);
        }

        if (this.policyStatus == 'APPROVED') {
          this.saveAdditionalInfo(1);
          this.showLoader.Quotation = false;
          Swal.fire(
            '',
            'Quotation ' +
            this.webQuoteNumber +
            ' has been approved and sent to user for policy issuance.',
            'success'
          );
          this._router.navigate(['motorscheme']);
        }

        if (this.policyStatus == 'ADDITIONALINFO') {
          this.showLoader.Quotation = false;
          Swal.fire(
            '',
            'Quotation ' +
            this.webQuoteNumber +
            ' has been sent to user to provide additional information as requested.',
            'success'
          );
          this._router.navigate(['motorscheme']);
        }
      });
  }

  async getRegCardData(type, docData) {
    if (type == 1) {


      this.document_data.Data =
        docData.Data != '' ? docData.Data : this.document_data.Data;

      if (
        this.document_data.Data['Chassis No.'] == 'Not Found' ||
        this.vehicleData.StatusCode == 422
      ) {
        this.quickquoteinfo.get('chassisno').setValue('');
        this.quickquoteinfo.get('isChassisValidate').setValue('');
      } else {
        this.checkChassisValidation = true;
        this.quickquoteinfo
          .get('chassisno')
          .setValue(this.document_data.Data['Chassis No.']);
        this.quickquoteinfo.get('isChassisValidate').setValue('1');
      }

      //Model year
      let modelYear = this.vehicleData?.General?.ModelYear;
      var indexMYear = this.vehicalmodelyears.findIndex(function (
        obj,
        k
      ) {
        return obj.label === modelYear;
      });
      let yearVal = this.vehicalmodelyears[indexMYear];

      this.quickquoteinfo.get('m_year').setValue(yearVal);
      await this.sleep(3000);
      // this.regMinDate = new Date(modelYear - 2, 0, 1);
      // let currDate = new Date();
      // if (modelYear + 2 >= currDate.getFullYear()) {
      //   this.regMaxDate = new Date();

      // }
      // this.regMaxDate = new Date(modelYear + 2, 11, 31);

      if (this.vehicleData?.General?.Make) {
        this.chnageData.rg_vhcl_make = this.vehicleData?.General?.Make;
        this.getVhclMakeData(this.vehicleData?.General?.Make, yearVal, 2);
      }

      //NO OF PAASENGER
      let numOfPass = this.vehicleData?.General?.NoOfSeats;
      var iPassenger = this.vehiseatcaps.findIndex(function (obj, k) {
        return obj.viewValue == numOfPass;
      });

      let passengerVal = this.vehiseatcaps[iPassenger];

      this.quickquoteinfo.get('capacity').setValue(passengerVal?.viewValue);

      //ORIGIN
      let origin = this.document_data.Data.Origin;
      var indexOrin = this.formDataRes.findIndex(function (obj, k) {
        return obj.CountryName === origin;
      });
      let originVal = this.formDataRes[indexOrin];
      this.quickquoteinfo.get('rg_origin').setValue(originVal);

      //cylinders

      let cylVal;
      this.vehicylinders.forEach((item, index) => {
        if (item.Id == this.vehicleData.Technical.EngineCylinders) {
          cylVal = item;
        }
      });

      this.quickquoteinfo.get('cylinder').setValue(cylVal);
    }

    if (type == 2) {
      this.document_data.Data =
        docData.Data != '' ? docData.Data : this.document_data.Data;

      let dateExp: string = this.document_data.Data['Exp. Date'];
      dateExp = dateExp.replace(/-/gi, '/');
      let dateReg: string = this.document_data.Data['Reg. Date'];
      dateReg = dateReg.replace(/-/gi, '/');
      let dateInsp: string = this.document_data.Data['Ins. Exp.'];
      dateInsp = dateInsp.replace(/-/gi, '/');
      let strTCNum: string = this.document_data.Data['T. C. No.'];

      //   if (this.document_data.Data['Exp. Date'] != "Not Found")
      //     this.horizontalStepperForm.get('quickquoteinfo.rg_expiry_date').setValue(this.dateConvert(dateExp));
      //   else {
      //     this.horizontalStepperForm.get('quickquoteinfo.rg_expiry_date').setValue('');
      //   }

      //   if (this.document_data.Data['Ins. Exp.'] != "Not Found")
      //     this.horizontalStepperForm.get('quickquoteinfo.rg_ins_exp').setValue(this.dateConvert(dateInsp));
      //   else {
      //     this.horizontalStepperForm.get('quickquoteinfo.rg_ins_exp').setValue('');
      //   }

      //   if (this.document_data.Data['Reg. Date'] != "Not Found")
      //     this.horizontalStepperForm.get('quickquoteinfo.rg_reg_date').setValue(this.dateConvert(dateReg));
      //   else {
      //     this.horizontalStepperForm.get('quickquoteinfo.rg_reg_date').setValue('');
      //   }

      // this.quickquoteinfo
      //     .get('rg_policy_num')
      //     .setValue(this.document_data.Data['Policy No.']);

      //   this.quickquoteinfo.get('quickquoteinfo.rg_TC_num').setValue(this.document_data.Data['T. C. No.']);
      //   this.horizontalStepperForm.get('quickquoteinfo.rg_traffic_plate_num').setValue(this.document_data.Data['Traffic Plate No.']);

      //   if (this.horizontalStepperForm.value.quickquoteinfo.d_TC_number == '') {
      // this.horizontalStepperForm.get('quickquoteinfo.d_TC_number').setValue(this.horizontalStepperForm.value.quickquoteinfo.rg_TC_num);
      //   }
      this.quickquoteinfo.get('rg_traffic_plate_num')?.setValue(this.document_data.Data['Traffic Plate No.']);

      if (this.document_data.Data['Ins. Exp.'] != "Not Found")
        this.quickquoteinfo.get('rg_ins_exp')?.setValue(this.dateConvert(dateInsp));
      else {
        this.quickquoteinfo.get('rg_ins_exp')?.setValue('');
      }


      this.quickquoteinfo.get('rg_TC_num')?.setValue(this.document_data.Data['T. C. No.']);

      let plate_code_array =
        this.document_data.Data['Traffic Plate No.'].split('/');

      let regPlace = this.document_data.Data['Place of Issue'];
      this.plate_code =
        this.document_data.Data['Plate_code'] != ''
          ? this.document_data.Data['Plate_code']
          : plate_code_array[0];

      if (strTCNum.length == 8) {
        var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
          return obj.CityName === 'Dubai';
        });
        let placelVal = this.cityArr[indexRegPlace];


        this.quickquoteinfo
          .get('r_place')
          .setValue(placelVal);
        this.getPlateCode(placelVal.CityName, 3);
      } else if (
        this.document_data.Data['Place of Issue'] != 'Not Found' &&
        strTCNum.length != 8
      ) {
        var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
          return (
            obj.CityName.toLowerCase() === regPlace.toLowerCase()
          );
        });
        if (indexRegPlace == -1) {

        } else {
          let placelVal = this.cityArr[indexRegPlace];

          this.quickquoteinfo.get('r_place').setValue(placelVal);
          this.getPlateCode(placelVal.CityName, 3);
        }
      } else {
        this.quickquoteinfo.get('r_place').setValue('');
      }

      //REG TyPE == PLATE CATEGORY
      if (
        this.document_data.Data['Registration Type'] == 'Not Found' ||
        this.document_data.Data['Registration Type'] == null ||
        this.document_data.Data['Registration Type'] == ''
      ) {
        this.quickquoteinfo.get('rg_type').setValue('');
      } else {
        let regType = this.document_data.Data['Registration Type'];
        var indexRegType = this.regType.findIndex(function (
          obj,
          k
        ) {
          return obj.value.toLowerCase() === regType.toLowerCase();
        });
        let typelVal = this.regType[indexRegType];


        this.quickquoteinfo.get('rg_type').setValue(typelVal.value);
      }
    }

  }


  getMotorQuoteDetail(webQuoteNumber) {

    this.showLoader.Quotation = true;
    let vatAMt = (this.totalFixPremium + this.totalVariablePremium) * 0.05;
    let total_premium = this.totalFixPremium + this.totalVariablePremium + vatAMt;
    let loadingAmt = this.loadByAmount;

    let deductAmt = 0;
    if (this.RoleDesc == 'ADMIN' || this.RoleDesc == 'UNDERWRITER') {
      deductAmt = this.Deductible;

    } else {

      deductAmt = this.retrieveData[0]?.Deductible;
    }
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      total_premium: total_premium,
      base_premium: Math.round(this.premium),
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_code: this.quickquoteinfo.value.adtnl_detail_insType.ProductName,
      VAT: vatAMt,
      benefitPreId: this.benfPremIdArray,
      calculation_type: this.calculBy,
      loading_by: this.loadingBy,
      loading_amount: loadingAmt,
      loadis_rate: this.loading_rate,
      deductible: deductAmt,
      premiumGarageAmount: this.repairLoadingAmt,
      // deductible: this.step2.value.adminDeductible
    }

    this.motorQuoteService.insertPlanData(this.PlanDataJson.quotationNumber, this.PlanDataJson.PlanDataJson, Math.round(this.premium),
      this.totalVariablePremium,
      this.policyFee,
      total_premium,
      this.PlanDataJson.planBenefitData.data,
      this.PlanDataJson.planBenefitData.benefit_data,
      this.quickquoteinfo.value.agencyrepair,
      // this.step2.value.adminDeductible,
      this.savePlanDetailArr,
      this.quickquoteinfo.value.adtnl_detail_insType.ProductName,
      'B2B',
      this.sideForm.value.schemeCode, '', '', '', '', this.contrinutionData
    ).subscribe(res => {
      this._router.navigate(["motorquote/update/" + webQuoteNumber]);
      // this._router.navigate(["motorquick/update/" + webQuoteNumber]);

    });
  }
  sumInc = ''; chgDeductAmt = ''; optBenfit = ''; others = '';
  saveAdditionalInfo(type) { }


  chgDeduct = '';
  //send refrel to admin
  sendRefferMailToAdmin(type) {

    if (type == 1 || type == 2) {

      if (this.referalDescription == '') {
        this.validtnMsg = true;
        return false;
      }
      this.validtnMsg = false;
      this.showLoader.referal = true;
    }

    if (type == 3 || type == 4 || type == 5) {
      if (this.referalDescription == '') {
        this.validtnMsg = true;
        return false;
      }
      this.validtnMsg = false;
      this.showLoader.referal = true;
    }


    let refer_type;
    let event_type;


    if (type == 1 || type == 2) {
      event_type = 'REFERQUOTE';        // REFER A QUOTE
      refer_type = type == 1 ? 'SYSTEM' : 'MANUAL';
      this.policyStatus = 'REFERED';

    }

    if (type == 3) {
      event_type = 'REFERAPPROVED';     // APPROVED
      refer_type = '';
      this.policyStatus = 'APPROVED';
    }

    if (type == 4) {
      event_type = 'REFERREJECTED';      // REJECTED
      refer_type = '';
      this.policyStatus = 'REJECTED';
    }

    if (type == 5) {
      event_type = 'ADDITIONALINFO';      // ADDITIONAL INFO
      refer_type = '';
      this.policyStatus = 'ADDITIONALINFO';
    }

    if (type == 6) {
      event_type = 'BORQUOTE';      // BOR Document
      refer_type = '';
      this.policyStatus = 'BORQUOTE';
    }
    if (type == 7) {
      event_type = 'REFCONFIRMED';      // BOR Document
      refer_type = '';
      this.policyStatus = 'CONFIRM';
    }
    let extraField = { sumInc: this.sumInc, chgDeduct: this.chgDeduct, optBenfit: this.optBenfit, deductible: this.Deductible }
    this.motorQuoteService.sendReferralMailToAdmin(this.webQuoteNumber, encodeURIComponent(this.referalDescription), this.emailadd, event_type, refer_type, this.referral_reason, this.tempMultipleDocData, this.refAdditionalCondition, extraField).subscribe(res => {
      if (res.response_code == 1) {
        if (type == 1 || type == 2) {
          if (this.policyStatus == 'REFERED') {
            this.showLoader.referal = false;
            Swal.fire('Your quote has been referred to UWs for review.', 'You will be notified soon after the review. Your Quotation Reference# ' + this.webQuoteNumber, 'success');
            // this.close();
            this._router.navigate(['motorscheme']);
          }
        }
        if (type == 4 || this.callRejected == true) {
          if (this.policyStatus == 'REJECTED') {
            this.showLoader.referal = false;
            Swal.fire(
              '',
              'Quotation ' +
              this.webQuoteNumber +
              ' has been rejected and a notification is sent to the user.',
              'success'
            );
            this._router.navigate(['motorscheme']);

          }

        }
        // if(type == 7 ){
        //   if(this.policyStatus = 'CONFIRM'){
        //     this.showLoader.referal = false;
        //     Swal.fire('','Quotation ' + this.webQuoteNumber +' has been Confirmed and a notification is sent to the user.','success');
        //     this.close();
        //      this._router.navigate(['motorscheme']);
        //     }
        // }

        if ((type == 2 || type == 3 || type == 4 || type == 5) && this.callRejected == false) {

          if (this.policyStatus == 'ISSUEPOLICY') {
            this.PaymentMode = 'CRD';
            localStorage.setItem('pageStatus', 'ISSUPOLICY');
            this.saveAdditionalInfo(3);
          }

          if (this.policyStatus == 'PAYMENT') {
            this.PaymentMode = 'ONL';
            localStorage.setItem('pageStatus', 'PAYMENT');
            Swal.fire("Your details will be saved and you will be re-directed to Payment gateway page", " Do not click back or click any button", 'success');
            this.saveAdditionalInfo(2);
          }

          if (this.policyStatus == 'SENDPAYMENTLINK') {
            this.saveAdditionalInfo(4);
          }

          // if(this.policyStatus == 'REFERED'){
          //         this.showLoader.Quotation = false;
          //         Swal.fire('Your quote has been referred to  UWs for review.', 'You will be notified soon after the review. Your Quotation Reference# ' + this.webQuoteNumber, 'success');
          //         this.close();
          //          this._router.navigate(['motorscheme']);
          // }

          if (this.policyStatus == 'REJECTED') {
            this.showLoader.Quotation = false;
            Swal.fire('', 'Quotation ' + this.webQuoteNumber + ' has been rejected and a notification is sent to the user.', 'success');
            this.close();
            this._router.navigate(['motorscheme']);
          }

          if (this.policyStatus == 'APPROVED') {
            this.saveAdditionalInfo(1);
            this.showLoader.Quotation = false;
            Swal.fire('', 'Quotation ' + this.webQuoteNumber + ' has been approved and sent to user for policy issuance.', 'success');
            this.close();
            this._router.navigate(['motorscheme']);
          }

          if (this.policyStatus == 'ADDITIONALINFO') {
            this.showLoader.Quotation = false;
            Swal.fire('', 'Quotation ' + this.webQuoteNumber + ' has been sent to user to provide additional information as requested.', 'success');
            this.close();
            this._router.navigate(['motorscheme']);
          }

          // this.getQuotePlan('');
          this.close();
          this.referalModel = false;
        }

        if ((type == 2 || type == 3 || type == 4 || type == 5) && this.callRejected == false) {

          this.getQuotePlan('');
          this.referalModel = false;
        }

        this.callRejected == false;
        this.close();

      }



    });



  }


  refAdditionalCondition(
    webQuoteNumber: any,
    referalDescription: string,
    emailadd: any,
    event_type: any,
    refer_type: any,
    referral_reason: any,
    tempMultipleDocData: any,
    refAdditionalCondition: any
  ) {
    throw new Error('Method not implemented.');
  }

  checkAccessForPolicyIssueButtons() {
    this.motorQuoteService
      .checkAccessToPolicyButtons('MT')
      .subscribe((res) => {
        if (res.IsNonPayIssueAllowed == 0) {
          this.issuePolicyBtnAccess = true;
        }

        if (res.IsOnlinePaymentAllowed == 0) {
          this.onlinePayBtnAccess = true;
        }

        if (res.QuoteConfirmAction == "CONFIRM") {
          this.confirmBtnAccess = true;
        }
      });
  }

  getAllFormData() {
    this.motorQuoteService
      .getDropdownData(
        'COMPREHENSIVE',
        '0',
        this.language_code,
        this.country,
        ''
      )
      .subscribe((res) => {

        this.cityArr = res.cityData;
        this.regType = res.PlateCategory;
        this.formDataRes = res.countryData;
        this.tmpCountryList = this.formDataRes;
        this.filteredNationCountries.next(this.formDataRes.slice());

        res.PlateCategory.forEach((item, index) => {
          this.plateCatArray.push(item);
        })
        this.filteredPlateCat.next(this.plateCatArray.slice());
      });
  }

  nonEditableFields(GCC_Specification) {
    if (GCC_Specification != '' && GCC_Specification != null) {
      return true;
    }
  }
  onVehiclAgeChange(vhclYear) {
    if (vhclYear == '') return false;
    var d = new Date(this.quickquoteinfo.value.rg_reg_date);
    let firstRegYear: number = d.getFullYear();
    var p = new Date(this.quickquoteinfo.value.SDate);
    let policyStartDateYear: number = p.getFullYear();
    

    let vhclNextYear = Number(vhclYear?.value) + 2;
    let vhclPrevYear = Number(vhclYear?.value) - 2;
    let schemeYear = Number(firstRegYear) - Number(vhclYear?.value);

    this.regMinDate = new Date(vhclPrevYear, 0, 1);

    let currDate = new Date();
    if (Number(vhclYear?.value) + 2 >= currDate.getFullYear()) {
      this.regMaxDate = new Date();
    } 
    else
      this.regMaxDate = new Date(Number(vhclYear?.value) + 2, 11, 31);
    // this.regMaxDate = new Date();
    let vhclAge = this.year - vhclYear?.value;
    // this.insuredDetailForm.get('rg_reg_date')?.setValue(this.regMinDate);
    let sLocalDate: any = new Date(this.quickquoteinfo.value.SDate);

    let timeDiff = Math.abs(this.quickquoteinfo.value.rg_reg_date - sLocalDate);
    let days_difference = Math.floor(timeDiff / (1000 * 60 * 60 * 24));

    /***  To be implemented later 04-12-2022 */
    let D1 = Math.ceil(1 + (days_difference / 397)); //this will give you years
    console.log(D1);
    let D2 = (Number(policyStartDateYear) - Number(vhclYear?.value));   // Model Year Result
    console.log(D2);

    this.vehicle_age = Math.max(D2, D1);
    if (this.vehicle_age <= 0) this.vehicle_age = 1;


    let RepairData = {

      partnerid: this.sideForm.value.partnerID,
      schemecode: this.sideForm.value.schemeCode,
      vhclModelYr: this.quickquoteinfo.value.m_year,
      vhclMake: this.quickquoteinfo.value.v_make,
      vhclModel: this.quickquoteinfo.value.v_model,
      vhclBodyType: this.quickquoteinfo.value.bodytype,
      insuredType: this.quickquoteinfo.value.adtnl_detail_vhclOwnBy.viewValue,
      engine: this.quickquoteinfo.value.adtnl_detail_engine.Name,
      age: this.vehicle_age,
      webQuoteNumber: this.webQuoteNumber
    }

    this.motorQuoteService
      .getRrepairType(RepairData)
      .subscribe((res) => {
        let response = res;
        this.repairs = response.repair_type_data;

        this.repairtypes = this.repairs
        this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
        if (this.retrieve_repair_type != '') {
          var indRepairType;
          this.repairs.forEach((item, index) => {
            if (item.RepairType.toLowerCase() == this.retrieve_repair_type.toLowerCase()) {
              indRepairType = item;
            }
          });
          this.quickquoteinfo.get('agencyrepair').setValue(indRepairType);

          if (this.repairtypes.length == 1) this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
        }
      });
  }
  // onVehiclAgeChange(vhclYear) {


  // //  if(!this.isRepiarTypeCall) return false ;

  //   var d = new Date(this.quickquoteinfo.value.rg_reg_date);
  //   let firstRegYear: number = d.getFullYear();

  //   var p = new Date(this.quickquoteinfo.value.SDate);
  //   let policyStartDateYear: number = p.getFullYear();
  //   let vhclYear1 = this.quickquoteinfo.value.m_year;
  //   let sLocalDate:any = new Date(this.quickquoteinfo.value.SDate);
  //   let timeDiff = Math.abs(this.quickquoteinfo.value.rg_reg_date - sLocalDate);
  //   let days_difference =  Math.floor(timeDiff / (1000 * 60 * 60 * 24));

  //   let  D1 = Math.ceil(1 + (days_difference/397)); //this will give you years
  //   let  D2 = (Number(policyStartDateYear) - Number(vhclYear1.value)) + 1;
  //   let vehicle_age = Math.max(D2,D1);
  //   let D3 = Math.abs(D2 - D1);
  //   if(D3 == 1){
  //       vehicle_age = D1;
  //   }
  //   else{
  //       vehicle_age = Math.max(D2,D1);
  //   }
  //   this.vehicle_age = vehicle_age ;
  //   // let currentYr = new Date();
  //   // this.vehicle_age = currentYr.getFullYear() -  this.quickquoteinfo.value.m_year.label;

  //   if(this.vehicle_age<=0) this.vehicle_age = 1 ;


  //     let RepairData = {

  //       partnerid: this.sideForm.value.partnerID,
  //       schemecode: this.sideForm.value.schemeCode,
  //       vhclModelYr: this.quickquoteinfo.value.m_year,
  //       vhclMake: this.quickquoteinfo.value.v_make,
  //       vhclModel: this.quickquoteinfo.value.v_model,
  //       vhclBodyType: this.quickquoteinfo.value.bodytype,
  //       insuredType :  this.quickquoteinfo.value.adtnl_detail_vhclOwnBy.viewValue,
  //       engine :  this.quickquoteinfo.value.adtnl_detail_engine.Name,
  //       age:this.vehicle_age,
  //       webQuoteNumber:this.webQuoteNumber
  //     }

  //     this.motorQuoteService
  //     .getRrepairType(RepairData)
  //         .subscribe((res) => {
  //             let response = res;
  //             this.repairs = response.repair_type_data;
  //          
  //             this.repairtypes=this.repairs
  //             this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
  //             if(this.retrieve_repair_type != ''){
  //                   var indRepairType;
  //                   this.repairtypes.forEach((item, index) => {
  //                     if (item.value.toLowerCase() == this.quoteDetail.RepairType.toLowerCase()) {
  //                           indRepairType = item;
  //                     }
  //                   });
  //                   this.quickquoteinfo.get('agencyrepair').setValue(indRepairType);

  //                   if(this.repairtypes.length==1) this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
  //             }
  //         });
  // }


  tempRepairType = { vhclBodyType: "", partnerid: "", schemecode: "", vhclModelYr: "", vhclMake: "", vhclModel: "", insuredType: "", webQuoteNumber: "", age: "" };

  checkBrandNew() {

    if (this.sideForm.value.schemeCode == "60D") {
      this.quickquoteinfo.get('v_value').setValue('');
    }

    if (this.quickquoteinfo?.value?.adtnl_detail_brandNew == 1) {

      this.quickquoteinfo.get('rg_reg_date')?.setValue(new Date(Date.now()));
    } else {

      this.quickquoteinfo.get('rg_reg_date')?.setValue('');
    }
    this.onVehiclAgeChange(this.quickquoteinfo.value.m_year);
    if (this.quickquoteinfo.value.m_year.label <= new Date().getFullYear() && this.quickquoteinfo?.value?.adtnl_detail_brandNew == 1) {

      // getRrepairType(){


      if (this.vehicle_age <= 0) this.vehicle_age = 1;
      let RepairData = {
        vhclBodyType: this.quickquoteinfo.value.bodytype,
        partnerid: this.partnerId,
        schemecode: this.sideForm.value.schemeCode,
        vhclModelYr: this.quickquoteinfo.value.m_year,
        vhclMake: this.quickquoteinfo.value.v_make,
        vhclModel: this.quickquoteinfo.value.m_year,
        insuredType: this.quickquoteinfo.value.adtnl_detail_vhclOwnBy.viewValue,
        webQuoteNumber: this.webQuoteNumber,
        age: this.vehicle_age
      }

      if (this.tempRepairType.vhclBodyType == RepairData.vhclBodyType && this.tempRepairType.partnerid == RepairData.partnerid &&
        this.tempRepairType.schemecode == RepairData.schemecode && this.tempRepairType.vhclModelYr == RepairData.vhclModelYr &&
        this.tempRepairType.vhclMake == RepairData.vhclMake && this.tempRepairType.vhclModel == RepairData.vhclModel &&
        this.tempRepairType.insuredType == RepairData.insuredType &&
        this.tempRepairType.webQuoteNumber == RepairData.webQuoteNumber && this.tempRepairType.age == RepairData.age
      ) {

        return false;
      } else {

        this.tempRepairType = RepairData;
      }

      this.motorQuoteService.getRrepairType(RepairData).subscribe((res) => {



        let response = res;
        this.repairs = response.Data;
        this.repairtypes = this.repairs;

        this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
        if (this.retrieve_repair_type != '') {
          var indRepairType;
          this.repairtypes.forEach((item, index) => {
            if (item.RepairType?.toLowerCase() == this.quoteDetail?.RepairType?.toLowerCase()) {
              indRepairType = item;
            }
          });
          if (indRepairType)
            this.quickquoteinfo.get('agencyrepair').setValue(indRepairType);
          else
            this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);

          if (this.repairtypes.length == 1) this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);

        }

      });

      // }



      Swal.fire({
        title: 'Do you want to change from  used to Brand new ?',
        showDenyButton: true,

        confirmButtonText: 'Save',

      }).then((result) => {

        /* Read more about isConfirmed, isDenied below */
        if (this.sideForm.value.schemeCode == "60D" && (result.isConfirmed == true || result.isConfirmed == false)) {
          this.quickquoteinfo.get('v_value').setValue('');
        }
        if (result.isConfirmed) {
          // if( ){
          //   
          // }
          // this.quickquoteinfo.get('rg_reg_date')?.setValidators(null);
          if (this.quickquoteinfo.value.m_year.label >= new Date().getFullYear() || true) {
            this.regMaxDate = new Date(Date.now());
            this.quickquoteinfo.get('rg_reg_date')?.setValue(new Date(Date.now()));
          }
          else {
            this.quickquoteinfo.get('rg_reg_date')?.setValue(null);
          }


          this.transactionTypeArray = [];
          this.transactionTypeArray.push(this.tempTransactionTypeArr[0]);
          this.quickquoteinfo.get('transaction_type')?.setValue(this.transactionTypeArray[0]);

        } else if (result.isDenied) {

          this.quickquoteinfo.get('adtnl_detail_brandNew').setValue('0');


        }
      })




    } else {

      if (this.quickquoteinfo?.value?.adtnl_detail_brandNew == 1) {
        this.quickquoteinfo.get('rg_reg_date')?.setValidators(null);

        this.transactionTypeArray = [];
        this.transactionTypeArray.push(this.tempTransactionTypeArr[0]);
        this.quickquoteinfo.get('transaction_type')?.setValue(this.transactionTypeArray[0]);
      }
      else {
        this.transactionTypeArray = [];
        this.transactionTypeArray.push(this.tempTransactionTypeArr[1]);
        this.transactionTypeArray.push(this.tempTransactionTypeArr[2]);
        this.quickquoteinfo.get('transaction_type')?.setValue(this.transactionTypeArray[0]);
      }

    }
    this.quickquoteinfo.get('rg_reg_date')?.setValue('');
    this.quickquoteinfo.get('rg_reg_date')?.updateValueAndValidity();

    this.quickquoteinfo.get('rg_plateCode')?.setValue('');



    setTimeout(
      function () {
        if (this.sideForm.value.schemeCode != '60D') {
          this.updateValuation_new();
        }
      }.bind(this),
      1000
    );
  }


  viewQuotePDF() {
    this.showLoader.Quotation = true;
    let vatAMt = (this.totalFixPremium + this.totalVariablePremium) * 0.05;
    let total_premium = this.totalFixPremium + this.totalVariablePremium + vatAMt;
    let loadingAmt = this.loadByAmount;

    let deductAmt = 0;
    if (this.RoleDesc == 'ADMIN' || this.RoleDesc == 'UNDERWRITER') {
      deductAmt = this.Deductible;

    } else {

      deductAmt = this.retrieveData[0]?.Deductible;
    }
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      total_premium: total_premium,
      base_premium: this.premium,
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_code: this.quickquoteinfo.value.adtnl_detail_insType.ProductName,
      VAT: vatAMt,
      benefitPreId: this.benfPremIdArray,
      calculation_type: this.calculBy,
      loading_by: this.loadingBy,
      loading_amount: loadingAmt,
      loadis_rate: this.loading_rate,
      deductible: deductAmt,
      premiumGarageAmount: this.repairLoadingAmt,

      // deductible: this.step2.value.adminDeductible
    }

    this.motorQuoteService.insertPlanData(this.PlanDataJson.quotationNumber, this.PlanDataJson.PlanDataJson, this.premium,
      this.totalVariablePremium,
      this.policyFee,
      total_premium,
      this.PlanDataJson.planBenefitData.data,
      this.PlanDataJson.planBenefitData.benefit_data,
      // this.step2.value.adminDeductible,
      this.quickquoteinfo.value.agencyrepair,
      this.savePlanDetailArr,
      this.quickquoteinfo.value.adtnl_detail_insType.ProductName,
      'B2B',
      this.sideForm.value.schemeCode, '', '', '', '', this.contrinutionData
    ).subscribe(res => {


      this.motorQuoteService.getQuoteDetailPDF(this.webQuoteNumber, this.partnerId, "B2B").subscribe(res => {


        this.showLoader.Quotation = false;
        setTimeout(
          function () {

          }.bind(this),
          600
        );
        let viewPDF = res;
        if (viewPDF.response_code == 1) {
          window.open(viewPDF.pdfPath, "_blank");
        }
      });
      //  this.editableStep.Quotation = false ;

    });

  }

  resBoxhistory() {
    this.isvisited = !this.isvisited;
  }



  getQuotePlanEmail() {
    this.showLoader.Quotation = true;
    let vatAMt = (this.totalFixPremium + this.totalVariablePremium) * 0.05;
    let total_premium = this.totalFixPremium + this.totalVariablePremium + vatAMt;
    let loadingAmt = this.loadByAmount;

    let deductAmt = 0;
    if (this.RoleDesc == 'ADMIN' || this.RoleDesc == 'UNDERWRITER') {
      deductAmt = this.Deductible;

    } else {

      deductAmt = this.retrieveData[0]?.Deductible;
    }
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      total_premium: total_premium,
      base_premium: Math.round(this.totalFixPremium),
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_code: this.quickquoteinfo.value.adtnl_detail_insType.ProductName,
      VAT: vatAMt,
      benefitPreId: this.benfPremIdArray,
      calculation_type: this.calculBy,
      loading_by: this.loadingBy,
      loading_amount: loadingAmt,
      loadis_rate: this.loading_rate,
      deductible: deductAmt,
      premiumGarageAmount: this.repairLoadingAmt,
      // deductible: this.step2.value.adminDeductible

    }

    this.motorQuoteService.insertPlanData(this.PlanDataJson.quotationNumber, this.PlanDataJson.PlanDataJson, Math.round(this.totalFixPremium),
      this.totalVariablePremium,
      this.policyFee,
      total_premium,
      this.PlanDataJson.planBenefitData.data,
      this.PlanDataJson.planBenefitData.benefit_data,
      this.quickquoteinfo.value.agencyrepair,
      // this.step2.value.adminDeductible,
      this.savePlanDetailArr,
      this.quickquoteinfo.value.adtnl_detail_insType.ProductName,
      'B2B',
      this.sideForm.value.schemeCode, '', '', '', '', this.contrinutionData
    ).subscribe(res => {

      this.sendMail();
      this.showLoader.Quotation = false;
      //  this.editableStep.Quotation = false ;

      Swal.fire("", "Thank you for choosing Dubai National Insurance for insuring your car. We have sent an email to your registered email with all the quotation details. Your Quotation Reference# " + this.webQuoteNumber, 'success');

    });
  }

  sendMail() {
    this.motorQuoteService.sendMail(this.webQuoteNumber, this.emailId, '').subscribe(res => {


    });
  }

  searchVehicle() {
    this.dialog.open(this.callAPIDialog1);
  }

  getQuotationHistory(quoteNumber) {
    this.motorQuoteService.getQuotationHistory(quoteNumber, 'MT').subscribe(res => {

      if (res.response_code == 1) {
        this.quotationHistoryArr = res.quotationHistoryList;

      }


    });
  }

  CheckAccessOnLoad() {

    this.motorQuoteService.checkUserAccess('QUICKMOTORQUOTE', this.localStorageData.EmailAddress, 'MT', this.retrieveQuoteNumber).subscribe(res => {
      let response = res;
      //  this.checkStepper = false;
      if (response.userAccessData == 0) {
        this.unauthorizedAccess = true;
        //  Swal.fire( "You are not authorized to access this section. Please contact your relationship manager.", 'warning');

      }
      else {

        this.Desclaimer = true;
        this.headerDesclaimer = response.HeaderDisclaimer;

      }

    });
  }
  quoteDetailPrev = '';
  isTonnageCall = false;
  isRepiarTypeCall = true;
  getRetrieveQuoteDataUpgrade() {



    /************* If Quotation numner blank  **************/
    if (this.retrieveQuoteNumber == "" || typeof (this.retrieveQuoteNumber) == "undefined") return true;
    this.isClickChassisValidate = true;
    this.isTonnageCall = false;
    this.isUpdateValuation = false;

    this.getQuotationHistory(this.retrieveQuoteNumber);
    this.getDataForEditQuoteDocs(this.retrieveQuoteNumber);
    this.motorQuoteService.getRetrieveQuote(this.retrieveQuoteNumber, 'BTBPORTAL', '').subscribe(res => {
    
      if (this.localStorageData.UserRole == 'RM' && this.retrieveQuoteNumber != '') {
        this.sideForm.disable();
        this.quickquoteinfo.disable();
      }
      

      /**********  Need to check this variable **********/
      
      this.isRepiarTypeCall = false;
      this.webQuoteNumber = this.retrieveQuoteNumber;
      this.retrieveData = res.quotationDetailsDataForCustomer;
      let resData = this.retrieveData[0];
      this.quoteDetail = this.retrieveData[0];
      this.quoteDetailPrev = this.retrieveData[0];
      this.sideForm.get("schemeCode").setValue(resData.SchemeCode);
      const schemes = ["65S", "65Q4", "66S", "65RK", "66RK", " 66Q"];
      const schemeCoTPL = ["66A", "60D", "64F"]
      let event = this.sideForm.value.schemeCode;
      if (schemes.includes(event)) { this.chassisMin = 17; this.chassisMax = 17; }
      if (schemeCoTPL.includes(event)) { this.chassisMin = 6; this.chassisMax = 17; }
      this.checkEngineValidation();
      this.checkTrimValidation();
      this.quoteStatus = resData.StatusDesc;
      /******************  retrive data fill form ********/
      this.quickquoteinfo.get('chassisno')?.setValue(resData.ChassisNumber);
      this.sideForm.get('promoCode').setValue(resData.PromoCode);
      this.getinsuredTypeOnRetrieve(resData.SchemeCode, 1);
      this.checkIsBorOrAddtionInfo();
      this.optionalBenefit = this.quoteDetail.SelectedBenefits;
      if (this.quoteDetail.LDCalType == 1)
        this.loadByAmount = this.quoteDetail.LDRate;
      else
        this.loadByAmount = this.quoteDetail.LDAmount;

      // this.LDAmount = this.quoteDetail.LDAmount;
      this.LDType = this.quoteDetail.LDType;
      this.LDRate = this.quoteDetail.LDRate;
      this.loadingBy = this.LDType;

      // Model Year Binding 
      this.vehicalmodelyears = [];
      this.vehicalmodelyears.push({ value: resData.VehicleModelYear.toString(), label: resData.VehicleModelYear.toString() });
      if (resData.VehicleModelYear)
        this.quickquoteinfo.get("m_year")?.setValue(this.vehicalmodelyears[0]);
     

      // this.regMinDate = new Date(resData.VehicleModelYear - 2, 0, 1);

      // let currDate = new Date();
      // if (resData.VehicleModelYear + 2 >= currDate.getFullYear()) {
      //   this.regMaxDate = new Date();

      // } else
      //   this.regMaxDate = new Date(resData.VehicleModelYear + 2, 11, 31);

      this.quickquoteinfo.get("adtnl_detail_brandNew")?.setValue(resData.IsBrandNew);
      

      // Vehicle Make Binding 
      this.vhclMakeArr = [];
      this.vhclMakeArr.push({
        VehicleMakeId: 1,
        VehicleMakeName: resData.VehicleMake,
        Active: true,
        IsReferral: 0,
        CRS_VEH_CODE: 1
      });
      this.quickquoteinfo.get("v_make").setValue(this.vhclMakeArr[0]);


      // Vehicle Model Binding 
      this.vhclModelArr = [];
      this.vhclModelArr.push({
        VehicleModelId: 1,
        VehicleModelName: resData.VehicleModel,
        Active: true,
        SeatingCapacityExDriver: 0,
        BodyTypeId: 1,
        CRS_MODEL_CODE: 1,
        EDATA_MODEL_CODE: "No"
      });
      this.quickquoteinfo.get("v_model").setValue(this.vhclModelArr[0]);
      
      


      // Vehicle Body Type Binding 
      this.vhclBodyTypeArr = [];
      this.vhclBodyTypeArr.push({ id: 1, BodyTypeName: resData.BodyType });
      this.quickquoteinfo.get("bodytype").setValue(this.vhclBodyTypeArr[0].BodyTypeName);
      
      

      this.onRetirveEngineCall = false;
      // Vehicle Trim Binding 
      this.vehitrims = [];
      this.vehitrims.push({ Name: resData.TrimName });
      this.quickquoteinfo.get("v_specification").setValue(this.vehitrims[0]);


      // Vehicle Engine Binding 
      let engineData = resData.EngineSize;
      this.engineList = [{ Name: engineData, Code: engineData, Cylinders: engineData, Passengers: 4 }];
      this.quickquoteinfo.get('adtnl_detail_engine').setValue(this.engineList[0]);

      // Vehicle Cylinders Binding 
      this.vehicylinders = [{ Id: 1, CylinderName: resData.VehicleCylinders, CylinderCode: "2" }];
      this.quickquoteinfo.get("cylinder").setValue(this.vehicylinders[0]);
      
      

      

      // Vehicle Number Of Passenger Binding 
      if (this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66Q") {
        this.vehiseatcaps = [];
        this.vehiseatcaps.push({ value: resData.PassengersCount, viewValue: resData.PassengersCount });
        this.quickquoteinfo.get('capacity')?.setValue(this.vehiseatcaps[0]);
      }
      this.vehiseatcaps = [{ value: 2, viewValue: resData.PassengersCount }];
      if (resData.PassengersCount == 2) {
        this.minCount = 2;
        this.maxCount = resData.PassengersCount + 2;
        this.vehiseatcaps = [];
        for (let i = this.minCount; i <= this.maxCount; i++) {
          this.vehiseatcaps.push({ value: i, viewValue: i });
        }
        this.quickquoteinfo.get('capacity')?.setValue(this.vehiseatcaps[0]);
      }

      if (resData.PassengersCount > 2) {
        this.minCount = resData.PassengersCount - 1;
        this.maxCount = resData.PassengersCount + 2;
        this.vehiseatcaps = [];
        for (let i = this.minCount; i <= this.maxCount; i++) {
          this.vehiseatcaps.push({ value: i, viewValue: i });
        }

        this.quickquoteinfo.get('capacity')?.setValue(this.vehiseatcaps[0]);
      }

      if (resData.PassengersCount < 8) {
        this.minCount = resData.PassengersCount - 1;
        this.maxCount = 8;
        this.vehiseatcaps = [];
        for (let i = this.minCount; i <= this.maxCount; i++) {
          this.vehiseatcaps.push({ value: i, viewValue: i });
        }
        this.quickquoteinfo.get('capacity')?.setValue(this.vehiseatcaps[0]);
      }
      
      this.quickquoteinfo.get("capacity").setValue(resData.PassengersCount);
      
      if ((this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66Q" || this.sideForm.value.schemeCode == "66RK")) {
        this.GCC.edata = false;
      }
      else {
        this.GCC.edata = true;
      }
      if (resData.HasGCCSpecification != "No") {

        this.GCC.Yes = true;
        this.quickquoteinfo.get("adtnl_detail_gccSpecified").setValue("Yes");
      }
      else {
        this.GCC.No = true; this.quickquoteinfo.get("adtnl_detail_gccSpecified").setValue("No");
      }

      if ((resData.ChassisNumber != '') && (this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66Q" || this.sideForm.value.schemeCode == "66RK")) {

        this.GCC.edata = false;
      }
      else {

        this.GCC.edata = true;
      }
      console.log(resData.SumInsured);
      console.log(this.vehicleValueLimit.startLimit);
      console.log(this.vehicleValueLimit.endLimit )
      this.quickquoteinfo.get("v_value").setValue(resData.SumInsured);
      console.log(this.quickquoteinfo)
      
      this.vehicleValueLimit.startLimit = resData.ValuationLow;
      // this.vehicleValueLimit.mediumLimit = res.Valuation.Medium;
      this.vehicleValueLimit.endLimit = resData.ValuationHigh;
      this.quickquoteinfo.get('v_value').setValidators([Validators.required, Validators.min(this.vehicleValueLimit.startLimit), Validators.max(this.vehicleValueLimit.endLimit)]);
      this.quickquoteinfo.get('v_value').updateValueAndValidity();
      

      var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
        return (
          obj.CityName.toLowerCase() === resData.RegistrationPlace.toLowerCase()
        );
      });
      let placelVal = this.cityArr[indexRegPlace];
      this.quickquoteinfo.get('r_place').setValue(placelVal);


      // var indexRegType = this.regType.findIndex(function (
      //             obj,
      //             k
      //         ) {
      //             return obj.value.toLowerCase() === resData.RegistrationType.toLowerCase();
      //         });
      //  let typelVal = this.regType[indexRegType];



      this.getPlateCategoryEdit(resData.RegistrationPlace, resData.RegistrationType);
      //this.quickquoteinfo.get('rg_type').setValue(typelVal.value);

      this.quickquoteinfo.get('i_name').setValue(resData.InsuredName);
      this.quickquoteinfo.get('emailaddress').setValue(resData.InsuredEmail);
      this.quickquoteinfo.get('mobileno').setValue(resData.InsuredMobile);
      this.quickquoteinfo.get('loading_capacity').setValue(resData.Tonnage);


      // Nationality
      var indexNationality;
      this.formDataRes.forEach((item, index) => {
        if (item.CountryName == resData.Nationality) {
          indexNationality = item;
        }
      });
      this.quickquoteinfo.get('nationality').setValue(indexNationality?.CountryName);

      this.quickquoteinfo.get('brith_date').setValue(new Date(resData.InsuredDOB));
      let SplitArray = resData.FirstRegistrationDate.split("/");
      let newDate = new Date(SplitArray[2]+"/"+SplitArray[1]+"/"+SplitArray[0])
      this.quickquoteinfo.get('SDate').setValue(new Date( resData.FirstRegistrationDate));

      //NCD
      var indexNCD = this.NCDPerDataF.findIndex(function (obj, k) {

        return obj.NCDDescription === resData.NCD;

      });
      let NCDVal = this.NCDPerDataF[indexNCD];
      this.quickquoteinfo.get('adtnl_detail_NCD').setValue(NCDVal);
      this.quickquoteinfo.get('lic_issue_date').setValue(new Date(resData.DrivingLicIssueDate));


      setTimeout(() => {
        this.quickquoteinfo.get('adtnl_detail_NCD_Perc').setValue(res.quotationDetailsDataForCustomer[0].AddlitionalNCDDisc);
      }, 1000);

      //Vehicle own by  covertype
      var indexOwnBy = this.insvehibys.findIndex(function (obj, k) {

        if ((upperCase(obj.value) == 'CORPORATE') === (resData.InsuredType)) {

        }

        return obj.value === resData.InsuredType;

      });
      let ownByVal = this.insvehibys[indexOwnBy];

      this.quickquoteinfo.get('adtnl_detail_vhclOwnBy').setValue(ownByVal);




      this.sideForm.get('partnerID').setValue(resData.PartnerId);


      this.quickquoteinfo.get("SDate").setValue(resData.PolicyStartDate);

      this.getPartnerBranchList();

      if (resData.RepairType == null) {
        this.repairtypes = [{ Id: 1, RepairType: resData.RepairType }];
        this.quickquoteinfo.get("agencyrepair")?.setValue(this.repairtypes[0]);
      }
      else {
        let repairTypeList = resData.RepairType.split(",");
        this.repairs = [];
        let repTypeSel: any;
        repairTypeList.forEach((item, index) => {
          this.repairs.push({ Id: index, RepairType: item });
          if (resData.RepairType.toLowerCase() == item.toLowerCase())
            repTypeSel = index;
        });

        if (repTypeSel == 0 || repTypeSel == 1)
          this.quickquoteinfo.get("agencyrepair")?.setValue(this.repairs[repTypeSel]);
        else {

          this.repairs = [{ Id: 1, RepairType: resData.RepairType }];

          this.quickquoteinfo.get("agencyrepair")?.setValue(this.repairs[0])
        }

      }

      //   if(resData.RepairType!=null){

      //   let repairTypeList  = resData.RepairType.split(",");
      //   
      //   this.repairs = [] ;
      //   let repTypeSel:any ;
      //   repairTypeList.forEach((item, index) => {
      //     this.repairs.push({Id:index,RepairType:item});
      //     if(resData.RepairType==item)
      //     repTypeSel = index;
      //     
      //   });
      // // this.repairs=[{Id:1,RepairType:resData.RepairType}];
      //   this.quickquoteinfo.get("agencyrepair").setValue(resData.RepairType);}

      //   else{
      //     this.repairs = [] ;
      //     this.repairs.push({Id:1,RepairType:resData.RepairType});
      //     this.quickquoteinfo.get("agencyrepair").setValue(this.repairs[0]);

      //   }

      this.quickquoteinfo.get('rg_reg_date')?.setValue(resData.FirstRegistrationDate);
      //  this.onVehiclAgeChange(this.quickquoteinfo.value.m_year)
      this.retrieve_repair_type = resData.RepairType;
      this.isClickChassisValidate = false
      this.isUpdateValuation = false;
      this.onVehiclAgeChange(resData.VehicleModelYear);
    });




  }

  getRetrieveQuoteData() {

    if (this.retrieveQuoteNumber == "" || typeof (this.retrieveQuoteNumber) == "undefined") return true;
    this.showLoader.retrieveQuote = true;
    this.motorQuoteService.getRetrieveQuote(this.retrieveQuoteNumber, 'BTBPORTAL', '').subscribe(res => {
      

      if (res.response_code == 1) {


        this.isUpdateValuation = false;
        this.webQuoteNumber = this.retrieveQuoteNumber;
        this.retrieveData = res.quotationDetailsDataForCustomer;
        let resData = this.retrieveData[0];
        this.quoteDetail = this.retrieveData[0];
        this.quoteDetail.plateCode = resData.PlateCode;
        this.vhcleValueFlag = true;
        this.quoteStatus = resData.StatusDesc;
        this.optionalBenefit = this.quoteDetail.SelectedBenefits;
        this.isRenewal = this.quoteDetail.IsRenewal;

        if (this.quoteDetail.LDCalType == 1)
          this.loadByAmount = this.quoteDetail.LDRate;
        else
          this.loadByAmount = this.quoteDetail.LDAmount;
        // this.LDAmount = this.quoteDetail.LDAmount;
        this.LDType = this.quoteDetail.LDType;
        this.LDRate = this.quoteDetail.LDRate;
        this.engineDefaultValue = resData.EngineSize;
        this.loadingBy = this.LDType;
        if (resData.HasGCCSpecification == "") this.GCC.No = true; else this.GCC.Yes = true;
        this.quickquoteinfo.get('capacity').setValue(resData.PassengersCount);


        //Passenger Count
        // var indexPasger = this.vehiseatcaps.findIndex(function (obj, k) {
        //                     return obj.value == resData.PassengersCount;
        //                   });
        // let PasgerVal = this.vehiseatcaps[indexPasger];
        //  this.quickquoteinfo.get('capacity')?.setValue(PasgerVal.viewValue);
        //IN CASE OF B2C - DOCUMENTS ARE NOT GETTING BECAUSE OF WE DON'T SAVE THEM BEFORE INSERT/UPDATE QUOTE
        // this.getDataForEditQuoteDocs(this.retrieveQuoteNumber);

        this.getQuotationHistory(this.retrieveQuoteNumber);
        this.getDataForEditQuoteDocs(this.retrieveQuoteNumber);

        if (resData.Bsrc == 'B2B') {

          //chassis
          this.quickquoteinfo.get('chassisno').setValue(resData.ChassisNumber);

          //Vehicle Cylinders

          var indexCylinder = this.vehicylinders.findIndex(function (obj, k) {
            return obj.CylinderCode === resData.VehicleCylinders;
          });
          let cylVal = this.vehicylinders[indexCylinder];
          this.quickquoteinfo.get('cylinder').setValue(cylVal);


          let PasgerVal;

          this.vehiseatcaps.forEach((item, index) => {
            if (item.value == (resData.PassengersCount - 1)) {
              PasgerVal = item;

            }
          });


          this.onRetirveEngineCall = false;
          this.quickquoteinfo.get('v_value').setValue(resData.SumInsured);

          this.vehicleValueLimit.startLimit = resData.ValuationLow;
          this.vehicleValueLimit.mediumLimit = res.Valuation.Medium;
          this.vehicleValueLimit.endLimit = resData.ValuationHigh;

          this.quickquoteinfo.get('v_value').setValidators([Validators.required, Validators.min(this.vehicleValueLimit.startLimit), Validators.max(this.vehicleValueLimit.endLimit)]);
          this.quickquoteinfo.get('v_value').updateValueAndValidity();
          this.vehicleValueLimit.isSet = true;


          //Plate category
          if (resData.RegistrationType != null) {
            var indexPlCat = this.regType.findIndex(function (obj, k) {
              return obj.PlateCategotyName.toLowerCase() === resData.RegistrationType.toLowerCase();
            });
            let plCatVal = this.regType[indexPlCat];

            if (typeof (plCatVal) != "undefined")
              this.quickquoteinfo.get('rg_type').setValue(plCatVal.PlateCategotyName);
          } else {
            this.quickquoteinfo.get('rg_type').setValue('');
          }

          //    //REG PLACE
          if (resData.RegistrationPlace != '' && resData.RegistrationPlace != null && resData.RegistrationPlace != undefined) {

            var indexPlace = this.cityArr.findIndex(function (obj, k) {
              return obj.CityName === resData.RegistrationPlace;
            });
            let placeal = this.cityArr[indexPlace];
            this.quickquoteinfo.get('r_place').setValue(placeal);
            this.quoteDetail.regplace = placeal.CityName;
            this.getPlateCode(this.quoteDetail.regplace, 2);
          }


          this.quickquoteinfo.get('i_name').setValue(resData.InsuredName);
          this.quickquoteinfo.get('emailaddress').setValue(resData.InsuredEmail);
          this.quickquoteinfo.get('mobileno').setValue(resData.InsuredMobile);
          this.quickquoteinfo.get('brith_date').setValue(this.dateConvert(resData.InsuredDOB));
          this.quickquoteinfo.get('brith_date').setValue(new Date(resData.InsuredDOB));
          this.quickquoteinfo.get('loading_capacity')?.setValue(resData.Tonnage);

          if (resData.CedantBrokerId == '') {
            this.sideForm.get('partnerID').setValue(this.partnerId);
            this.getPartnerBranchList();

          } else {
            this.sideForm.get('partnerID').setValue(resData.CedantBrokerId);

            this.getPartnerBranchList();
          }


          if (resData.DrivingLicIssueDate == null || resData.DrivingLicIssueDate == '1900-01-01 00:00:00.000') {
            this.quickquoteinfo.get('lic_issue_date').setValue(null);
          } else {
            this.quickquoteinfo.get('lic_issue_date').setValue(new Date(resData.DrivingLicIssueDate));
          }

          //Vehicle own by
          var indexOwnBy = this.insvehibys.findIndex(function (obj, k) {
            return obj.value.toLowerCase() === resData.InsuredType.toLowerCase();
          });
          let ownByVal = this.insvehibys[indexOwnBy];
          console.log(ownByVal);
          console.log(this.insvehibys[indexOwnBy])
          this.quickquoteinfo.get('adtnl_detail_vhclOwnBy').setValue(ownByVal);


          //NCD
          var indexNCD = this.NCDData.findIndex(function (obj, k) {
            return obj.NCDDescription === resData.NCD;

          });
          let NCDVal = this.NCDData[indexNCD];
          this.quickquoteinfo.get('adtnl_detail_NCD').setValue(NCDVal);


          setTimeout(() => {
            this.quickquoteinfo.get('adtnl_detail_NCD_Perc').setValue(res.quotationDetailsDataForCustomer[0].AddlitionalNCDDisc);
          }, 1000);

          // Nationality
          var indexNationality;
          this.formDataRes.forEach((item, index) => {
            if (item.CountryName == resData.Nationality) {
              indexNationality = item;

            }
          });
          this.quickquoteinfo.get('nationality').setValue(indexNationality.CountryName);

          //  VEHICLE YEAR
          let yearVal;
          this.vehicalmodelyears.forEach((item, index) => {
            if (item.label == resData.VehicleModelYear) {
              yearVal = item;
            }
          });
          this.quickquoteinfo.get('m_year').setValue(yearVal);
          // this.regMinDate = new Date(resData.VehicleModelYear - 2, 0, 1);

          // let currDate = new Date();
          // if (resData.VehicleModelYear + 1 >= currDate.getFullYear()) {
          //   this.regMaxDate = new Date();

          // } else
          //   this.regMaxDate = new Date(resData.VehicleModelYear + 2, 11, 1);




          this.quoteDetail.VehicleMake = resData.VehicleMake;
          this.quoteDetail.VehicleModel = resData.VehicleModel;
          this.quoteDetail.TrimCode = resData.TrimCode;
          this.quoteDetail.TrimName = resData.TrimName;
          this.quoteDetail.BodyType = resData.BodyType;
          this.retrieve_repair_type = resData.RepairType;
          this.quoteDetail.RepairType = resData.RepairType;

          if (this.repairtypes.length == 1) this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
          this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);

          // this.quickquoteinfo.get('adtnl_detail_gccSpecified').setValue(resData.TrimCode);



          //vhcl make
          this.getVhclMakeData(this.quoteDetail.VehicleMake, yearVal, 1);



        }
      }
    });
  }

  checkValidInputData(event: any, type) {

    this.globalService.checkValidInputData(event, type);
  }

  changeChasisValidation(type) {

    // commented for timing
    if (this.checkChassisValidation == false) {
      this.quickquoteinfo.get('isChassisValidate').setValue('');
      if (type == 1) {
        this.quickquoteinfo.get('m_year').setValue('');
        this.quickquoteinfo.get('v_make').setValue('');
        this.quickquoteinfo.get('v_model').setValue('');
        this.quickquoteinfo.get('v_specification').setValue('');
        this.quickquoteinfo.get('bodytype').setValue('');
        this.quickquoteinfo.get('cylinder').setValue('');
        //  this.quickquoteinfo.get('capacity').setValue('');
        //   this.quickquoteinfo.get('adtnl_detail_brandNew').setValue('0');
        //  this.quickquoteinfo.get('rg_plateCode').setValue('');

      }
    } else {
      this.checkChassisValidation = false;
    }

  }

  async onKeyVehicleData(event: any) {

    if (this.Search_vehicle.value.selected_motor.length < 4) { this.FilterVehicleData = []; return false; }
    await Promise.all([this.promise1, this.promise2, this.promise3]);
    this.isLoading = true;
    this.searchData = event.target.value;
    await this.quickQuoteService.globalSearchForData(this.searchData).subscribe(res => {

      this.FilterVehicleData = res.response_data;
      this.isLoading = false;
      let resData = res.response_data; // to - do



    })
  }

  dateConvert(inputFormat) {

    let vDOEntryArray = inputFormat.split('/');
    let DOEntry = new Date();
    DOEntry.setDate(vDOEntryArray[0]);
    DOEntry.setMonth(vDOEntryArray[1] - 1);
    DOEntry.setFullYear(vDOEntryArray[2]);

    return DOEntry;

  }


  getDataForEditQuoteDocs(quoteNumber) {
    this.motorQuoteService.getDataForEditQuoteDoc(quoteNumber).subscribe(res => {


      this.editQuoteDocs = res.getDataForEditQuoteDoc;


      if (res.response_message != "Failed") {


        this.editQuoteDocs.forEach((item, index) => {
          var sDoc = false;
          this.fileType = item.DocFileName.split(".");
          this.fileType = this.fileType[this.fileType.length - 1];
          this.fileType = this.fileType == "pdf" ? "PDF" : "IMG";
          if ((item.DocumentType != "Other" || item.DocumentType != "OTHERS" || item.DocumentType != "Additional_Doc") && item.DocFilePath != '') {
            this.tempDocArray = this.editQuoteDocs;
          }


          if (item.DocumentType == "reg_Card_Front" && item.DocFilePath != '') {
            sDoc = true;
            this.showLoader.reg_card_front = false;
            this.hideImages.reg_card_front = true;
            this.quickquoteinfo.get('reg_Card_FrontFilePath').setValue(this.editQuoteDocs[index].DocFilePath);

            this.quickquoteinfo.get('reg_Card_FrontFileType').setValue(this.fileType);

          }

          if (item.DocumentType == "reg_Card_Back" && item.DocFilePath != '') {
            sDoc = true;

            this.showLoader.reg_card_back = false;
            this.hideImages.reg_card_back = true;
            this.quickquoteinfo.get('reg_Card_BackFilePath').setValue(this.editQuoteDocs[index].DocFilePath);
            this.quickquoteinfo.get('reg_Card_BackFileType').setValue(this.fileType);
          }

          if (item.DocumentType == "emirated_ID_Front" && item.DocFilePath != '') {
            sDoc = true;
            this.showLoader.emirates_Id_front = false;
            this.hideImages.emirates_Id_front = true;
            this.quickquoteinfo.get('emirated_ID_FrontFilePath').setValue(this.editQuoteDocs[index].DocFilePath);
            this.quickquoteinfo.get('emirated_ID_FrontFileType').setValue(this.fileType);
          }

          if (item.DocumentType == "emirated_ID_Back" && item.DocFilePath != '') {
            sDoc = true;
            this.showLoader.emirates_Id_back = false;
            this.hideImages.emirates_Id_back = true;
            this.quickquoteinfo.get('emirated_ID_BackFilePath').setValue(this.editQuoteDocs[index].DocFilePath);
            this.quickquoteinfo.get('emirated_ID_BackFileType').setValue(this.fileType);
          }

          if (item.DocumentType == "driving_Lic_Front" && item.DocFilePath != '') {
            sDoc = true;
            this.showLoader.driving_Lic_front = false;
            this.hideImages.driving_Lic_front = true;
            this.quickquoteinfo.get('driving_Lic_FrontFilePath').setValue(this.editQuoteDocs[index].DocFilePath);
            this.quickquoteinfo.get('driving_Lic_FrontFileType').setValue(this.fileType);
          }

          if (item.DocumentType == "driving_Lic_Back" && item.DocFilePath != '') {
            sDoc = true;
            this.showLoader.driving_Lic_back = false;
            this.hideImages.driving_Lic_back = true;
            this.quickquoteinfo.get('driving_Lic_BackFilePath').setValue(this.editQuoteDocs[index].DocFilePath);
            this.quickquoteinfo.get('driving_Lic_BackFileType').setValue(this.fileType);

          }

          if (item.DocumentType == "trade_Licence" && item.DocFilePath != '') {
            sDoc = true;
            this.showLoader.trade_Licence = false;
            this.hideImages.trade_Licence = true;
            this.quickquoteinfo.get('trade_LicenceFilePath').setValue(this.editQuoteDocs[index].DocFilePath);
            this.quickquoteinfo.get('trade_LicenceFileType').setValue(this.fileType);

          }

          if (item.DocumentType == "TRN_Certificate" && item.DocFilePath != '') {
            sDoc = true;
            this.showLoader.TRN_Certificate = false;
            this.hideImages.TRN_Certificate = true;
            this.quickquoteinfo.get('TRN_CertificateFilePath').setValue(this.editQuoteDocs[index].DocFilePath);
            this.quickquoteinfo.get('TRN_CertificateFileType').setValue(this.fileType);

          }


          if ((item.DocumentType == "Other" || sDoc == false) && item.DocFilePath != '') {
            this.showLoader.multipleDoc = false;
            this.hideImages.multipleDoc = true;

            this.multilpleFile = this.editQuoteDocs;

            //  this.multilpleFile.push(item);

            this.tempMultipleDocData = this.multilpleFile;

            this.multilpleFile.forEach((item1, index1) => {
              let fileType = this.multilpleFile[index1].DocFileName.split(".");
              fileType = fileType[fileType.length - 1];
              fileType = fileType == "pdf" ? "PDF" : "IMG";
              this.multilpleFile[index1].file = this.multilpleFile[index1].DocFilePath;
              this.multilpleFile[index1].fileType = fileType;

            });
          }

          if (item.DocumentType == "Additional_Doc" && item.DocFilePath != '') {    //&& item.UploadedStage == "QUOTE_ADDINFO"
            this.showLoader.additionalDoc = false;
            this.hideImages.additionalDoc = true;

            this.additionalDocFile = this.editQuoteDocs;
            //
            this.additionalDocFile.forEach((item1, index1) => {

              let fileType = this.additionalDocFile[index1].DocFileName.split(".");
              fileType = fileType[fileType.length - 1];
              fileType = fileType == "pdf" ? "PDF" : "IMG";
              this.additionalDocFile[index1].file = this.additionalDocFile[index1].DocFilePath;
              this.additionalDocFile[index1].fileType = fileType;

            });

            this.additionalDocFile.push(item);
          }

        });

      }
    });
  }


  getdetailsbySearch() {
    if (this.Search_vehicle.invalid) {
      Swal.fire("", "Please enter mandatory data", 'warning');
    }
    else {
      let data = {
        chasisNo: this.Search_vehicle.value.chassis_no,
        RegTcNo: this.Search_vehicle.value.reg_tc_no,
        LicNo: this.Search_vehicle.value.license_no,
        PartnerID: this.partnerId
      }
      this.motorQuoteService.getDetailsBySearch(data).subscribe(async res => {
        if (res.response_code == 2) {
          this.quickquoteinfo.get("chassisno").setValue(this.Search_vehicle.value.chassis_no);
          this.validateChassisNum(this.Search_vehicle.value.chassis_no, this.stepper, 1)
        
        } 
        else {
          let resdata = res.vechileData[0];
          this.quoteDetail = resdata;
          let resData = resdata; // to - do
        }
        this.close();
      });
    }
  }

  getRrepairTypeOnLoad(repairTypeName) {


    let RepairData = {
      vhclBodyType: this.quickquoteinfo.value.bodytype,
      partnerid: this.partnerId,
      schemecode: this.sideForm.value.schemeCode,
      vhclModelYr: this.quickquoteinfo.value.m_year,
      vhclMake: this.quickquoteinfo.value.v_make,
      vhclModel: this.quickquoteinfo.value.v_model,
      insuredType: this.quickquoteinfo.value.adtnl_detail_vhclOwnBy.viewValue,
      engine: this.quickquoteinfo.value.adtnl_detail_engine.Name,
      webQuoteNumber: this.webQuoteNumber,
      age: this.vehicle_age
    }

    this.motorQuoteService
      .getRrepairType(
        RepairData
      )
      .subscribe((res) => {


        let response = res;
        this.repairs = response.Data;
        this.repairtypes = this.repairs


        if (this.repairs.length == 1) {

          this.quickquoteinfo.get('agencyrepair').setValue(this.repairs[0]);
          return true;
        }
        if (true) {
          var indRepairType = -1;
          this.repairs.forEach((item, index) => {
            if (item.RepairType.toLowerCase() == repairTypeName.toLowerCase()) {
              indRepairType = index;
            }
          });
          if (indRepairType > -1) {
            this.quickquoteinfo.get('agencyrepair').setValue(this.repairs[indRepairType]);
          }
          else {
            this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
          }



        }

        if (this.repairtypes.length == 1) this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
      });
  }
  getRrepairType() {

    if (!this.isRepiarTypeCall) return false;
    let RepairData = {
      vhclBodyType: this.quickquoteinfo.value.bodytype,
      partnerid: this.partnerId,
      schemecode: this.sideForm.value.schemeCode,
      vhclModelYr: this.quickquoteinfo.value.m_year,
      vhclMake: this.quickquoteinfo.value.v_make,
      vhclModel: this.quickquoteinfo.value.v_model,
      insuredType: this.quickquoteinfo.value.adtnl_detail_vhclOwnBy.viewValue,
      engine: this.quickquoteinfo.value.adtnl_detail_engine.Name,
      webQuoteNumber: this.webQuoteNumber,
      age: this.vehicle_age
    }
    var p = new Date(this.quickquoteinfo.value.SDate);
    let policyStartDateYear: number = p.getFullYear();

    let vhclAge = this.vehicle_age;

    this.motorQuoteService
      .getRrepairType(
        RepairData
      )
      .subscribe((res) => {


        let response = res;
        this.repairs = response.Data;
        this.repairtypes = this.repairs

        this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes);
        if (this.retrieve_repair_type != '') {
          var indRepairType;
          this.repairtypes.forEach((item, index) => {
            if (item.RepairType.toLowerCase() == this.quoteDetail.RepairType.toLowerCase()) {
              indRepairType = item;
            }
          });
          if (indRepairType) {
            this.quickquoteinfo.get('agencyrepair').setValue(indRepairType);
          }
          else {
            this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
          }



        }

        if (this.repairtypes.length == 1) this.quickquoteinfo.get('agencyrepair').setValue(this.repairtypes[0]);
      });
  }

  onSelectionChange(event, selectedId) {

    this.getAllData = event.source.value;
    this.id = selectedId;


    this.quickQuoteService.getAllData(this.id).subscribe(res => {
      this.close();
      let resdata = res.response_data;
      this.quoteDetail = resdata;
      this.quoteDetail.VehicleMake = resdata.VehicleMake;
      this.quoteDetail.VehicleModel = resdata.VehicleModel;
      this.quoteDetail.TrimCode = resdata.TrimCode;
      this.quoteDetail.TrimName = resdata.VehicleTrim;
      this.quoteDetail.BodyType = resdata.BodyType;
      let resData = res.response_data;

      this.isClickChassisValidate = true;
      // this.quickquoteinfo.get('chassisno').setValue(resData.ChassisNumber);

      // Model Year Binding 
      this.vehicalmodelyears = [];
      this.vehicalmodelyears.push({ value: resData.ModelYear.toString(), label: resData.ModelYear.toString() });
      this.quickquoteinfo.get("m_year").setValue(this.vehicalmodelyears[0]);

      // this.regMinDate = new Date(resData.ModelYear - 2, 0, 1);


      // let currDate = new Date();
      // if (resData.VehicleModelYear + 2 >= currDate.getFullYear()) {
      //   this.regMaxDate = new Date();

      // } else
      //   this.regMaxDate = new Date(resData.VehicleModelYear + 2, 11, 31);
      // Vehicle Make Binding 
      this.vhclMakeArr = [];
      this.vhclMakeArr.push({
        VehicleMakeId: 1,
        VehicleMakeName: resData.VehicleMake,
        Active: true,
        IsReferral: 0,
        CRS_VEH_CODE: 1
      });
      this.quickquoteinfo.get("v_make").setValue(this.vhclMakeArr[0]);


      // Vehicle Model Binding 
      this.vhclModelArr = [];
      this.vhclModelArr.push({
        VehicleModelId: 1,
        VehicleModelName: resData.VehicleModel,
        Active: true,
        SeatingCapacityExDriver: 0,
        BodyTypeId: 1,
        CRS_MODEL_CODE: 1,
        EDATA_MODEL_CODE: "No"
      });
      this.quickquoteinfo.get("v_model").setValue(this.vhclModelArr[0]);


      // Vehicle Body Type Binding 
      this.vhclBodyTypeArr = [];
      this.vhclBodyTypeArr.push({ id: 1, BodyTypeName: resData.BodyType });
      this.quickquoteinfo.get("bodytype").setValue(this.vhclBodyTypeArr[0].BodyTypeName);


      // Vehicle Trim Binding 
      this.vehitrims = [];
      this.vehitrims.push({ Name: resData.VehicleTrim });
      this.quickquoteinfo.get("v_specification").setValue(this.vehitrims[0]);


      // Vehicle Engine Binding 
      let engineData = resData.EngineSize;
      this.engineList = [{ Name: engineData, Code: engineData, Cylinders: engineData, Passengers: 4 }];
      this.quickquoteinfo.get('adtnl_detail_engine').setValue(this.engineList[0]);

      // Vehicle Cylinders Binding 
      this.vehicylinders = [{ Id: 1, CylinderName: resData.EngineCylinders, CylinderCode: "2" }];
      this.quickquoteinfo.get("cylinder").setValue(this.vehicylinders[0]);


      // Vehicle Number Of Passenger Binding 
      this.vehiseatcaps = [{ value: 1, viewValue: resData.NoOfSeats }];
      this.quickquoteinfo.get("capacity").setValue(this.vehiseatcaps[0].viewValue);

      // Vehicle Number Of Passenger Binding 
      this.vehiseatcaps = [{ value: 1, viewValue: resData.PassengerCount }];
      this.quickquoteinfo.get("capacity").setValue(this.vehiseatcaps[0].viewValue);



      this.quickquoteinfo.get("v_value").setValue(resData.SumInsured);
      this.vehicleValueLimit.startLimit = resData.ValuationHigh;
      this.vehicleValueLimit.mediumLimit = res.Valuation.Medium;
      this.vehicleValueLimit.endLimit = resData.ValuationLow;
      this.quickquoteinfo.get('v_value').setValidators([Validators.required, Validators.min(this.vehicleValueLimit.startLimit), Validators.max(this.vehicleValueLimit.endLimit)]);
      this.quickquoteinfo.get('v_value').updateValueAndValidity();

      this.Search_vehicle.reset();
      this.FilterVehicleData = [];
      this.isClickChassisValidate = false;


    })
  }
  isClickChassisValidate = false;
  validateChassisNum(chassisNo, stepper, type) {
   

    
    const schemesTPL = ["66A", "66RK", "66S", "66Q","60D"];
    if (schemesTPL.includes(this.sideForm.value.schemeCode)) return false;

     //this.validChassisNum = true;
    if (!this.isUpdateValuation) { this.isUpdateValuation = true; return false; }
    if (chassisNo == '' || chassisNo.length < this.chassisMin || chassisNo.length > this.chassisMax) {

      this.showLoader.chasisNoButton = false;
      this.quickquoteinfo.get('v_make').setValue('');
      this.quickquoteinfo.get('m_year').setValue('');
      //   this.quickquoteinfo.get('capacity').setValue('');
      //  this.quickquoteinfo.get('adtnl_detail_gccSpecified').setValue('');
      this.quickquoteinfo.get('v_model').setValue('');
      this.quickquoteinfo.get('v_specification').setValue('');
      this.quickquoteinfo.get('bodytype').setValue('');
      this.quickquoteinfo.get('cylinder').setValue('');
      this.quickquoteinfo.get('v_value').setValue('');
      this.quickquoteinfo.get('adtnl_detail_engine').setValue('');
  
  
      //this.blankChassis = true;
       return false;
    }
    // this.blankChassis = false;
    this.showLoader.chasisNoButton = true;
  
    this.motorQuoteService.validateChassisNumber(chassisNo, this.partnerId, this.userId, this.sideForm.value.schemeCode, "N").subscribe(res => {
  
      let validateRes = res;
      this.quickquoteinfo.get('v_make').setValue('');
      this.quickquoteinfo.get('m_year').setValue('');
      //   this.quickquoteinfo.get('capacity').setValue('');
      //  this.quickquoteinfo.get('adtnl_detail_gccSpecified').setValue('');
      this.quickquoteinfo.get('v_model').setValue('');
      this.quickquoteinfo.get('v_specification').setValue('');
      this.quickquoteinfo.get('bodytype').setValue('');
      this.quickquoteinfo.get('cylinder').setValue('');
      this.quickquoteinfo.get('v_value').setValue('');
      this.quickquoteinfo.get('adtnl_detail_engine').setValue('');
  
  
      if (validateRes.validateChassisNumber != 'BOR') this.showBor = false; // at start make it false
  
      if (this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName == 'THIRD PARTY LIABILITY') this.showLoader.chasisNoButton = false;
      if (validateRes.validateChassisNumber == 'W') {
        Swal.fire(validateRes.validateChassisMessage);
        this.showLoader.chasisNoButton = false;
        this.quickquoteinfo.get('isChassisValidate').setValue('');
        this.quickquoteinfo.get('chassisno').setValue('');
        return false;
      }
  
      else if(validateRes.validateChassisNumber == 'E') {
        Swal.fire(validateRes.validateChassisMessage);
        this.quickquoteinfo.get('chassisno').setValue('');
        return false;
      }
      else if (validateRes.validateChassisNumber == 'A' || validateRes.validateChassisNumber == 'BOR') {
        // if (validateRes.validateChassisNumber == 'BOR') {
        //   stepper.previous();
        //   Swal.fire(validateRes.validateChassisMessage);
        //   this.showBor = true;
        // }
        this.showLoader.chasisNoButton = false;
        const schemes = ["65S", "65Q4", "66S", "65RK", "66RK", " 66Q"];
        let event = this.sideForm.value.schemeCode;
     
        if (this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName != 'THIRD PARTY LIABILITY' && !schemesTPL.includes(this.sideForm.value.schemeCode))
          this.motorQuoteService.getDetailsByVIN(chassisNo, this.sideForm.value.schemeCode, 0, this.quickquoteinfo.value.adtnl_detail_brandNew).subscribe(async res => {
      
            this.showLoader.chasisNoButton = false;
            /**  if scheme code block edata  */
            this.isHideChassisNo = false;
            this.milageData = res?.vechileData?.VehicleDetails?.EstimatedMileage;
            this.color = res?.vechileData?.VehicleDetails?.General?.ColourEN;
            this.noOfSeats = Number(res?.vechileData?.VehicleDetails?.General?.NoOfSeats);
            this.noOfDoors = res?.vechileData?.VehicleDetails?.General?.NoOfDoors;
            // this.region = res.vechileData.VehicleDetails.General.Region
            if (res.response_code == 0 && res.access.ParameterValue == "NO") {
              this.isHideChassisNo = true;
  
              this.quickquoteinfo.get('v_make').setValue('');
              this.quickquoteinfo.get('m_year').setValue('');
              //   this.quickquoteinfo.get('capacity').setValue('');
              //  this.quickquoteinfo.get('adtnl_detail_gccSpecified').setValue('');
              this.quickquoteinfo.get('v_model').setValue('');
              this.quickquoteinfo.get('v_specification').setValue('');
              this.quickquoteinfo.get('bodytype').setValue('');
              this.quickquoteinfo.get('cylinder').setValue('');
              this.quickquoteinfo.get('v_value').setValue('');
              return false;
            }
  
  
            if (res.response_code == 5) {
              this.isHideChassisNo = false;
  
              this.quickquoteinfo.get('v_make').setValue('');
              this.quickquoteinfo.get('m_year').setValue('');
              //   this.quickquoteinfo.get('capacity').setValue('');
              //  this.quickquoteinfo.get('adtnl_detail_gccSpecified').setValue('');
              this.quickquoteinfo.get('v_model').setValue('');
              this.quickquoteinfo.get('v_specification').setValue('');
              this.quickquoteinfo.get('bodytype').setValue('');
              this.quickquoteinfo.get('cylinder').setValue('');
              this.quickquoteinfo.get('v_value').setValue('');
              this.quickquoteinfo.get('chassisno').setValue('');
  
  
              this.modelYearRang();
              Swal.fire(" ", res.response_message, "error");
              return false;
            }
  
            if (res.isEdataCall == "YES")
              this.isClickChassisValidate = true;
            else
              this.isClickChassisValidate = false;
  
  
  
            this.getVechileDetailData = res.vechileData;
            this.chassis_No_Details = res.vechileData.VehicleDetails;
            this.quoteDetail = this.getVechileDetailData;
  
  
            if (res.vechileData.StatusCode == 400 || res.vechileData.StatusCode == 422 || res.vechileData.ExpiresIn == 1200 || res.vechileData.StatusCode == 500) {
              Swal.fire(" ", "Invalid Chassis Number, please verify and try again", "warning");
              if (type == 1) {
                this.vehicalmodelyears = [];
                //   this.quickquoteinfo.get('isChassisValidate').setValue('');
                this.quickquoteinfo.get('v_make').setValue('');
                this.quickquoteinfo.get('m_year').setValue('');
                //   this.quickquoteinfo.get('capacity').setValue('');
                //  this.quickquoteinfo.get('adtnl_detail_gccSpecified').setValue('');
                this.quickquoteinfo.get('v_model').setValue('');
                this.quickquoteinfo.get('v_specification').setValue('');
                this.quickquoteinfo.get('bodytype').setValue('');
                this.quickquoteinfo.get('cylinder').setValue('');
                this.quickquoteinfo.get('v_value').setValue('');
                // this.quickquoteinfo.get('chassisno').setValue('');
              }
            }
            else {
              if (this?.quickquoteinfo?.value?.chassisno != '') {
                this?.quickquoteinfo?.get('isChassisValidate').setValue('1');

                if (this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName == 'THIRD PARTY LIABILITY' || schemesTPL.includes(this.sideForm.value.schemeCode))
                { 
                 this.showLoader.chasisNoButton = false;
                 return false ;
                }
  
                /****  SET Edata Yr , Model , Make , Body , Trim , Engine , Capacity , Pagenger  */
                //JTEJU3FJ1FK081528
  
                // Model Year Binding 
                this.vehicalmodelyears = [];
                this.vehicalmodelyears.push({ value: this.chassis_No_Details.General.ModelYear.toString(), label: this.chassis_No_Details.General.ModelYear.toString() });
                this.quickquoteinfo.get("m_year").setValue(this.vehicalmodelyears[0]);
                console.log(this.quickquoteinfo)
                

                
                // this.regMinDate = new Date(this.chassis_No_Details.General.ModelYear - 2, 0, 1);
  
  
                // let currDate = new Date();
                // if (this.chassis_No_Details.General.ModelYear + 1 >= currDate.getFullYear()) {
                //   this.regMaxDate = new Date();
  
                // } else
                //   this.regMaxDate = new Date(this.chassis_No_Details.General.ModelYear + 2, 11, 31);
                // if (!this.chassis_No_Details.General.ModelYear) {
                  //this.modelYearRang(); this.quickquoteinfo.get('chassisno').setValue('');
                // }
  
                // Vehicle Make Binding 
                this.vhclMakeArr = [];
                this.vhclMakeArr.push({
                  VehicleMakeId: 1,
                  VehicleMakeName: this.chassis_No_Details.General.Make,
                  Active: true,
                  IsReferral: 0,
                  CRS_VEH_CODE: 1
                });
                this.quickquoteinfo.get("v_make").setValue(this.vhclMakeArr[0]);
                
                
                // if (!this.chassis_No_Details.General.Make) {
                  //this.modelYearRang(); 
                  //this.quickquoteinfo.get('chassisno').setValue('');
                // }
  
                // Vehicle Model Binding 
                this.vhclModelArr = [];
                this.vhclModelArr.push({
                  VehicleModelId: 1,
                  VehicleModelName: this.chassis_No_Details.General.Model,
                  Active: true,
                  SeatingCapacityExDriver: 0,
                  BodyTypeId: 1,
                  CRS_MODEL_CODE: 1,
                  EDATA_MODEL_CODE: "No"
                });
                this.quickquoteinfo.get("v_model").setValue(this.vhclModelArr[0]);
                this.showLoader.vhclModel = false;
                
                
                // if (!this.chassis_No_Details.General.Model) {
                  //this.modelYearRang();
                  // this.quickquoteinfo.get('chassisno').setValue('');
  
  
                // }
  
  
                // Vehicle Body Type Binding 
                this.vhclBodyTypeArr = [];
                this.vhclBodyTypeArr.push({ id: 1, BodyTypeName: this.chassis_No_Details.General.BodyType });
                console.log(this.vhclBodyTypeArr);
                this.quickquoteinfo.get("bodytype").setValue(this.vhclBodyTypeArr[0].BodyTypeName);
               // return;
               
                
  
                // Vehicle Trim Binding 
                this.vehitrims = [];
                this.vehitrims.push({ Name: this.chassis_No_Details.General.Trim });
                this.quickquoteinfo.get("v_specification").setValue(this.vehitrims[0]);
                
                if (!this.chassis_No_Details.General.Trim) {
                  //this.modelYearRang();
                  //this.quickquoteinfo.get('chassisno').setValue('');
  
                }
  
  
                // Vehicle Engine Binding 
                let engineData = this.chassis_No_Details.Technical.EngineDisplacementNominal.Value;
                this.engineList = [{ Name: engineData, Code: engineData, Cylinders: engineData, Passengers: 4 }];
                this.quickquoteinfo.get('adtnl_detail_engine').setValue(this.engineList[0]);
  
                if (!this.chassis_No_Details.Technical.EngineDisplacementNominal.Value) {
                  // this.modelYearRang(); this.quickquoteinfo.get('chassisno').setValue('');
  
                }
                  console.log( this.chassis_No_Details.Technical.EngineCylinders);
                // Vehicle Cylinders Binding 
                this.vehicylinders = [{ Id: 1, CylinderName: this.chassis_No_Details.Technical.EngineCylinders, CylinderCode: "2" }];
                this.quickquoteinfo.get("cylinder").setValue(this.vehicylinders[0]);
                if (!this.chassis_No_Details.Technical.EngineCylinders) {
  
                  //  this.modelYearRang(); this.quickquoteinfo.get('chassisno').setValue('');
  
                }
  
                //milage
                if (this.chassis_No_Details.EstimatedMileage != '') {
                  this.milageData = this.chassis_No_Details.EstimatedMileage;
                }
                else {
                  this.milageData = 0;
  
                }
  
  
                // Vehicle Number Of Passenger Binding 
                this.quickquoteinfo.get('capacity').setValue(Number(this.chassis_No_Details.General.NoOfSeats));
                console.log(this.quickquoteinfo);
  
  
                // this.quickquoteinfo.get("capacity").setValue( icnt);
  
  
  
                // TO -DO
  
                // if(res.import.Report.IsGccSpec==0){  res.vechileData.importedData.IsGccSpec==0
                if (this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66Q" || this.sideForm.value.schemeCode == "66RK") {
                  this.GCC.edata = false;
                }
                else {
  
                  this.GCC.edata = true;
                }
  
                if (res?.import?.Report?.IsGccSpec == 0) {
  
                  this.GCC.Yes = true;
                  this.GCC.No = false;
                  this.quickquoteinfo.get("adtnl_detail_gccSpecified").setValue("Yes");
                }
                else {
  
                  this.GCC.Yes = false;
                  this.GCC.No = true;
                  this.quickquoteinfo.get("adtnl_detail_gccSpecified").setValue("No");
                }
  
                //  this.GCC.edata = true ;
              
                this.updateValuation_new();
               
              

                this.onVehiclAgeChange(this.vehicalmodelyears[0]);
  
  
  
                this.isClickChassisValidate = false;
  
                // call one function and send data
  
                this.sendMailOnIncompleteData(res);
  
  
              }
            }
          });
      }
      else if (validateRes.validateChassisNumber == 'D'){
        Swal.fire({
          title: validateRes.validateChassisMessage,
          showDenyButton: true,
          confirmButtonText: 'Ok',
        }).then((result) => {
          if(result.isConfirmed == true){
            this.motorQuoteService.getDetailsByVIN(chassisNo, this.sideForm.value.schemeCode, 0, this.quickquoteinfo.value.adtnl_detail_brandNew).subscribe(async res => {
            
              this.showLoader.chasisNoButton = false;
              /**  if scheme code block edata  */
              this.isHideChassisNo = false;
              this.milageData = res.vechileData.VehicleDetails.EstimatedMileage;
              this.color = res.vechileData.VehicleDetails.General.ColourEN;
              this.noOfSeats = res.vechileData.VehicleDetails.General.NoOfSeats;
              this.noOfDoors = res.vechileData.VehicleDetails.General.NoOfDoors;
              // this.region = res.vechileData.VehicleDetails.General.Region
              if (res.response_code == 0 && res.access.ParameterValue == "NO") {
                this.isHideChassisNo = true;
                this.quickquoteinfo.get('v_make').setValue('');
                this.quickquoteinfo.get('m_year').setValue('');
                this.quickquoteinfo.get('v_model').setValue('');
                this.quickquoteinfo.get('v_specification').setValue('');
                this.quickquoteinfo.get('bodytype').setValue('');
                this.quickquoteinfo.get('cylinder').setValue('');
                this.quickquoteinfo.get('v_value').setValue('');
                return false;
              }
              if (res.response_code == 5) {
                this.isHideChassisNo = false;
                this.quickquoteinfo.get('v_make').setValue('');
                this.quickquoteinfo.get('m_year').setValue('');
                this.quickquoteinfo.get('v_model').setValue('');
                this.quickquoteinfo.get('v_specification').setValue('');
                this.quickquoteinfo.get('bodytype').setValue('');
                this.quickquoteinfo.get('cylinder').setValue('');
                this.quickquoteinfo.get('v_value').setValue('');
                this.quickquoteinfo.get('chassisno').setValue('');
                this.modelYearRang();
                Swal.fire(" ", res.response_message, "error");
                return false;
              }
              if (res.isEdataCall == "YES")
                this.isClickChassisValidate = true;
              else
                this.isClickChassisValidate = false;
              this.getVechileDetailData = res.vechileData;
              this.chassis_No_Details = res.vechileData.VehicleDetails;
              this.quoteDetail = this.getVechileDetailData;
              if (res.vechileData.StatusCode == 400 || res.vechileData.StatusCode == 422 || res.vechileData.ExpiresIn == 1200 || res.vechileData.StatusCode == 500) {
                Swal.fire(" ", "Invalid Chassis Number, please verify and try again", "warning");
                if (type == 1) {
                  this.vehicalmodelyears = [];
                  this.quickquoteinfo.get('v_make').setValue('');
                  this.quickquoteinfo.get('m_year').setValue('');
                  this.quickquoteinfo.get('v_model').setValue('');
                  this.quickquoteinfo.get('v_specification').setValue('');
                  this.quickquoteinfo.get('bodytype').setValue('');
                  this.quickquoteinfo.get('cylinder').setValue('');
                  this.quickquoteinfo.get('v_value').setValue('');
                }
              }
              else {
                if (this.quickquoteinfo.value.chassisno != '') {
                  this.quickquoteinfo.get('isChassisValidate').setValue('1')
                  // Model Year Binding 
                  this.vehicalmodelyears = [];
                  this.vehicalmodelyears.push({ value: this.chassis_No_Details.General.ModelYear.toString(), label: this.chassis_No_Details.General.ModelYear.toString() });
                  this.quickquoteinfo.get("m_year").setValue(this.vehicalmodelyears[0]);
                  // this.regMinDate = new Date(this.chassis_No_Details.General.ModelYear - 2, 0, 1);
  
                  // let currDate = new Date();
                  // if (this.chassis_No_Details.General.ModelYear + 1 >= currDate.getFullYear()) {
                  //   this.regMaxDate = new Date();
                  // } 
                  // else
                  //   this.regMaxDate = new Date(this.chassis_No_Details.General.ModelYear + 2, 11, 31);
                  if (!this.chassis_No_Details.General.ModelYear) {
                  }
  
                  // Vehicle Make Binding 
                  this.vhclMakeArr = [];
                  this.vhclMakeArr.push({
                    VehicleMakeId: 1,
                    VehicleMakeName: this.chassis_No_Details.General.Make,
                    Active: true,
                    IsReferral: 0,
                    CRS_VEH_CODE: 1
                  });
                  this.quickquoteinfo.get("v_make").setValue(this.vhclMakeArr[0]);
                  if (!this.chassis_No_Details.General.Make) {
                  }
  
                  // Vehicle Model Binding 
                  this.vhclModelArr = [];
                  this.vhclModelArr.push({
                    VehicleModelId: 1,
                    VehicleModelName: this.chassis_No_Details.General.Model,
                    Active: true,
                    SeatingCapacityExDriver: 0,
                    BodyTypeId: 1,
                    CRS_MODEL_CODE: 1,
                    EDATA_MODEL_CODE: "No"
                  });
                  this.quickquoteinfo.get("v_model").setValue(this.vhclModelArr[0]);
  
                  if (!this.chassis_No_Details.General.Model) {
                  }
    
                  // Vehicle Body Type Binding 
                  this.vhclBodyTypeArr = [];
                  this.vhclBodyTypeArr.push({ id: 1, BodyTypeName: this.chassis_No_Details.General.BodyType });
                  this.quickquoteinfo.get("bodytype").setValue(this.vhclBodyTypeArr[0].BodyTypeName);
  
                  // Vehicle Trim Binding 
                  this.vehitrims = [];
                  this.vehitrims.push({ Name: this.chassis_No_Details.General.Trim });
                  this.quickquoteinfo.get("v_specification").setValue(this.vehitrims[0]);
                  if (!this.chassis_No_Details.General.Trim) {
                  }
    
                  // Vehicle Engine Binding 
                  let engineData = this.chassis_No_Details.Technical.EngineDisplacementNominal.Value;
                  this.engineList = [{ Name: engineData, Code: engineData, Cylinders: engineData, Passengers: 4 }];
                  this.quickquoteinfo.get('adtnl_detail_engine').setValue(this.engineList[0]);
                  if (!this.chassis_No_Details.Technical.EngineDisplacementNominal.Value) {
                  }
  
                  // Vehicle Cylinders Binding 
                  this.vehicylinders = [{ Id: 1, CylinderName: this.chassis_No_Details.Technical.EngineCylinders, CylinderCode: "2" }];
                  this.quickquoteinfo.get("cylinder").setValue(this.vehicylinders[0]);
                  if (!this.chassis_No_Details.Technical.EngineCylinders) {
  
                    //  this.modelYearRang(); this.quickquoteinfo.get('chassisno').setValue('');
  
                  }
  
                  //milage
                  if (this.chassis_No_Details.EstimatedMileage != '') {
                    this.milageData = this.chassis_No_Details.EstimatedMileage;
                  }
                  else {
                    this.milageData = 0;
  
                  }
  
  
                  // Vehicle Number Of Passenger Binding 
                  if (this.chassis_No_Details.General.NoOfSeats.PassengersCount < 8) {
  
                    let minCount = this.chassis_No_Details.General.NoOfSeats.PassengersCount - 1;
                    let maxCount = Number(this.chassis_No_Details.General.NoOfSeats.PassengersCount) + 2;
  
                    if (maxCount >= 8) maxCount = 8;
                    this.vehiseatcaps = [];
                    if (minCount <= 1) minCount = 2;
                    for (let i = minCount; i <= maxCount; i++) {
                      this.vehiseatcaps.push({ value: i, viewValue: i });
                    }
                  }
                  var indexPasger = this.vehiseatcaps.findIndex(function (obj, k) {
                    return obj.value == this.chassis_No_Details.General.NoOfSeats.PassengersCount;
                  });
                  let PasgerVal = this.vehiseatcaps[indexPasger];
                  this.quickquoteinfo.get('capacity')?.setValue(PasgerVal);
                  // let icnt = 0 ;
                  // if(this.chassis_No_Details.General.NoOfSeats<=8){
                  //   let minCount = this.chassis_No_Details.General.NoOfSeats-1 ;
                  //   let maxCount = Number(this.chassis_No_Details.General.NoOfSeats)+2;
  
                  //   if(maxCount>=8)  maxCount = 8 ;
                  //   this.vehiseatcaps = [];
                  //   for(let i=minCount;i<=maxCount;i++){
                  //     this.vehiseatcaps.push({value	:i , viewValue	: i});
                  //     if(this.chassis_No_Details.General.NoOfSeats==i) 
                  //      icnt=i;
                  //   }
  
                  // }
  
  
                  // this.quickquoteinfo.get("capacity").setValue( icnt);
  
  
  
                  // TO -DO
  
                  // if(res.import.Report.IsGccSpec==0){  res.vechileData.importedData.IsGccSpec==0
                  if (this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66Q" || this.sideForm.value.schemeCode == "66RK") {
                    this.GCC.edata = false;
                  }
                  else {
  
                    this.GCC.edata = true;
                  }
  
                  if (res?.import?.Report?.IsGccSpec == 0) {
  
                    this.GCC.Yes = true;
                    this.GCC.No = false;
                    this.quickquoteinfo.get("adtnl_detail_gccSpecified").setValue("Yes");
                  }
                  else {
  
                    this.GCC.Yes = false;
                    this.GCC.No = true;
                    this.quickquoteinfo.get("adtnl_detail_gccSpecified").setValue("No");
                  }
  
                  //  this.GCC.edata = true ;
                  setTimeout(() => {
                  this.updateValuation_new();
                  },1000);
                  this.onVehiclAgeChange(this.vehicalmodelyears[0]);
  
  
  
                  this.isClickChassisValidate = false;
  
                  // call one function and send data
  
                  this.sendMailOnIncompleteData(res);
  
  
                }
              }
            });
  
          }
          else if(result.isDenied == true){
            this.quickquoteinfo.get('isChassisValidate').setValue('');
          }
        });
  
      }
      else {
        Swal.fire(validateRes.validateChassisMessage);
        // this.chassisStatus=false;
        this.showLoader.chasisNoButton = false;
      }
    });
  }

  GCC = { Yes: false, No: false, edata: false }

  termsAndConditions(type) {
    const dialogRef = this.dialog.open(this.termsandconditions);
    this.policyStatus = type;
    this.getTermsConditions();
  }
  /**************  CreditLimit variables  */
  public creditLimit = { CreditLimit: 0, AvailableLimit: 0 }
  public noCreditLimt = 0;

  public getPartnerCreditLimit() {   // LOB 10 for motor
    setTimeout(() => {
      this.motorQuoteService.partnerCreditLimit(3, this.partnerId, this.sideForm.value.branchID).subscribe(res => {

        if (res.response_message == null) {
          this.noCreditLimt = 0;
          this.creditLimit = { CreditLimit: 0, AvailableLimit: 0 };
        } else {

          this.creditLimit = res.response_message;

          this.noCreditLimt = 0;
        }
      })
    }, 1000);
  }
  getParterLimitOnSelection() {

    this.partnerId = this.sideForm.value.partnerID;
    this.motorQuoteService.partnerCreditLimit(10, this.partnerId, this.sideForm.value.branchID).subscribe(res => {

      if (res.response_message == null) {
        this.noCreditLimt = 0;
        this.creditLimit = { CreditLimit: 0, AvailableLimit: 0 };
      } else {

        this.creditLimit = res.response_message;
        this.noCreditLimt = 1;
      }
    })
  }

  issuePolicyCreditLimitCheck() {
    this.isEditable = false;
    this.partnerId = this.sideForm.value.partnerID;
    this.motorQuoteService.partnerCreditLimit(10, this.partnerId, this.sideForm.value.branchID).subscribe(res => {

      if (res.response_message == null) {
        this.noCreditLimt = 0;
        this.creditLimit = { CreditLimit: 0, AvailableLimit: 0 };
        Swal.fire("Your credit limit seems to be exhausted. Please contact the Credit Control department.", "", "error");
      } else {
        this.creditLimit = res.response_message;
        this.noCreditLimt = 1;
        if (this.creditLimit.AvailableLimit < (((this.totalFixPremium + this.totalVariablePremium) * 0.05) + (this.totalFixPremium + this.totalVariablePremium)))
          Swal.fire("Your credit limit seems to be exhausted. Please contact the Credit Control department.", "", "error");
        else
          this.termsAndConditions("ISSUEPOLICY");
      }
    })
  }

  getTermsConditions() {

    this.showTerms = true;
    this.motorQuoteService.getTermsConditions('B2B').subscribe(res => {
      if (res.response_code == 1) {
        this.showTerms = false;
        this.termsAndCondition = res.termsAndCondition;
      }

    });
  }

  public additionalLoading: number; additionalDiscount: number; loadingByPercent: number;

  //----------------- APPLY DISCOUNT ON PREMIUM WITH VAT ----------------//
  public MaxLDPer: number;
  public MaxLDAmt: number;
  public MaxDSPer: number;
  public MaxDSAmt: number;
  calculateDiscount1(loadingby, loadByAmount, calculationType) {

    //return false ;

    // for  discount
    if (loadingby == 2) {

      if (calculationType == 1 && loadByAmount >= this.MaxDSPer) {       // for percent

        Swal.fire('', 'Invalid percent selected for discount', 'warning');
        return false;
      }
      if (calculationType == 0 && loadByAmount >= this.MaxDSPer) {     // for amount

        Swal.fire('', 'Invalid amount selected for discount', 'warning');
        return false;
      }

    }

    // for loading
    if (loadingby == 1) {
      if (this.businessSource == 'DIRECT') {   // for admin

        if (calculationType == 1 && loadByAmount >= this.MaxDSPer) {       // for percent

          Swal.fire('', 'Invalid percent selected for loading', 'warning');
          return false;
        }
        if (calculationType == 0 && loadByAmount >= this.MaxLDAmt) {     // for amount

          Swal.fire('', 'Invalid amount selected for loading', 'warning');
          return false;
        }
      } else {         // for user

        if (calculationType == 1 && loadByAmount >= this.MaxDSPer) {       // for percent

          Swal.fire('', 'Invalid percent selected for loading', 'warning');
          return false;
        }
        if (calculationType == 0 && loadByAmount >= this.MaxLDAmt) {     // for amount

          Swal.fire('', 'Invalid amount selected for loading', 'warning');
          return false;
        }
      }


    }

    const copy = JSON.parse(JSON.stringify(this.tempBenefitData));

    let base_Primium = copy;

    this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData;

    let Multiple: number;

    if (loadingby == 1) {
      Multiple = 1;
    } else {
      Multiple = -1;
    }

    this.totalFixPremium = this.tempTotalLoadFixPrem;

    let loadingAmt = loadByAmount;

    //let discount:number = Number(this.PlanDataJson.thirdPartyAPIData.NcdDiscount.NcdAmnt);
    let discount: number = 0;
    let policyFee: number = 0;




    if (loadingby == 1) {
      this.additionalLoading = loadingAmt;

    } else {
      this.additionalDiscount = loadingAmt;
    }
    if (loadingby == 1) {
      if (calculationType == 1) {
        this.additionalLoading = Number(this.premium * loadingAmt / 100);
        this.totalFixPremium = Number(Number(this.premium) + Number(this.premium * loadingAmt / 100));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) * this.PlanDataJson.vatPer / 100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData = copy;
      }
      else {

        this.totalFixPremium = Number(Number(this.premium) + Number(loadingAmt));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) * this.PlanDataJson.vatPer / 100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData = copy;

      }

    } else {

      if (calculationType == 1) {
        this.additionalLoading = Number(this.premium * loadingAmt / 100);
        this.totalFixPremium = Number(Number(this.premium) - Number(this.premium * loadingAmt / 100));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) * this.PlanDataJson.vatPer / 100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData = copy;
      }
      else {
        this.additionalLoading = Number(loadingAmt);
        this.totalFixPremium = Number(Number(this.premium) - Number(loadingAmt));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) * this.PlanDataJson.vatPer / 100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData = copy;

      }

    }


  }




  engineDefaultValue = "";
  isUpdateValuation = true;
  engineSizeList() {

    if (this.onRetirveEngineCall == false) {

      this.onRetirveEngineCall = true; return false;
    }


    if (this.isClickChassisValidate == true) {
      this.engineList = [];
      if (this.vehicleData?.Technical?.EngineDisplacementNominal?.Value) {
        let engineData = this.vehicleData.Technical.EngineDisplacementNominal.Value;
        this.engineList = [{ Name: engineData, Code: engineData, Cylinders: this.getVechileDetailData.VehicleDetails.Technical.EngineCylinders, Passengers: 4 }];

        this.quickquoteinfo.get('adtnl_detail_engine').setValue(this.engineList[0]);
      }

      return false;
    }

    this.showLoader.vhclEngine = true;
    this.motorQuoteService.getEngineSizeListQuick(this.quickquoteinfo.value, this.sideForm.value.schemeCode).subscribe(res => {
      this.showLoader.vhclEngine = false;
      if (res.response_message.LookupList == "" || res.response_message.LookupList == null) return false;
      this.engineList = res.response_message.LookupList;
      this.showLoader.vhclEngine = false;




      if (this.vehicleData.length != 0)
        this.engineDefaultValue = this.vehicleData.Technical.EngineDisplacementNominal.Value;

      if (this.quickquoteinfo.value?.adtnl_detail_engine?.Name) {
        let engineValue: any = {};
        res.response_message?.LookupList?.forEach((item, index) => {

          if (this.quickquoteinfo.value?.adtnl_detail_engine?.Name == item.Name) engineValue = item;
        });
        this.quickquoteinfo.get('adtnl_detail_engine').setValue(engineValue);
        this.quickquoteinfo.get('capacity').setValue(engineValue.Passengers);
        this.engineDefaultValue = "";
      }
      if (res.response_message.LookupList.length == 1) {
        this.quickquoteinfo.get('adtnl_detail_engine').setValue(res.response_message.LookupList[0]);
        this.quickquoteinfo.get('capacity').setValue(res.response_message.LookupList[0].Passengers);

      }

    });

  }

  // drog drop

  DragDropfiles(event) {

    this.showLoader.multipleDoc = true;

    this.multilpleFile = [];
    for (var i = 0; i < event.length; i++) {
      this.showLoader.multipleDoc = true;
      const formData = new FormData();
      formData.append('file', event[i].file);
      formData.append('stage', 'QUOTE');
      formData.append('schemeCode', this.sideForm.value.schemeCode);
      this.formDataRes = this.tmpCountryList;
      this.motorQuoteService.uploadMultipleDocuments(formData).subscribe(res => {
        let updateMemResponse = res;
        this.document_data = updateMemResponse.Document_data;
        this.hideImages.multipleDoc = true;

        if (updateMemResponse.res_code == 1) {
          let fileType = updateMemResponse.File.split(".");
          fileType = fileType[fileType.length - 1];
          fileType = fileType == "pdf" ? "PDF" : "IMG";


          this.multilpleFile.push({
            "file": updateMemResponse.FileDir,
            "fileType": fileType,
            'file_name': 'Other',
            'file_dir': updateMemResponse.FileDir,
            'docName': updateMemResponse.File,
          });

          this.tempMultipleDocData = this.multilpleFile;
          this.showLoader.multipleDoc = false;
          this.document_data.forEach((item, index) => {
            if (item.ErroCode == 'Null') {
              if (item.DocumentType == 'Emirates-Id' && item.DocumentSubType == 'Front') {

                this.getEmiratesIdData(1, item);
              }
              else if (item.DocumentType == 'Emirates-Id' && item.DocumentSubType == 'Back') {

                this.getEmiratesIdData(2, item);
              }
              else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Front') {

                this.getDrivingLicData(1, item);
              }
              else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Back') {

                this.getDrivingLicData(2, item);
              }
              else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Back') {

                this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
                this.getRegCardData(1, item);

              }
              else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Front') {

                this.getRegCardData(2, item);
              }
              else if (item.DocumentType == 'Vehicle License' && item.DocumentSubType == 'Both') {
                this.getRegCardData(2, item);
                this.vehicleData = updateMemResponse.vechile_data.VehicleDetails;
                this.getRegCardData(1, item);
              }
              else if (item.DocumentType == 'Driving License' && item.DocumentSubType == 'Both') {
                this.getDrivingLicData(2, item);
                this.getDrivingLicData(1, item);
              }
              else if (item.DocumentType == 'Emirates-Id' && item.DocumentSubType == 'Both') {
                this.getEmiratesIdData(2, item);
                this.getEmiratesIdData(1, item);
              }
            }
          });
        }
        if (updateMemResponse.response_code == 5) {

          this.showLoader.multipleDoc = false;

          Swal.fire("Please select valid file format.", "only .pdf, .jpg, .png and .jpeg file formats allowed.", 'warning');

        }

        if (updateMemResponse.response_code == 6) {

          this.showLoader.multipleDoc = false;

          Swal.fire(updateMemResponse.response_status);
        }
      });
    }
  }

  accountChange() {

    let branch = this.sideForm.value.branchID;

    this.sideForm.get("Accounting").setValue(branch);
    this.getPartnerCreditLimit();
  }

  modelYearRang() {
    // return false ;
    let currentYear = new Date().getFullYear();
    let currentMonth = new Date().getMonth() + 1;
    let maxYear = currentYear;
    let minYear = currentYear - 12;
    if (currentMonth >= 8) {

      maxYear = ++currentYear;
    }
    let yr = '';
    if (this.quickquoteinfo?.value.m_year)
      yr = this.quickquoteinfo.value.m_year;
    else
      yr = '';
    if (this.quickquoteinfo?.value?.adtnl_detail_insType) {


      if ("THIRD PARTY LIABILITY" == this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName) minYear = currentYear + 1 - 30;
      else if (this.sideForm.value.schemeCode == "60D" || this.sideForm.value.schemeCode == "64F") minYear = currentYear + 1 - 20;
      else minYear = currentYear + 1 - 12;
    } else {

      minYear = currentYear + 1 - 20;
    }
    this.vehicalmodelyears = [];
    let yrIndex = 0;
    for (let i = maxYear; i >= minYear; i--) {
      this.vehicalmodelyears.push({ value: i.toString(), label: i.toString() });
      if (this.quickquoteinfo.value.m_year.label == i) yrIndex = this.vehicalmodelyears.length - 1;

    }
    if (this.quickquoteinfo?.value?.m_year)
      this.quickquoteinfo.get("m_year").setValue(this.vehicalmodelyears[yrIndex]);



  }

  openModal() {
    const dialogRef = this.dialog.open(this.referaquote);

  }
  popupTitle = "";
  getReferalCondtion(ref_val) {
    const dialogRef = this.dialog.open(this.referaquote);
    this.referalModel = true;
    if (ref_val == 'APPROVED') {
      this.popupTitle = "Approve a Quote";
      this.refer_type = 'Approve';
      this.refer_condtion_type = 3;
    }
    if (ref_val == 'REJECTED') {
      this.popupTitle = "Reject a Quote";
      this.refer_type = 'Reject';
      this.refer_condtion_type = 4;
    }
    if (ref_val == 'REFERRAL') {
      this.popupTitle = "Refer a Quote";
      this.refer_type = 'Refer';
      this.refer_condtion_type = 2;
    }
    if (ref_val == 'ADDITIONALINFO') {
      this.popupTitle = "Additional info ";
      this.refer_type = 'Additional Info';
      this.refer_condtion_type = 5;
    }
    //   if(ref_val == 'CONFIRM'){ this.popupTitle = "Confirm a quote "; 
    //   this.refer_type = 'Confirm';
    //   this.refer_condtion_type = 7;
    // }



    // if(this.webQuoteNumber ==''){
    //   this.getQuotation('',2);
    // }

  }

  checkIscheassisBlank(event) {


    if (event != '' && this.sideForm.value.schemeCode == "60D") {
      this.GCC.edata = false;
    }
    if (event == " ") {
      this.modelYearRang();
    }
    if ((event == " ") && (this.sideForm.value.schemeCode == "66A" || this.sideForm.value.schemeCode == "66S" || this.sideForm.value.schemeCode == "66Q" || this.sideForm.value.schemeCode == "66RK")) {

      this.GCC.edata = false;
    }
    else {
      this.GCC.edata = false;
    }
  }

  checkTPLCompresive(event) {
    if (event.ProductShortName == "THIRD PARTY LIABILITY") {
  
      this.quickquoteinfo.get('v_value').setValue(0);
      this.quickquoteinfo.get('v_value').setValidators([]);
      this.quickquoteinfo.get('v_value').updateValueAndValidity()
      this.quickquoteinfo.get('agencyrepair').setValidators([]);
      this.quickquoteinfo.get('agencyrepair').updateValueAndValidity()
    }
  }

  callChangeStepper(event: any, stepper) {
    if (event.selectedIndex == 0) {
      this.disabledStatus = false;
    }
  }

 

  getTonnageData(event) {

    console.log(event);
    if (!this.isTonnageCall) return false;
    this.checkIsSchmeForHeavyVeh();

    if(this.sideForm.value.schemeCode!="60D" && this.sideForm.value.schemeCode!="66A") return false ;

    let partnerId = this.sideForm.value.partnerID;


    let bodyCode = "";
    this.vhclBodyTypeArr.forEach(element => {

      if (element.BodyTypeName == this.quickquoteinfo.value.bodytype) bodyCode = element.BodyTypeCode;

    });

 

    let attribute = {
      InsuredType: this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName,
      VehicleMakeName: this.quickquoteinfo.value.v_make.VehicleMakeName,
      VehicleModelName: this.quickquoteinfo.value.v_model.VehicleModelName,
      ModelYear: this.quickquoteinfo.value.m_year.label,
      LanguageCode: "ENG",
      SchemeCode: this.sideForm.value.schemeCode,
      BodyTypeName: event,
      BodyTypeCode: bodyCode,
    }

    this.motorQuoteService.getTonnage(partnerId, attribute).subscribe(res => {

      this.quickquoteinfo.get("loading_capacity")?.setValue(res?.tonnageData[0]?.VehicleTonnage);
      // this.quickquoteinfo.controls['loading_capacity'].disable();

      // Vehicle Number Of Passenger Binding 
      this.vehiseatcaps = [];
      res.tonnageData.forEach((element) => {
        this.vehiseatcaps.push({ value: 1, viewValue: element.SeatingCapacityExDriver });
      })

      this.quickquoteinfo.get("capacity")?.setValue(this?.vehiseatcaps[0]?.viewValue);
      // this.quickquoteinfo.get("capacity")?.setValue(res.tonnageData[0].SeatingCapacityExDriver.toString());

    });

  }
  image: any;
  openImgDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog);
    dialogRef.afterClosed().subscribe((result) => { });

    this.image = img;
  }

  targetFile = '';
  onBORUpload(event, docName, FiledName, files: FileList) {

    this.docNameType = FiledName;
    //  this.showLoader.bor_card=true;
    const formData = new FormData();

    this.targetFile = event.target.files[0];

    formData.append('file', event.target.files[0]);
    formData.append('docName', docName);
    formData.append('source', 'B2B');
    formData.append('stage', 'QUOTE');
    formData.append('schemeCode', this.sideForm.value.schemeCode);

    this.bor_formData = formData;

    this.refer_type = 'BORQUOTE';
    this.refer_condtion_type = 6;
  }

  submitBOR() {


    if (this.quickquoteinfo.invalid) {
      this.motorQuoteService.uploadBOR(this.bor_formData).subscribe(res => {

        if (res.response_message == 'Success') {

          this.sendRefferMailToAdmin(6);

          this.motorQuoteService.proc_bor(this.quickquoteinfo.value.chassisno, this.webQuoteNumber).subscribe(res => {


          });

          this.showLoader.bor_card = false;

          this._router.navigate(['dashboards/project']);

          Swal.fire("BOR has been submitted for approval. Should you require any clarification please contact your relationship manager. ");

        }

      });
    }
  }

  submitAdditionalDocs() {
    if (this.quickquoteinfo.status == 'INVALID') {
      this.showLoader.bor_card = true;
      this.motorQuoteService.uploadBOR(this.bor_formData).subscribe(res => {
        this.showLoader.bor_card = false;
        this.hideImages.additionalDoc = true;
        this.quickquoteinfo.get('additional_DocumentFilePath')?.setValue(res.FileDir);
        this.saveQuatationData();
      });
    } else {
      Swal.fire('', 'Please fill all the mandatory data', 'warning');
    }
  }

  checkIsBorOrAddtionInfo() {

    if (this.quoteStatus == 'ADDITIONALINFO') {

      this.quickquoteinfo.get('additional_DocumentFilePath')?.setValidators([Validators.required]);
      this.quickquoteinfo.get('additional_DocumentFilePath')?.updateValueAndValidity()

    }




  }

  /******* If scheme TPL and 60d 60a then hide and  remove validation */

  hideRemoveEng = false;
  hideRemoveTrim = false;

  checkEngineValidation() {

    if (this.sideForm.value.schemeCode.length != 0) {

      const schemesTPL = ["66Q", "66S", "66RK", "66Q"];
      const schemes = ["65S", "65Q4", "65RK", "60A-MR", "64F"];
      const schemesHVeh = ["60D", "66A", "64F"];

      if (schemes.includes(this.sideForm.value.schemeCode) || schemesTPL.includes(this.sideForm.value.schemeCode)) {

        this.quickquoteinfo.get('adtnl_detail_engine')?.setValidators([Validators.required]);
        this.quickquoteinfo.get('adtnl_detail_engine')?.updateValueAndValidity();
        this.hideRemoveEng = false;

      }
      else {

        this.quickquoteinfo.get('adtnl_detail_engine')?.setValidators(null);
        this.quickquoteinfo.get('adtnl_detail_engine')?.updateValueAndValidity();
        this.hideRemoveEng = true;

      }

    } else {

      setTimeout(() => {

        this.checkEngineValidation();

      }, 100);
    }

  }

  checkTrimValidation() {

    const schemes = ["65S", "65Q4", "65RK", "60A-MR", "64F"];
    const schemesTPL = ["66Q", "66S", "66A", "66RK"];

    if (schemes.includes(this.sideForm.value.schemeCode)) {
      this.quickquoteinfo.get('v_specification')?.setValidators([Validators.required]);
      this.quickquoteinfo.get('v_specification')?.updateValueAndValidity();
      this.hideRemoveTrim = false;
    }
    else if (schemesTPL.includes(this.sideForm.value.schemeCode)) {
      this.quickquoteinfo.get('v_specification').setValidators(null);
      this.quickquoteinfo.get('v_specification').updateValueAndValidity();
      this.hideRemoveTrim = true;
    }
    else {
      this.quickquoteinfo.get('v_specification')?.setValidators(null);
      this.quickquoteinfo.get('v_specification')?.updateValueAndValidity();
      this.hideRemoveTrim = true;

    }


  }

  //----------------- APPLY DISCOUNT ON PREMIUM WITH VAT ----------------//
  calculateDiscount(loadingby, loadByAmount, calculationType) {
    let isValid = true;
    // for  discount
    if (loadingby == 2) {

      if (calculationType == 1 && loadByAmount > this.MaxDSPer) {       // for percent

        Swal.fire('', 'Invalid percent selected for discount', 'warning');
        this.loadByAmount = 0;
        this.additionalLoading = 0;
        loadingby = 0;
        isValid = false;
        //    return false;
      }
      if (calculationType == 0 && loadByAmount > this.MaxDSAmt) {     // for amount

        Swal.fire('', 'Invalid amount selected for discount', 'warning');
        this.loadByAmount = 0;
        this.additionalLoading = 0;
        loadingby = 0;
        isValid = false;
        //   return false;
      }

    }

    // for loading
    if (loadingby == 1) {
      if (this.businessSource == 'DIRECT') {   // for admin

        if (calculationType == 1 && loadByAmount > this.MaxLDPer) {       // for percent

          Swal.fire('', 'Invalid percent selected for loading', 'warning');
          this.loadByAmount = 0;
          this.additionalLoading = 0;
          loadingby = 0;
          isValid = false;
          // return false;
        }
        if (calculationType == 0 && loadByAmount > this.MaxLDAmt) {     // for amount

          Swal.fire('', 'Invalid amount selected for loading', 'warning');
          this.loadByAmount = 0;
          this.additionalLoading = 0;
          loadingby = 0;
          isValid = false;
          // return false;
        }
      } else {         // for user

        if (calculationType == 1 && loadByAmount > this.MaxLDPer) {       // for percent

          Swal.fire('', 'Invalid percent selected for loading', 'warning');
          this.loadByAmount = 0;
          this.additionalLoading = 0;
          loadingby = 0;
          isValid = false;
          //   return false;
        }
        if (calculationType == 0 && loadByAmount > this.MaxLDAmt) {     // for amount

          Swal.fire('', 'Invalid amount selected for loading', 'warning');
          this.loadByAmount = 0;
          this.additionalLoading = 0;
          loadingby = 0;
          isValid = false;
          // return false;
        }
      }


    }

    const copy = JSON.parse(JSON.stringify(this.tempBenefitData));

    let base_Primium = copy;

    this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData;

    let Multiple: number;

    if (loadingby == 1) {
      Multiple = 1;
    } else {
      Multiple = -1;
    }

    this.totalFixPremium = this.tempTotalLoadFixPrem;

    let loadingAmt = 0;
    if (isValid)
      loadingAmt = loadByAmount;
    else
      loadingAmt = 0;

    //let discount:number = Number(this.PlanDataJson.thirdPartyAPIData.NcdDiscount.NcdAmnt);
    let discount: number = 0;
    let policyFee: number = 0;

    this.tempBenefitData.forEach((item, index) => {
      if (this.quickquoteinfo.value.adtnl_detail_insType.value == 200 && item.Code == '40099') {
        //get policy fee
        policyFee = item.premium;
      }
    });


    if (loadingby == 1) {
      this.additionalLoading = loadingAmt;

    } else {
      this.additionalDiscount = loadingAmt;
    }
    if (loadingby == 1) {
      if (calculationType == 1) {
        this.additionalLoading = Number(this.premium * loadingAmt / 100);
        this.totalFixPremium = Number(Number(this.premium) + Number(this.premium * loadingAmt / 100));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) * this.PlanDataJson.vatPer / 100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData = copy;
      }
      else {

        this.totalFixPremium = Number(Number(this.premium) + Number(loadingAmt));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) * this.PlanDataJson.vatPer / 100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData = copy;

      }

    } else {

      if (calculationType == 1) {
        this.additionalLoading = Number(this.premium * loadingAmt / 100);
        this.totalFixPremium = Number(Number(this.premium) - Number(this.premium * loadingAmt / 100));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) * this.PlanDataJson.vatPer / 100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData = copy;
      }
      else {
        this.additionalLoading = Number(loadingAmt);
        this.totalFixPremium = Number(Number(this.premium) - Number(loadingAmt));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) * this.PlanDataJson.vatPer / 100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData = copy;

      }

    }


  }

  callWhenTPL(event) {
    const schemes = ["65S", "65Q4", "65RK", "64F"];
    if (schemes.includes(this.sideForm.value.schemeCode)) {
    }
    else {
      this.engineSizeList();
    }
  }

  sendMailOnIncompleteData(res) { }

  // set regType
  getPlateCategory() {
    if (this.quickquoteinfo?.value?.adtnl_detail_vhclOwnBy?.viewValue && this.quickquoteinfo.value?.r_place?.CityName) {
      let data = {
        language_code: this.language_code,
        policy_type: this.quickquoteinfo.value.adtnl_detail_vhclOwnBy.viewValue,
        reg_place: this.quickquoteinfo.value.r_place.CityName,
        cover_type: this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName
      }
      this.motorQuoteService.getPlateCategory(data).subscribe(res => {
        this.regType = res.plateCodeData;
        //this.filterPlateCat();
      });
    }
  }

  getPlateCategoryEdit(regPlace, PlaceValue) {
    let data = {
      language_code: this.language_code,
      policy_type: this.quickquoteinfo.value.adtnl_detail_vhclOwnBy.viewValue,
      reg_place: regPlace,
      cover_type: this.quickquoteinfo.value.adtnl_detail_insType.ProductShortName
    }
    this.motorQuoteService.getPlateCategory(data).subscribe(res => {
      this.regType = res.plateCodeData;
      this.regType?.forEach((elem, index) => {
        if (PlaceValue == elem.PlateCategotyName) {
          this.quickquoteinfo.get("rg_type").setValue(elem.PlateCategotyName);
        }
      })
      //this.filterPlateCat();
    });
  }
  resetAll() {
    this.multilpleFile = [];
  }

  resetInvAll() {
    this.quickquoteinfo.get('reg_Card_Front')?.setValue('');
    this.quickquoteinfo.get('reg_Card_FrontFilePath')?.setValue('');
    this.quickquoteinfo.get('reg_Card_FrontFileType')?.setValue('');
    this.quickquoteinfo.get('docRegCardBack')?.setValue('');
    this.quickquoteinfo.get('reg_Card_Back')?.setValue('');
    this.quickquoteinfo.get('reg_Card_BackFilePath')?.setValue('');
    this.quickquoteinfo.get('reg_Card_BackFileType')?.setValue('');
    this.quickquoteinfo.get('docEmiratedIdFront')?.setValue('');
    this.quickquoteinfo.get('emirated_ID_Front')?.setValue('');
    this.quickquoteinfo.get('emirated_ID_FrontFilePath')?.setValue('');
    this.quickquoteinfo.get('emirated_ID_FrontFileType')?.setValue('');
    this.quickquoteinfo.get('docEmiratedIdBack')?.setValue('');
    this.quickquoteinfo.get('emirated_ID_Back')?.setValue('');
    this.quickquoteinfo.get('emirated_ID_BackFilePath')?.setValue('');
    this.quickquoteinfo.get('emirated_ID_BackFileType')?.setValue('');
    this.quickquoteinfo.get('docDrivingLicFront')?.setValue('');
    this.quickquoteinfo.get('driving_Lic_Front')?.setValue('');
    this.quickquoteinfo.get('driving_Lic_FrontFilePath')?.setValue('');
    this.quickquoteinfo.get('driving_Lic_FrontFileType')?.setValue('');
    this.quickquoteinfo.get('docDrivingLicBack')?.setValue('');
    this.quickquoteinfo.get('driving_Lic_Back')?.setValue('');
    this.quickquoteinfo.get('driving_Lic_BackFilePath')?.setValue('');
    this.quickquoteinfo.get('driving_Lic_BackFileType')?.setValue('');
    this.quickquoteinfo.get('docTradeLicence')?.setValue('');
    this.quickquoteinfo.get('trade_Licence')?.setValue('');
    this.quickquoteinfo.get('trade_LicenceFilePath')?.setValue('');
    this.quickquoteinfo.get('trade_LicenceFileType')?.setValue('');
    this.quickquoteinfo.get('docTRNCertificate')?.setValue('');
    this.quickquoteinfo.get('TRN_Certificate')?.setValue('');
    this.quickquoteinfo.get('TRN_CertificateFilePath')?.setValue('');
    this.quickquoteinfo.get('TRN_CertificateFileType')?.setValue('');
  }

  callRejected = false;
  rejectQuote() {
    Swal.fire({
      title: "Reject Quote",
      text: "Are you sure want to reject this quotation ?",
      showCancelButton: true,
      confirmButtonColor: '#3085D6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      allowOutsideClick: false,
    }).then((result) => {
      if (result.value) {
        this.callRejected = true;
        this.getReferalCondtion("REJECTED");
      }
    })
  }
  calculateNCD(){
    let d = new Date();
    let licIssueDate = new Date(this.quickquoteinfo.value.lic_issue_date);
    let difference = ( d.getTime()-licIssueDate.getTime());
    var ageInYears = difference / (1000 * 60 * 60 * 24 * 365);
    
    if(ageInYears<1){
      this.NCDPerDataF = [this.NCDData[0]]
    }
    else if(ageInYears>1 && ageInYears<2){
      this.NCDPerDataF = [this.NCDData[0],this.NCDData[1]];
    }

    else if(ageInYears>2 && ageInYears<3){
      this.NCDPerDataF = [this.NCDData[0],this.NCDData[1],this.NCDData[2]] ;
    }else{

      this.NCDPerDataF = this.NCDData;
    }
  }

  setVehModelAndSetChassisMaxMin(event){

    const schemes = ["65S", "65Q4", "66S", "65RK", "66RK", " 66Q"];
    const schemeCoTPL = ["66A", "60D", "64F"]

    if (schemes.includes(event)) {
      this.chassisMin = 17; this.chassisMax = 17;
    }
   else if (schemeCoTPL.includes(event)) {
      this.chassisMin = 6; this.chassisMax = 17;
    }
    else {
      // this.chassisMin = 10 ; this.chassisMax = 17 ; 
    }
  
    this.getVhclMakeData('',this.quickquoteinfo.value.m_year,0);
    this.quickquoteinfo.get('chassisno')?.setValue('');
    this.quickquoteinfo.get('m_year')?.setValue('');
    this.quickquoteinfo.get('rg_reg_date')?.setValue('');

    
    
  }

}





function expDateValidators(c: FormControl) {
  const monthAndYear = /^(0[1-9]|1[0-2])\/?([0-9]{4}|[0-9]{2})$/;
  return monthAndYear.test(c.value)
    ? null
    : {
      validateInput: {
        valid: false,
      },
    };
    
}
