import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector     : 'unauthrized',
    templateUrl  : './unauthorized.html',
    encapsulation: ViewEncapsulation.None
})
export class UnauthorizedComponent
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
