import { NgModule } from '@angular/core';
import { Route, RouterModule } from '@angular/router';
import { UnauthorizedComponent } from 'app/modules/admin/unauthorized/unauthorized.component';

const unauthorizedRoutes: Route[] = [
    {
        path     : '',
        component: UnauthorizedComponent
    }
];

@NgModule({
    declarations: [
        UnauthorizedComponent
    ],
    imports     : [
        RouterModule.forChild(unauthorizedRoutes)
    ]
})
export class UnauthorizedModule
{
}
