import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ProjectService

{
    private _data: BehaviorSubject<any> = new BehaviorSubject(null);

    /**
     * Constructor
     */
     apiurl = environment.apiurl;
    constructor(private _httpClient: HttpClient)
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for data
     */
    get data$(): Observable<any>
    {
        return this._data.asObservable();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Get data
     */
    getData(): Observable<any>
    {
        return this._httpClient.get('api/dashboards/project').pipe(
            tap((response: any) => {
                this._data.next(response);
            })
        );
    }

    getDashboardData(user_id,partner_id,lob_code): Observable<any> {
        return this._httpClient.post(
            `${this.apiurl}DashboardController/getDashboardData`,
            {user_id:user_id,partner_id:partner_id,lob_code:lob_code}
        );
    }

    getDashboardTransaction(user_id,partner_id,lob_code): Observable<any>{
        return this._httpClient.post(
            `${this.apiurl}DashboardController/dashboardTranscation`,
            {user_id:user_id,partner_id:partner_id,lob_code:lob_code}
        );

    }

    getDashboardQuickLink(user_id,partner_id,lob_code): Observable<any>{
        return this._httpClient.post(
            `${this.apiurl}DashboardController/dashboardDocQuickLinks`,
            {user_id:user_id,partner_id:partner_id,lob_code:lob_code}
        );

    }
}
