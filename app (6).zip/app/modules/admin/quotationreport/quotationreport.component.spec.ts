import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotationreportComponent } from './quotationreport.component';

describe('QuotationreportComponent', () => {
  let component: QuotationreportComponent;
  let fixture: ComponentFixture<QuotationreportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuotationreportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuotationreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
