
 export interface VehiModelYr {
  value: string;
  label: string;
}

export interface DrivExp {
  value: string;
  viewValue: string;
}



export interface BrandNew {
  value: string;
  viewValue: string;
}

export interface Gender {
  value: string;
  viewValue: string;
}

export interface industry {
  id: number;
  IndustryName: string;
}

export interface Model {
  VehicleModelId: number;
  VehicleModelName: string;
  Active: boolean;
  SeatingCapacityExDriver: number;
  BodyTypeId: number;
  CRS_MODEL_CODE: number;
  EDATA_MODEL_CODE: string;
}

export interface PlateCategory {
  label: string;
  value: string;
}

export interface VichleColor {
  ColorId: number;
  ColorName: string;
  CRS_COLOR_CODE: string;
}

export interface MortageBank {
  Id: number;
  InstituteName: string;
  InstituteCode: string
  CRS_Bank_Map_Code: string;
}

export interface Code {
  value: string;
  viewValue: string;
}

export interface Country {
  id: number;
  CountryName: string;
  Active: boolean;
  CountryCode: string;
  CurrencyCode: string;
  CRS_NATION_CODE: number;
  CRS_Country_Map_Code: number;
}

export interface Make {
  VehicleMakeId: number;
  VehicleMakeName: string;
  Active: boolean;
  IsReferral: number;
  CRS_VEH_CODE: number;
}

export interface occupation {
  OccupationId: number;
  OccupationName: string;
}
