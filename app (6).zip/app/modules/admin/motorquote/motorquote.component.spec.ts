import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorquoteComponent } from './motorquote.component';

describe('MotorquoteComponent', () => {
  let component: MotorquoteComponent;
  let fixture: ComponentFixture<MotorquoteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotorquoteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotorquoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
