import { FormGroup, Validators } from '@angular/forms';

export var  insvehibys: any = [
  { value: 'Individual', viewValue: 'Individual', code: '100' },
  { value: 'Corporate', viewValue: 'Corporate', code: '200' },
];

export const maskEid = [/[1-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/,];


export const insuredDetailForm = {
  docRegCardFront: [''],
  reg_Card_Front: [''],
  reg_Card_FrontFilePath: '',
  reg_Card_FrontFileType: '',

  docSupporting: [''],
  supporting_Document: [''],
  AdditionalDoc: [''],
  supporting_DocumentFilePath: '',
  supporting_DocumentFileType: '',
  additional_DocumentFilePath: '',
  additional_DocumentFileType: '',

  docSupportingGAP: [''],
  additional_bor_document: [''],

  docRegCardBack: [''],
  reg_Card_Back: [''],
  reg_Card_BackFilePath: '',
  reg_Card_BackFileType: '',

  docEmiratedIdFront: [''],
  emirated_ID_Front: [''],
  emirated_ID_FrontFilePath: '',
  emirated_ID_FrontFileType: '',

  docEmiratedIdBack: [''],
  emirated_ID_Back: [''],
  emirated_ID_BackFilePath: '',
  emirated_ID_BackFileType: '',

  docDrivingLicFront: [''],
  driving_Lic_Front: [''],
  driving_Lic_FrontFilePath: '',
  driving_Lic_FrontFileType: '',

  docDrivingLicBack: [''],
  driving_Lic_Back: [''],
  driving_Lic_BackFilePath: '',
  driving_Lic_BackFileType: '',

  docTradeLicence: [''],
  trade_Licence: [''],
  trade_LicenceFilePath: '',
  trade_LicenceFileType: '',

  docTRNCertificate: [''],
  TRN_Certificate: [''],
  TRN_CertificateFilePath: '',
  TRN_CertificateFileType: '',

  MulkhiyaStatus: [true],

  // reg card front form fields
  rg_model_year: ['', [Validators.required]],
  rg_num_passenger: ['', [Validators.required]],
  rg_origin: [''],
  rg_vhcl_make: ['', [Validators.required]],
  rg_vhcl_model: ['', [Validators.required]],
  rg_gvm: [''],
  rg_engin_num: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
  rg_chassis_num: ['', [Validators.required]],

  // reg card back form fields
  rg_traffic_plate_num: ['', [Validators.required]],
  rg_place_issue: ['', [Validators.required]],
  rg_TC_num: ['', [Validators.required]],
  rg_type: ['', [Validators.required]],
  rg_plateCode: ['', [Validators.required]],
  rg_noOfDoor: ['', [Validators.required]],
  // rg_expiry_date: ['', [Validators.required]],
  rg_reg_date: ['', [Validators.required]],
  rg_ins_exp: ['', [Validators.required]],
  rg_policy_num: [''],
  rg_mortgage: [''],
  adtnl_detail_gccSpecified: ['', [Validators.required]],
  adtnl_detail_vhclModified: ['', [Validators.required]],

  // eid front form fields
  e_eid: ['', [Validators.required]],
  e_name: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
  e_nationality: ['', [Validators.required]],
  e_cardNumber: [''],
  e_expiryDate: ['', [Validators.required]],
  e_gender: ['', [Validators.required]],
  e_arabic_name: [''],
  // eid back form fields

  // driving lic front form fields
  d_driv_lic_num: ['', [Validators.required]],
  d_dob: ['', [Validators.required]],
  d_issue_date: ['', [Validators.required]],
  d_expiry_date: ['', [Validators.required]],
  d_place_issue: ['', [Validators.required]],
  d_TC_number: ['', [Validators.required]],
  po_box_location: ['', [Validators.required]],
  po_box_number: ['', [Validators.required]],
  driver_occupation: ['', [Validators.required]],
  d_lic_type: [''],

  // Additional detail fields /^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/  //'[050|052|054|055|056|057|058|059]{1}[0-9]{7}'
  adtnl_detail_email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
  // adtnl_detail_mbCode: ['', [Validators.required]],
  adtnl_detail_mobile: ['', Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
  adtnl_detail_NCD: ['', [Validators.required]],
  adtnl_detail_NCD_Perc: [''],
  adtnl_detail_repairTye: ['', [Validators.required]],
  adtnl_detail_vhclValue: ['', [Validators.required]],
  weight_empty: [''],
  weight_full: [''],

  adtnl_detail_vhclValue_high: [''],
  adtnl_detail_vhclValue_low: [''],
  adtnl_detail_vhclValue_medium: [''],
  adtnl_detail_trim: ['', [Validators.required]],
  adtnl_detail_bodyType: ['', [Validators.required]],
  adtnl_detail_engine: ['', [Validators.required]],
  adtnl_detail_cylinder: ['', [Validators.required]],

  adtnl_detail_brandNew: [''],
  adtnl_detail_address: [''],
  adtnl_detail_area: [''],
  adtnl_detail_poBoxNum: [''],
  adtnl_detail_insType: ['', [Validators.required]],
  isChassisValidate: [''],
  adtnl_detail_vhclOwnBy: ['', [Validators.required]],
  polStartDate: [new Date(Date.now()), Validators.required],
  vhclTPLCoverage: ['', [Validators.required]],
  promoCode: [''],
  vhclColor: ['', [Validators.required]],
  eIDCheck: [''],
  CC: [''],
  loading_capacity: [''],
  deductible: [''],

  //For Corporate : insured vehicle own by
  TRN_num: [''],
  trade_lic_num: [''],
  industry_type: [''],
  vat_register: ['No'],
  vat_tl_location: [''], // TO - do ,[Validators.required]
  transaction_type: ['', [Validators.required]],
  mileage: ['0', [Validators.required]],

  // Added Partner And Branch
  partner: [''],
  branch: [''],
};


export const invalidData = {
  subjectData: [''],
  reason: [''],
  description: [''],
  chassisnumber: ['']
};


export const codeData = [
  { value: '050', viewValue: '050' },
  { value: '052', viewValue: '052' },
  { value: '054', viewValue: '054' },
  { value: '055', viewValue: '055' },
  { value: '056', viewValue: '056' },
  { value: '057', viewValue: '057' },
  { value: '058', viewValue: '058' },
];



