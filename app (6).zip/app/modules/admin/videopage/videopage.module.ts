import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Route, RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import {MatExpansionModule} from '@angular/material/expansion';
import { VideopageComponent } from './videopage.component';

export const routes: Route[] = [
  {
      path     : '',
      component: VideopageComponent
  },
];

@NgModule({
  declarations: [
    VideopageComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatExpansionModule
  ]
})
export class VideopageModule { }
