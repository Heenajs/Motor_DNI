import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-videopage',
  templateUrl: './videopage.component.html',
  styleUrls: ['./videopage.component.scss']
})
export class VideopageComponent implements OnInit {

  isvisited: boolean = true;
  panelOpenState = true;

   video1:boolean=true;
   video2:boolean=false;
   video3:boolean=false;

  constructor() { }

  ngOnInit(): void {
  }

  videolistbtn(){
    this.isvisited = !this.isvisited;
  }

  videolink(){
    this.video1=true;
    this.video2=false;
    this.video3 = false;
  }
  videolink1(){
    this.video1=false;
    this.video2=true;
    this.video3 = false;
  }
  videolink2(){
    this.video1 = false;
    this.video2 = false;
    this.video3 = true;
  }

}
