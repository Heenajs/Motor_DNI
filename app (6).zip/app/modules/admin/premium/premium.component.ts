import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-premium',
  templateUrl: './premium.component.html',
  styleUrls: ['./premium.component.scss']
})
export class PremiumComponent implements OnInit {
  webQuoteNumber: any = '';
  totalFixPremium: number = 0;
  totalVariablePremium: number = 0;
  VATAMT: any;
  PlanDataJson:any;
  loadingBy: any;
  businessSource: any;
  partnerId: any;
  userType:any;
  userRole:any;
  calculBy:any = '0';

  calculationby = [
    { label: "By Amount", value: "0" },
    { label: "By Percent", value: "1" }
];

  constructor() { }

  ngOnInit(): void {
  }

}
