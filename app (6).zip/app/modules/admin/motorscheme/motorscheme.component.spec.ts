import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorschemeComponent } from './motorscheme.component';

describe('MotorschemeComponent', () => {
  let component: MotorschemeComponent;
  let fixture: ComponentFixture<MotorschemeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotorschemeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotorschemeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
