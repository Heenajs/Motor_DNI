import { Component, OnInit } from '@angular/core';
import {MotorquoteService} from '../../service/motorquote.service';

@Component({
  selector: 'app-motorscheme',
  templateUrl: './motorscheme.component.html',
  styleUrls: ['./motorscheme.component.scss']
})
export class MotorschemeComponent implements OnInit {

  constructor( private motorQuoteService: MotorquoteService) { }

  public scheme_list:any;
  public schemecode:any;
 

  ngOnInit(): void {
    this.getSchemeByProduct();
    
  }


  //get scheme by product
  getSchemeByProduct(){
    this.motorQuoteService.getSchemesByProduct('MT').subscribe(result=>{
      this.scheme_list= result.getSchemesByProduct;
      // console.log( this.scheme_list);
     
    })
  }

  //get scheme code from localstorage
  getSchemeCode(schemecode):void {
    // console.log(schemecode);
    localStorage.setItem("Schemecode",schemecode);
  }



}
