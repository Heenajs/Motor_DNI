import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, TemplateRef } from '@angular/core';
import {AfterViewInit, ViewChild} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';
import { AuthService } from 'app/core/auth/auth.service';
import { GlobalService } from 'app/modules/service/global.service';
import { MotorquoteService } from '../../service/motorquote.service';
import Swal from 'sweetalert2';
import * as xlsx from 'xlsx';
import { invalid } from 'moment';

interface Partner {
   value: string;
   viewValue: string;
 }
 interface Nationality{
   value: string;
   viewValue: string;
 }
 interface Renewstatus{
  value: string;
  viewValue: string;
 }
 interface Claimstatus{
  value: string;
  viewValue: string;
 }

@Component({
  selector: 'app-renewpolicy',
  templateUrl: './renewpolicy.component.html',
  styleUrls: ['./renewpolicy.component.scss']
})
export class RenewpolicyComponent implements OnInit {

  displayedColumns: string[] = ['policyno', 'insname'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  partnersArr: any = [];
  renewPolicyForm: FormGroup;
  notificationGroup: FormGroup;

  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('CustomerNotification') CustomerNotification: TemplateRef<any>;
  @ViewChild('claimPopup') claimPopup: TemplateRef<any>;
  partnerID: any;
  partnerVal: any;
  latest_date: string;
  gridData:boolean = false;
  gridStatus:boolean = false; 
  hideField: boolean = false;
  hiderenewalrow: boolean = true;
  renewPolicyListData:any = [];
  localStorageData: any;
  quoteRes:boolean=false;
  res_Status: any;
  lobCode: any;
  date = new Date();    //new Date().setMonth(new Date().getMonth() + 2)
  minDate = new Date();
  frdate = new Date(new Date().setDate(new Date().getDate() - 7));
  toDate = new Date(new Date(this.frdate).setDate(this.frdate.getDate() + 1));
  minToDate = new Date(new Date().setDate(new Date().getDate() + 1));
  maxToDate =  new Date();
  public datepipe: DatePipe
  LOBCode: any;
  showNotifRes:boolean = false;
  pol_exp_dt: any;
  insured_Name: any;
  policy_Number: any;
  notification_type: any;
  lob_code: any;
  email_id: any;
  mobile_number: any;
  quote_Number: any;
  renewalpremiumlist: any = [];
  quoteNum: any;
  isMng = 0 ;
fromMaxDate = new Date();
fromMinDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));

nation: Nationality[] = [
  {value: 'steak-0', viewValue: 'Dubai'},
  {value: 'pizza-1', viewValue: 'China'},
  {value: 'tacos-2', viewValue: 'France'},
];
renewstatus: Renewstatus[] = [
  {value: 'All', viewValue: 'All'},
  {value: 'Expired Policies', viewValue: 'Expired Policies'},
  {value: 'Non Expired Policies', viewValue: 'Non Expired Policies'},
];

claimstatus: Claimstatus[] = [
  {value: 'All', viewValue: 'All'},
  {value: 'No Claims', viewValue: 'No Claims'},
  { value: 'Has Claims (Renew Allowed)', viewValue: 'Has Claims (Renew Allowed)'},
  {value: 'Has Claims (Renew with Referral)', viewValue: 'Has Claims (Renew with Referral)'},
];
  userRole: any;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  constructor( public motorQuoteService: MotorquoteService,  public formBuilder: FormBuilder,
    public globalService: GlobalService,private el: ElementRef, public dialog: MatDialog, private _authService: AuthService,
    private _router: Router,) { }

  ngOnInit(): void {
    this.getQuotationFormData();
    this.localStorageData = this.globalService.getLocalStorageData();
   
    this.partnerID = this.localStorageData.PartnerId;
    this.isMng  = this.localStorageData.IsMng;
    this.userRole = this.localStorageData.RoleDesc;
    let renewalData = JSON.parse(localStorage.getItem("renewalLocalstorageDta"));
   


    this.renewPolicyForm = this.formBuilder.group({
      product: ['MT',Validators.required],
      partner : ['',Validators.required],
      issue_date_from: [this.fromMaxDate,this.frdate,Validators.required],
      issue_date_to: [new Date(new Date().setDate(new Date().getDate()+7)),Validators.required],
      renewal_status: [this.renewstatus[0].viewValue,Validators.required],
      claim_status: [this.claimstatus[0].viewValue,Validators.required],
      optionalText: [''],
    
    });

if(renewalData){
      this.renewPolicyForm.setValue({
      product: renewalData.Product_Name,
      partner : renewalData.Partner_Name,
      issue_date_from: renewalData.From_Date,
      issue_date_to: renewalData.To_Date,
      renewal_status: renewalData.renewal_status,
      claim_status: renewalData.claim_status,
      optionalText: '',
    });
    this.getRenewPolicyList()
    localStorage.removeItem('renewalLocalstorageDta')
}
   
  
  this.notificationGroup = this.formBuilder.group({
    policyNum:['', Validators.required],
    insuredName:['', Validators.required],
    emailId:['', Validators.required],
    mobileNumber:['', 
    [
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern(
            '^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$'
        ),
    ],]


  })

  }

 
 
  
  getQuotationFormData() {
    // this.loadPartner = this.globalService.spinnerShow(); 
    this.motorQuoteService.getQuotationFormData().subscribe(response => {
    
        let formDataRes = response;
        this.partnersArr = formDataRes.Partners;
        this.partnersArr.forEach((item, index) => {
    
          if (item.PartnerId == this.partnerID) {
                this.partnerVal = item.PartnerId;
          }
    
        });
       // this.loadPartner = this.globalService.spinnerHide(); 
        this.renewPolicyForm.get('partner').setValue(this.partnerVal);
       // this.callSearchHistroy();
        
      
      });
    
    }

    openDialog(){
      this.dialog.open(this.CustomerNotification);
      

    }
    openDialogClaim(){
      this.dialog.open(this.claimPopup);
  

    }

    close(){
      this.dialog.closeAll();
    }


    demo(input){
      this.latest_date =this.datepipe.transform(input, 'dd/MM/yyyy');
    
    }
    Date(input){
      input = new Date(Date.now());
    
    }


    convertDate(inputFormat,type) {
      function pad(s) { return (s < 10) ? '0' + s : s; }
       var d = new Date(inputFormat);
        if(type == 1){
          return ([ pad(d.getMonth()+1),pad(d.getDate()),d.getFullYear()].join('/'));
        }
        if(type == 2){
          return ([ pad(d.getDate()),pad(d.getMonth()+1),d.getFullYear()].join('/'));
        }
      
  }
  renewalSchemecode:any;

    getRenewPolicyList(){

     
   
      if(this.renewPolicyForm.invalid){
        return false;
      }
  
     this.quoteRes=true; 
          this.motorQuoteService.getPolicyRenewList(this.convertDate(this.renewPolicyForm.value.issue_date_from,1),
                                                    this.convertDate(this.renewPolicyForm.value.issue_date_to,1),
                                                    this.renewPolicyForm.value.product,
                                                    this.renewPolicyForm.value.partner,
                                                    this.renewPolicyForm.value.optionalText,
                                                    this.renewPolicyForm.value.claim_status,
                                                    this.renewPolicyForm.value.renewal_status
  
                                                    ).subscribe(res =>{
                        
                        if(res.response_code == 1){
                            this.res_Status = res.response_message;
                            this.LOBCode = res?.renewalPolicyListData[0]?.LOBCode;
                            this.quoteRes = false;
                            this.renewPolicyListData = res.renewalPolicyListData;
                            // sessionStorage.setItem("searchRenewalData", JSON.stringify(this.renewPolicyListData));
                            this.dataSource = res.renewalPolicyListData;
                            this.renewPolicyListData.forEach((element,index) => {
                            element['checked']=true;
                            localStorage.setItem("renewalSchemecode",element.SchemeCode)
                            });
                       
                            
                          // ----------------- For data table----------------------------
                           this.dataSource=new MatTableDataSource<any>(this.renewPolicyListData);
                           this.renewPolicyListData.length = res.renewalPolicyListData.length;
                         
                           setTimeout(() => this.dataSource.paginator = this.paginator);
                        
                          //  this.pagesize=this.dataSource.paginator.pageSize;
                          //  this.pageindex=0;
                           
  
                            let renewalLocalstorageDta:any = {

                            Partner_Name : this.renewPolicyForm.value.partner,
                            Product_Name : this.renewPolicyForm.value.product,
                            Renewal_Status : this.renewPolicyForm.value.renewalStatus,
                            From_Date : this.renewPolicyForm.value.issue_date_from,
                            To_Date : this.renewPolicyForm.value.issue_date_to,
                            renewal_status : 'All',
                            claim_status : 'All'
                          }
                         localStorage.setItem("renewalLocalstorageDta", JSON.stringify(renewalLocalstorageDta));      
                        }
                        if(res.response_code == 2){
                           this.res_Status = res.response_message;
                           this.quoteRes = false;
                        }
  
          });
          this.gridStatus = true;

    }

    
  renewquotepage(quotNum,corePolicyNum) {
    if(this.renewPolicyForm.value.product == 'MT'){
      // let cedantPartnerId =  this.renewPolicyForm.value.partner;
      
      // localStorage.setItem('Policy_Renewal_Quotation_Number',quotNum);
      // localStorage.setItem('Core_Policy_Number',corePolicyNum);
      let modPolicyNo = corePolicyNum.replaceAll("/","-");

      this._router.navigate(['renewal/update/'+modPolicyNo]);
   
    }
    else if(this.renewPolicyForm.value.product == 'HT'){
      let cedantPartnerId =  this.renewPolicyForm.value.partnerName.PartnerId;
      localStorage.setItem('Policy_Renewal_Quotation_Number',quotNum);
      localStorage.setItem('Core_Policy_Number',corePolicyNum);

    }
       
  }
    sendNotification(frame){
  
     // this.notificationLoader = true;
        // this.MotorquoteService.sendNotifications(this.quoteNum,this.email_id,this.mobile_number,this.notification_type, this.lob_code,'RENEWAL REMINDER',this.policy_Number,this.pol_exp_dt,this.insured_Name).subscribe(res =>{
        //       if(res.response_code == 1){
        //           this.showNotifRes = true;
        //           this.notificationLoader = false; 
        //           frame.hide();
        //       }else{
        //         this.showNotifRes = false;
        //         this.notificationLoader = false; 
        //       }
        // });
  
  }

  openSMSModelforNotification(quoteNumber,mobileNumber,emailId,type,policyNumb,insuredName,lobCode,pol_exp_dt){
    
    this.openDialog();
      this.getQuoteNumber(policyNumb,lobCode,'','');
          this.quote_Number = quoteNumber;
          this.mobile_number = mobileNumber;
          this.email_id = emailId;
          this.lob_code = lobCode;
          this.notification_type = type;
          this.policy_Number = policyNumb;
          this.insured_Name = insuredName;
          this.pol_exp_dt = pol_exp_dt
          this.showNotifRes = false;
    }
    openSMSModelforSendEmail(policyNumb,insuredName,emailId,mobileNumber){
      this.openDialog();
      this.policy_Number = policyNumb;
      this.mobile_number = mobileNumber;
      this.email_id = emailId;
      this.insured_Name = insuredName;
      this.notificationGroup.get('policyNum').setValue(this.policy_Number);
      this.notificationGroup.get('insuredName').setValue( this.insured_Name);
      this.notificationGroup.get('emailId').setValue(this.email_id);
      this.notificationGroup.get('mobileNumber').setValue(this.mobile_number );
    }
    numColumns: number = 1;

    //Export to Excel
  exportToExcel() {
    console.log(this.renewPolicyListData);
    // this.hiderenewalrow = true;
    this.renewPolicyListData.forEach((element) => {
      this.renewalpremiumlist.push(element.RenewalPremium);
    })
    if (this.renewalpremiumlist != 'NA') {
       const sheetName = ["sheet1"];
        const ws: xlsx.WorkSheet =  xlsx.utils.table_to_sheet(this.epltable.nativeElement);
        const wb: xlsx.WorkBook = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
        xlsx.writeFile(wb, 'renewalList.xlsx');
    }
  }

    sendMailOnRenewal(){
      this.policy_Number = this.notificationGroup.value.policyNum,
      this.insured_Name = this.notificationGroup.value.insuredName,
      this.email_id = this.notificationGroup.value.emailId,
      this.mobile_number = this.notificationGroup.value.mobileNumber

      if(this.notificationGroup.invalid){
        Swal.fire('', 'Please fill all the mandatory data', 'warning');
        this.notificationGroup.markAllAsTouched();
      }
      else{
        this.motorQuoteService.sendRenewalEmail(this.policy_Number,this.insured_Name,this.email_id,this.mobile_number).subscribe(result=>{
        
          Swal.fire('Renewal Email', 'Email sent successfully!', 'success');
      this.close();
        });
      }

      
        
      

    }

    selectedClaim ;
    openClaim(item){

      this.selectedClaim = item ;
   

      this.openDialogClaim();
    }
    onRenewalStatusChange(renewalStatus,fromDate){
      
        if(renewalStatus == 'All'){
           this.minDate = new Date(new Date().setDate(new Date().getDate() - 30));
           this.minToDate = new Date(new Date(fromDate).setDate(fromDate.getDate() + 1));
           this.maxToDate = new Date(new Date().setDate(new Date().getDate() + 59));
           this.date = new Date(new Date().setDate(new Date().getDate() + 60));
           this.renewPolicyForm.get('toDate').setValue(this.minToDate);
        }
        if(renewalStatus == 'All' && this.renewPolicyForm.value.product == 'SM'){
           this.minDate = new Date(new Date().setDate(new Date().getDate() - 90));
           this.minToDate = new Date(new Date(fromDate).setDate(fromDate.getDate() + 1));
           this.maxToDate = new Date(new Date().setDate(new Date().getDate() + 59));
           this.date = new Date(new Date().setDate(new Date().getDate() + 60));
           this.renewPolicyForm.get('toDate').setValue(this.minToDate);
        }
        if(renewalStatus == 'Expired Policies'){
           this.minDate = new Date(new Date().setDate(new Date().getDate() - 30));
           this.minToDate = new Date(new Date(fromDate).setDate(fromDate.getDate() + 1));
           this.date = new Date(new Date().setDate(new Date().getDate() - 1));
           this.maxToDate = new Date(new Date().setDate(new Date().getDate() - 1));
           this.renewPolicyForm.get('toDate').setValue(this.minToDate);
        }
        if(renewalStatus == 'Non Expired Policies'){
           this.minDate = new Date();
           this.minToDate = new Date(new Date(fromDate).setDate(fromDate.getDate() + 1));
           this.date = new Date(new Date().setDate(new Date().getDate() + 60));
           this.maxToDate = new Date(new Date().setDate(new Date().getDate() + 60));
           this.renewPolicyForm.get('toDate').setValue(this.minToDate);
        }
        
   }
  
getQuoteNumber(CorePolNo,LOB,type,planeName){
  let cedantPartnerId =  this.renewPolicyForm.value.partner;
    this.motorQuoteService.processRenewal(CorePolNo,cedantPartnerId,LOB).subscribe(result=>{
    this.quoteNum=result.Plans[0].WebQuotationNumber;

    if(type == 'PDF' && LOB == 'HT'){
      // this.viewPdf(CorePolNo,LOB,planeName);
    }
    else if(type == 'PDF' && LOB == 'SM'){
      let quotenum =result.Plans[0].QuotationNumber;
      let QuoteArray =[{
        productCode: result.Plans[0].ProductName,
        lob_code:'SM',
        processType : 'INSERT' ,
        policyType:'NEW',
        source : 'B2B' 
      }]
      // this.motorQuoteService.printsmepdf(QuoteArray ,quotenum).subscribe(result=>{

      // })
    }
    
  })

}

filterByLegend(condType){


  this.renewPolicyListData.forEach((item)=>{

        switch(condType) { 
          case "No Claim": { 
            //statements;
            if(item?.RecClaimCount == 0 && item?.NonRecClaimAmount==0){

              item.checked = true ;
            }else{
              item.checked = false ;

            }
            break; 
          } 
          case "Recovery Claim": { 
            //statements; 
            if(item?.RecClaimCount > 0 && item?.NonRecClaimAmount==0){

              item.checked = true ;
            }else{
              item.checked = false ;

            }
            break; 
          } 

          case "Renewal allowed": { 
            //statements; 
            if(item?.NonRecClaimAmount>0 && item?.NonRecClaimAmount <= 5000){

              item.checked = true ;
            }else{
              item.checked = false ;

            }
            break; 
        } 

        case "Referral": { 
          //statements; 
          if(item.NonRecClaimAmount>5000){

            item.checked = true ;
          }else{
            item.checked = false ;

          }
          break; 
      } 

   
    default: { 
       //statements; 
       item.checked = true ;
       break; 
    } 
 } 

})
}

}

export interface PeriodicElement {
  insname: string;
  policyno: number;
  // exdate: string;
  // policytype: string;
  // existsi:string;
  // existprem:string;
  // sms:string;
  // email:string;
}

const ELEMENT_DATA: PeriodicElement[] = [];
