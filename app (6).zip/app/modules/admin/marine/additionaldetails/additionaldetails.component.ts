import { Component, OnInit,ViewChild ,TemplateRef} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

interface Plan{
    value: string;
    viewValue: string;
   }
   interface Branch{
    value: string;
    viewValue: string;
   }
   interface CoverType{
    value: string;
    viewValue: string;
   }
   interface Gender{
    value: string;
    viewValue: string;
   }
   interface Mstatuss{
    value: string;
    viewValue: string;
   }
   interface Relationship{
    value: string;
    viewValue: string;
   }
   interface Visa{
    value: string;
    viewValue: string;
   }

   interface Visarigion{
    value: string;
    viewValue: string;
   }
   interface Partner{
    value: string;
    viewValue: string;
   }



@Component({
  selector: 'app-additionaldetails',
  templateUrl: './additionaldetails.component.html',
  styleUrls: ['./additionaldetails.component.scss']
})
export class AdditionaldetailsComponent implements OnInit {

    @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;

  constructor(public dialog: MatDialog,private router: Router) { }

  ngOnInit(): void {
  }
  plan: Plan[] = [
    {value: 'steak-0', viewValue: 'Plan A'},
    {value: 'pizza-1', viewValue: 'Plan B'},
    {value: 'tacos-2', viewValue: 'Plan C'},
  ];
  gender: Gender[] = [
    {value: 'steak-0', viewValue: 'Male'},
    {value: 'pizza-1', viewValue: 'Female'},
  ];
  Mstatus: Mstatuss[] = [
    {value: 'steak-0', viewValue: 'Single'},
    {value: 'pizza-1', viewValue: 'Married'},
  ];

  relationship: Relationship[] = [
    {value: 'steak-0', viewValue: 'Mother'},
    {value: 'pizza-1', viewValue: 'Father'},
  ];
  visa: Visa[] = [
    {value: 'steak-0', viewValue: 'Visa Old'},
    {value: 'pizza-1', viewValue: 'Visa New'},
  ];
  visaregion: Visarigion[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'Abi Dhabi'},
    {value: 'steak-0', viewValue: 'Ajman'},
    {value: 'steak-0', viewValue: 'Sharjah'},
  ];

  branch: Branch[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'England'},
    {value: 'tacos-2', viewValue: 'India'},
    {value: 'tacos-2', viewValue: 'Japan'},
  ];
  partner: Partner[] = [
    {value: 'steak-0', viewValue: 'ABC Travel Agency'},
    {value: 'pizza-1', viewValue: 'AL Sayegh'},
    {value: 'tacos-2', viewValue: 'AL Sayegh insurance Broker'},
    {value: 'tacos-2', viewValue: 'Links insurance Broker'},
  ];
  coverTypes:CoverType[] = [
    {value: 'steak-0', viewValue: 'Self'},
    {value: 'pizza-1', viewValue: 'Self and Dependent'},
    {value: 'tacos-2', viewValue: 'Domestic Helper'},
    {value: 'tacos-3', viewValue: 'Parent'},
    {value: 'tacos-4', viewValue: 'Self Investor'}
  ];

  popupTC(){
    this.dialog.open(this.callAPIDialog);
  }
  popupTCclose() {
    this.dialog.closeAll();
  }
  gotoThanks(){
    this.router.navigateByUrl('/thankyou');
    this.dialog.closeAll();
  }
}
