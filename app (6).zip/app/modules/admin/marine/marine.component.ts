import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import {
  FormArray,
    FormBuilder,
    FormControl,
    FormGroup,
    Validators,
} from '@angular/forms';
import { MotorquoteService } from '../../service/motorquote.service';
import { QuickquoteService } from '../../service/quickquote.service';
import { MarineService } from '../../service/marine.service';
import { VehiModelYear } from '../motorquote/VehiModelYr';
import { vehimodelyrs } from '../motorquote/motoryear';
import Swal from 'sweetalert2';
import { of, ReplaySubject, Subject } from 'rxjs';
import { GlobalService } from '../../service/global.service';
import { take, takeUntil } from 'rxjs/operators';
import { registerLocaleData } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'app/core/auth/auth.service';
import { MatStepper } from '@angular/material/stepper';
import { ApexYAxis } from 'ng-apexcharts';
import { toUpper } from 'lodash';
interface Branch{
  value: string;
  viewValue: string;
 }


@Component({
  selector: 'app-marine',
  templateUrl: './marine.component.html',
  styleUrls: ['./marine.component.scss']
})



export class MarineComponent implements OnInit {
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  @ViewChild('callAPIDialogImg') callAPIDialogImg: TemplateRef<any>;
  
  @ViewChild('stepper') stepper : MatStepper;
  unauthorizedAccess: boolean = false;
  headerDesclaimer: any;
  Desclaimer: boolean=false;
  quotationHistoryArr:any = [];
  partnerBranchArr: any = [];
  disabledStatus:boolean =false;
  isvisited: boolean =true;
  quoteDetail: any;
  SchemeCodeClick : false ;
  partnersArr: any = [];
  isUpdateValuation = true ;
  todayDate = new Date(Date.now());
  minDOB = new Date(new Date().setDate(new Date().getDate() - 365*99));
  maxDOB = new Date(new Date().setDate(new Date().getDate() - 365*18));
  /**************  CreditLimit variables  */
  public creditLimit = {CreditLimit:0,AvailableLimit:0}
  public noCreditLimt  = 0 ;
  sideForm: FormGroup;
  marineInsuredForm: FormGroup;
  additionaldetails: FormGroup;
  Search_clone: FormGroup;
  vesselForm: FormGroup;
  partnerId: any;
  branchId: any;
  userRole:any;
  businessSource:any;
  userType:any;
  loadingBy: string;
  RoleDesc:any;
  id:number;
  // PlanDataJson: any={planBenefitData:[]};
  planName: any;
  cedantId: any;
  userId: any;
  localStorageData: any;
  calculBy: any = '0';
  loadByAmount: any = 0;
  retrieveQuoteNumber:any;
  product_list: any;
  SchemeCode: string;
  partnerDataRes: any;
  branchVal: any;
  selectedschemecode: any;
  instypes: any;
  date = new Date(Date.now()); 
  maxdate = new Date(new Date().setDate(new Date().getDate() + 30));

  ashore = [
    {value:'0', ashoreval:'Ashore'},
    {value:'1', ashoreval:'Moored'}
  ]
  calculationby = [
    { label: "By Amount", value: "0" },
    { label: "By Percent", value: "1" }
 ];
  insvehibys: any = [
    { value: 'Individual', viewValue: 'Individual', code: '100' },
    { value: 'Corporate', viewValue: 'Corporate', code: '200' },
  ];
  activePolicyTypeArr = [
    { value: 'Yes', label: 'No INSURANCE' , isDisable:true },
    { value: 'No', label: 'COMPREHENSIVE' , isDisable:true },
    { value: 'Yes', label: 'THIRD PARTY LIABILITY' , isDisable:true }
  ];

  PlanDataJson: any = {
    "quotationNumber": "",
    "productCode": "",
    "planBenefitData": {},
    "data": []

  };
  initial_benefit_data: any;
  branch: Branch[] = [];
  formDataRes: any;
  vesselManufacture: any;
  getAllData: any;
  bodyTypeArr: any;
  usageTypeArr: any;
  enginetypearr: any;
  vesselDetailsArray: any;
  vesselTypeArr: any;
  insuredTypeArr: any;
  nationalityArr: any;
  coverTypeArr: any;
  productCode: any;
  webQuoteNumber: any;
  QuotationId: any;
  responsedata: any;
  policyFee: number;
  totalVariablePremium: number;
  totalFixPremium: any;
  plan_Id: any;
  benfPremIdArray: any;
  tempBenefitData: any;
  quoteNumber: any;
  plan_Name: any;
  mulOption: any;
  premium: any;
  occupatindata: any;
  public today: Date = new Date();
  public currentYear: number = this.today.getFullYear();
  public currentMonth: number = this.today.getMonth();
  public currentDay: number = this.today.getDate();
  vehicleColorsData:[{"ColorId":4,"ColorName":"Advertisment Stiker","CRS_COLOR_CODE":"E-C01"},{"ColorId":1,"ColorName":"ALUMINIUM MICA","CRS_COLOR_CODE":"E-C255"},{"ColorId":2,"ColorName":"AQUA METALLIC","CRS_COLOR_CODE":"E-C214"},{"ColorId":3,"ColorName":"ASTER BLUE","CRS_COLOR_CODE":"E-C186"},{"ColorId":5,"ColorName":"BEIGE ADVT STICKER","CRS_COLOR_CODE":"E-C327"},{"ColorId":6,"ColorName":"BEIGE BROWN STICKER ADVT","CRS_COLOR_CODE":"E-C216"},{"ColorId":7,"ColorName":"BEIGE-BROWN","CRS_COLOR_CODE":"E-C30"},{"ColorId":8,"ColorName":"BEIGE-GOLD","CRS_COLOR_CODE":"E-C31"}]
  optionalBenefit: string;
  planBenefitIDforBronze: any;
  tempTotalLoadFixPrem: any;
  Total_Primium: number;
  VATAMT: number;

  public showLoader = {   // remove unwated variable
    reg_card_front: false,
    reg_card_back: false,
    bor_card: false,
    emirates_Id_front: false,
    emirates_Id_back: false,
    driving_Lic_front: false,
    driving_Lic_back: false,
    Quotation: false,
    VehicleValue: false,

    chasisNoButton: false,
    additionalDoc: false,
   
    passport:false,
    report:false,
    certificate:false,
    registration:false

  }
  savePlanDetailArr:any ;
  total_premium: any;
  loading_rate: any;
  repairLoadingAmt: any;
  deductibleData: any;
  vatPer: any;
  image: any;
  cityArr: any;
  termsAndCondition: any;
  issuePolicyDetail: any;
  yearRange  = [] ;
  toDay = new Date(Date.now());
  constructor(private _formBuilder: FormBuilder,
    public motorQuoteService: MotorquoteService,
    private quickQuoteService: QuickquoteService,
    private marineService: MarineService,
    private globalService: GlobalService,
    private _router: Router,
    public dialog: MatDialog,
    private _authService: AuthService,
    private el: ElementRef,
    private _activatedRoute: ActivatedRoute,

    ) { }

  ngOnInit(): void {
    this.retrieveQuoteNumber = '' ;
    this.localStorageData = this.globalService.getLocalStorageData();
    console.log(this.localStorageData);
    const routeParams = this._activatedRoute.snapshot.params;
    this.partnerId = this.localStorageData.PartnerId;
    this.branchId = this.localStorageData.BranchId;
    this.cedantId = this.localStorageData.CedantId;
    this.userId = this.localStorageData.UserId;
    this.userRole = this.localStorageData.UserRole;
    this.businessSource = this.localStorageData.BusinessSource;
    this.userType = this.localStorageData.UserType;
    this.RoleDesc = this.localStorageData.RoleDesc;

    for(let j= 2023;j>2005;j--){

        this.yearRange.push({yr:j}) ;

    }

    console.log(this.yearRange);
    
    if (routeParams.quoteNum) {
        this.retrieveQuoteNumber = routeParams.quoteNum;
        this.webQuoteNumber = this.retrieveQuoteNumber;
        console.log(this.retrieveQuoteNumber);
      }
     
      this.sideForm = this._formBuilder.group({
        schemeCode: ['', Validators.required],
        partnerID: ['', Validators.required],
        branchID:['',Validators.required],
        Accounting: ['']
     });
      this.marineInsuredForm = this._formBuilder.group({
        insuredName:['',Validators.required],
        DOB:['',Validators.required],
        insuredType:['',Validators.required],
        coverType:[new Date(Date.now()),Validators.required],
        email:['',Validators.required],
        mobNo:['',Validators.compose([Validators.required,Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
        nationality:['',Validators.required],
        licIssuedate:['',Validators.required],
        licExpirydate:['',Validators.required],
        coverStartDate:[new Date(this.currentYear, this.currentMonth, this.currentDay),Validators.required]
      });
      this.Search_clone = this._formBuilder.group({
        selected_clone:['']
      })
      this.additionaldetails=this._formBuilder.group({
        coverStartDate:['',Validators.required],
        emiratesid:['',Validators.required],
        emiratesExpDate:['',Validators.required],
        pobox:['',Validators.required],
        poboxLocation:['',Validators.required],
        Businessprofessionntype:['',Validators.required],
       
        
        address:['',Validators.required],
                       
        altNo:[''],
        passportFile:['',Validators.required],
        reportFile:['',Validators.required],
        certificateFile:['',Validators.required],
        registrationFile:['',Validators.required],
       });
      this.vesselForm = this._formBuilder.group({
        vesselDetails:this._formBuilder.array([]),
      });

      this.getQuotationHistory(this.retrieveQuoteNumber);
      this.CheckAccessOnLoad();
      this.getSchemesByProduct();

      
      this.getVesselManufacture();
      this.getQuotationFormData();
      this.getBodyTypeData();
      this.getUsageType();     
      this.getenginetype();
      this.getVesselType();
      this.getinsuredType();
      this.getCoverType();
      this.getOccupation();
      if (routeParams.quoteNum) {
        this.retrieveQuoteNumber = routeParams.quoteNum;
        
      }else{
        this.addVessel();
      }

      

  this.getTermsConditions()


   let cloneQwebNo = localStorage.getItem("cloneQuoteNo");

   if(cloneQwebNo){
      
    
    this.cloneQuoteData(cloneQwebNo);
    localStorage.removeItem("cloneQuoteNo");

   }else{

    console.log("no data to cloene");
   }

  }




  //search clone data
  onKeyCloneData(event){}
  //get search details
  getdetailsbySearch(){}

  //Allow Only Numbers
  keyPressNumber(event){
    var charCode = event.which ? event.which : event.keyCode;
    if(charCode < 48 || charCode > 57){
      event.preventDefault();
      return false;
    }
    else{
      return true;
    }


  }

  ngAfterViewInit(): void
    {
      this.retrieveQuoteData();
    }

    dateConvert(inputFormat) {

      if(!inputFormat) return '' ;

      let vDOEntryArray = inputFormat.split('/');
      let DOEntry = new Date();
      DOEntry.setDate(vDOEntryArray[0]);
      DOEntry.setMonth(vDOEntryArray[1] - 1);
      DOEntry.setFullYear(vDOEntryArray[2]);
  
      return DOEntry;
  
    }
  

  //calculate issuedate
  lic_issue_min ;
  calucateLicIssueDate(inputData, type) {
    console.log(inputData); 
    const d =     new Date( inputData);
    this.lic_issue_min = new Date(new Date(d).setDate(365*18));
  }

  //Calculate Age  
  calucateAge(inputData, type) {
    console.log(this.lic_issue_min);
      if (inputData != '') {
          let timeDiff = Math.abs(Date.now() - inputData);
          if (type == 1) {
              return Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
          }
          if (type == 2) {
              return Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
          }
      } else {
          return '';
      }
  }

  //convert date into DD/MM/YYYY
  convertDate(inputFormat) {
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat);
    return ([ d.getFullYear(),pad(d.getMonth()+1),pad(d.getDate())].join('-'));
    return ([pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('-'));

  }

  //Get Quotation History
  getQuotationHistory(quoteNumber){
    this.motorQuoteService.getQuotationHistory(quoteNumber,'MT').subscribe(res =>{
      console.log(res);
              if(res.response_code == 1){
                      this.quotationHistoryArr = res.quotationHistoryList;
                      console.log(this.quotationHistoryArr);
              }
    });
  }

  //get SchemeCode
  temp_product_list ;
  getSchemesByProduct() {
    this.marineService.getSchemesByProduct().subscribe((res)=>{
      this.product_list = res.getSchemesByProduct;
      this.temp_product_list= res.getSchemesByProduct;
          this.selectedschemecode = res.getSchemesByProduct[0].SchemeCode;
    })
   
  }

  //Get QuotationForm Data
  getQuotationFormData(){
    console.log(this.retrieveQuoteNumber);
    this.motorQuoteService.getQuotationFormData().subscribe(response =>{
      this.cityArr = response.getCityByCountry;
      this.formDataRes = response;
      this.partnersArr = this.formDataRes.Partners;
      this.nationalityArr = this.formDataRes.Nationality;
        if(this.retrieveQuoteNumber =='' || this.retrieveQuoteNumber == undefined){
          console.log(this.partnerId);
          this.sideForm.get("partnerID")?.setValue(this.partnerId);
          this.getPartnerBranchList();
        }
    });
  }
  
  //close
  close() {
    this.dialog.closeAll();
  }

  //on selection data
  onSelectionChange(event, selectedId) {
    this.getAllData = event.source.value;
    this.id = selectedId;
    console.log(this.id);
    console.log(event.source.value, event.source.selected);
    this.quickQuoteService.getAllData( this.id).subscribe(res=>{
        console.log(res.response_data);
        this.close();
      let  resdata = res.response_data;
      this.quoteDetail = resdata;
        this.quoteDetail.VehicleMake = resdata.VehicleMake;
        this.quoteDetail.VehicleModel = resdata.VehicleModel;
        this.quoteDetail.TrimCode = resdata.TrimCode;
        this.quoteDetail.TrimName = resdata.VehicleTrim;
        this.quoteDetail.BodyType = resdata.BodyType;
    })

}
  //Get Branch List
  getPartnerBranchList() {
    this.partnerBranchArr = [];
    this.motorQuoteService
        .getpartnerBranch(this.sideForm.value.partnerID)
        .subscribe((res) => {
            let updateRes: any = res;
            this.partnerBranchArr = updateRes.branchList;
            this.branchId = updateRes.branchList[0];
            //  branch
            console.log(this.retrieveQuoteNumber);
            if (this.retrieveQuoteNumber == '' || this.retrieveQuoteNumber == undefined || this.retrieveQuoteNumber != '') {
              console.log(this.partnerBranchArr);
                this.partnerBranchArr.forEach((item, index) => {
                    if (item.Id == this.branchId.Id) {
                      console.log(this.branchId.Id);
                        this.branchVal = item;
                        console.log(this.branchVal);
                    }
                });
                this.sideForm.get('branchID')?.setValue(this.branchVal.Id);
                this.sideForm.get('Accounting')?.setValue(this.branchVal.Id);
                this.getParterLimitOnSelection();
            } 
        });
  }

  //Get Credit Limit
  getParterLimitOnSelection(){
    this.partnerId = this.sideForm.value.partnerID;
    this.motorQuoteService.partnerCreditLimit(10,this.partnerId,this.sideForm.value.branchID).subscribe(res=>{
        if(res.response_message==null){
            this.noCreditLimt = 0 ;
            this.creditLimit = {CreditLimit:0,AvailableLimit:0};
        }else{
            this.creditLimit = res.response_message;
            this.noCreditLimt = 1 ;
        }
      })
  }

  //Get Vessel Manufactures data
  getVesselManufacture(){
    this.marineService.getVesselManufacturers().subscribe(res=>{
      console.log(res);
      this.vesselManufacture = res.VesselManufacturers;
    })
  }

  //Get Body Type
  getBodyTypeData(){
    this.marineService.getBodyType().subscribe(res=>{
      console.log(res);
      this.bodyTypeArr= res.BodyType;
    })
  }
  
  //Get Usage Type
  getUsageType(){
    this.marineService.getUsageType().subscribe(res=>{
      this.usageTypeArr = res.UsageType;
      console.log(this.usageTypeArr);
    })
  }

  //get engine type
  getenginetype(){
    this.marineService.getenginetype().subscribe(res=>{
      this.enginetypearr=res.EningeType;
    })
  }

  //get Vessel Type
  getVesselType(){
    this.marineService.getVesselType().subscribe(res=>{
      this.vesselTypeArr = res.BoatType;
      console.log(this.vesselTypeArr[0].Type);
      // if(this.vesselTypeArr[0].Type = "Pleasure Boat"){
      //   this.marineInsuredForm.get('noOfCrew').setValidators([Validators.required]);
      // }
      // else{
      //   this.marineInsuredForm.get('noOfCrew').setValidators(null);
      // }
      // this.marineInsuredForm.get('noOfCrew').updateValueAndValidity();
    })
  }

   //Get Insured Type
   getinsuredType(){
    this.marineService.getInsurredType().subscribe(res=>{
      this.insuredTypeArr = res.InsuredType;
    });
  }

  changeSchemeCode(event:any){
    let temp = this.tmpCoverType ;
    if(event == "56S"){

      this.coverTypeArr = [{Id: 2 ,​ProductCode: "PCTPL79" , ​Type: "THIRD PARTY LIABILITY" ,  SchemeCode: "56S"  }];
    
      this.marineInsuredForm.get('coverType').setValue(this.coverTypeArr[0].Type);

      this.vesselForm.get('vesselDetails')['controls'].forEach((element,index) => {
        this.vesselForm.get('vesselDetails')['controls'][index].get('sumInsured')?.setValidators(null);
        this.vesselForm.get('vesselDetails')['controls'][index].get('sumInsured')?.updateValueAndValidity();
        
      });
     
    }else{
      this.coverTypeArr = [{Id: 1 ,​ProductCode: "PCCOMP78" , ​Type: "COMPREHENSIVE" ,  SchemeCode: "55S"  }];
    
      this.marineInsuredForm.get('coverType').setValue(this.coverTypeArr[0].Type);
       
     

        this.vesselForm.get('vesselDetails')['controls'].forEach((element,index) => {
          this.vesselForm.get('vesselDetails')['controls'][index].get('sumInsured')?.setValidators([Validators.required]);
          this.vesselForm.get('vesselDetails')['controls'][index].get('sumInsured')?.updateValueAndValidity();
          
        });
        
              
    }
    this.tmpCoverType = temp;
       
  }
  //Get Cover Type
   tmpCoverType  ;
  getCoverType(){
    // console.log(event);
    // Swal.fire('', 'Please fill all the mandatory data', 'warning');
    // this.quid= routeParams.quoteNum;
    
    this.marineService.getCoverType().subscribe(res=>{
      this.coverTypeArr = res.PolicyType;
      this.tmpCoverType = res.PolicyType;
      this.productCode = this.coverTypeArr[0].ProductCode;
          this.marineInsuredForm.get('coverType').setValue(res.PolicyType[0].Type);
    })
  }


  //getQuoteEmail
  getQuotePlanEmail(){}
  //getreferal
  getMotorQuoteDetail(webQuoteNumber){}
  getReferalCondtion(ref_val){}
  //get partner list
  
  buttonClick = 0 ;
  popupTC(buttonType){
    this.buttonClick = buttonType;
    this.dialog.open(this.callAPIDialog);
  }
  popupTCclose() {
    this.dialog.closeAll();
  }
  gotoThanks(){
    this._router.navigateByUrl('/thankyou');
    this.dialog.closeAll();
  }






update(){}
//call change stepper
callChangeStepper(event: any, stepper) {
  if (event.selectedIndex == 0) {
        this.disabledStatus = true;
  }
}

vesselDetails(): FormArray {
  return this.vesselForm.get('vesselDetails') as FormArray;
}
newVesselDetails(): FormGroup{
  return this._formBuilder.group({
    vesselName:['',Validators.required],
    vesselType:['',Validators.required],
    vesselMake:['',Validators.required],
    yearBuilt:['',Validators.required],
    usageType:['',Validators.required],
    passengers:['',Validators.compose([Validators.required,Validators.pattern("^(100|[1-9][0-9]?)$")])],
    noOfCrew:[''],
    bodyType:['',Validators.required],
    moored:['',Validators.required],
    sumInsured:['',Validators.compose([Validators.required,Validators.pattern("^[0-9]*$"),Validators.minLength(5),Validators.maxLength(7)])],
    length:['',Validators.compose([Validators.required,Validators.pattern("^[0-9]*$"),Validators.minLength(1),Validators.maxLength(3)])],
    // width:['',Validators.compose([Validators.required,Validators.pattern("^[0-9]*$"),Validators.minLength(3),Validators.maxLength(5)])],
    enginePower:['',Validators.compose([Validators.required,Validators.pattern("[0-9]{1,2}(\.[0-9][0-9])?$")])],
    engineNo:['',Validators.compose([Validators.required,Validators.minLength(5),Validators.maxLength(20)])],
    engineType:['',Validators.required],
    hull:['',Validators.compose([Validators.required,Validators.minLength(5),Validators.maxLength(20)])]

  });
}
//add multiple vessel details
addVessel(){
  this.vesselDetails().push(this.newVesselDetails());

}
//remove vessel
removeVessel(vesselIndex: number) {
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  });
  this.vesselDetails().removeAt(vesselIndex);
}
//get credit limit
public getPartnerCreditLimit(){   // LOB 10 for motor
  setTimeout(()=>{ 
  this.motorQuoteService.partnerCreditLimit(3,this.partnerId,this.sideForm.value.branchID).subscribe(res=>{

      if(res.response_message==null){
          this.noCreditLimt = 0 ;
          this.creditLimit = {CreditLimit:0,AvailableLimit:0};
      }else{

          this.creditLimit = res.response_message;

          this.noCreditLimt = 0 ;
      }
    })
  },1000);
}

  accountChange(event){
    let branch = this.sideForm.value.branchID;
    this.sideForm.get("Accounting").setValue(branch);
    this.getPartnerCreditLimit();
  }
//save marine quotation
  checkValidation(stepper){
    if(this.marineInsuredForm.status == 'INVALID' && this.vesselForm.invalid){
      console.log(this.vesselForm.value.vesselDetails[0].vesselType);
      this.marineInsuredForm.markAllAsTouched();
      this.vesselForm.markAllAsTouched();
      Swal.fire('', 'Please fill all the mandatory data', 'warning');
    }
    else{
      let marineQuoteArray = {
        cedant_broker_id:this.sideForm.value.partnerID,
        broker_branch_id:this.sideForm.value.branchID,
        SchemeCode: this.sideForm.value.SchemeCode,
        branchID : this.sideForm.value.branchID,
        i_name: this.marineInsuredForm.value.insuredName,
        dob:this.convertDate(this.marineInsuredForm.value.DOB),
        i_Type:this.marineInsuredForm.value.insuredType,
        c_Type:this.marineInsuredForm.value.coverType,
        email:this.marineInsuredForm.value.email,
        mobileNo:this.marineInsuredForm.value.mobNo,
        nationality:this.marineInsuredForm.value.nationality,
        d_issue_date:this.convertDate(this.marineInsuredForm.value.licIssuedate),
        d_expiry_date:this.convertDate(this.marineInsuredForm.value.licExpirydate),
        c_start_date:this.marineInsuredForm.value.coverStartDate,
        product_code:  this.productCode,
        no_crew: this.marineInsuredForm.value.noOfCrew
      }
      this.vesselDetailsArray = this.vesselForm.value;
      
      console.log(marineQuoteArray);
      console.log(this.vesselDetailsArray);
      console.log(this.marineInsuredForm.value.coverType.ProductCode);
      this.marineService.insertQuote(marineQuoteArray,this.vesselDetailsArray).subscribe(res=>{
        console.log(res);
        this.responsedata = res;
        this.webQuoteNumber = res.response_data[0].WebQuotationNumber;
        this.PlanDataJson.planBenefitData.benefit_data = [];
        this.vatPer = res.vatPer;
        this.initial_benefit_data =   this.responsedata.planBenefitData.benefit_data;
        this.policyFee = 0;
        this.totalVariablePremium = 0;
        this.PlanDataJson =   this.responsedata;
        this.totalFixPremium =   this.responsedata.totalPremium;
        this.plan_Name = this.PlanDataJson.planBenefitData.data[0].PlanName;
        this.plan_Id = this.PlanDataJson.planBenefitData.data[0].PlanId;
        this.benfPremIdArray = this.PlanDataJson.planBenefitData.data;
       
        this.quoteNumber = res.response_data[0].QuotationId;
        this.tempBenefitData = this.PlanDataJson.planBenefitData.benefit_data;

        this.PlanDataJson.planBenefitData.data.forEach((item, index) => {
  
          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1) {
            this.mulOption = item.multipleOptionData[0];
            this.PlanDataJson.planBenefitData.data[index].benefitSelectedData = item.multipleOptionData[0];
            this.PlanDataJson.planBenefitData.data[index].multiOptID = item.multipleOptionData[0].BenefitId;
            this.PlanDataJson.planBenefitData.data[index].Price = item.multipleOptionData[0].Price;
            this.PlanDataJson.planBenefitData.data[index].checked = false;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;

          }

          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1) {

            this.PlanDataJson.planBenefitData.data[index].checked = false;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          }
        });

        this.premium = this.PlanDataJson.premium   ;

        stepper.next();
        this.addOptionalBenigits(1,1);
        this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy)
      })
    }
  }


  updateQuote(stepper){
    console.log(stepper);
    if(this.marineInsuredForm.status == 'INVALID' && this.vesselForm.invalid){
      console.log(this.vesselForm.value.vesselDetails[0].vesselType);
      this.marineInsuredForm.markAllAsTouched();
      this.vesselForm.markAllAsTouched();
      Swal.fire('', 'Please fill all the mandatory data', 'warning');
    }
    else{
      let marineQuoteArray = {
        cedant_broker_id:this.sideForm.value.partnerID,
        broker_branch_id:this.sideForm.value.branchID,
        SchemeCode: this.sideForm.value.SchemeCode,
        branchID : this.sideForm.value.branchID,
        i_name: this.marineInsuredForm.value.insuredName,
        dob:this.convertDate(this.marineInsuredForm.value.DOB),
        i_Type:this.marineInsuredForm.value.insuredType,
        c_Type:this.marineInsuredForm.value.coverType,
        email:this.marineInsuredForm.value.email,
        mobileNo:this.marineInsuredForm.value.mobNo,
        nationality:this.marineInsuredForm.value.nationality,
        d_issue_date:this.convertDate(this.marineInsuredForm.value.licIssuedate),
        d_expiry_date:this.convertDate(this.marineInsuredForm.value.licExpirydate),
        c_start_date:this.marineInsuredForm.value.coverStartDate,
        product_code:  this.productCode,
        no_crew: this.marineInsuredForm.value.noOfCrew
      }
      this.vesselDetailsArray = this.vesselForm.value;
      
      console.log(marineQuoteArray);
      console.log(this.vesselDetailsArray);
      console.log(this.marineInsuredForm.value.coverType.ProductCode);
      this.marineService.updateQuote(this.retrieveQuoteNumber,marineQuoteArray,this.vesselDetailsArray).subscribe(res=>{
        console.log(res);
        this.responsedata = res;
        this.webQuoteNumber = res.response_data[0].WebQuotationNumber;
        this.PlanDataJson.planBenefitData.benefit_data = [];
        this.vatPer = res.vatPer;
        this.initial_benefit_data =   this.responsedata.planBenefitData.benefit_data;
        this.policyFee = 0;
        this.totalVariablePremium = 0;
        this.PlanDataJson =   this.responsedata;
        this.totalFixPremium =   this.responsedata.totalPremium;
        this.plan_Name = this.PlanDataJson.planBenefitData.data[0].PlanName;
        this.plan_Id = this.PlanDataJson.planBenefitData.data[0].PlanId;
        this.benfPremIdArray = this.PlanDataJson.planBenefitData.data;
       
        this.quoteNumber = res.response_data[0].QuotationId;
        this.tempBenefitData = this.PlanDataJson.planBenefitData.benefit_data;

        this.PlanDataJson.planBenefitData.data.forEach((item, index) => {
  
          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1) {
            this.mulOption = item.multipleOptionData[0];
            this.PlanDataJson.planBenefitData.data[index].benefitSelectedData = item.multipleOptionData[0];
            this.PlanDataJson.planBenefitData.data[index].multiOptID = item.multipleOptionData[0].BenefitId;
            this.PlanDataJson.planBenefitData.data[index].Price = item.multipleOptionData[0].Price;
            this.PlanDataJson.planBenefitData.data[index].checked = false;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;

          }

          if (item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1) {

            this.PlanDataJson.planBenefitData.data[index].checked = false;
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          }
        });

        this.premium = this.PlanDataJson.premium   ;

        stepper.next();
      })
    }
  }

  //get Retrive Data
  retrieveQuoteData(){
    console.log(this.retrieveQuoteNumber)
    this.marineService.getRetrieveQuote(this.retrieveQuoteNumber).subscribe((res)=>{
      this.sideForm.get('schemeCode').setValue(res.QuotationDetails[0].SchemeCode);
      if (res.QuotationDetails[0].PartnerId != ''){
      this.sideForm.get('partnerID').setValue(res.QuotationDetails[0].PartnerId);
      this.getPartnerBranchList();
    }
      this.marineInsuredForm.get('insuredName').setValue(res.QuotationDetails[0].InsuredName);
      this.marineInsuredForm.get('email').setValue(res.QuotationDetails[0].InsuredEmail);
      this.marineInsuredForm.get('mobNo').setValue(res.QuotationDetails[0].InsuredMobile);
      this.marineInsuredForm.get('insuredType').setValue(res.QuotationDetails[0].InsuredType);
      this.marineInsuredForm.get('coverType').setValue(res.QuotationDetails[0].CoverType);
      this.marineInsuredForm.get('DOB')?.setValue(this.dateConvert(res.QuotationDetails[0].InsuredDOB));
      this.marineInsuredForm.get('nationality').setValue(res.QuotationDetails[0].InsuredNationality);
      this.marineInsuredForm.get('licIssuedate')?.setValue(this.dateConvert(res.QuotationDetails[0].DrivingLicenseIssueDate));
      this.marineInsuredForm.get('licExpirydate')?.setValue(this.dateConvert(res.QuotationDetails[0].DrivingLicenseIssueDate));
      this.marineInsuredForm.get('coverStartDate')?.setValue(this.dateConvert(res.QuotationDetails[0].CoverStartDate));
      res.QuotationDetails.forEach((element,index) => {
           this.addVessel();
          this.vesselForm.get('vesselDetails')['controls'][index].get('vesselType').setValue(element.BoatType);
          this.vesselForm.get('vesselDetails')['controls'][index].get('yearBuilt').setValue(element.BuiltYear);
          this.vesselForm.get('vesselDetails')['controls'][index].get('bodyType').setValue(element.BodyTypeName);
          this.vesselForm.get('vesselDetails')['controls'][index].get('engineType').setValue(element.EngineType);
          this.vesselForm.get('vesselDetails')['controls'][index].get('sumInsured').setValue(Number(element.SumInsured));
          this.vesselForm.get('vesselDetails')['controls'][index].get('passengers').setValue(element.PassengerCount);
          this.vesselForm.get('vesselDetails')['controls'][index].get('noOfCrew').setValue(element.CrewCount);
          this.vesselForm.get('vesselDetails')['controls'][index].get('usageType').setValue(element.UsageType);
          this.vesselForm.get('vesselDetails')['controls'][index].get('vesselName').setValue(element.VesselName);
          this.vesselForm.get('vesselDetails')['controls'][index].get('vesselMake').setValue(element.MakeName);
          this.vesselForm.get('vesselDetails')['controls'][index].get('length').setValue(element.VesselLength);
          this.vesselForm.get('vesselDetails')['controls'][index].get('engineNo').setValue(element.EngineNumber);
          this.vesselForm.get('vesselDetails')['controls'][index].get('enginePower').setValue(element.EnginePower);
          this.vesselForm.get('vesselDetails')['controls'][index].get('hull').setValue(element.HullNumber);
          this.vesselForm.get('vesselDetails')['controls'][index].get('moored').setValue(element.NotInUse);
      });



      /*
      this.vesselForm.get('vesselDetails')['controls'][0].get('vesselType').setValue(res.QuotationRiskDetails.BoatType);
      this.vesselForm.get('vesselDetails')['controls'][0].get('yearBuilt').setValue(res.QuotationRiskDetails.BuiltYear);
      this.vesselForm.get('vesselDetails')['controls'][0].get('bodyType').setValue(res.QuotationRiskDetails.BodyTypeName);
      this.vesselForm.get('vesselDetails')['controls'][0].get('engineType').setValue(res.QuotationRiskDetails.EngineType);
      this.vesselForm.get('vesselDetails')['controls'][0].get('sumInsured').setValue(res.QuotationRiskDetails.SumInsured);
      this.vesselForm.get('vesselDetails')['controls'][0].get('passengers').setValue(res.QuotationRiskDetails.PassengerCount);
      this.vesselForm.get('vesselDetails')['controls'][0].get('noOfCrew').setValue(res.QuotationRiskDetails.CrewCount);
      this.vesselForm.get('vesselDetails')['controls'][0].get('vesselType').setValue(res.QuotationRiskDetails.BoatType);

      */
    })
  }

  cloneQuoteData(retrieveQuoteNumber){
    console.log(retrieveQuoteNumber)


    this.marineService.getRetrieveQuote(retrieveQuoteNumber).subscribe((res)=>{
      
      this.marineInsuredForm.get('insuredName').setValue(res.QuotationDetails[0].InsuredName);
      this.marineInsuredForm.get('email').setValue(res.QuotationDetails[0].InsuredEmail);
      this.marineInsuredForm.get('mobNo').setValue(res.QuotationDetails[0].InsuredMobile);
      this.marineInsuredForm.get('insuredType').setValue(res.QuotationDetails[0].InsuredType);
      this.marineInsuredForm.get('coverType').setValue(res.QuotationDetails[0].CoverType);
      this.marineInsuredForm.get('DOB')?.setValue(this.dateConvert(res.QuotationDetails[0].InsuredDOB));
      this.marineInsuredForm.get('nationality').setValue(res.QuotationDetails[0].InsuredNationality);
      this.marineInsuredForm.get('licIssuedate')?.setValue(this.dateConvert(res.QuotationDetails[0].DrivingLicenseIssueDate));
      this.marineInsuredForm.get('licExpirydate')?.setValue(this.dateConvert(res.QuotationDetails[0].DrivingLicenseIssueDate));
      this.marineInsuredForm.get('coverStartDate')?.setValue(this.dateConvert(res.QuotationDetails[0].CoverStartDate));

      res.QuotationDetails.forEach((element,index) => {
           if(index>0)
           this.addVessel();
          this.vesselForm.get('vesselDetails')['controls'][index].get('vesselType').setValue(element.BoatType);
          this.vesselForm.get('vesselDetails')['controls'][index].get('yearBuilt').setValue(element.BuiltYear);
          this.vesselForm.get('vesselDetails')['controls'][index].get('bodyType').setValue(element.BodyTypeName);
          this.vesselForm.get('vesselDetails')['controls'][index].get('engineType').setValue(element.EngineType);
          this.vesselForm.get('vesselDetails')['controls'][index].get('sumInsured').setValue(Number(element.SumInsured));
          this.vesselForm.get('vesselDetails')['controls'][index].get('passengers').setValue(element.PassengerCount);
          this.vesselForm.get('vesselDetails')['controls'][index].get('noOfCrew').setValue(element.CrewCount);
          this.vesselForm.get('vesselDetails')['controls'][index].get('usageType').setValue(element.UsageType);
          this.vesselForm.get('vesselDetails')['controls'][index].get('vesselName').setValue(element.VesselName);
          this.vesselForm.get('vesselDetails')['controls'][index].get('vesselMake').setValue(element.MakeName);
          this.vesselForm.get('vesselDetails')['controls'][index].get('length').setValue(element.VesselLength);
          this.vesselForm.get('vesselDetails')['controls'][index].get('engineNo').setValue(element.EngineNumber);
          this.vesselForm.get('vesselDetails')['controls'][index].get('enginePower').setValue(element.EnginePower);
          this.vesselForm.get('vesselDetails')['controls'][index].get('hull').setValue(element.HullNumber);
          this.vesselForm.get('vesselDetails')['controls'][index].get('moored').setValue(element.NotInUse);  
      });



      /*
      this.vesselForm.get('vesselDetails')['controls'][0].get('vesselType').setValue(res.QuotationRiskDetails.BoatType);
      this.vesselForm.get('vesselDetails')['controls'][0].get('yearBuilt').setValue(res.QuotationRiskDetails.BuiltYear);
      this.vesselForm.get('vesselDetails')['controls'][0].get('bodyType').setValue(res.QuotationRiskDetails.BodyTypeName);
      this.vesselForm.get('vesselDetails')['controls'][0].get('engineType').setValue(res.QuotationRiskDetails.EngineType);
      this.vesselForm.get('vesselDetails')['controls'][0].get('sumInsured').setValue(res.QuotationRiskDetails.SumInsured);
      this.vesselForm.get('vesselDetails')['controls'][0].get('passengers').setValue(res.QuotationRiskDetails.PassengerCount);
      this.vesselForm.get('vesselDetails')['controls'][0].get('noOfCrew').setValue(res.QuotationRiskDetails.CrewCount);
      this.vesselForm.get('vesselDetails')['controls'][0].get('vesselType').setValue(res.QuotationRiskDetails.BoatType);

      */
    })
  }

  //get clone data
  getClone(){
     localStorage.setItem("cloneQuoteNo",this.retrieveQuoteNumber);
     this._router.navigateByUrl('/marine');
  }


    CheckAccessOnLoad(){
  
      this.motorQuoteService.checkUserAccess('QUICKMOTORQUOTE', this.localStorageData.EmailAddress, 'MT',this.retrieveQuoteNumber).subscribe(res => {
        let response = res;
        //  this.checkStepper = false;
        if (response.userAccessData == 0) {
        this.unauthorizedAccess= true;
        //  Swal.fire( "You are not authorized to access this section. Please contact your relationship manager.", 'warning');
       
        }
        else{
  
          this.Desclaimer = true;
          this.headerDesclaimer = response.HeaderDisclaimer;
  
    }
  
          });
   }

   getOccupation(){
    this.motorQuoteService.getOccupation('MT').subscribe(res=>{
      this.occupatindata = res.response_data;
  

   
    });
  }

  tickDriver(benifitItem,i){

    if(this.PlanDataJson.planBenefitData.data[i].checked){
      if(benifitItem.BenefitId==319){

        this.PlanDataJson.planBenefitData.data[2].checked = true ;
        this.PlanDataJson.planBenefitData.data[2].disable = true;
        this.addOptionalBenigits(318,2);
        this.calculateDiscount(this.loadingBy,this.loadByAmount,this.calculBy);
      }
    }else{

      if(benifitItem.BenefitId==319)
      this.PlanDataJson.planBenefitData.data[2].disable = false;
    }

   }

   addOptionalBenigits(id, event) {

    // alert(id)
  
  
    this.totalVariablePremium = 0;
    this.optionalBenefit = "";

    if( typeof this.PlanDataJson.planBenefitData.data != undefined)
   
    this?.PlanDataJson?.planBenefitData?.data?.forEach((item, index) => {
    
        //admin this.accessGroup == 'ADMIN
        if (this.localStorageData.BusinessSource == 'DIRECT' && this.localStorageData.Partner_ID == 1 && this.localStorageData.UserRole == 'TELEMARKETING' && this.localStorageData.UserType == 'POS') {
  
          if (item.offerChecked == true) {
            //this.PlanDataJson.planBenefitData.data[index].checked = true;
            this.totalVariablePremium = Number(this.totalVariablePremium + 1);
          }
          if (item.checked == false) {
            //this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          }
          
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1 && item.offerChecked == false) {
          
                  if(id == 321){
                        if(item.BenefitId == this.planBenefitIDforBronze && item.checked == true){
                         
                          this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                            item.checked = false;
                        }
                  }
                   // 477 for production & 509 for online test - Roadside Assistance - Bronze
                  if(id == this.planBenefitIDforBronze){
                
                        if(item.BenefitId == 321 && item.checked == true){
                          this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                            item.checked = false;
                        }
                  }
            this.optionalBenefit = this.optionalBenefit + "," + item.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
     
          }
  
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1 && item.offerChecked == false) {
            this.optionalBenefit = this.optionalBenefit + "," + this.mulOption.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
          
          }
  
  
        } else {
  
           //USER
  
          if (item.offerChecked == true) {
            this.PlanDataJson.planBenefitData.data[index].checked = true;
            this.totalVariablePremium = Number(this.totalVariablePremium + 1);
          }
          if (item.checked == false) {
            this.PlanDataJson.planBenefitData.data[index].offerChecked = false;
          }
         
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag != 1 && item.offerChecked == false) {
  
            if(id == 321){
            
                  if(item.BenefitId == this.planBenefitIDforBronze && item.checked == true){
                  
                    this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                      item.checked = false;
                  }
            }
            // 477 for production & 509 for online test
            if(id == this.planBenefitIDforBronze){
             
  
                  if(item.BenefitId == 321 && item.checked == true){
                    this.totalVariablePremium = Number(this.totalVariablePremium - item.Price);
                      item.checked = false;
                  }
            }
            this.optionalBenefit = this.optionalBenefit + "," + item.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
          
          }
  
          if (item.checked == true && item.PlanBenefitType == 'OPTIONAL' && item.MultiOptionFlag == 1 && item.offerChecked == false) {
            this.optionalBenefit = this.optionalBenefit + "," + this.mulOption.BenefitId;
            this.totalVariablePremium = Number(this.totalVariablePremium + item.Price);
          }


          
  
        
        }
  
    });

    
  
  }


  public additionalLoading:number; additionalDiscount:number; loadingByPercent:number;

  //----------------- APPLY DISCOUNT ON PREMIUM WITH VAT ----------------//

  public MaxLDPer:number ;
  public MaxLDAmt:number ;
  public MaxDSPer:number ;
  public MaxDSAmt:number ;
  calculateDiscount(loadingby, loadByAmount, calculationType) {

    // for  discount
    if(loadingby == 2 ){

          if(calculationType == 1 && loadByAmount > this.MaxDSPer){       // for percent

            Swal.fire('','Invalid percent selected for discount','error');
                return false;
          }
         if(calculationType == 0 && loadByAmount > this.MaxDSAmt){     // for amount

            Swal.fire('','Invalid amount selected for discount','error');
                return false;
          }

    }


    // for loading
    if(loadingby == 1){
          if(this.businessSource == 'DIRECT'){   // for admin

              if(calculationType == 1 && loadByAmount > this.MaxLDPer){       // for percent

                Swal.fire('','Invalid percent selected for loading','error');
                    return false;
              }
              if(calculationType == 0 && loadByAmount > this.MaxLDAmt){     // for amount

                Swal.fire('','Invalid amount selected for loading','error');
                    return false;
              }
          }else{         // for user

              if(calculationType == 1 && loadByAmount > this.MaxLDPer){       // for percent

                Swal.fire('','Invalid percent selected for loading','error');
                    return false;
              }
              if(calculationType == 0 && loadByAmount > this.MaxLDAmt){     // for amount

                Swal.fire('','Invalid amount selected for loading','error');
                    return false;
              }
          }


    }

    const  copy = JSON.parse(JSON.stringify(this.tempBenefitData));
    console.log(copy);
    let base_Primium = copy;
    console.log(this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData);

    this.PlanDataJson.planBenefitData.benefit_data = this.tempBenefitData;

    let Multiple: number;

    if (loadingby == 1) {
         Multiple = 1;
    } else {
        Multiple = -1;
    }

    this.totalFixPremium = this.tempTotalLoadFixPrem;
    let loadingAmt = loadByAmount;
    //let discount:number = Number(this.PlanDataJson.thirdPartyAPIData.NcdDiscount.NcdAmnt);
    let discount:number = 0 ;
    let policyFee:number = 0 ;
    if(loadingby == 1){
              this.additionalLoading = loadingAmt;

    }else{
              this.additionalDiscount = loadingAmt;
    }
    if(loadingby == 1){
    if(calculationType == 1){
      this.additionalLoading = Number(this.premium*loadingAmt/100) ;
        this.totalFixPremium = Number(Number(this.premium) + Number(this.premium*loadingAmt/100));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) *this.PlanDataJson.vatPer/100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData =  copy  ;
    }
    else{

        this.totalFixPremium = Number(Number(this.premium) + Number(loadingAmt));
        this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) *this.PlanDataJson.vatPer/100;
        this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
        this.tempBenefitData =  copy  ;

    }

    }else{

        if(calculationType == 1){
          this.additionalLoading = Number(this.premium*loadingAmt/100) ;
            this.totalFixPremium = Number(Number(this.premium) - Number(this.premium*loadingAmt/100));
            this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) *this.PlanDataJson.vatPer/100;
            this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
            this.tempBenefitData =  copy  ;
        }
        else{
          this.additionalLoading = Number(loadingAmt) ;
            this.totalFixPremium = Number(Number(this.premium) - Number(loadingAmt));
            this.VATAMT = Number(this.totalFixPremium + Number(this.totalVariablePremium)) *this.PlanDataJson.vatPer/100;
            this.Total_Primium = Number(this.totalFixPremium) + Number(this.totalVariablePremium) + Number(this.VATAMT);
            this.tempBenefitData =  copy  ;

        }

    }

   


  }
  


  //----------------------------------- VIEW QUOTE PDF -------------------------------------------
  viewQuotePDF() {
    this.showLoader.Quotation = true;
    let vatAMt = (this.premium + this.totalVariablePremium) * this.vatPer;
    let total_premium = this.totalFixPremium + this.totalVariablePremium + vatAMt+this.loadByAmount;
    console.log(this.loadByAmount);
    let loadingAmt = this.loadByAmount;
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      base_premium: this.premium ,
      total_premium: this.total_premium,
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_code: '',
      VAT: vatAMt.toFixed(2),
      benefitPreId: this.benfPremIdArray,
      calculation_type : this.calculBy,
      loading_by : this.loadingBy,
      loading_amount  : loadingAmt,
      loadis_rate : this.loading_rate,
      premiumGarageAmount : this.repairLoadingAmt,
      deductible: this.deductibleData
    }

    this.marineService.insertPlanData(this.webQuoteNumber, this.PlanDataJson.PlanDataJson, this.totalFixPremium,
    this.totalVariablePremium,
    this.policyFee,
    total_premium,
    this.PlanDataJson.planBenefitData.data,
    this.PlanDataJson.planBenefitData.benefit_data,
     '',
    this.savePlanDetailArr,
   '',
    // this.step2.value.adminDeductible,
    'B2B',
    this.SchemeCode,'','','','',''
    ).subscribe(res => {

      if(res.response_code==99 || res.response_code==909){

        Swal.fire("", res.show_message, 'error');
        this.showLoader.Quotation = false;
        return false ;
      }


      
      this.marineService.getQuoteDetailPDF(this.webQuoteNumber,this.partnerId,"B2B").subscribe(res => {


        this.showLoader.Quotation = false;
        setTimeout(
          function () {

          }.bind(this),
          600
        );
        let viewPDF = res;
        if (viewPDF.response_code == 1) {
          window.open(viewPDF.pdfPath, "_blank");
        }
      });
      //  this.editableStep.Quotation = false ;
    });
  }

  goToAddtionInfo(stepper){
    this.showLoader.Quotation = true;
    let vatAMt = (this.premium + this.totalVariablePremium) * this.vatPer;
    let total_premium = this.totalFixPremium + this.totalVariablePremium + vatAMt+this.loadByAmount;
    console.log(this.loadByAmount);
    let loadingAmt = this.loadByAmount;
    this.savePlanDetailArr = {
      quotation_number: this.webQuoteNumber,
      plan_id: this.plan_Id,
      base_premium: this.premium ,
      total_premium: this.total_premium,
      optional_benefit_premiun: this.totalVariablePremium,
      admin_fees: this.policyFee,
      CRS_quote_number: this.quoteNumber,
      service_fees: 0,
      product_code: '',
      VAT: vatAMt.toFixed(2),
      benefitPreId: this.benfPremIdArray,
      calculation_type : this.calculBy,
      loading_by : this.loadingBy,
      loading_amount  : loadingAmt,
      loadis_rate : this.loading_rate,
      premiumGarageAmount : this.repairLoadingAmt,
      deductible: this.deductibleData
    }

    this.marineService.insertPlanData(this.webQuoteNumber, this.PlanDataJson.PlanDataJson, this.totalFixPremium,
    this.totalVariablePremium,
    this.policyFee,
    total_premium,
    this.PlanDataJson.planBenefitData.data,
    this.PlanDataJson.planBenefitData.benefit_data,
     '',
    this.savePlanDetailArr,
   '',
    // this.step2.value.adminDeductible,
    'B2B',
    this.SchemeCode,'','','','',''
    ).subscribe(res => {

      stepper.next();


    });
  }

  global_formData: FormData;
  targetFile = '' ;
  uploadDocument(event, docName) {

   
    this.showLoader[docName]=true;
    const formData = new FormData();
    this.targetFile = event.target.files[0] ;
    formData.append('file', event.target.files[0]);
    formData.append('docName', docName);
    formData.append('source', 'B2B');
    formData.append('stage', 'QUOTE');
    formData.append('schemeCode',this.sideForm.value.schemeCode);

    this.marineService.uploadDocument(formData).subscribe(res => {

      console.log(res);

      let fileArr = res.FileDir.split(".");
      let fileType = '' ;
      if(fileArr[fileArr.length-1].toLowerCase()=="pdf") {

        fileType = "PDF";
      }else{

        fileType = "IMG";
      }

      this.additionaldetails.get(docName+'File').setValue({fileName:res.FileDir,fileType:fileType});
      this.showLoader[docName]=false;


    });
  
  }

  openImgDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialogImg);
    dialogRef.afterClosed().subscribe((result) => {});
    console.log(img);
    this.image = img;
  }


  goTOAction(){

    if(this.buttonClick==3){ this.callIssuePolicy(); }
  }

  callIssuePolicy(){

    if(this.additionaldetails.status == 'INVALID' ){

      this.additionaldetails.markAllAsTouched();
      this.additionaldetails.markAllAsTouched();
      Swal.fire('', 'Please fill all the mandatory data', 'warning');
    }
    else{

      this.marineService.issuePolicy(this.webQuoteNumber,this.additionaldetails.value).subscribe(res=>{

       this.issuePolicyDetail = res ;
       this.dialog.closeAll();

       this.stepper.next();

      });

    }


  }


  getTermsConditions() {

   
    this.motorQuoteService.getTermsConditions('B2B').subscribe(res => {
      if (res.response_code == 1) {
       
        this.termsAndCondition = res.termsAndCondition;
      }

    });
  }

}
