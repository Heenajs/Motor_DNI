import { Component, OnInit, ViewChild, ɵConsole, ElementRef, Directive, TemplateRef, Input, EventEmitter, SimpleChanges } from '@angular/core';
import { MotorquoteService } from '../../service/motorquote.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { GlobalService } from '../../service/global.service';
import Swal from 'sweetalert2';
import { Router, ActivatedRoute } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { Observable, Subscription, fromEvent } from 'rxjs';
import { config } from '../../../config';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from '../../../core/auth/auth.service';

@Component({
  selector: 'app-retrivequote',
  templateUrl: './retrivequote.component.html',
  styleUrls: ['./retrivequote.component.scss']
})
export class RetrivequoteComponent implements OnInit {
  toppings = new FormControl();

  toppingList = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];
  //declare variable
  partnerVal: any; partnerID: any; statusDescription: any; localStorageData: any; PartyCode: any; cedantId: any; userId: any; businessSource: any; userRole: any; userType: any; email: any; psw: any; renewalPolNo: string; res_Status: any; lobCode: any;
  popupTitle = "";transaction_type:any;transaction_condtion_type:any;sumInc = ''; chgDeduct = ''; optBenfit = '';

  //Declare FormGroup
  retreiveQuoteForm: FormGroup; sessionData: FormGroup; transactionStageData: FormGroup;

  //Declare Array
  businessSrcArr = []; partnersArr: any = []; public products: any = []; quotations: any = []; tableData: any = []; quoteData: any = [];userHerchyList = [];transactionarr:any=[];tempMultipleDocData: any = [];

  //Declare conditions
  isSubmitted: boolean = false; gridStatus: boolean = false; loadProducts: boolean = false; quoteRes: boolean = false; loadPartner: boolean = false; validtnMsg: boolean = false; showring: boolean = false; trstageData: boolean = true;

  //Declare Date
  fromDate: any = ""; toDate: any = ""; date = new Date(Date.now()); fromMaxDate = new Date(); fromDateFrom3month = new Date(); minDate = new Date(new Date().setMonth(new Date().getMonth())); frdate = new Date(new Date().setDate(new Date().getDate() - 7));
  fromMinDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));

  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('Showtransaction') Showtransaction: TemplateRef<any>;
  @ViewChild('statusquote') statusquote: TemplateRef<any>;

  @Input() partnerUser; // decorate the property with @Input()
  changeStatus: any;
  transactionDescription: string;
  webQuoteNumber: any;
  emailadd: any;

  constructor(public _route: Router, public _activatedroute: ActivatedRoute, public motorQuoteService: MotorquoteService, public formBuilder: FormBuilder, public globalService: GlobalService, private el: ElementRef, public dialog: MatDialog, private _authService: AuthService) { }
  statusArr  = [
    {value: 'ALLQUOTES', label: 'All'},
    {value: 'QUOTED', label: 'QUOTED'},
    {value: 'CONFIRM COVER', label: 'CONFIRM COVER'},
    {value: 'ADDITIONALINFO', label: 'ADDITIONALINFO'},
    {value: 'REFERRED', label: 'REFERRED'},
    {value: 'APPROVE', label: 'APPROVE'},
    {value: 'PAYMENTLINKSENT', label: 'PAYMENTLINKSENT'},
    {value: 'PAYMENTRECEIVED', label: 'PAYMENTRECEIVED'},
    {value: 'ISSUED', label: 'ISSUED'},
  ];

  transactionarray = [
    { value: 0, label: 'Customer Accepted' },
    { value: 1, label: 'Sent to Customer by Email' },
    { value: 2, label: 'Negotiation' },
    { value: 3, label: 'Confirmed by Customer' },
    
  ];

  ngOnInit(): void {
    this.retrieveQuoteFormData();
    this.getQuotationFormData();
    
    this.localStorageData = this.globalService.getLocalStorageData();
    this.partnerID = this.localStorageData.PartnerId;
    this.PartyCode = this.localStorageData.PartyCode;
    this.cedantId = this.localStorageData.CedantId;
    this.userId = this.localStorageData.UserId;
    this.businessSource = this.localStorageData.BusinessSource;
    this.userRole = this.localStorageData.UserRole;
    this.userType = this.localStorageData.UserType;
    this.renewalPolNo = localStorage.getItem('POL_No');

    this.sessionData = this.formBuilder.group({
      password: ['', Validators.required],
    });
    this.transactionStageData = this.formBuilder.group({
      transactionstage: [''],
      showTransactioncomment:['']
    })

    if (this.partnerID != 1 && this.partnerID != 3) {
      this.businessSrcArr = []
      this.retreiveQuoteForm = this.formBuilder.group({
        partner: ['', Validators.required],
        userSel: ['', Validators.required],
        product: ['', Validators.required],
        fromDate: [new Date(new Date().setDate(new Date().getDate() - 7)), this.frdate, Validators.required],
        toDate: [this.fromMaxDate, Validators.required],
        businessSrc: [this.businessSrcArr[0], Validators.required],
        quoteRefNum: [''],
        optionalText: [''],
        status: ['ALLQUOTES']
      });
    }
    else {
      this.retreiveQuoteForm = this.formBuilder.group({
        partner: ['', Validators.required],
        userSel: ['', Validators.required],
        product: ['', Validators.required],
        fromDate: [new Date(new Date().setDate(new Date().getDate() - 7)), Validators.required],
        toDate: [new Date(), Validators.required],
        businessSrc: [this.businessSrcArr[0], Validators.required],
        quoteRefNum: [''],
        optionalText: [''],
        status: ['ALLQUOTES']
      })
    }
    this.saveTransactionStageData();
    this.getUserHerchy();
  }

  get f() { return this.retreiveQuoteForm.controls; }

  fromDateChange(event) {
    const d = new Date(this.retreiveQuoteForm.value.fromDate);
    let month = d.getMonth();
    let today = new Date();
    this.fromDateFrom3month = new Date(new Date(d).setMonth(month + 3));
    var Difference_In_Time = today.getTime() - this.fromDateFrom3month.getTime();
    if (Difference_In_Time < 0)
      this.fromDateFrom3month = today;
  }

  saveData() {
    this.email = this.localStorageData.EmailAddress;
    this.psw = this.sessionData.value.password;
    if (this.email == '') {
      this._route.navigate(['/sign-in']);
    } else {
      this._authService
        .validateuser(this.email, this.psw).subscribe(() => {});
    }
    this._route.navigate(['/retrivequote']);
    this.close();
  }
  close() {
    this.dialog.closeAll();
  }
  getQuotationFormData() { 
    this.motorQuoteService.getQuotationFormData().subscribe(response => {
      let formDataRes = response;
      this.partnersArr = formDataRes.Partners;
      this.partnersArr.forEach((item, index) => {
        if (item.PartnerId == this.partnerID) {
          this.partnerVal = item.PartnerId;
        }
      });
      this.retreiveQuoteForm.get('partner').setValue(this.partnerVal);
      this.businessSrcArr = formDataRes.busiSource;
      this.retreiveQuoteForm.get('businessSrc').setValue(this.businessSrcArr[0]);
      this.callSearchHistroy();
    });
  }

  callSearchHistroy() {
    if (sessionStorage.getItem("retreiveQuoteForm") != null && sessionStorage.getItem("retreiveQuoteForm") != '' && typeof (sessionStorage.getItem("retreiveQuoteForm")) != undefined && typeof (sessionStorage.getItem("retreiveQuoteForm")) != "undefined") {
      let sessonData = JSON.parse(sessionStorage.getItem("retreiveQuoteForm"));
      this.retreiveQuoteForm.get('fromDate')?.setValue(sessonData.fromDate);
      this.retreiveQuoteForm.get('toDate')?.setValue(sessonData.toDate);
      this.retreiveQuoteForm.get('status')?.setValue(sessonData.status);
      this.retreiveQuoteForm.get('optionalText')?.setValue(sessonData.optionalText);
      this.retreiveQuoteForm.get('quoteRefNum')?.setValue(sessonData.quoteRefNum);
      this.serachQuote();
    }
  }

  convertDate(inputFormat) {
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat);
    return ([pad(d.getMonth() + 1), pad(d.getDate()), d.getFullYear()].join('/'));
  }

  retrieveQuoteFormData() {
    this.motorQuoteService.retrieveQuoteFormData().subscribe(res => {
      let retrieveRes = res;
      this.products = retrieveRes.Products;
      this.retreiveQuoteForm.get("product").setValue(this.products[0]);
      this.serachQuote();
    });
  }

  serachQuote() {
    this.quoteRes = true;
    if (this.retreiveQuoteForm?.invalid) {
      return;
    }
    var retriveSearchFormData: any = {
      partner: this.retreiveQuoteForm.value.partner,
      user: this.retreiveQuoteForm.value.userSel,
      product: this.retreiveQuoteForm.value.product,
      fromDate: this.retreiveQuoteForm.value.fromDate,
      toDate: this.retreiveQuoteForm.value.toDate,
      quoteRefNum: this.retreiveQuoteForm.value.quoteRefNum,
      businessSrc: this.retreiveQuoteForm.value.businessSrc,
      status: this.retreiveQuoteForm.value.status,
      optionalText: this.retreiveQuoteForm.value.optionalText
    };
    sessionStorage.setItem("retreiveQuoteForm", JSON.stringify(retriveSearchFormData));
    this.motorQuoteService.retrieveQuoteList(this.retreiveQuoteForm.value.partner,
      this.retreiveQuoteForm.value.product.Id,
      this.convertDate(this.retreiveQuoteForm.value.fromDate),
      this.convertDate(this.retreiveQuoteForm.value.toDate),
      this.retreiveQuoteForm.value.quoteRefNum,
      this.retreiveQuoteForm.value.optionalText,
      this.retreiveQuoteForm.value.status,
      this.retreiveQuoteForm.value.businessSrc.label,
      this.retreiveQuoteForm.value.userSel.UserId
    ).subscribe(res => {
      console.log(res);
      let quoteListRes = res;
      if (res.response_code == 1000) {
        const dialogRef = this.dialog.open(this.callAPIDialog);
      }
      if (quoteListRes.res_code == 1) {
        this.res_Status = quoteListRes.res_status;
        this.quotations = quoteListRes.Quotations;
        this.lobCode = this.quotations[0].LOBCode;
        this.quoteRes = false;
        this.tableData = this.quotations
        // console.log( this.tableData.length)
        if (this.lobCode == 'MT' || this.lobCode == 'PC') {
          this.quotations.forEach((item, index) => {
            if (item == 'QUOTECONFIRMED' || item == 'INITIATED') {
              this.statusDescription = item;
              this.quotations[index].mailStatus = false;
            }
          });
        }
      }
      if (quoteListRes.res_code == 2) {
        this.res_Status = quoteListRes.res_status;
        this.quoteRes = false;
      }
    });
    this.gridStatus = true;
  }

  getPCQuoteDetail(quoteNum, status, schemeCode, QuoteType, Isrenewal) {
    this._route.navigate(["marine/update/" + quoteNum]);
  }


  getMotorQuoteDetail(quoteNum, status, schemeCode, QuoteType, Isrenewal, RenewalPolNo, item) {
    localStorage.setItem("schemeCode", schemeCode);
    localStorage.setItem("Schemecode", schemeCode);

    if (Isrenewal == 1 && status != 'RENEWALCONFIRMED') {
      localStorage.setItem('SchemeCode', schemeCode);
      let polNo = RenewalPolNo.replaceAll("/", "-");
      this._route.navigate(["renewal/update/" + polNo]);
    }
    else {
      // if (!(this.businessSource == 'DIRECT' && this.partnerID == 1 && this.userType == 'POS') && item.StatusDesc == 'REFERRED') {
      //   return false;
      // }
      // if (!(this.businessSource == 'DIRECT' && this.partnerID == 1 && this.userType == 'POS') && item.StatusDesc == 'QUOTECONFIRMED') {
      //   return false;
      // }
      if (QuoteType == 'QUICKQUOTE') {
        localStorage.setItem('SchemeCode', schemeCode);
        this._route.navigate(["quickquote/update/" + quoteNum]);
      }
      else if (status == 'PAYMENTLINKSENT') {
        this._route.navigate(["referrals/approveQuote/" + quoteNum]);
      }
      else if (status == 'RENEWALCONFIRMED') {
        if (item.RenewalProcessFlow == "RENEDIT") {
          localStorage.setItem('SchemeCode', schemeCode);
          let polNo = RenewalPolNo.replaceAll("/", "-");
          this._route.navigate(["renewal/update/" + polNo]);
        }
        else
          this._route.navigate(["referrals/approveQuote/" + quoteNum]);
      }
      else {
        if (status == 'QUOTED' || status == 'REFREJECTED' || status == 'ADDITIONALINFO' || QuoteType == 'STANDARD' || QuoteType == 'FULLQUOTE'
          || status == 'DRAFT') {
          localStorage.setItem('SchemeCode', schemeCode);
          this._route.navigate(["motorquote/update/" + quoteNum]);
        }
        if (status == 'REFERRED' && this.businessSource == 'DIRECT' && this.partnerID == 1) {
          localStorage.setItem('SchemeCode', schemeCode);
          this._route.navigate(["motorquote/update/" + quoteNum]);
        }
        if (status == 'QUOTECONFIRMED' && this.businessSource == 'DIRECT' && this.partnerID == 1) {
          localStorage.setItem('SchemeCode', schemeCode);
          this._route.navigate(["motorquote/update/" + quoteNum]);
        }
      }
    }
  }

  getFullQuote(QuotationNumber, SchemeCode) {
    localStorage.setItem('SchemeCode', SchemeCode);
    this._route.navigate(["motorquote/update/" + QuotationNumber]);
  }

  getApproveQuoteForPolicy(quoteNumber, status, schemeCode) {
    if (status == 'REFAPPROVED' || status == 'INITIATED') {
      this._route.navigate(["agentMotor/MTquotepage/approveQuote/" + quoteNumber]);
    }
    if (status == 'QUOTED') {
      localStorage.setItem('SchemeCode', schemeCode);
      this._route.navigate(["agentMotor/MTquotepage/update/" + quoteNumber]);
    }
    if (status == 'REFREJECTED') {
      if (this.businessSource == 'DIRECT' && this.partnerID == 1) {
        localStorage.setItem('SchemeCode', schemeCode);
        this._route.navigate(["agentMotor/MTquotepage/update/" + quoteNumber]);
      }
    }
    if (status == 'ADDITIONALINFO') {
      if (this.businessSource != 'DIRECT' || this.partnerID != 1) {
        localStorage.setItem('SchemeCode', schemeCode);
        this._route.navigate(["agentMotor/MTquotepage/update/" + quoteNumber]);
      }
    }
  }
  
  getUserHerchy() {
    this.motorQuoteService.getPartnerUserList().subscribe(res => {
      this.userHerchyList = res.res_data;
      this.userHerchyList.forEach((item, index) => {
        if (this.localStorageData.UserId == item.UserId) this.retreiveQuoteForm.get("userSel")?.setValue(item);
      })
    });

  }

  ngOnChanges(changes: SimpleChanges) {
    this.userHerchyList.forEach((item, index) => {
      if (changes.partnerUser.currentValue.UserId == item.UserId)
        this.retreiveQuoteForm.get("userSel")?.setValue(item);
    })
    setTimeout(() => {
      this.serachQuote();
    }, 2000);
  }

  getUserList() {
    this.motorQuoteService.getUsers(this.retreiveQuoteForm.value.partner).subscribe(res => {
      this.userHerchyList = res.res_data;
    });
  }

  //display quick quote details in table
  showquickData(type) {
    let quickQuote = []
    let fullQuote = []
    this.quotations.forEach(element => {
      if (element.QuoteType == "QUICKQUOTE" && element.IsRenewal == 0) {
        quickQuote.push(element)
      }
      else if (element.QuoteType == "FULLQUOTE" && element.IsRenewal == 0) {
        fullQuote.push(element);
      }

    });
    if (type == 'quickQuote') {
      this.tableData = quickQuote
    }
    else if (type == 'fullQuote') {
      this.tableData = fullQuote
    }
    else {
      this.tableData = this.quotations
    }
  }

  expiredquickData(type) {
    let expiredQuickquote = []
    let expiredFullquote = []
    let renewalQuote = []
    this.quotations.forEach(element => {
      if (element.QuoteType == "QUICKQUOTE") {
        expiredQuickquote.push(element)
      }
      else if (element.QuoteType == "FULLQUOTE" && element.IsRenewal == "0") {
        expiredFullquote.push(element);
      }
      else if (element.IsRenewal == "1") { renewalQuote.push(element); }
    });
    if (type == 'expiredQuickquote') {
      this.tableData = expiredQuickquote
    }
    else if (type == 'expiredFullquote') {
      this.tableData = expiredFullquote
    }
    else if (type == 'Renewal') {
      this.tableData = renewalQuote
    }
    else {
      this.tableData = this.quotations
    }
  }

  //reset data
  sendPaymentLink(quotNo, statusDesc, schemeCode, emailId, partnerId) {
    this.motorQuoteService.sendPaymentLinkNew(quotNo).subscribe(res => {
      let payRes = res;
      if (payRes.res_code == 1) {
        //  this.pageLoader = false;
        this.motorQuoteService.sendReferralMailToAdmin(quotNo, '', emailId, 'PAYMENTLINKSENT', '', '', '', '', '').subscribe(res => {
        });
        Swal.fire('', 'Payment link has been sent to customer for the reference no. ' + quotNo, 'success');
      }
    });
  }

  //show transaction stage
  showTransactionStage(quotNo) {
    this.webQuoteNumber = quotNo;
    const dialogRef = this.dialog.open(this.Showtransaction);
   
  }

  //save transaction stage data
  saveTransactionStageData(){
    this.motorQuoteService.getTransactionStageData().subscribe(res=>{
     this.transactionarr = res.transactionStageArr
    })
  }
  onSelectionChange(event:any){
    this.changeStatus = event.source.value;
  }
  sendTransactionStatus(transaction_status) {
    
    this.transactionStageData.reset();
    this.showring = true;
    this.trstageData = false;
    transaction_status = this.changeStatus;
    if (transaction_status.name == 'Customer Accepted') {
      this.popupTitle = "Accept the Customer";
      this.transaction_type = 'TRANSCATIONSTAGE';
      this.transaction_condtion_type = 1;
    }
    if (transaction_status.name == 'Sent to Customer by Email') {
      this.popupTitle = "Sent email to the customer";
      this.transaction_type = 'TRANSCATIONSTAGE';
      this.transaction_condtion_type = 2;
    }
    if (transaction_status.name == 'Negotiation') {
      this.popupTitle = "Negotiation";
      this.transaction_type = 'TRANSCATIONSTAGE';
      this.transaction_condtion_type = 3;
    }
    if (transaction_status.name == 'Confirmed by Customer') {
      this.popupTitle = "Confirm from the customer";
      this.transaction_type = 'TRANSCATIONSTAGE';
      this.transaction_condtion_type = 4;
    }
    // const dialogRef = this.dialog.open(this.statusquote);
    let extraField = { sumInc: this.sumInc, chgDeduct: this.chgDeduct, optBenfit: this.optBenfit }
    // this.motorQuoteService.sendReferralMailToAdmin(this.webQuoteNumber, encodeURIComponent(this.transactionDescription), this.this.emailadd, transaction_type, refer_type, )
    this.motorQuoteService.sendReferralMailToAdmin(this.webQuoteNumber, encodeURIComponent(this.transactionDescription), this.emailadd, this.transaction_type, this.changeStatus, '', this.transactionDescription, this.tempMultipleDocData, extraField).subscribe(res => {
      console.log(res);
      if (res.response_code == 1) {
        this.showring = false;
        this.close();
        this._route.navigate[('/retrivequote')];
      }

     });
  }

  // sendStatusMailToAdmin(type) {
  //   alert(type)
  //   if (type == 1 || type == 2 || type == 3 || type == 4) {
  //     if (this.transactionDescription == '') {
  //       this.validtnMsg = true;
  //       return false;
  //     }
  //     let transaction_type;
  //     let event_type;
  //     if (type == 7) {
  //       event_type = 'QUOTECONFIRMED';      // BOR Document
  //       transaction_type = '';
  //       // this.policyStatus = 'CONFIRM';
  //     }
     
      
  //   }

  // }

  //reset data
  resetData(type) {
    let resetdata = []
    this.quotations.forEach(element => {
      resetdata.push(element)
    });
    if (type == 'resetdata') {
      this.tableData = this.quotations
    }
  }
}
