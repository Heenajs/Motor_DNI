import { ComponentFixture, TestBed } from '@angular/core/testing';

import { sendpaymentlinkComponent } from './sendpaymentlink.component';

describe('sendpaymentlinkComponent', () => {
  let component: sendpaymentlinkComponent;
  let fixture: ComponentFixture<sendpaymentlinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ sendpaymentlinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(sendpaymentlinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
