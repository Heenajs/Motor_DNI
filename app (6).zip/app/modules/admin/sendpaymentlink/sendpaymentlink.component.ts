
import { Component, OnInit, ElementRef,Input,EventEmitter,SimpleChanges, TemplateRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { MotorquoteService } from '../../service/motorquote.service';
import {ViewpolicyService} from '../../service/viewpolicy.service';
import { GlobalService } from '../../service/global.service';
import { Router } from '@angular/router';
import * as xlsx from 'xlsx';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2';
interface LOB {
  value: string;
  label: string;
}

interface Partner {
   value: string;
   viewValue: string;
 }
 interface Nationality{
   value: string;
   viewValue: string;
 }
 

 @Component({
     selector: 'app-sendpaymentlink',
    templateUrl: './sendpaymentlink.component.html',
     styleUrls: ['./sendpaymentlink.component.scss']
  })
export class sendpaymentlinkComponent implements AfterViewInit  {

  viewPolicyForm:FormGroup;
  sendLinkForm:FormGroup;

  date = new Date(Date.now());
  frdate= new Date(new Date().setDate(new Date().getDate() - 7));
  partnersArr: any = [];
  // lobs: LOB[] = [
  //   { value: 'MT', label: 'Motor' },
  // ];

 
minDate =new Date(new Date().setMonth(new Date().getMonth() ));

fromMaxDate = new Date();
fromMinDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));

  displayedColumns: string[] = ['policyno', 'insname', 'exdate', 'policytype','existsi','existprem','sms','email'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  partnerID: any;
  localStorageData: any;
  partnerVal: any;
  quoteRes: boolean = false;
  gridStatus: boolean = false;
  policyData = {
    InsuredEmail: '', 
    CRS_ASSURED_CODE : "",
  };
  sendEmailData: any = [];
  emailSend: boolean = false;
  res_Status:any;
  userName: any; 
  localStorDta: any;
  userrole: any;
  QNumber:any;
  QNumber1:any;
  Email:any;
  LinkForm: boolean = true;
  loader: boolean = false;
  show: boolean = false;

  minDate1 = new Date(Date.now());

  statusArr  = [
    {value: 'ALL', label: 'ALL'},
    {value: 'APPROVED', label: 'Policy Approved'},
    {value: 'CANCELLED', label: 'Policy Cancelled'},
    {value: 'ISSUED', label: 'Policy Issued'}
   
   
  ];

  @Input() partnerUser ; // decorate the property with @Input()
  BranchId: any;
   AssuredCode: string;
  
  ngAfterViewInit() {
          this.dataSource.paginator = this.paginator;
  }

  constructor( public dialog: MatDialog,private formBuilder: FormBuilder,public motorQuoteService: MotorquoteService,public globalService: GlobalService, public viewpolicyService:ViewpolicyService, private router: Router) { }

  ngOnInit(): void {

    this.localStorageData = this.globalService.getLocalStorageData();
    this.userrole = this.localStorageData.UserRole;
    this.userName = this.localStorageData.EmailAddress;
    this.partnerID = this.localStorageData.PartnerId;
    this.BranchId = this.localStorageData.BranchId;
    this.viewPolicyForm = this.formBuilder.group({
      QNumber: ['', Validators.required],
      QNumber1: ['',],
      Email: ['',],
      partner: ['', Validators.required],
      userSel: ['', Validators.required],
      policyFromDate: [new Date(new Date().setDate(new Date().getDate()-7)),this.frdate, Validators.required],
      policyToDate: [this.date, Validators.required],
      lob: ['MT', Validators.required],
      status:[this.statusArr[0]],
      optionalText : ['']
    });
    this.sendLinkForm = this.formBuilder.group({
     
      QNumber1: ['', Validators.required],
      Email: ['',[Validators.compose([Validators.required,Validators.pattern('[a-zA-Z0-9.-_-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])]],
    
    });


    this.getQuotationFormData();
    this.dateValidation();
    this.getUserHerchy();

    
  }

  getUserList(){
    this.motorQuoteService.getUsers(this.viewPolicyForm.value.partner).subscribe(res => {

      this.userHerchyList = res.res_data;

      this.viewPolicyForm.get("userSel").setValue(this.userHerchyList[0]);
     
  });
    
  }
   //getformdata
   getQuotationFormData() {
    this.motorQuoteService.getQuotationFormData().subscribe(response => {
        let formDataRes = response;
        this.partnersArr = formDataRes.Partners;
        this.partnersArr.forEach((item, index) => {
          if (item.PartnerId == this.partnerID) {
                this.partnerVal = item.PartnerId;
          }
        }); 
        this.viewPolicyForm.get('partner').setValue(this.partnerVal);

        

      //  this.callSearchHistory();
        
      });
  }
  convertDate(inputFormat) {
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat);
    return ([pad(d.getMonth() + 1), pad(d.getDate()), d.getFullYear()].join('/'));
  }

  dateValidation(){
    
    let datechange =new Date(this.viewPolicyForm.value.policyFromDate);
  
    this.frdate = new Date(datechange.setMonth(datechange.getMonth() + 1));
    if(this.frdate > this.date){
      this.frdate = new Date(Date.now())
    }
    this.minDate1 = new Date(this.viewPolicyForm.value.policyFromDate);
    this.viewPolicyForm.get('policyToDate').setValue(this.frdate)
    // console.log( this.minDate1)
  }

  openImgDialog() {
    const dialogRef = this.dialog.open(this.callAPIDialog);
    dialogRef.afterClosed().subscribe((result) => { });
    // this.image = img;
  }
  callSearchHistory(){
    if(sessionStorage){
    let sessonData =JSON.parse(sessionStorage?.getItem("policyFormDataSessionData"));
  
    //this.viewPolicyForm.get('lob').setValue(sessonData?.lob);
    this.viewPolicyForm.get('policyFromDate').setValue(sessonData?.policyFromDate);
    this.viewPolicyForm.get('policyToDate').setValue(sessonData?.policyToDate);
    this.viewPolicyForm.get('optionalText').setValue(sessonData?.optionalText);

    this.getPolicies();
    }
  }

  //getpolicy
  getPolicies() {
    this.quoteRes=true; 
    if (this.viewPolicyForm.invalid) {
      return
    }
    var viewPolicyFormData:any = {partner:this.viewPolicyForm.value.partner,
                                  lob:this.viewPolicyForm.value.lob,
                                  policyFromDate:this.viewPolicyForm.value.policyFromDate,
                                  policyToDate:this.viewPolicyForm.value.policyToDate,
                                  status:this.viewPolicyForm.value.status,
                                  optionalText:this.viewPolicyForm.value.optionalText,
                                } ;
    sessionStorage.setItem("policyFormDataSessionData", JSON.stringify(viewPolicyFormData));
    this.viewpolicyService.getPoliciesByUser(this.viewPolicyForm.value.partner,
                                             this.viewPolicyForm.value.userSel.UserId,
                                            this.viewPolicyForm.value.lob,
                                            this.viewPolicyForm.value.status,
                                            this.convertDate(this.viewPolicyForm.value.policyFromDate),
                                            this.convertDate(this.viewPolicyForm.value.policyToDate),
                                            this.viewPolicyForm.value.optionalText).subscribe(res => {
                                         
       
                this.policyData = res.data;
            
                if (res.res_code == 1) {
                 
                    this.res_Status = res.res_status;
                    this.quoteRes = false;
                }
                if (res.res_code == 2) {
                    this.res_Status = res.res_status;
                  
                    this.quoteRes = false;
                }
      });
    this.gridStatus = true;
  }

 
  getPolicies1() {  
    this.quoteRes = true;
    if (this.viewPolicyForm.invalid) {
      this.quoteRes=false;
      Swal.fire("Please Enter Quotation Number","", "error");
      return
    } 
    
    var viewPolicyFormDatanew:any = {QNumber:this.viewPolicyForm.value.QNumber,
    } ;

    sessionStorage.setItem("policyFormDataSessionData", JSON.stringify(viewPolicyFormDatanew));

    this.viewpolicyService.searchPaymentLinkDetails(this.viewPolicyForm.value.QNumber).subscribe(res => {
                        
                                                                              if (res.response_code == 1) {
                                                                                 this.res_Status = res.response_sucess;
                                                                                 this.quoteRes = false;
                                                                                 this.policyData = res.QuotationData[0];
                                                                                 this.Email = this.policyData.InsuredEmail
                                                                                 this.AssuredCode = this.policyData.CRS_ASSURED_CODE
                                                                                }
                                                                              if (res.response_code == 2) {
                                                                                 this.res_Status = res.response_sucess;
                                                                                 this.quoteRes = false;
                                                                                 }
                                                                             });
  }
  insuredEmailControl = new FormControl('', [
    Validators.required,
    Validators.email, // Assuming you want to validate the email format
  ]);

  // Create a variable to hold error messages
  emailError = '';

  // Function to show error message
  showEmailError() {
    if (this.insuredEmailControl.hasError('required')) {
      this.emailError = ' Please Enter Email Address ';
    } else if (this.insuredEmailControl.hasError('email')) {
      this.emailError = 'Enter Valid Email Address';
    }}


  sendLink(){

    console.log(this.viewPolicyForm.value.QNumber) 
    this.loader = true;
    
    this.viewpolicyService.sendPaymentLink(this.viewPolicyForm.value.QNumber,this.policyData.InsuredEmail).subscribe(
      (response) => {

        if (response.response_code == 1) {
          this.AssuredCode = response.response_data[0].AssuredCode
          Swal.fire("Email sent successfully.", response.response_data[0].StatusMsg + "\n" +this.policyData.InsuredEmail,'success');
          this.loader = false;
           
        }
       if (response.response_code == 2) {
        this.AssuredCode = response.response_data[0].AssuredCode
               console.log(response.response_data[0].StatusMsg)
          //  Swal.fire("Email sent unsuccessfully. ", " MIGRATION FAILED - Policy not migrated error code 1020 " + this.sendLinkForm.value.Email, 'warning');
        Swal.fire("Email Sending Failed. ", response.response_data[0].StatusMsg + "\n"+ this.policyData.InsuredEmail, 'warning');

        this.loader = false;
      }

      // this.dialog.closeAll();
      //   console.log('Data sent successfully:', response);
      //   Swal.fire("Email sent successfully.","Email has been sent to customer with payment link on following email address " +this.sendLinkForm.value.Email,'success');
      //   this.loader = false;
      // },
      // (error) => {
      //   console.error('Error sending data:', error);
      //   Swal.fire("Email sent unsuccessfully.","We are facing issue while sending email, please check your email address " +this.sendLinkForm.value.Email,'warning');
      //   this.loader = false;
      });

  }

  close(){
    this.dialog.closeAll();
    this.sendLinkForm.get('QNumber1').setValue('')
    this.sendLinkForm.get('Email').setValue('')
  }
  // private showSnackBar(message: string): void {
  //   this.snackBar.open(message, 'Close', {
  //     duration: 3000, // Duration in milliseconds for how long the snackbar should be visible
  //   });
  // }


  //Export to Excel
  exportToExcel(){
    const ws: xlsx.WorkSheet =  xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'epltable.xlsx');
  }

  //viewpolicydetailpage
  viewPolicyDetail(policyNo){
    this.router.navigate(['viewpolicy/viewpolicydetail/' + this.viewPolicyForm.value.partner + "/" + this.userName + "/" + this.viewPolicyForm.value.lob + "/" + policyNo ]);
  }
  
 

 userHerchyList = [];
getUserHerchy(){

  this.motorQuoteService.getPartnerUserList().subscribe(res => {

      this.userHerchyList = res.res_data;
      this.userHerchyList.forEach((item, index) => {
 
        if(this.localStorageData.UserId==item.UserId) this.viewPolicyForm.get("userSel")?.setValue(item);
      })
  });



}



resetForm(){
  this.viewPolicyForm.get('QNumber').setValue('')
}

  

  
}

export interface PeriodicElement {
  insname: string;
  policyno: number;
  exdate: string;
  policytype: string;
  existsi:string;
  existprem:string;
  sms:string;
  email:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
 
  
];