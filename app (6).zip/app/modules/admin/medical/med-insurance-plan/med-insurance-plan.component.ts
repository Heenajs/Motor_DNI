import { Component, OnInit } from '@angular/core';
import {MatCheckboxModule} from '@angular/material/checkbox';
@Component({
  selector: 'app-med-insurance-plan',
  templateUrl: './med-insurance-plan.component.html',
  styleUrls: ['./med-insurance-plan.component.scss']
})
export class MedInsurancePlanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
