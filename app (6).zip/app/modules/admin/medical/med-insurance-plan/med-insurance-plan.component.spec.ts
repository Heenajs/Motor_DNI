import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedInsurancePlanComponent } from './med-insurance-plan.component';

describe('MedInsurancePlanComponent', () => {
  let component: MedInsurancePlanComponent;
  let fixture: ComponentFixture<MedInsurancePlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedInsurancePlanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedInsurancePlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
