/* eslint-disable @typescript-eslint/quotes */
/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/member-ordering */
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators,FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {MedicalService} from '../../service/medical.service';
import { GlobalService } from '../../service/global.service';
import Swal from 'sweetalert2';

interface Plan{
  value: string;
  viewValue: string;
 }
 interface Branch{
  value: string;
  viewValue: string;
 }
 interface CoverType{
  value: string;
  viewValue: string;
 }
 interface Gender{
  value: string;
  viewValue: string;
 }
 interface Mstatuss{
  value: string;
  viewValue: string;
 }
 interface Relationship{
  value: string;
  viewValue: string;
 }
 interface Visa{
  value: string;
  viewValue: string;
 }

 interface Visarigion{
  value: string;
  viewValue: string;
 }
 interface Partner{
  value: string;
  viewValue: string;
 }



@Component({
  selector: 'app-medical',
  templateUrl: './medical.component.html',
  styleUrls: ['./medical.component.scss']
})
export class MedicalComponent implements OnInit {

//formGroup
policyForm: FormGroup ; policyHolderForm: FormGroup; memberDetailsForm: FormGroup; sidebarForm: FormGroup;

//Variables
formDataRes: any; router: any;retrieveQuoteNumber: any = '';partnerId: any; PartyCode: any; cedantId: any; userId: any;businessSource: any; userRole: any; userType: any; RoleDesc: any; AccessGroup: any; localStorageData: any;
branchId: any; branchVal: any; quoteDetail: any; userName:any; partnerName:any; age:any;  memAge:any; childAge:any;  memberDetailStatus:boolean =false;isEdit:boolean = false; submited:boolean = false; i

//array
partnerArr:any=[];partnerBranchArr:any=[]; regionData:any=[]; covarageType:any=[]; genders:any=[]; maritalstatusArr:any=[]; nationality:any=[]; relationShipStatu:any=[];salaryData:any=[];policyPeriodArr:any=[]; policyHolderFormData:any = [];
RelationshipArr:any=[]; memberDetailFormData:any = []; 
//Data
maxDate = new Date();
minDate = new Date(Date.now());
date = new Date(new Date().setDate(new Date().getDate() + 30));
minDOB = new Date(new Date().setDate(new Date().getDate() - 365*99));
maxDOB = new Date(new Date().setDate(new Date().getDate() - 365*18));

// tableData =;
  constructor(public _route: Router,private formBuilder: FormBuilder, public _medicalService:MedicalService,public _activatedroute: ActivatedRoute, public globalService: GlobalService) { }

  ngOnInit(): void {
    this.partnerName=this.globalService.getLocalStorageData();
    this.localStorageData = this.globalService.getLocalStorageData();
    const routeParams = this._activatedroute.snapshot.params;
    console.log(this.localStorageData);
    this.userName = this.localStorageData.EmailAddress;
    this.partnerId = this.localStorageData.PartnerId;
    this.PartyCode = this.localStorageData.PartyCode;
    this.cedantId = this.localStorageData.CedantId;
    this.userId = this.localStorageData.UserId;
    this.businessSource = this.localStorageData.BusinessSource;
    this.userRole = this.localStorageData.UserRole;
    this.userType = this.localStorageData.UserType;
    this.RoleDesc = this.localStorageData.RoleDescs
    this.AccessGroup = this.localStorageData.AccessGroup
    this.policyForm = this.formBuilder.group(
        {
        email: ['',[Validators.compose([Validators.required,Validators.pattern('[a-zA-Z0-9.-_-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])]],
        visaregions: ['',Validators.required],
        coverType: ['',Validators.required],
        planType: ['',Validators.required],
        policyPeriod: ['',Validators.required],
        remark: ['',Validators.required],
        coverstartDate: [new Date(Date.now()),Validators.required],
        mobile: ['',Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
    });
    this.policyHolderForm = this.formBuilder.group(
    {
      cedantID:this.partnerName.Cedant_ID,
        Fname: ['',[Validators.required,Validators.minLength(3), Validators.maxLength(150),Validators.pattern('^[a-zA-Z \-\']+')]],
        Lname: ['',[Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]],
        dob: ['',Validators.required],
        gender: ['',Validators.required],
        nationality: ['',Validators.required],
        maritalstatus: ['',Validators.required],
        height: ['',Validators.required],
        weight: ['',Validators.required],
        salary: ['',Validators.required],
        visa: ['',Validators.required],
    });
    this.memberDetailsForm = this.formBuilder.group(
        {
        Mfname:['',[Validators.required,Validators.minLength(3), Validators.maxLength(150),Validators.pattern('^[a-zA-Z \-\']+')]],
        Mlname: ['',[Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]],
        relationship: ['',Validators.required],
        Mdob: ['',Validators.required],
        MmaritalStatus: ['',Validators.required],
        Mheight: ['',Validators.required],
        Mweight: ['',Validators.required],
        Mvisatype: ['',Validators.required],
        coc: ['',Validators.required],
        Msalary: ['',Validators.required],
        mgender: ['',[Validators.required]],
    });
    this.sidebarForm = this.formBuilder.group(
        {
            partner: ['',Validators.required],
            branch: ['',Validators.required],
            Abracnh: ['',Validators.required],
    });
    // this.policyForm.valueChanges.subscribe((selectedValue)  => {

    // });
    this.getQuotationFormData();
  
  }


  plan: Plan[] = [
    {value: '1', viewValue: 'Plan A'},
    {value: '2', viewValue: 'Plan B'},
    {value: '3', viewValue: 'Plan C'},
  ];
  

  relationship: Relationship[] = [
    {value: '1', viewValue: 'Mother'},
    {value: '2', viewValue: 'Father'},
  ];
  visaArr=  [ {value: '0', label: 'Visa Old'},{value: '1', label: 'Visa New '}]
  
  
  
  coverTypes: CoverType[] = [
    {value: 'steak-0', viewValue: 'Self'},
    {value: 'pizza-1', viewValue: 'Self and Dependent'},
    {value: 'tacos-2', viewValue: 'Domestic Helper'},
    {value: 'tacos-3', viewValue: 'Parent'},
    {value: 'tacos-4', viewValue: 'Self Investor'}
  ];

  coverstartDate = new Date(Date.now());
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  //----------- CONVERT DATE INTO DD/MM/YYYY FORMAT ------------//
  convertDate(inputFormat) {
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat);
    return ([ pad(d.getDate()),pad(d.getMonth()+1),d.getFullYear()].join('-'));
  }

   //---------VALIDATION FOR AGE ------------//
   calucateAge()
   {
     let timeDiff = Math.abs(Date.now() - this.policyHolderForm.value.dob);
     this.age = Math.floor((timeDiff / (1000 * 3600 * 24))/365.25);    
   }

   // MEMBER DOB VALIDATION
   calucateMemAge(dob)
  {
    //dob = this.memberDetailForm.value.mdob;
    let timeDiff = Math.abs(Date.now() - dob);
    this.memAge = Math.floor((timeDiff / (1000 * 3600 * 24))/365.25);    
    this.childAge = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
    if(this.memberDetailsForm.value.relationship.label == "Child" && this.childAge <= 60){
        //Visa type status
        var indexV = this.visaArr.findIndex(function(obj, k) {
          return obj.value === '1';
        });
        let visaVal = this.visaArr[indexV];
        this.memberDetailsForm.get('visaType').setValue(visaVal);
        this.memberDetailsForm.get('visaDOEntry').setValue(this.memberDetailsForm.value.mdob);

    }
  }


  //get form data
  getQuotationFormData(){
    this._medicalService.getQuotationFormData().subscribe((res)=>{
      console.log(res);
      this.formDataRes = res;
      this.partnerArr = this.formDataRes.Partners;
      this.regionData = this.formDataRes.Region;
      this.covarageType = this.formDataRes.Coverage;
      this.genders = this.formDataRes.Gender;
      this.maritalstatusArr = this.formDataRes.MaritalStatus;
      this.nationality = this.formDataRes.Nationality;
      this.RelationshipArr = this.formDataRes.Relationship;
      this.salaryData = this.formDataRes.Salary;
      console.log(this.partnerArr);
      if(this.retrieveQuoteNumber == ''){
        this.sidebarForm.get("partner")?.setValue(this.partnerId); 
        this.getPartnerBranchList(); 
      }

    })
  }
  //get branch list data
  getPartnerBranchList() {
    this.partnerBranchArr = [];
   // console.log(this.sideForm.value.partnerID);
    this._medicalService
        .getpartnerBranch(this.sidebarForm.value.partner)
        .subscribe((res) => {
            let updateRes: any = res;
            this.partnerBranchArr = updateRes.branchList;
            this.branchId = updateRes.branchList[0];
            //  branch
            console.log('25658');
            console.log(this.retrieveQuoteNumber);
            if (this.retrieveQuoteNumber == '') {
                this.partnerBranchArr.forEach((item, index) => {
                    if (item.Id == this.branchId.Id) {
                        this.branchVal = item;
                    }
                });
                this.sidebarForm.get('branch')?.setValue(this.branchVal.Id);
                   this.sidebarForm.get('Abracnh')?.setValue(this.branchVal.Id);
            } else {
                this.sidebarForm.get('Abracnh')?.setValue(this.quoteDetail.CedantBrokerBranchId);
                this.sidebarForm.get('branch')?.setValue(this.quoteDetail.CedantBrokerBranchId);
            }
        });
}

//covarage data
coverageTypeData(){
  this.memberDetailStatus = (this.policyForm.value.coverType.Id == 2 || this.policyForm.value.coverType.Id == 3 || this.policyForm.value.coverType.Id == 4 || this.policyForm.value.coverType.Id == 5 || this.policyForm.value.coverType.Id == 7) ? true:false;
  // 
  if( (this.policyHolderFormData.length > 1 && (this.policyForm.value.coverType.Id == 1 || this.policyForm.value.coverType.Id == 6)) 
  || (this.policyHolderFormData.length > 1 && (this.policyForm.value.coverType.Id == 3 || this.policyForm.value.coverType.Id == 2 || this.policyHolderForm.value.coverType.Id == 4 || this.policyHolderForm.value.coverType.Id == 5 || this.policyHolderForm.value.coverType.Id == 7))
  ){
    Swal.fire({
     // title: 'Are you sure?',
      text: "If you change coverage type, you will lost all members detail",
      
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, change it!'
    }).then((result) => {
      if (result.value) {
          if(this.policyForm.value.coverType.Id == 1 || this.policyForm.value.coverType.Id == 6){
            this.policyHolderFormData.splice(1, this.policyHolderFormData.length);
          }
          if(this.policyForm.value.coverType.Id == 5 || this.policyForm.value.coverType.Id == 4){
            this.policyHolderFormData.splice(1, this.policyHolderFormData.length);
          }                
      }
     else if (result.dismiss === Swal.DismissReason.cancel) {
            Swal.fire("Cancelled", "Member's detail not Deleted :)", "error");
          }
    })
  }
  this.addPrincipalMember();
}
//All Menu Data
getAllMenuData(){
  let userName =  this.userName;
  this._medicalService.getAllMenuData(userName).subscribe((res)=>{
    console.log(res);
  })
}

  //get Policy Period
  getPolicyPeriod(visa_region){
    console.log(visa_region);
    this._medicalService.getPolicyPeriod(visa_region).subscribe((res) => {
    if(res.response_code == 1){
      this.policyPeriodArr = res.policy_period;
      this.policyForm.get('policyPeriod').setValue(this.policyPeriodArr[0]);
    }
  });
  }

  //------------------ CHECKING CONDIOTIONS ON MARITAL STATUS & GENDER AGAINST RELATIONSHIP ---------------//
checkMaritalStatus(){
   
  if(this.memberDetailsForm.value.relationship.label == "Wife" || this.memberDetailsForm.value.relationship.label == "Husband"){
    //Marital status
    var indexM = this.maritalstatusArr.findIndex(function(obj, k) {
      return obj.value === 'M';
    });
    let maritalStatusVal = this.maritalstatusArr[indexM];
     this.memberDetailsForm.get('MmaritalStatus').setValue(maritalStatusVal);
  }

  if(this.memberDetailsForm.value.relationship.label == "Child"){
  
   
    //Marital status
    var indexM = this.maritalstatusArr.findIndex(function(obj, k) {
      return obj.value === 'S';
    });
    let maritalStatusVal = this.maritalstatusArr[indexM];
     this.memberDetailsForm.get('MmaritalStatus').setValue(maritalStatusVal);
  }

     if(this.memberDetailsForm.value.relationship.label == "Wife" || this.memberDetailsForm.value.relationship.label == "Mother" ){
          //Gender
          var indexG = this.genders.findIndex(function(obj, k) {
            return obj.value === 'F';
          });
          let genderVal = this.genders[indexG];
          this.memberDetailsForm.get('mgender').setValue(genderVal);
        }

        if(this.memberDetailsForm.value.relationship.label == "Husband" || this.memberDetailsForm.value.relationship.label == "Father" ){
          //Gender
          var indexG = this.genders.findIndex(function(obj, k) {
            return obj.value === 'M';
          });
          let genderVal = this.genders[indexG];
          this.memberDetailsForm.get('mgender').setValue(genderVal);
        }  
  }


  //Add Member
  addPrincipalMember(){
    if(this.policyForm.value.height == '' &&  this.policyForm.value.weight == ''){
      this.policyForm.value.height = 175;
      this.policyForm.value.weight = 75;
    }
    let tempPolicyHolderFormData = {
      partner:this.policyForm.value.partner,
      branch:this.policyForm.value.branch,
      cedantID:this.partnerName.Cedant_ID,
      region:this.policyForm.value.visaregions,
      coverageType:this.policyForm.value.coverType,
      email:this.policyForm.value.email,
      mobileNum:this.policyForm.value.mobile,
      coverStartDate :this.convertDate(this.policyForm.value.coverstartDate),
      policyPeriod:this.policyForm.value.policyPeriod.label,
      remarks: this.policyForm.value.remark,
      firstName:this.policyHolderForm.value.Fname,
      lastName:this.policyHolderForm.value.Lname,
      dob:this.convertDate(this.policyHolderForm.value.dob),
      gender:this.policyHolderForm.value.gender,
      maritalStatus:this.policyHolderForm.value.maritalstatus,
      height:this.policyHolderForm.value.height,
      weight:this.policyHolderForm.value.weight,
      salary:this.policyHolderForm.value.salary,
      visaType:this.policyHolderForm.value.visa,
      // visaDOEntry:this.convertDate(this.policyForm.value.visaDOEntry),
      relationship:(this.policyForm.value.coverType.Id == 1 || this.policyForm.value.coverType.Id == 2 || this.policyForm.value.coverType.Id == 3) ? this.RelationshipArr[7] : (this.policyForm.value.coverType.Id == 6 || this.policyForm.value.coverType.Id == 7) ? this.RelationshipArr[8] :'',
      age:this.age,
      // policyExpDate :this.convertDate(this.policyHolderForm.value.policyExpDate),
      formNumber:0,
    } 
    console.log(tempPolicyHolderFormData);
    console.log(this.policyHolderForm.value.gender.label);
    console.log(this.policyHolderForm.value.maritalstatus);
    if(this.policyHolderFormData.length > 0){
      if(this.policyHolderFormData[0].formNumber == 0 ){
            this.policyHolderFormData[0]=tempPolicyHolderFormData;
      }
  }
  else
     this.policyHolderFormData.push(tempPolicyHolderFormData);
  }
  // ----- ADD NEW MEMEBER --------//
addNewMember(){                    
  // console.log(this.memberDetailForm)
// this.submited = true;
  if(this.memberDetailsForm.invalid){
    return;
  }
 
  let sr_no=this.memberDetailFormData.length==0?1:this.memberDetailFormData.length+1;
  let tempmemberDetailFormData = 
    { memberId:sr_no,
      firstName:this.memberDetailsForm.value.Mfname,
      lastName:this.memberDetailsForm.value.Mlname,
      dob:this.convertDate(this.memberDetailsForm.value.Mdob),
      gender:this.memberDetailsForm.value.mgender,
      relationship:this.memberDetailsForm.value.relationship,
      salary:this.memberDetailsForm.value.Msalary,
      policyExpDate:this.convertDate(this.memberDetailsForm.value.coc),
      age:this.memAge,
      maritalStatus :this.memberDetailsForm.value.MmaritalStatus ,
      height : this.memberDetailsForm.value.Mheight,
      weight :this.memberDetailsForm.value.Mweight,
      visaType : this.memberDetailsForm.value.Mvisatype,
      // visaDOEntry : this.convertDate(this.memberDetailsForm.value.visaDOEntry)
  };

  if((this.memAge > 25  && this.memberDetailsForm.value.relationship.RelationshipId == 3) || (this.memAge < 40 && this.memAge > 90  && ( this.memberDetailsForm.value.relationship.RelationshipId == 4 || this.memberDetailsForm.value.relationship.RelationshipId == 5)) || (this.memAge < 18  && (this.memberDetailsForm.value.relationship.RelationshipId == 1 || this.memberDetailsForm.value.relationship.RelationshipId == 2 || this.memberDetailsForm.value.relationship.RelationshipId == 6 || this.memberDetailsForm.value.relationship.RelationshipId == 7))){
      this.submited = true;
    return;
  }

  if( this.memberDetailsForm.value.Mheight > 280 || this.memberDetailsForm.value.Mheight < 40 ){
      this.submited = true;
    return;
  }
  
  if( this.memberDetailsForm.value.Mweight > 380 || this.memberDetailsForm.value.Mweight < 1 ){
      this.submited = true;
    return;
  }

  
  if(this.policyForm.value.visaregions.label == 'Dubai' && this.memberDetailsForm.value.Msalary.SalaryId == 2){
      this.submited = true;
      return;
  }

  if(this.policyForm.value.coverType.Id == 5 || this.policyForm.value.coverType.Id == 4){
      if(this.policyHolderFormData.length==1){
            this.policyHolderFormData.push(tempmemberDetailFormData);
      }
  }

  else{
    this.policyHolderFormData.push(tempmemberDetailFormData);
  }
  
  console.log(this.policyHolderForm.value.coverageType.Id);
  console.log(this.policyHolderFormData.length);
  sessionStorage.setItem('additionalMemberDetails',JSON.stringify(this.memberDetailFormData));
  this.changeCoverageType();
  this.resetForm();
}
changeCoverageType(){
  console.log(this.policyForm.value.coverType.Id);
  console.log(this.policyHolderFormData.length);
   if((this.policyForm.value.coverType.Id == 5 || this.policyForm.value.coverType.Id == 4) && this.policyHolderFormData.length == 2){
     Swal.fire("you are not allowed to add more than one member");
     return false;
   }
  
 }
 //----------RESET MEMBER FORM-----------//
resetForm(){ 
  this.memberDetailsForm = this.formBuilder.group({
    Mfname:[''],
        Mlname: [''],
        relationship: [''],
        Mdob: [''],
        MmaritalStatus: [''],
        Mheight: [''],
        Mweight: [''],
        Mvisatype: [''],
        coc: [''],
        Msalary: [''],
        mgender: [''],
   
  });

 
  if(this.memberDetailsForm.invalid){
    return;
  }

 

}


  //get quotation for medical
  savePolicy(): void
  {
    console.log(this.policyHolderFormData);
    console.log(this.policyForm);
    if(this.policyForm.status=='INVALID' && this.policyHolderForm.status=='INVALID' && this.sidebarForm.status=='INVALID'  && this.memberDetailsForm.status=='INVALID')
    {
        this.policyForm.markAllAsTouched();
        this.sidebarForm.markAllAsTouched();
        this.policyHolderForm.markAllAsTouched();
        this.memberDetailsForm.markAllAsTouched();
        Swal.fire('Please fill all mandatory feilds.','', 'error');
    }
    else
    {
        // this.router.navigate(['/med_ins_plan']);
        this._route.navigate(['/med_ins_plan']);
        this._medicalService.getQuote(this.policyHolderFormData).subscribe((res)=>{
          console.log(res);
        })
        

    }
  }

}
