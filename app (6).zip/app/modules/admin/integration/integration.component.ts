import { Component, OnInit } from '@angular/core';
import { ElementRef, Input, EventEmitter, SimpleChanges, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AfterViewInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MotorquoteService } from '../../service/motorquote.service';
import { ViewpolicyService } from '../../service/viewpolicy.service';
import { GlobalService } from '../../service/global.service';
import { Router, ActivatedRoute } from '@angular/router';
import * as xlsx from 'xlsx';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { PeriodicElement } from '../viewpolicy/viewpolicy.component';



interface LOB {
  value: string;
  label: string;
}

interface Partner {
  value: string;
  viewValue: string;
}
interface Nationality {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-integration',
  templateUrl: './integration.component.html',
  styleUrls: ['./integration.component.scss']
})
export class IntegrationComponent implements AfterViewInit {

  integrateForm: FormGroup;



  // dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  partnerID: any;
  localStorageData: any;
  partnerVal: any;
  quoteRes: boolean = false;
  gridStatus: boolean = false;
  policyData: any = [];
  sendEmailData: any = [];
  emailSend: boolean = false;
  res_Status: any;
  userName: any;
  localStorDta: any;
  userrole: any;
  QNumber: any;
  QNumber1: any;
  Email: any;
  minDate1 = new Date(Date.now());
  

  statusArr = [
    { value: 'ALL', label: 'ALL' },
    { value: 'APPROVED', label: 'Policy Approved' },
    { value: 'CANCELLED', label: 'Policy Cancelled' },
    { value: 'ISSUED', label: 'Policy Issued' }


  ];

  @Input() partnerUser; // decorate the property with @Input()
  BranchId: any;
  retrieveQuoteNumber: any;
  RoleDesc: any;
  // ngAfterViewInit() {
  //         this.dataSource.paginator = this.paginator;
  // }

  constructor(public dialog: MatDialog, private formBuilder: FormBuilder, public motorQuoteService: MotorquoteService, public globalService: GlobalService, public viewpolicyService: ViewpolicyService, private router: Router, public _activatedroute: ActivatedRoute) { }
  ngAfterViewInit(): void {
    throw new Error('Method not implemented.');
  }

  ngOnInit(): void {
    this.localStorageData = this.globalService.getLocalStorageData();
    this.userrole = this.localStorageData.UserRole;
    const routeParams = this._activatedroute.snapshot.params;
    this.userName = this.localStorageData.EmailAddress;
    this.partnerID = this.localStorageData.PartnerId;
    this.BranchId = this.localStorageData.BranchId;
    this.RoleDesc = this.localStorageData.RoleDesc;
   
    this.integrateForm = this.formBuilder.group({
      QNumber2: ['',],
      Email: ['', Validators.required],
    });


  }

  
  //getformdata
  openImgDialog() {
    const dialogRef = this.dialog.open(this.callAPIDialog);
    dialogRef.afterClosed().subscribe((result) => { });
    // this.image = img;
  }





  // getPolicies1() {  
  //   this.quoteRes=true; 

  //   var viewPolicyFormDatanew:any = {QNumber:this.viewPolicyForm.value.QNumber,
  //   } ;

  //   sessionStorage.setItem("policyFormDataSessionData", JSON.stringify(viewPolicyFormDatanew));

  //   this.viewpolicyService.searchPaymentLinkDetails(this.viewPolicyForm.value.QNumber).subscribe(res => {
  //                        this.policyData = res.QuotationData[0];
  //                        if (res.response_code == 1) {
  //                         this.res_Status = res.response_sucess;
  //                         this.quoteRes = false;
  //                       }
  //                       if (res.response_code == 2) {
  //                         this.res_Status = res.response_sucess;

  //                         this.quoteRes = false;
  //                       }
  //                     });

  // }
  // sendLink() {
  //   const formData = this.sendLinkForm.value;

  //   this.viewpolicyService.sendPaymentLink(this.sendLinkForm.value.QNumber1,this.sendLinkForm.value.Email).subscribe(
  //     (response) => {
  //       // Handle success response from the API
  //       console.log('Data sent successfully:', response);
  //       // this.showSnackBar('Data sent successfully');
  //       Swal.fire("Email sent successfully.","Email has been sent to customer with payment link on following email address " +this.sendLinkForm.value.Email,'success');

  //     },
  //     (error) => {
  //       // Handle error response from the API
  //       console.error('Error sending data:', error);
  //       // this.showSnackBar('Error sending data');
  //       Swal.fire("Email sent unsuccessfully.","Email has been sent to customer with payment link on following email address " +this.Email,'warning');
  //     }
  //   );
  // }
  // private showSnackBar(message: string): void {
  //   this.snackBar.open(message, 'Close', {
  //     duration: 3000, // Duration in milliseconds for how long the snackbar should be visible
  //   });
  // }

  integrateData() { }

  //Export to Excel
  exportToExcel() {
    const ws: xlsx.WorkSheet = xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'epltable.xlsx');
  }

  //viewpolicydetailpage

  resetForm() {
    this.integrateForm.reset();
  }

}



