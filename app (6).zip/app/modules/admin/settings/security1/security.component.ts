import { ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MotorquoteService } from 'app/modules/service/motorquote.service';
import { GlobalService } from '../../../service/global.service';
import { FuseValidators } from '@fuse/validators';
@Component({
    selector       : 'settings-security',
    templateUrl    : './security.component.html',
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SettingsSecurityComponent implements OnInit
{
    securityForm: FormGroup;
    localStorageData: any;
    username: any;

    /**
     * Constructor
     */
    constructor(
        private _formBuilder: FormBuilder,
        public global_service : GlobalService,
        public _activatedroute: ActivatedRoute,
        public motorQuoteService: MotorquoteService,
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {

        this.localStorageData = this.global_service.getLocalStorageData();
  
        const routeParams = this._activatedroute.snapshot.params;
             
              this.username = this.localStorageData.EmailAddress
              console.log(this.username);
        // Create the form
        this.securityForm = this._formBuilder.group({
            currentPassword  : [''],
            newPassword      : ['', Validators.compose([Validators.required,
            Validators.pattern(
                /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}/
              )])],
            
            confirmPassword: ['', Validators.compose([Validators.required,
            Validators.pattern(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}/)])],

        },
        {
          validators: FuseValidators.mustMatch('newPassword', 'confirmPassword')
      }
        );
    }

    ConfirmedValidator(controlName: string, matchingControlName: string) {
        return (formGroup: FormGroup) => {
          const control = formGroup.controls[controlName];
          const matchingControl = formGroup.controls[matchingControlName];
          if (
            matchingControl.errors &&
            !matchingControl.errors.confirmedValidator
          ) {
            return;
          }
          if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ confirmedValidator: true });
          } else {
            matchingControl.setErrors(null);
          }
        };
      }

 savechanges(){

  console.log(this.securityForm);

  // Return if the form is invalid
  if ( this.securityForm.invalid )
  {
      return;
  }

this.motorQuoteService.resetpassword(this.securityForm.value).subscribe((res)=>{
console.log(res);

});

      }

}
