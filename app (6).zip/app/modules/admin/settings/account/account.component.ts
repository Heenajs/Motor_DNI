import { ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GlobalService } from '../../../service/global.service';
import { MotorquoteService } from '../../../service/motorquote.service';

@Component({
    selector       : 'settings-account',
    templateUrl    : './account.component.html',
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SettingsAccountComponent implements OnInit
{
    accountForm: FormGroup;
    profileData:any ;
    localStorageData: any;
    branch: any;
    partnerBranchArr:any=[];
    partnerId: any;
    branchNumber: any;
    branchVal: any;

    /**
     * Constructor
     */
    constructor(
        private _formBuilder: FormBuilder,
        public motorQuoteService: MotorquoteService,
        public globalService: GlobalService
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {

        this.localStorageData = this.globalService.getLocalStorageData();
        console.log(this.localStorageData);
                    this.branch = this.localStorageData.RoleDesc;
                    this.partnerId= this.localStorageData.PartnerId;
        // Create the form
        this.accountForm = this._formBuilder.group({
            name    : [''],
            username: [''],
            title   : [''],
            company : [''],
            about   : [''],
            email   : ['', Validators.email],
            phone   : [''],
            country : [''],
            officePhone: [],
            _dob: [''],
            branchID: ['']
        });

        this.getUserDetail();
        this.getPartnerBranchList();
    }


    getUserDetail(){

        this.motorQuoteService.profileDetail().subscribe(res=>{


            this.profileData = res[0];

            this.accountForm.get("name")?.setValue(this.profileData.UserName);
            this.accountForm.get("email")?.setValue(this.profileData.EmailAddress); 
            this.accountForm.get("phone")?.setValue(this.profileData.MobileNumber);
            this.accountForm.get("officePhone")?.setValue(this.profileData.OfficeNumber);
            this.accountForm.get("_dob")?.setValue(this.profileData.UserDOB);
            this.accountForm.get("title")?.setValue(this.profileData.UserRole);
        })
    }

    onFileChanged(event){

    }
    getPartnerBranchList() {
        this.partnerBranchArr = [];
    
       // console.log(this.sideForm.value.partnerID);
    
        this.motorQuoteService
            .getpartnerBranch(this.partnerId)
            .subscribe((res) => {
                let updateRes: any = res;
    
                this.partnerBranchArr = updateRes.branchList;
                this.branchNumber = updateRes.branchList[0];
    
                //  branch
                console.log('25658');
               // console.log(this.retrieveQuoteNumber);
              this.partnerBranchArr.forEach((item, index) => {
                        if (item.Id == this.branchNumber.Id) {
                            this.branchVal = item;
    
                        }
                    });
                    console.log(  this.branchVal);
                    this.partnerBranchArr=[];
                    this.partnerBranchArr.push({
                        BranchName: this.branchVal.BranchName
                    })
           this.accountForm.get('branchID')?.setValue(this.partnerBranchArr[0]);
                    
               
            });
    }
}
