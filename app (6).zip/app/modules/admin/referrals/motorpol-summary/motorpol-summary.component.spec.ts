import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorpolSummaryComponent } from './motorpol-summary.component';

describe('MotorpolSummaryComponent', () => {
  let component: MotorpolSummaryComponent;
  let fixture: ComponentFixture<MotorpolSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotorpolSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotorpolSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
