import {
  Component,
  OnInit,
  ViewChild,
  ɵConsole,
  ElementRef,
  Directive,
  TemplateRef,
} from "@angular/core";

import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
} from "@angular/forms";

import Swal from "sweetalert2";
// import { AppDateAdapter, APP_DATE_FORMATS } from '../motorquote/date.adapter';
import { Router, ActivatedRoute } from "@angular/router";
import { ReplaySubject, Subject } from "rxjs";
import { take, takeUntil } from "rxjs/operators";
import { Observable, Subscription, fromEvent } from "rxjs";

import { MatSelectModule } from "@angular/material/select";

import { MatDialog } from "@angular/material/dialog";
import { AuthService } from "app/core/auth/auth.service";
import { StepperSelectionEvent } from "@angular/cdk/stepper";
import { MotorquoteService } from "app/modules/service/motorquote.service";
import { GlobalService } from "app/modules/service/global.service";

interface Partner {
  value: string;
  viewValue: string;
}
interface Nationality {
  value: string;
  viewValue: string;
}
interface Renewstatus {
  value: string;
  viewValue: string;
}

interface Gender {
  value: string;
  viewValue: string;
}
interface Claimstatus {
  value: string;
  viewValue: string;
}

interface MortageBank {
  Id: number;
  InstituteName: string;
  InstituteCode: string;
  CRS_Bank_Map_Code: string;
}

interface PlateCategory {

  label: string;
  value: string;
}

interface industry {
  id: number;
  IndustryName: string;
 
}
@Component({
  selector: "app-motorpol-summary",
  templateUrl: "./motorpol-summary.component.html",
  styleUrls: ["./motorpol-summary.component.scss"],
})
export class MotorpolSummaryComponent implements OnInit {
  @ViewChild("referaquote") referaquote: TemplateRef<any>;

  // DECLARE ARRAY
  savePlanDetailArr: any = [];
  quoteDetail: any = [];
  slectedOptBenefit: any = [];
  optionalBenefit: any = [];
  quotationHistoryArr: any = [];
  public termsAndCondition: any = [];
  
  genders: Gender[] = [
    { value: "M", viewValue: "Male" },
    { value: "F", viewValue: "Female" },
  ];

  public maskEid = [ /[1-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/,/\d/,'-', /\d/, /\d/, /\d/, /\d/,/\d/, /\d/, /\d/, '-',/\d/, ] ;


  // DECLARE VARIABLES
  public webQuoteNum: any;
  TotalPremium: any;
  quoteNumber: any;
  emailId: any;
  pageLoader: boolean = true;
  BaseContribution: any;
  localStorageData: any;
  businessSource: any;
  partnerId: any;
  userAccessStatus: any;
  prevInsExpDate: any;
  quoteStatus: any;
  showLoader: boolean = false;
  public policyStatus: any;
  public showTerms: boolean = false;
  issuePolicyBtnAccess: boolean = false;
  onlinePayBtnAccess: boolean = false;
  invalidEID: boolean = false;

  public accept_terms: boolean = false;
  disable_btns: any;
  public referalModel: boolean = false;
  public referalPopUp: boolean = false;
  public referalDescription: any = "";
  toDay = new Date(Date.now());
  refer_type: string;
  refer_condtion_type: number;
  validtnMsg: boolean;
  todayDate = new Date(Date.now());
  
  emailadd: any;
  startMaxDate = new Date(new Date().setDate(new Date().getDate() + 30));
  EditDataForm: FormGroup;
  quoteBtn: any;
  language_code = "ENG";
  country = "United Arab Emirates";
  vhclBodyTypeArr: any = [];
  vehitrims: any = [];
  tempRepairTypeArr: any = [];
  cityArr: any = [];
  plateCatigoryData: any = [];
  multilpleFile: any = [];
  coverData: any = [];
  NCDData: any = [];
  benfPremIdArray: any = [];
  quoteDetailArr: any = [];
  bankDetail: MortageBank[];
  quoteDetailDataForCUst: any = [];
  plateCodeArray: any = [];
  tempAdditionalDoc: any = [];
  document_data: any = [];
  vehicleData: any = [];
  tempDocArray: any = [];
  retrieveData: any = [];
  tempBenefitData: any = [];
  tempMultipleDocData: any = [];
  additionalDocFile: any = [];
  plateCatArray: any = [];
  industryTypeArr: any = [];
  tempTransactionTypeArr: any = [];
  partnerBranchArr: any = [];
  Platecategory: any;
  occupatindata: any;
  unauthorizedAccess: boolean = false;
  headerDesclaimer: any;
  Desclaimer: boolean = false;
  vhclColorArr: any;
  userId: any;
  userRole: any;
  isvisited: boolean = true;

  sendPaymentLinkBtnAccess: boolean = false;
  totalPremium: any;
  vatAmount: any;
  premium: any;
  trimName: any;
  vehicleModel: any;
  insuredName: any;
  policyWebNum: any;
  plate_code: any;
  tcMin=10;
  tcMax = 10;
  
  public plateFilterCtrl: FormControl = new FormControl();
  public industryFilterCtrl: FormControl = new FormControl();
  public filteredPlateCat: ReplaySubject<PlateCategory[]> = new ReplaySubject<PlateCategory[]>(1);
  public industryTypeFilter: ReplaySubject<industry[]> = new ReplaySubject<industry[]>(1);
  private _onDestroy = new Subject<void>();
  payLink_email: any;
  transactionTypeArray: { value: string; label: string; }[];
  issueReadOnly: boolean= false;
  btnClickLoadder:boolean=false;
  value: any;
  constructor(
    public _route: Router,
    public _activatedroute: ActivatedRoute,
    public motorQuoteService: MotorquoteService,
    public formBuilder: FormBuilder,
    public dialog: MatDialog,
    private el: ElementRef,
    private _authService: AuthService,
    public globalService: GlobalService
  ) {}
  @ViewChild("termsandconditions") termsandconditions: TemplateRef<any>;
  ngOnInit(): void {
    this.pageLoader = true;
    this.EditDataForm = this.formBuilder.group({
      adtnl_detail_email: ["", Validators.required],
       e_eid:['',Validators.required],
      e_gender: ["", Validators.required],
      d_driv_lic_num: ["", Validators.required],
      e_name: ["", Validators.required],
      adtnl_detail_mobile: ["", Validators.required],
      //   reg_place:['',Validators.required],
   //   rg_type:['',Validators.required],
       rg_plateCode:['',Validators.required],
      po_box_number: ["", Validators.required],
      po_box_location: ["", Validators.required],
      reg_place:["", Validators.required],
    //  plate_code:["", Validators.required],
      rg_traffic_plate_num:["", Validators.required],
      plate_category:["",Validators.required],
      startDate:["",Validators.required],
      driver_occupation: ["", Validators.required],
      d_TC_number: ["", Validators.required],
      rg_mortgage: [""],
      // rg_traffic_plate_num:['',Validators.required],
      rg_engin_num: ["", Validators.required],
      vhclColor: ["", Validators.required],
      rg_tc_num:["", Validators.required],
      transaction_type : ['',[Validators.required]],
      TRN_num : [''],
      trade_lic_num : [''],
      vat_register : ['No'],
      industry_type : [''],
      // startDate:[new Date(Date.now()), Validators.required],
    });

    this.localStorageData = this.globalService.getLocalStorageData();
    this.businessSource = this.localStorageData.BusinessSource;
   
    this.partnerId = this.localStorageData.PartnerId;
   
    const routeParams = this._activatedroute.snapshot.params;
    this.userId = this.localStorageData.UserId;
    if (routeParams.quoteNum) {
      this.webQuoteNum = routeParams.quoteNum;
    }
 
    localStorage.setItem("policyWebNum", routeParams.quoteNum);
    // this.policyWebNum = this.localStorageData.routeParams.quoteNum;

    this.userRole = this.localStorageData.UserRole;

    if (this.userRole == "CEDANT") this.userRole = "ADMIN/UW";

    if (this.userRole == "BANCA") this.userRole = "BROKER";

    this.getOccupation();
    this.getAllFormData();
    this.getUserAccessPermission();
    this.getIndustryTypes();

    setTimeout(() => {
      this.getQuotationDetial();
      this.getQuotationDetailPdf();
    }, 3000);

    this.checkAccessForPolicyIssueButtons();
    this.CheckAccessOnLoad();

    this.filteredPlateCat.next(this.plateCatArray.slice());

    this.plateFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.filterPlateCat();
      });


      this.industryFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {

        this.industryfilter();
      });

  }

  convertDate(inputFormat) {
    function pad(s) {
      return s < 10 ? "0" + s : s;
    }
    var d = new Date(inputFormat);
    //return ([ d.getFullYear(),pad(d.getMonth()+1),pad(d.getDate())].join('-'));
    return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join("-");
  }

  partner: Partner[] = [
    { value: "steak-0", viewValue: "Product A" },
    { value: "pizza-1", viewValue: "Product B" },
    { value: "tacos-2", viewValue: "Product C" },
  ];
  nation: Nationality[] = [
    { value: "steak-0", viewValue: "Dubai" },
    { value: "pizza-1", viewValue: "China" },
    { value: "tacos-2", viewValue: "France" },
  ];
  renewstatus: Renewstatus[] = [
    { value: "steak-0", viewValue: "All" },
    { value: "pizza-1", viewValue: "Expired Policies" },
    { value: "tacos-2", viewValue: "Non Expired Policies" },
  ];

  claimstatus: Claimstatus[] = [
    { value: "steak-0", viewValue: "No Claims" },
    { value: "pizza-1", viewValue: "Has Claims" },
  ];

  checkTermsCond() {
    this.accept_terms = !this.accept_terms;
  }

  termsAndConditions(type) {
    const dialogRef = this.dialog.open(this.termsandconditions);
    this.policyStatus = type;
    this.getTermsConditions();
  }

  getTermsConditions() {
    this.showTerms = true;
    this.motorQuoteService.getTermsConditions("B2B").subscribe((res) => {
      if (res.response_code == 1) {
        this.showTerms = false;
        this.termsAndCondition = res.termsAndCondition;

      }
    });
  }

  viewQuotePDF() {

    this.btnClickLoadder = true;
    this.motorQuoteService
      .getQuoteDetailPDF(this.webQuoteNum, this.partnerId, "B2B")
      .subscribe((res) => {
        // this.btnClickLoadder.Quotation = false;
        this.btnClickLoadder = false;
        setTimeout(function () {}.bind(this), 600);
        let viewPDF = res;
        if (viewPDF.response_code == 1) {
          window.open(viewPDF.pdfPath, "_blank");
        }
      });
  }

  sendMail() {
    this.btnClickLoadder = true;
    this.motorQuoteService
      .sendMail(this.webQuoteNum, this.emailId, "")
      .subscribe((res) => {
        if (res.response_code == 1) {
          this.btnClickLoadder = false;
          Swal.fire(
            "",
            "Thank you for choosing Dubai National Insurance for insuring your car. We have sent an email to your registered email with all the quotation details. Your Quotation Reference# " +
              this.webQuoteNum,
            "success"
          );
        }
      });
  }

  public paymentMode: string = "";
  getPolicy(frame) {
    if (this.quoteStatus == "PAYMENTLINKSENT") {
      this.referalDescription = "Reset OTP for Edit Quote";
      Swal.fire({
        title: "Reset OTP",
        text: "The existing OTP will be reset. Are you sure you want to continue?",
        showCancelButton: true,
        confirmButtonColor: "#3085D6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes",
      }).then((result) => {
        if (result.value) {
          this.motorQuoteService
            .resetOtp(this.webQuoteNum, this.referalDescription)
            .subscribe((res) => {
              this.dialog.closeAll();
              this.pageLoader = true;
              if (this.policyStatus == "ISSUEPOLICY") {
                this.paymentMode = "CRD";
                localStorage.setItem("pageStatus", "ISSUPOLICY");
                this.insertPolicy(); // for issue policy
              }

              if (this.policyStatus == "PAYMENT") {
                this.paymentMode = "ONL";
                localStorage.setItem("pageStatus", "PAYMENT");
                this.getPayment(); // for Payment
              }

              if (this.policyStatus == "SENDPAYMENTLINK") {
                this.sendPaymentLink(); // for Send payment link
              }
            });
        }
      });
    } else {
      this.dialog.closeAll();
      this.pageLoader = true;
      if (this.policyStatus == "ISSUEPOLICY") {
        this.paymentMode = "CRD";
        localStorage.setItem("pageStatus", "ISSUPOLICY");
        this.insertPolicy(); // for issue policy
      }

      if (this.policyStatus == "PAYMENT") {
        this.paymentMode = "ONL";
        localStorage.setItem("pageStatus", "PAYMENT");
        this.getPayment(); // for Payment
      }

      if (this.policyStatus == "SENDPAYMENTLINK") {
        this.sendPaymentLink(); // for Send payment link
      }
    }
  }

  insertPolicy() {
    let motorPolicyValuesArray = {
      payment_mode: "CREDIT",
    };

    this.btnClickLoadder = true ;

    this.motorQuoteService.GetVehicleMakeCode( this.webQuoteNum).subscribe(res=>{
    
      if(res.vehicleMakeCode[0].StatusCode == 200 && res.vehicleMakeCode[0].VehicleMakeCode != ''){
     
        
        this.motorQuoteService.insertPolicy(motorPolicyValuesArray, this.webQuoteNum).subscribe((res) => {
          // this._route.navigateByUrl('agentMotor/MTquotepage/thankyou/' + this.policyNumber +"/"+ this.webQuoteNumber +"/"+" ");
          // res.policy_number
          //this.viewPolicySummary(res.policyNumber[0].PolicyNumber);
        this.btnClickLoadder = false;
          localStorage.setItem("Policy_Number", res.policyNumber);
          localStorage.setItem("Payment_Quotation_Number", this.webQuoteNum);
          this._route.navigateByUrl("motor/thankyou");
        });
      }
      else if(res.vehicleMakeCode[0].StatusCode == 400){
      //this.errorMessage = res.vehicleMakeCode[0].StatusMsg
        Swal.fire('',res.vehicleMakeCode[0].StatusMsg,'warning');
        // this.stepper.previous();
      }
    })
   
  }

  getMotorQuoteDetail(webQuoteNumber,status) {
    if(status == 'REFAPPROVED'){
       this._route.navigate(["motorquote/update/" + webQuoteNumber]);
     // this._route.navigate(["referral/update/" + webQuoteNumber]);
    }
    else{
      this._route.navigate(["motorquote/update/" + webQuoteNumber]);
    }

    
  }

  approvePolicyRequest() {
    this.motorQuoteService
      .approvePolicyRequestSummary(
        this.quoteNumber,
        this.webQuoteNum,
        "B2B",
        this.paymentMode
      )
      .subscribe(
        (res) => {
          if (res.response_code == 1) {
            let polNum = res.approvePolicyRequest.PolNo;
            let policy_uid = res.approvePolicyRequest.PolicyUid;

            localStorage.setItem("Payment_Quotation_Number", this.webQuoteNum);
            localStorage.setItem("CRS_Quotation_Number", this.quoteNumber);

            if (polNum == "" || polNum == null || polNum == undefined) {
              localStorage.removeItem("Policy_Number");
              localStorage.removeItem("Policy_UID");
            } else {
              localStorage.setItem("Policy_Number", polNum);
              localStorage.setItem("Policy_UID", policy_uid);
            }

            this.viewPolicySummary();
          }
        },
        (error) => {
          localStorage.removeItem("Policy_Number");
          localStorage.removeItem("Policy_UID");
          localStorage.setItem("Payment_Quotation_Number", this.webQuoteNum);
          localStorage.setItem("CRS_Quotation_Number", this.webQuoteNum);
          this._route.navigateByUrl("motor/thankyou");
          console.error(error.status);
        }
      );
  }

  getPayment() {
    let return_url = "http://k2key.in/motor_ins//dashboard";
    let site_url = "http://k2key.in/motor_ins/" + this._route.url;

    //this.paymentLoader = this.globalService.spinnerShow();

    this.motorQuoteService
      .paymentAuth(this.webQuoteNum, site_url, return_url, "MT", "1", "", "B2B")
      .subscribe((res) => {
        let payRes = res;

        if (payRes.res_code == 101) {
          Swal.fire(payRes.res_msg);
          // this.paymentLoader = this.globalService.spinnerHide();

          return false;
        } else if (
          payRes.result.response_code == 4012 &&
          payRes.res_code == 1
        ) {
          //this.paymentLoader = this.globalService.spinnerHide();

          localStorage.setItem("Payment_Order_ID", payRes.result.p_id);
          localStorage.setItem("Payment_Order_Tokan", payRes.result.token);
          localStorage.setItem("Payment_Quotation_Number", this.webQuoteNum);

          window.location.href = payRes.result.redirect_url;
        }
      });
  }

  async getAllFormData() {
    let error = false;

    //  let promise = new Promise((resolve,reject)=> {
    //         setTimeout(() => {
    //           if (error){
    //               reject('error');
    //           }else {
    //             resolve('Done');
    this.motorQuoteService
      .getDropdownData(
        "COMPREHENSIVE",
        "0",
        this.language_code,
        this.country,
        ""
      )
      .subscribe((res) => {
    
        this.cityArr = res.cityData;
        this.plateCatigoryData = res.PlateCategory;
        this.Platecategory = res.PlateCategory;
        this.motorQuoteService.getBankDetail().subscribe((res) => {
          this.bankDetail = res.bankdetailsData;
        });
        // var indexRegPlace = this.cityArr.findIndex(function (obj, k) {
        //   return obj.CityName === 'Dubai';
        // });
        // let placelVal = this.cityArr[indexRegPlace];
        // this.EditDataForm.get('reg_place')?.setValue(placelVal);

        this.vhclColorArr = res.vehicleColorsData;

        //   this.filteredVchColor.next(this.vhclColorArr.slice());
        //   this.countryArr = res.countryData;
     
        //   // this.EditDataForm.get("licIssueContry")?.setValue(this.countryArr[32]);
        //   this.filteredCountries.next(this.countryArr.slice());

        res.PlateCategory.forEach((item, index) => {
          this.plateCatArray.push(item);
        });
        //   this.filteredPlateCat.next(this.plateCatArray.slice());

        //   // this.EditDataForm.get("nationality")?.setValue(this.countryArr[32]);
        //   this.filteredNationCountries.next(this.countryArr.slice());
       

        // });

        // this.motorQuoteService.getBankDetail().subscribe(res => {

        //   this.bankDetail = res.bankdetailsData;
        //   this.filteredBank.next(this.bankDetail.slice());
      });

    // this.getVhclNCD();
  }

  getOccupation() {
    this.motorQuoteService.getOccupation("MT").subscribe((res) => {
      this.occupatindata = res.response_data;
   
    });
  }

  checkEID(value) {
    value = this.EditDataForm.value.e_eid;
    this.value = value;
    this.value = this.value.toString().replace(/-/g, "");
    let pattern = /^784-?[0-9]{4}-?[0-9]{7}-?[0-9]{1}$/;
    if (pattern.test(this.value))
      this.invalidEID = true;
    if (this.value.length != 18) {
      this.invalidEID = true;
      this.EditDataForm.get("eIDCheck")?.setValue('');
      return this.invalidEID;
    }
    if (this.invalidEID = true) {
      Swal.fire('Please Enter Valid Emirates Id', '', 'info')
    }
    if (this.value == "111111111111111" || this.value == "000000000000000" || this.value == "222222222222222" || this.value == "333333333333333") {
      this.invalidEID = false;
      this.EditDataForm.get("eIDCheck")?.setValue('1');
      return this.invalidEID;
    }
    else {
      var nCheck = 0, nDigit = 0, bEven = false;
      this.value = this.value.toString().replace(/\D/g, "");
      for (let n = this.value.length - 1; n >= 0; n--) {
        var cDigit = this.value.charAt; nDigit = parseInt(this.value[n]);
        if (bEven) {
          if ((nDigit *= 2) > 9)
            nDigit -= 9;
        }
        nCheck += nDigit;
        bEven = !bEven;
      }

      if ((nCheck % 10) == 0) {
        this.invalidEID = false;
        this.EditDataForm.get("eIDCheck")?.setValue(1);
        return this.invalidEID;
      }
      else {
        this.invalidEID = true;
        this.EditDataForm.get("eIDCheck")?.setValue('');
        return this.invalidEID;
      }
    }
  }

  checkValidation() {
    console.log(this.EditDataForm);
    
    // this.EditDataForm.invalid.focus()
  

    if (this.EditDataForm?.invalid) {
      const invalidControl = this.el.nativeElement.querySelector(".ng-invalid");
      invalidControl.focus();
      return;
    }
    this.checkEID(this.EditDataForm.value.e_eid);

    if( this.quoteStatus == "ISSUED" ){

      this.issueReadOnly = true ;
      const ctrl = this.EditDataForm.get('e_gender');
      ctrl.enable();

      const ctrl1 = this.EditDataForm.get('rg_mortgage');
      ctrl1.enable();

      const ctrl2 = this.EditDataForm.get('po_box_location');
      ctrl2.enable();
      
      const ctrl3 = this.EditDataForm.get('plate_category');
      ctrl3.enable();

      const ctrl4 = this.EditDataForm.get('vhclColor');
      ctrl4.enable()

      const ctrl5 = this.EditDataForm.get('e_gender');
      ctrl4.enable()
      
      const ctrl6 = this.EditDataForm.get('transaction_type');
      ctrl6.enable()



      
    }

    let motorArrayQuote = {
      gender: this.EditDataForm.value.e_gender,
      quotation_number: this.webQuoteNum,
      insured_name: this.EditDataForm.value.e_name,
      // gender: this.EditDataForm.value.e_gender,
      userId: this.userId,
      partnerId: this.partnerId,
      email: this.EditDataForm.value.adtnl_detail_email,
      mobile: this.EditDataForm.value.adtnl_detail_mobile,
      //  registered_place: this.EditDataForm.value.reg_place,
      e_eid: this.EditDataForm.value.e_eid,
      mortgage: this.EditDataForm.value.rg_mortgage,
      // plate_number: this.EditDataForm.value.rg_traffic_plate_num,
       plate_code: this.EditDataForm.value.rg_plateCode,
      // plate_category: this.EditDataForm.value.rg_type,
      driv_lic_TC_number: this.EditDataForm.value.d_TC_number,
      //driv_lic_type: this.EditDataForm.value.d_lic_type,
      vehicleColor: this.EditDataForm.value.vhclColor,
      // PO_box: this.EditDataForm.value.adtnl_detail_poBoxNum,
      po_box_number: this.EditDataForm.value.po_box_number,
      po_box_location: this.EditDataForm.value.po_box_location,
      driver_occupation: this.EditDataForm.value.driver_occupation,
      engine: this.EditDataForm.value.rg_engin_num,
      license: this.EditDataForm.value.d_driv_lic_num,
      reg_tc_no: this.EditDataForm.value.rg_tc_num,
      reg_place: this.EditDataForm.value.reg_place,
          rg_traffic_plate_num: this.EditDataForm.value.rg_traffic_plate_num,
      plate_category: this.EditDataForm.value.plate_category,
      policyDate: new Date(this.EditDataForm.value.startDate).toUTCString(),
      transaction_type:this.EditDataForm.value.transaction_type,
      TRN_number : this.EditDataForm.value.TRN_num,
      trade_Lic_number :  this.EditDataForm.value.trade_lic_num,
      industry_type : this.EditDataForm.value.industry_type,
      isTaxReg: this.EditDataForm.value.vat_register

      //startDate: this.convertDate(this.EditDataForm.value.startDate),
    };

    


    if( this.quoteStatus == "ISSUED" ){

      this.issueReadOnly = true ;
      const ctrl = this.EditDataForm.get('e_gender');
      ctrl.disable();

      const ctrl1 = this.EditDataForm.get('rg_mortgage');
      ctrl1.disable();

      const ctrl2 = this.EditDataForm.get('po_box_location');
      ctrl2.disable();
      
      const ctrl3 = this.EditDataForm.get('plate_category');
      ctrl3.disable();

      const ctrl4 = this.EditDataForm.get('vhclColor');
      ctrl4.disable()

      const ctrl5 = this.EditDataForm.get('e_gender');
      ctrl4.disable()
      
      const ctrl6 = this.EditDataForm.get('transaction_type');
      ctrl6.disable()

      

      
    }
  //  return false ;

    this.motorQuoteService
      .saveCustomerData(motorArrayQuote)
      .subscribe((res) => {
        Swal.fire("", "Record updated sucessfully", "success");

      });
  }
  //---------------------------------------- GET PLATE CODE ARRAY -----------------------------//
  getPlateCode_old(regPlaceId, type) {
    return false;

    //  let plateSource = regPlaceId;
    // if(regPlaceId == 'Dubai'){
    //       this.reg_place = 1;
    // }
    // else{
    //       this.reg_place = 0;
    // }

   
    let plateSource = this.EditDataForm.value.reg_place.CityName;
   
    if (typeof plateSource != undefined && typeof plateSource != "undefined") {
      this.motorQuoteService
        .getPlateCode(this.language_code, plateSource, "")
        .subscribe((res) => {
          this.plateCodeArray = res.plateCodeData;

          // if(this.EditDataForm.value.adtnl_detail_brandNew == 1 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined"){
          //       var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
          //         return obj.PlateCode == "NEW NUMBER";
          //       });
          //       let plCodeVal = this.plateCodeArray[indexPlCode];
          //       this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
          // }

          // if (type == 2 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined" && this.quoteDetail?.plateCode) {
          //   //Plate COde
          //   let plateCode = this.quoteDetail.plateCode;

          //   var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
          //     return obj.PlateCode === plateCode;
          //   });
          //   let plCodeVal = this.plateCodeArray[indexPlCode];
          //   this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
          // }

          // if (type == 3 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined") {
          //   //Plate COde
          //   let plateCode = this.plate_code;
          //   if (plateCode != undefined) {
          //     var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
          //       return obj.PlateCode === plateCode;
          //     });
          //     let plCodeVal = this.plateCodeArray[indexPlCode];
          //     this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
          //   }
          // }
      
          if (this.retrieveData && this.retrieveData.length != 0) {
            // let item= '';
            // this.plateCodeArray.forEach(element => {
            //   if(this.retrieveData[0].PlateCode)
            //   if( element.PlateCode == this.retrieveData[0].PlateCode){
            //     item = element;
            //   }
        
            // });
            // if(item!='')
            // this.EditDataForm.get('rg_plateCode')?.setValue(item);
          }
        });
    }
  }

  viewPolicySummary() {
    this.motorQuoteService
      .viewPolicySummary(this.webQuoteNum, "", "", "")
      .subscribe((res) => {
        if (res.response_code == 1) {
          localStorage.setItem("schedulelink", res.link_data.schedulelink);
          localStorage.setItem("creditNote", res.credit_note);
          localStorage.setItem("debitNote", res.debit_note);
          localStorage.setItem("hirePurchase", res.hirePurchaselink);
          localStorage.setItem("CRS_Quotation_Number", this.webQuoteNum);
          localStorage.setItem("Payment_Quotation_Number", this.webQuoteNum);
          localStorage.setItem("mortgage_bank", res.mortgageBank);
          localStorage.setItem("Policy_Number", res.policy_number);

          this._route.navigateByUrl("motor/thankyou");
        }
      });
  }
  

  sendPaymentLink() {
    this.btnClickLoadder = true;
    this.motorQuoteService.GetVehicleMakeCode( this.webQuoteNum).subscribe(res=>{
     
      if(res.vehicleMakeCode[0].StatusCode == 200 && res.vehicleMakeCode[0].VehicleMakeCode != ''){
      
        this.motorQuoteService.sendPaymentLink( this.webQuoteNum, "MT", this.payLink_email, "B2B",this.webQuoteNum,"" ).subscribe((res) => {
          let payRes = res;
          
          if (payRes.res_code == 1) {
            
  
            if(payRes.res_msg[0].StatusCode==200 || payRes.res_code == 1){        
            this.motorQuoteService
              .sendReferralMailToAdmin(
                this.webQuoteNum,
                "",
                this.emailId,
                "PAYMENTLINKSENT",
                "",
                "",
                "",
                "",
                ''
              )
              .subscribe((res) => {  this.btnClickLoadder = false;  });
            Swal.fire(
              "",
              "Payment link has been sent to customer for the reference no. " +
                this.webQuoteNum,
              "success"
            );
  
            this._route.navigate(["referrals"]); }
            
            else{
  
  
              Swal.fire(
                "",
                payRes.res_msg[0].StatusMsg
              );
            }
          }
          else{
            // Swal.fire({
            //   title: '<strong>HTML <u>example</u></strong>',
            //   icon: 'warning',
            //   html: 'You can use <b>bold text</b>, ' +
            //     '<a href="//sweetalert2.github.io">links</a> ' +
            //     'and other HTML tags' +
            //     '<br><br><button class="tool-tip btn" title-new="this is how it look like">Hover here to check</button>',
            //   showCloseButton: true,
            //   showCancelButton: true,
            //   focusConfirm: false,
            //   confirmButtonText: '<i class="fa fa-thumbs-up"></i> Great!',
            //   confirmButtonAriaLabel: 'Thumbs up, great!',
            //   cancelButtonText: '<i class="fa fa-thumbs-down"></i>',
            //   cancelButtonAriaLabel: 'Thumbs down'
            // })
            Swal.fire({
              icon: 'warning',
              // text: 'Payment link could not be generated please contact DNI IT , for the reference no.' + this.webQuoteNum,
              html: 'Payment link could not be generated please contact DNI IT , for the reference no.' + this.webQuoteNum + 
                    '<br><br><span>Policy Start Date:<span style="color:red; font-weight:700">06/04/2023</span><br><small>(If you wish to change the Policy Start Date, close this pop-up window and go to the Customer Details section to change the details)</small> </span> ',
              // "",
              // "Payment link could not be generated please contact DNI IT , for the reference no. " +
              //   this.webQuoteNum +  "",
              // "warning"
          });
            
            
            this._route.navigate(["referrals"]);
          }
        });
      }
      else if(res.vehicleMakeCode[0].StatusCode == 400){
      //this.errorMessage = res.vehicleMakeCode[0].StatusMsg
        Swal.fire('',res.vehicleMakeCode[0].StatusMsg,'warning');
        // this.stepper.previous();
      }
    })
   
  }
  
  PlateCategory = '';
  responseData  ;
  getQuotationDetial() {
    this.motorQuoteService
      .getRetrieveQuote(this.webQuoteNum, "BTBPORTAL", "")
      .subscribe((res) => {
        
        if (res.response_code == 1) {
          this.pageLoader = false;
          this.showLoader = true;
          //  this.webQuoteNumber = this.retrieveQuoteNumber;
          this.retrieveData = res.quotationDetailsDataForCustomer;

          if(this.retrieveData[0].RenewalProcessFlow=="RENEDIT") {

            let polNo = this.retrieveData[0].PrvInsPolNo.replaceAll("/", "-");
            this._route.navigate(["renewal/update/" + polNo]);
          }
        
          let resData = this.retrieveData[0];
          this.responseData = resData ;
          let responseData = res.quotationDetailsDataForCustomer;
          this.insuredName = res.quotationDetailsDataForCustomer[0].InsuredName;
          this.vehicleModel = res.quotationDetailsDataForCustomer[0].VehicleMakeModel;
          this.trimName = res.quotationDetailsDataForCustomer[0].TrimName;
          this.premium = res.quotationDetailsDataForCustomer[0].BaseContribution;
          this.vatAmount = res.quotationDetailsDataForCustomer[0].VATAmount;
          this.totalPremium = res.quotationDetailsDataForCustomer[0].TotalPremium;
          
          this.quoteDetail = responseData;
          this.TotalPremium = this.quoteDetail[0].TotalPremium;
          this.quoteNumber = this.quoteDetail[0].CRSQuoteNumber;
          this.emailId = this.quoteDetail[0].InsuredEmail;
          this.slectedOptBenefit = this.quoteDetail[0].SelectedBenefits;
          this.prevInsExpDate = this.quoteDetail[0].InsuranceExpiryDate;
          this.quoteStatus = this.quoteDetail[0].StatusDesc;
          this.BaseContribution = this.quoteDetail[0].BaseContribution;
          this.disable_btns = this.quoteDetail[0].PolAll;
          this.quoteBtn = this.quoteDetail[0].QuoteType;
         
          this.getQuotationHistory(this.webQuoteNum);
         
          this.PlateCategory = resData.PlateCategory;
         
         
          if (resData.Bsrc == "B2B") {
            this.EditDataForm.get("e_name")?.setValue(resData.InsuredName);
            this.EditDataForm.get("adtnl_detail_email")?.setValue(
              resData.InsuredEmail
            );

            this.payLink_email = this.EditDataForm.value.adtnl_detail_email ;
            this.EditDataForm.get("adtnl_detail_mobile")?.setValue(
              resData.InsuredMobile
            );
            this.EditDataForm.get("rg_engin_num")?.setValue(
              resData.EngineNumber
            );
          //  this.EditDataForm.get("plate_code").setValue(resData.PlateCode);
            this.EditDataForm.get("rg_traffic_plate_num").setValue(resData.RegistrationNumber);
            this.EditDataForm.get("rg_tc_num").setValue(resData.TrafficFileNo);
        
            this.EditDataForm.get('e_eid')?.setValue(resData.EmiratesIdNumber);
            this.EditDataForm.get("d_TC_number")?.setValue(resData.DLTCNo);
        //    this.EditDataForm.get("e_id")?.setValue(resData.DLTCNo);

         //     //Mortagage bank
         if (resData.Mortgage != '' || resData.Mortgage != null) {
          var indexBank = this.bankDetail.findIndex(function (obj, k) {
            return obj.InstituteName === resData.Mortgage;
          });
          let bankVal = this.bankDetail[indexBank];
          if (resData.Mortgage == "Not Mortgaged")
            this.EditDataForm.get('rg_mortgage')?.setValue(this.bankDetail[0]);
          else
            this.EditDataForm.get('rg_mortgage')?.setValue(bankVal);
        }
        else {
          this.EditDataForm.get('rg_mortgage')?.setValue('');
        }

        
        this.EditDataForm.get("TradeLicNumber")?.setValue(resData.DLTCNo);


        this.transactionTypeArray = [
          {value: '0', label: 'New Vehicle Registration'},
          {value: '1', label: 'Vehicle Renewal'},
          {value: '2', label: 'Change in Ownership'},
        ]
      

        if(resData.TransType=="New Vehicle Registration") {
          this.EditDataForm.get('transaction_type')?.setValue(this.transactionTypeArray[0]);
        }
        else if(resData.TransType=="Vehicle Renewal") {
          
          this.EditDataForm.get('transaction_type')?.setValue(this.transactionTypeArray[1]);
        }else{

          this.EditDataForm.get('transaction_type')?.setValue(this.transactionTypeArray[2]);
        }
            
          

            if(this.convertDate(resData.PolicyStartDate) > this.convertDate(this.todayDate)){

              this.EditDataForm.get("startDate").setValue( resData.PolicyStartDate );
             }else{
              this.EditDataForm.get("startDate").setValue( this.todayDate );

             }
             
           

            this.EditDataForm.get("d_driv_lic_num")?.setValue(
              resData.LicenceNumber
            );

            /***** Added extra field retrive 28-10-2022 *************/

            this.EditDataForm.get("po_box_number")?.setValue(resData.POBox);

            var indexPo_box_location = this.cityArr.findIndex(function (
              obj,
              k
            ) {
              return obj.CityName === resData.InsuredLocation;
            });
            this.EditDataForm.get("po_box_location")?.setValue(
              this.cityArr[indexPo_box_location]
            );
            var indexReg_location = this.cityArr.findIndex(function (
              obj,
              k
            ) {
              return obj.CityName === resData.RegistrationPlace;
            });
            this.EditDataForm.get("reg_place")?.setValue(
              this.cityArr[indexReg_location]
            );
            
            var indexplate_category = this.plateCatigoryData.findIndex(function (
              obj,
              k
            ) {
              return obj.CityName === resData.RegistrationType;
            });
            this.EditDataForm.get("plate_category")?.setValue(
              this.plateCatigoryData[indexplate_category]
            );


            this.getPlateCategory();

          

            // this.EditDataForm.get("po_box_location")?.setValue(
            //   this.cityArr[indexPo_box_location]
            // );
            

            //        if(resData.RegistrationNumber !== '' && resData.RegistrationNumber != null){
            //         this.EditDataForm.get('rg_traffic_plate_num')?.setValue(resData.RegistrationNumber);
            // }

            var indexOcc = this.occupatindata.findIndex(function (obj, k) {
              return obj.OccupationName === resData.InsuredOccupation;
            });
            this.EditDataForm.get("driver_occupation")?.setValue(
              this.occupatindata[indexOcc]
            );


            this.EditDataForm.get("rg_tc_num")?.setValue(
              resData.TrafficFileNo
            );
            //    //REG PLACE
            if (
              resData.RegistrationPlace != "" &&
              resData.RegistrationPlace != null &&
              resData.RegistrationPlace != undefined
            ) {
              var indexPlace = this.cityArr.findIndex(function (obj, k) {
                return obj.CityName === resData.RegistrationPlace;
              });
           
              let placeal = { CityName: "" };
              if (indexPlace == -1) placeal = this.cityArr[0];
              else placeal = this.cityArr[indexPlace];
              //  this.EditDataForm.get('reg_place')?.setValue(placeal);
              //  this.quoteDetail.regplace = placeal.CityName;

              setTimeout(() => {
                this.getPlateCode(this.quoteDetail.regplace, 2);
              }, 3000);
            }

            //Plate category
            //  if( resData.PlateCategory != null){
            //          var indexPlCat = this.plateCatArray.findIndex(function (obj, k) {
            //            return obj.label.toLowerCase() === resData.PlateCategory.toLowerCase();
            //          });
            //          let plCatVal = this.plateCatArray[indexPlCat];
            //          if(typeof (plCatVal) !="undefined")
            //                this.EditDataForm.get('rg_type')?.setValue(plCatVal.value);
            //  }else{
            //        this.EditDataForm.get('rg_type')?.setValue('');
            //  }

            if (resData.Mortgage != "" || resData.Mortgage != null) {
              var indexBank = this.bankDetail.findIndex(function (obj, k) {
                return obj.InstituteName === resData.Mortgage;
              });
              let bankVal = this.bankDetail[indexBank];
              if (resData.Mortgage == "Not Mortgaged")
                this.EditDataForm.get("rg_mortgage")?.setValue(
                  this.bankDetail[0]
                );
              else this.EditDataForm.get("rg_mortgage")?.setValue(bankVal);
            } else {
              this.EditDataForm.get("rg_mortgage")?.setValue("");
            }

            //Vehicle Color
            if (resData.VehicleColor == null || resData.VehicleColor == "") {
              this.EditDataForm.get("vhclColor")?.setValue("");
            } else {
              var indexColor = this.vhclColorArr.findIndex(function (obj, k) {
                return obj.ColorName === resData.VehicleColor;
              });
              let clrVal = this.vhclColorArr[indexColor];
              this.EditDataForm.get("vhclColor")?.setValue(clrVal);
            }

            //     //Gender
            var indexGender = this.genders.findIndex(function (obj, k) {
              return obj.value === resData.InsuredGender;
            });
            let gnderVal = this.genders[indexGender];
            this.EditDataForm.get("e_gender")?.setValue(gnderVal);


            


            setTimeout(() => {
              this.getPlateCodeRenew(resData.RegistrationPlace, resData.PlateCategory);
            }, 3000);

              // Business Type 

            if(resData.BusinessCategory){
              var indexBusniesType = this.industryTypeArr.findIndex(function (obj, k) {
                return obj.IndustryName.toLowerCase() === resData.BusinessCategory.toLowerCase();
              });
              let bType = this.industryTypeArr[indexBusniesType];
              this.EditDataForm.get('industry_type')?.setValue(bType);
            }

            //     //Mortagage bank

            //  var indexRegType = this.plateCatArray.findIndex(function (obj, k) {
            //    return obj.value.toLowerCase() === resData.RegistrationType.toLowerCase();
            //  });
            //  let typelVal = this.plateCatArray[indexRegType];

            //  if(typelVal?.value)
            //  this.EditDataForm.get('rg_type')?.setValue(typelVal?.value);


            if(resData.InsuredType=="CORPORATE"){
              if(resData.IsTaxReg=="Y" ||resData.IsTaxReg=="Yes" )
             this.EditDataForm.get('vat_register')?.setValue("Yes");
             else
             this.EditDataForm.get('vat_register')?.setValue("No");
            }

            this.EditDataForm.get('TRN_num')?.setValue(resData.TaxRegNumber);
            this.EditDataForm.get('trade_lic_num')?.setValue(resData.TradeLicNumber);


            if( resData.StatusDesc == "ISSUED" ){

              this.issueReadOnly = true ;
              const ctrl = this.EditDataForm.get('vat_register');
              ctrl.disable();

              const ctrl1 = this.EditDataForm.get('reg_place');
              ctrl1.disable();

              const ctrl2 = this.EditDataForm.get('rg_plateCode');
              ctrl2.disable();
        
              const ctrl3 = this.EditDataForm.get('plate_category');
              ctrl3.disable();
      
              const ctrl4 = this.EditDataForm.get('e_name');
              ctrl4.disable();
      
              const ctrl5 = this.EditDataForm.get('d_TC_number');
              ctrl5.disable();
              
              const ctrl6 = this.EditDataForm.get('transaction_type');
              ctrl6.disable();

              const ctrl7= this.EditDataForm.get('rg_traffic_plate_num');
              ctrl7.disable()

              const ctrl8= this.EditDataForm.get('rg_tc_num');
              ctrl8.disable()

             

              
            }

            
          }
        }


  

        if ( this?.retrieveData[0]?.CorePolStatus == "Pending Approval" ) {
            Swal.fire(
              "Policy Issued.",
              "Policy might have already issued or is under process. Please go to View Policy and check or contact your relationship manager.",
              "warning"
          );
          //this._route.navigate(['home/viewPolicy']);
        }
      });

      
  }



  getQuotationHistory(quoteNumber) {
    this.motorQuoteService
      .getQuotationHistory(quoteNumber, "MT")
      .subscribe((res) => {
        if (res.response_code == 1) {
          this.quotationHistoryArr = res.quotationHistoryList;
        }
      });
  }

  //------------------------ CHECK ACCESS FOR PAGE ------------------------------//
  getUserAccessPermission() {
    //    REFAPP
    this.motorQuoteService
      .checkUserAccess(
        "MOTORREFSUM",
        this.localStorageData.EmailAddress,
        "MT",
        this.webQuoteNum
      )
      .subscribe((res) => {
        let response = res;
        this.userAccessStatus = response.userAccessData;
      });
  }

  getQuotationDetailPdf() {
    this.optionalBenefit = [];
    this.motorQuoteService
      .getQuoteDetailPdf(this.webQuoteNum, "B2C")
      .subscribe((res) => {
        let optnBenefit;
        let plaBenefitData = res.planBenefitData;
        let benfitId = [];

        if (this.slectedOptBenefit.length != 0) {
          optnBenefit = this.slectedOptBenefit.split(",");

          if (res.response_code == 1) {
            plaBenefitData.forEach((item, index) => {
              optnBenefit.forEach((index1) => {
                if (item.BenefitId == index1 && !benfitId.includes(index1)) {
                  this.optionalBenefit.push(item);
                  benfitId.push(index1);
                }
              });
            });
          }
        }
      });
  }

  remove_duplicates(arr) {
    let obj = {};
    for (let i = 0; i < arr.length; i++) {
      obj[arr[i]] = true;
    }
    arr = [];
    for (let key in obj) {
      arr.push(key);
    }
    return arr;
  }

  buttonCondtionsCheck: any;
  // --------------- CHECK ACCESS FOR BUTTONS -------------------------//
  checkAccessForPolicyIssueButtons() {
    this.motorQuoteService.checkAccessToPolicyButtons("MT").subscribe((res) => {
      this.buttonCondtionsCheck = res;
      if (res.IsNonPayIssueAllowed == 0) {
        this.issuePolicyBtnAccess = true;
      }

      if (res.IsOnlinePaymentAllowed == 0) {
        this.onlinePayBtnAccess = true;
      }
    });
  }

  resBoxhistory() {
    this.isvisited = !this.isvisited;
  }

  CheckAccessOnLoad() {
    this.motorQuoteService
      .checkUserAccess(
        "MOTORREFSUM",
        this.localStorageData.EmailAddress,
        "MT",
        this.webQuoteNum
      )
      .subscribe((res) => {
        let response = res;
        //  this.checkStepper = false;
        if (response.userAccessData == 0) {
          this.unauthorizedAccess = true;
          //  Swal.fire( "You are not authorized to access this section. Please contact your relationship manager.", 'error');
        } else {
          this.Desclaimer = true;
          this.headerDesclaimer = response.HeaderDisclaimer;
        }
      });
  }

  submitCustomerData() {}
  popupTitle = "";
  getReferalCondtion(ref_val) {
    const dialogRef = this.dialog.open(this.referaquote);
    this.referalModel = true;
    if (ref_val == "APPROVED") {
      this.popupTitle = "Approve a Quote";
      this.refer_type = "Approve";
      this.refer_condtion_type = 3;
    }
    if (ref_val == "REJECTED") {
      this.popupTitle = "Reject a Quote";
      this.refer_type = "Reject";
      this.refer_condtion_type = 4;
    }
    if (ref_val == "REFERRAL") {
      this.popupTitle = "Refer a Quote";
      this.refer_type = "Refer";
      this.refer_condtion_type = 2;
    }
    if (ref_val == "ADDITIONALINFO") {
      this.popupTitle = "Additional info a Quote";
      this.refer_type = "Additional Info";
      this.refer_condtion_type = 5;
    }
    // if(this.webQuoteNumber ==''){
    //   this.getQuotation('',2);
    // }
  }

  sendRefferMailToAdmin(type) {
    if (this.quoteStatus == "PAYMENTLINKSENT") {
      this.referalDescription = "Reset OTP for Edit Quote";
      Swal.fire({
        title: "Reset OTP",
        text: "The existing OTP will be reset. Are you sure you want to continue?",
        showCancelButton: true,
        confirmButtonColor: "#3085D6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes",
      }).then((result) => {
        if (result.value) {
          this.motorQuoteService
            .resetOtp(this.webQuoteNum, this.referalDescription)
            .subscribe((res) => {
              let event_type = "REFERQUOTE";

              this.motorQuoteService
                .reRefered(this.webQuoteNum, this.referalDescription)
                .subscribe((res) => {
                  this.close();
                  this._route.navigate(["motorscheme"]);
                });
            });
        }
      });
    } 
    else {
      let event_type = "REFERQUOTE";

      this.motorQuoteService
        .reRefered(this.webQuoteNum, this.referalDescription)
        .subscribe((res) => {
          this.close();
          this._route.navigate(["motorscheme"]);
        });
    }
   
  }

  callResendOtp() {
    this.referalDescription = "Reset OTP for Edit Quote";
    Swal.fire({
      title: "Reset OTP",
      text: "The existing OTP will be reset. Are you sure you want to continue?",
      showCancelButton: true,
      confirmButtonColor: "#3085D6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.motorQuoteService
          .resetOtp(this.webQuoteNum, this.referalDescription)
          .subscribe((res) => {
            this._route.navigate(["motorquote/update/" + this.webQuoteNum]);
          });
      }
    });
  }

  close() {
    this.dialog.closeAll();
  }

  tmpDataPlateCategory = { policy_type:"",reg_place:"",cover_type:""} ;
  getPlateCategory(){
   
    this.addTcNoValidation();
 
     let data = { 
                 language_code:this.language_code,
                 policy_type:  this?.retrieveData[0]?.InsuredType,
                 reg_place: this.EditDataForm.value?.reg_place?.CityName,
                 cover_type: this?.retrieveData[0]?.PolicyType
     }
   
     if( true)
     {
     
    // if(this.tmpDataPlateCategory.policy_type!==data.policy_type || this.tmpDataPlateCategory.reg_place!==data.reg_place || this.tmpDataPlateCategory.cover_type!==data.cover_type) 
     if(true)
      {
       this.motorQuoteService.getPlateCategory(data).subscribe(res => {
 
         this.plateCatArray = res.plateCodeData ;

         this.plateCatArray.forEach(element => {

          if(element.PlateCategotyName== this.responseData.PlateCategory){

            this.EditDataForm.get("plate_category").setValue(element);
          }
          
         });
        this.plateCatigoryData= res.plateCodeData ;
         this.filterPlateCat();
         
         });
       }
       this.tmpDataPlateCategory=data;
     }
 
      this.EditDataForm.get("plate_category")?.setValue('');
      this.EditDataForm.get("rg_plateCode")?.setValue('');
 
   }



     //---------------------------------------- GET PLATE CODE ARRAY -----------------------------//
     getPlateCode(regPlaceId, type) {
  

      let plateSource = regPlaceId;
      
  
      if (typeof (plateSource) != undefined && typeof (plateSource) != "undefined") {
        this.motorQuoteService.getPlateCode(this.language_code, plateSource,this.EditDataForm.value.plate_category.value).subscribe(res => {
  
          this.plateCodeArray = res.plateCodeData;
  
          if(this.EditDataForm.value.adtnl_detail_brandNew == 1 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined"){
                var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
                  return obj.PlateCode == "NEW NUMBER";
                });
                let plCodeVal = this.plateCodeArray[indexPlCode];
                this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
          }
  
          if (type == 2 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined" && this.quoteDetail?.plateCode) {
            //Plate COde
            let plateCode = this.EditDataForm.value.rg_plateCode.plateCode;
  
            var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
              return obj.PlateCode === plateCode;
            });
            let plCodeVal = this.plateCodeArray[indexPlCode];
            this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
          }
  
          if (type == 3 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined") {
            //Plate COde
            let plateCode = this.plate_code;
            if (plateCode != undefined) {
              var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
                return obj.PlateCode === plateCode;
              });
              let plCodeVal = this.plateCodeArray[indexPlCode];
              this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
            }
          }
  
          if(this.retrieveData && this.retrieveData.length!=0) {
            
            let item= '';
            this.plateCodeArray?.forEach(element => {
              if(this.retrieveData[0].PlateCode)
              if( element.PlateCode == this.retrieveData[0].PlateCode){
                item = element;
              }
              
            });
            if(item!='')
            this.EditDataForm.get('rg_plateCode')?.setValue(item);
            
           }
  
        });
  
      
  
      }
      if(this.EditDataForm.value.reg_place.CityName !="Dubai"){
  
        this.tcMin = 10 ; this.tcMax=10;
      }else{
  
        this.tcMin = 8 ; this.tcMax=8;
      }
  
  
  
    }


    getPlateCodeRenew(regPlaceId, type) {
  

      let plateSource = regPlaceId;
      
  
      if (typeof (plateSource) != undefined && typeof (plateSource) != "undefined") {
        this.motorQuoteService.getPlateCode(this.language_code, plateSource,type).subscribe(res => {
  
          this.plateCodeArray = res.plateCodeData;
  
          if(this.EditDataForm.value.adtnl_detail_brandNew == 1 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined"){
                var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
                  return obj.PlateCode == "NEW NUMBER";
                });
                let plCodeVal = this.plateCodeArray[indexPlCode];
                this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
          }
  
          if (type == 2 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined" && this.quoteDetail?.plateCode) {
            //Plate COde
            let plateCode = this.quoteDetail.plateCode;
  
            var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
              return obj.PlateCode === plateCode;
            });
            let plCodeVal = this.plateCodeArray[indexPlCode];
            this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
          }
  
          if (type == 3 && typeof (this.plateCodeArray) != undefined && typeof (this.plateCodeArray) != "undefined") {
            //Plate COde
            let plateCode = this.plate_code;
            if (plateCode != undefined) {
              var indexPlCode = this.plateCodeArray.findIndex(function (obj, k) {
                return obj.PlateCode === plateCode;
              });
              let plCodeVal = this.plateCodeArray[indexPlCode];
              this.EditDataForm.get('rg_plateCode')?.setValue(plCodeVal);
            }
          }
  
          if(this.retrieveData && this.retrieveData.length!=0) {
            
            let item= '';
            this.plateCodeArray.forEach(element => {
              if(this.retrieveData[0].PlateCode)
              if( element.PlateCode == this.retrieveData[0].PlateCode){
                item = element;
              }
              
            });
            if(item!='')
            this.EditDataForm.get('rg_plateCode')?.setValue(item);
            
           }
  
        });
  
      
  
      }
      if(this.EditDataForm.value.reg_place.CityName !="Dubai"){
  
        this.tcMin = 10 ; this.tcMax=10;
      }else{
  
        this.tcMin = 8 ; this.tcMax=8;
      }
  
  
  
    }
  addTcNoValidation(){

    if( this.EditDataForm.value?.reg_place?.CityName == 'Dubai'){
       this.EditDataForm.get('rg_TC_num')?.setValidators([Validators.required,  Validators.minLength(8), Validators.maxLength(8)]);
      // this.horizontalStepperForm.get('d_TC_number').setValidators([ Validators.minLength(8), Validators.maxLength(8),]);
  }else{
       this.EditDataForm.get('rg_TC_num')?.setValidators([Validators.required,  Validators.minLength(10), Validators.maxLength(10)]);
      // this.horizontalStepperForm.get('d_TC_number').setValidators([ Validators.minLength(10), Validators.maxLength(10),]);
  }
  
   this.EditDataForm.get('rg_TC_num')?.updateValueAndValidity();
   }


   private filterPlateCat() {
    if (!this.plateCatArray) {
      return;
    }

    // get the search keyword
    let search = this.plateFilterCtrl.value;
    if (!search) {
      this.filteredPlateCat.next(this.plateCatArray.slice());
      return;
    } else {
      search = search.toLowerCase();
    }


    // filter the banks
    this.filteredPlateCat.next(
      this.plateCatArray.filter(bank => bank.label.toLowerCase().indexOf(search) > -1)
    );
  }


  isHidePlatCodeNPlatNum = false ;
 onChangeTranType(){

  if(this.EditDataForm.value.transaction_type.label=="Change in Ownership" || this.EditDataForm.value.transaction_type.label=="Vehicle Renewal"){

    this.EditDataForm.get('rg_plateCode')?.setValidators([Validators.required]);
    this.EditDataForm.get('rg_traffic_plate_num')?.setValidators([Validators.required]);
    this.isHidePlatCodeNPlatNum = false ;
  }else{

    this.EditDataForm.get('rg_plateCode')?.setValidators(null);
    this.EditDataForm.get('rg_traffic_plate_num')?.setValidators(null);
    this.isHidePlatCodeNPlatNum = true ;
  }



  this.EditDataForm.get('rg_plateCode')?.updateValueAndValidity();
  this.EditDataForm.get('rg_traffic_plate_num')?.updateValueAndValidity();
 }


 private industryfilter() {
  if (!this.industryTypeArr) {
    return;
  }
 
  // get the search keyword
  let search = this.industryFilterCtrl.value;
  if (!search) {
    this.industryTypeFilter.next(this.industryTypeArr.slice());
    return;
  } else {
    search = search.toLowerCase();
  }
  // filter the banks
 
  this.industryTypeFilter.next(
    this.industryTypeArr.filter(bank => bank.IndustryName.toLowerCase().indexOf(search) > -1)
  );
}

  //---------------------------------- GET INDUSTRY TYPE --------------------------------------------------------//
  getIndustryTypes(){
    this.motorQuoteService.getIndustryTypes('MT').subscribe(res => {
            this.industryTypeArr = res.industries;
            this.industryTypeFilter.next(this.industryTypeArr.slice());
           
    });
}


checkValidInputData(event: any, type) {
    

  this.globalService.checkValidInputData(event, type);

     
}

  
}
