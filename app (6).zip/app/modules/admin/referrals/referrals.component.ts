import { Component, OnInit, ViewChild, ɵConsole ,ElementRef,Directive, TemplateRef,Input,EventEmitter,SimpleChanges} from '@angular/core';
import { MotorquoteService } from '../../service/motorquote.service';
import { GlobalService } from '../../service/global.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'app/core/auth/auth.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-referrals',
  templateUrl: './referrals.component.html',
  styleUrls: ['./referrals.component.scss']
})
export class ReferralsComponent implements OnInit {


  refStatus =[
    {value:'ALLREFERRALS', label:'All'},
    {value:'REFERRED', label:'Referred'},
    {value:'REFAPPROVED', label:'Approved'},
    {value:'REFREJECTED', label:'Rejected'},
    {value:'ADDITIONALINFO', label:'Additional Info'},
 ]

 quoteType = [
  {value: 'QUICK QUOTE', label:'Quick Quote'},
  {value:'FULL QUOTE', label:'Full Quote'}
 ]



  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('claimPopup') claimPopup: TemplateRef<any>;
  gridStatus:boolean = false;
  public products:any = [];
  quotations:any = [];
  partnersArr: any = [];
  partnerVal: any;
  partnerID: any;
  localStorageData: any;
  reffralQuoteForm:FormGroup;
  quoteRes:boolean=false;
  lobCode:any; 
  fromDateFrom3month = new Date();
  tableData:any = [];

  statusDescription: any;
 // frdate= new Date(new Date().setDate(new Date().getDate() - 7));
  businessSrcArr = [
    
    ]
  res_Status: any;
  businessSource: string;
  email: any;
 date = new Date(Date.now());
minDate =new Date(new Date().setMonth(new Date().getMonth() ));
frdate = new Date(new Date().setDate(new Date().getDate() - 7));
fromMaxDate = new Date();
fromMinDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
  psw: any;
  sessionData: FormGroup;
  UserRole;
  RoleDesc;
  @Input() partnerUser ; // decorate the property with @Input()
  product_list: any;
  selectedschemecode: any;
  userId: any;
  constructor(public _route: Router, public _activatedroute: ActivatedRoute, public motorQuoteService: MotorquoteService, public formBuilder: FormBuilder,  public globalService: GlobalService,private el: ElementRef,public dialog: MatDialog, private _authService: AuthService) { }

  ngOnInit(): void {
    this.getQuotationFormData();
    this.retrieveQuoteFormData();

    this.localStorageData = this.globalService.getLocalStorageData();
    this.businessSource = this.localStorageData.BusinessSource;
  
    this.partnerID = this.localStorageData.PartnerId;
    this.UserRole = this.localStorageData.UserRole;
    this.RoleDesc = this.localStorageData.RoleDesc;
    this.userId = this.localStorageData.UserId;
    let sessonData = JSON.parse(localStorage.getItem("retreiveQuoteForm"));
      
    this.sessionData = this.formBuilder.group({
      password: ['', Validators.required],
    });
    
    
      if( this.partnerID != 1 &&  this.partnerID !=3){
        this.businessSrcArr = [ ] 
        this.reffralQuoteForm = this.formBuilder.group({
            partner : ['',Validators.required],
            userSel: ['',Validators.required],
            product: [{ "Id": 0, "LOBId": 18, "ProductName": "All" },Validators.required],
            fromDate: [this.frdate,Validators.required],
            toDate: [this.date,Validators.required],
            businessSrc: [this.businessSrcArr[0],Validators.required],
            quoteRefNum: [''],
            optionalText: [''],
            schemeCode:[''],
            ref_quoteType:[''],
            ref_status: [this.refStatus[0].value]
        });
      }else{
        this.reffralQuoteForm = this.formBuilder.group({
        partner : ['',Validators.required],
        userSel: ['',Validators.required],
        product: [{ "Id": 0, "LOBId": 18, "ProductName": "All" },Validators.required],
        fromDate: [this.frdate,Validators.required],
        toDate: [this.date,Validators.required],
        businessSrc: [this.businessSrcArr[0],Validators.required],
        quoteRefNum: [''],
        optionalText: [''],
        schemeCode:[''],
        ref_quoteType:[''],
        ref_status: [this.refStatus[0].value]
      })
    }
    if(sessonData?.ref_UserId){
      this.reffralQuoteForm.setValue({
        partner: sessonData.partner,
        userSel : sessonData.ref_UserId,
        product: sessonData.ref_product,
        fromDate: sessonData.fromDate,
        toDate: sessonData.toDate,
        businessSrc: sessonData.businesSrc,
        quoteRefNum: '',
        optionalText:'',
        schemeCode:'',
        ref_quoteType:'',
        ref_status:sessonData.refstatus
    });
  
    this.searchQuote1();
    // localStorage.removeItem('retreiveQuoteForm');
    // this.serachQuote();
    // localStorage.clear();
}
    
    this.getUserHerchy();
    this.getSchemesByProduct();
    
 
  }

  //getformdata
  getQuotationFormData() {
    this.motorQuoteService.getQuotationFormData().subscribe(response => {
        let formDataRes = response;
        this.partnersArr = formDataRes.Partners;
        this.partnersArr.forEach((item, index) => {
          if (item.PartnerId == this.partnerID) {
                this.partnerVal = item.PartnerId;
          }
        }); 
     
        this.reffralQuoteForm.get('partner').setValue(this.partnerVal);

        this.businessSrcArr = formDataRes.busiSource;
       this.reffralQuoteForm.get('businessSrc').setValue(this.businessSrcArr[0]);
      //  this.callSearchHistroy();
       
      });
  }

  //schemecode list
  getSchemesByProduct(){
    this.motorQuoteService.getSchemesByProduct('MT').subscribe(result=>{
    this.product_list = result.getSchemesByProduct;
    this.selectedschemecode = result.getSchemesByProduct[0].SchemeCode;
  })
}

  //product list
  retrieveQuoteFormData(){
     this.motorQuoteService.retrieveQuoteFormData().subscribe(res => {
           let retrieveRes = res;
           this.products = retrieveRes.Products;

           this.products.unshift({Id:0,LOBId:0,ProductName:'All'});
           
           this.reffralQuoteForm.get("product").setValue(this.products[0]); 
         
     });
   }

   //go to reffeed page


  //date convert
  convertDate(inputFormat){
    function pad(s){
      return (s < 10) ? '0' + s : s;
    }
    var d = new Date(inputFormat);
    return ([ pad(d.getMonth()+1),pad(d.getDate()),d.getFullYear()].join('/'));
  }

  
 
 saveData() {
   this.email = this.localStorageData.EmailAddress;
   this.psw = this.sessionData.value.password;
  
   if (this.email == '') {
       this._route.navigate(['/sign-in']);
   } else {
       this._authService
           .validateuser(this.email, this.psw)
           .subscribe(() => {
               // const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/signed-in-redirect';
               // this.router.navigateByUrl(redirectURL);
           });
   }
   this._route.navigate(['/referrals']);
   this.close();
 }
 close() {
   this.dialog.closeAll();
 }

 fromDateChange(event){
  

  const d =     new Date(this.reffralQuoteForm.value.fromDate);
  let month  =d.getMonth();
   let today = new Date();
  
  this.fromDateFrom3month  = new Date(new Date(d).setMonth(month+3));

  var Difference_In_Time =  today.getTime() - this.fromDateFrom3month.getTime();
  if(Difference_In_Time<0)
  this.fromDateFrom3month = today;

 // this.fromDateFrom3month = this.fromDateFrom3month.setMonth(month+3);
 
  
}
searchQuote1(){
  this.motorQuoteService.retrieveQuoteList( this.reffralQuoteForm.value.partner,
    this.reffralQuoteForm.value.product,
    this.convertDate(this.reffralQuoteForm.value.fromDate),
    this.convertDate(this.reffralQuoteForm.value.toDate),
    this.reffralQuoteForm.value.quoteRefNum,
  this.reffralQuoteForm.value.optionalText,
  this.reffralQuoteForm.value.ref_status,
  this.reffralQuoteForm.value.businessSrc,
  this.reffralQuoteForm.value.userSel).subscribe(res => {
    
    let quoteListRes = res;
    if (res.response_code == 1000) {
      const dialogRef = this.dialog.open(this.callAPIDialog);
  }

    if(quoteListRes.res_code == 1){
      this.res_Status = quoteListRes.res_status;
      this.quotations = quoteListRes.Quotations;
     
      this.lobCode = this.quotations[0].LOBCode;
      this.quoteRes = false;     
      this.tableData = this.quotations;
  
  
    }

    if(quoteListRes.res_code == 2){
      this.res_Status = quoteListRes.res_status;
      this.quoteRes = false;
    }
  });
  localStorage.removeItem('retreiveQuoteForm');
  this.gridStatus = true;
}
  serachQuote(){
    this.quoteRes=true; 
    if(this.reffralQuoteForm?.invalid){
      return;
    }

   
  
    var retriveSearchFormData:any = {
      ref_product: this.reffralQuoteForm.value.product.Id,
      optionalText:this.reffralQuoteForm.value.optionalText,
      businesSrc:this.reffralQuoteForm.value.businessSrc.label,
      fromDate:this.reffralQuoteForm.value.fromDate,
      partner:this.reffralQuoteForm.value.partner,
      quoteRefNum:this.reffralQuoteForm.value.quoteRefNum,
      refstatus:this.reffralQuoteForm.value.ref_status,
      toDate:this.reffralQuoteForm.value.toDate,
      ref_UserId:this.reffralQuoteForm.value.userSel.UserId,
     } ;
    localStorage.setItem("retreiveQuoteForm", JSON.stringify(retriveSearchFormData));
   
  
  
  
    this.motorQuoteService.retrieveQuoteList(  this.reffralQuoteForm.value.partner,
                                              this.reffralQuoteForm.value.product.Id,
                                              this.convertDate(this.reffralQuoteForm.value.fromDate),
                                              this.convertDate(this.reffralQuoteForm.value.toDate),
                                               this.reffralQuoteForm.value.quoteRefNum,
                                               this.reffralQuoteForm.value.optionalText,
                                               this.reffralQuoteForm.value.ref_status,
                                               this.reffralQuoteForm.value.businessSrc.label,
                                              //  this.reffralQuoteForm.value.ref_quoteType.label,
                                               this.reffralQuoteForm.value.userSel.UserId,
                                               ).subscribe(res => {
     
      let quoteListRes = res;
      

      if (res.response_code == 1000) {
        const dialogRef = this.dialog.open(this.callAPIDialog);
    }
  
      if(quoteListRes.res_code == 1){
        this.res_Status = quoteListRes.res_status;
        this.quotations = quoteListRes.Quotations;
        
        this.lobCode = this.quotations[0].LOBCode;
        this.quoteRes = false;     
        this.tableData = this.quotations;
      
    
      }
  
      if(quoteListRes.res_code == 2){
        this.res_Status = quoteListRes.res_status;
        this.quoteRes = false;
      }
    });
    this.gridStatus = true;
   

  }

  getMotorQuoteDetail(quoteNum,status,schemeCode,QuoteType){
    
   
    if(this.UserRole=="CEDANT" &&  (this.RoleDesc=="ADMIN" || this.RoleDesc=="UNDERWRITER")){
    if(status == 'QUOTED' || status == 'REFREJECTED' || status == 'ADDITIONALINFO'){
        localStorage.setItem('SchemeCode', schemeCode);
          this._route.navigate(["motorquote/update/" + quoteNum]);
    }

    if( status == 'REFERRED' ){
         localStorage.setItem('SchemeCode', schemeCode);
      //  if(QuoteType)
      if(QuoteType=="QUICKQUOTE")
      this._route.navigate(["quickquote/update/" + quoteNum]);
      else
          this._route.navigate(["motorquote/update/" + quoteNum]);
    }
  }
  }

  getApproveQuoteForPolicy(quoteNumber,status,schemeCode,QuoteType){
    if(status == 'REFAPPROVED' || status == 'QUOTECONFIRMED' || status == 'INITIATED') {
        this._route.navigate(["referrals/approveQuote/" + quoteNumber]);
    }
  
    if(status == 'QUOTED'  ){
        localStorage.setItem('SchemeCode', schemeCode);
        if(QuoteType=="QUICKQUOTE")
        this._route.navigate(["quickquote/update/" + quoteNumber]);
        else
          this._route.navigate(["motorquote/update/" + quoteNumber]);
    }
  
    if(status == 'REFREJECTED' ){
          if(this.businessSource == 'DIRECT' && this.partnerID == 1 || true){
                localStorage.setItem('SchemeCode', schemeCode);
                if(QuoteType=="QUICKQUOTE")
                this._route.navigate(["quickquote/update/" + quoteNumber]);
                else
                this._route.navigate(["motorquote/update/" + quoteNumber]);
          }
   }
  
   if(status == 'ADDITIONALINFO' ){
        if(this.businessSource != 'DIRECT' || this.partnerID != 1){
              localStorage.setItem('SchemeCode', schemeCode);
              if(QuoteType=="QUICKQUOTE")
              this._route.navigate(["quickquote/update/" + quoteNumber]);
              else
              this._route.navigate(["motorquote/update/" + quoteNumber]);
        }
  }
  }

  getQuotationNumber(quoteNumber){
    localStorage.setItem("QuotationNo",quoteNumber);
   
  }

  userHerchyList=[];
getUserHerchy(){
  this.motorQuoteService.getPartnerUserList().subscribe(res => {
      this.userHerchyList = res.res_data;
      this.userHerchyList.forEach((item, index) => {
        if(this.localStorageData.UserId==item.UserId) this.reffralQuoteForm.get("userSel")?.setValue(item);
      })
  });

}

showquickData(type){
  let quickQuote = []
  let fullQuote = []
  let renewalData = []
 
   this.quotations.forEach(element => {
     if(element.QuoteType == "QUICKQUOTE"){
         quickQuote.push(element)
       }
      else if(element.IsRenewal == 1){
        renewalData.push(element);
      }
       else{
         fullQuote.push(element);
       }
   });

 if(type == 'quickQuote'){
   this.tableData = quickQuote 
 }

 else if(type == 'renewal'){
  this.tableData = renewalData 
 }

 else if (type == 'fullQuote'){
 this.tableData = fullQuote
   }

   else{
 this.tableData = this.quotations 
   }
}


//reset data
resetData(type){
  let resetdata = []
  this.quotations.forEach(element => {
    resetdata.push(element)
  });
if(type == 'resetdata'){
  this.tableData = this.quotations
}
}
 
ngOnChanges(changes: SimpleChanges) {
  // changes.prop contains the old and the new value...
  this.userHerchyList.forEach((item, index) => {
    if(changes.partnerUser.currentValue.UserId==item.UserId) 
    this.reffralQuoteForm.get("userSel")?.setValue(item);
    })
    setTimeout(() => {
    this.serachQuote(); } ,2000);
}

getUserList(){
  this.motorQuoteService.getUsers(this.reffralQuoteForm.value.partner).subscribe(res => {
    this.userHerchyList = res.res_data;
});
}


selectedClaim ;
openClaim(item){
  this.selectedClaim = item ;
 
  this.openDialogClaim();
}


openDialogClaim(){
  this.dialog.open(this.claimPopup);
}


}
