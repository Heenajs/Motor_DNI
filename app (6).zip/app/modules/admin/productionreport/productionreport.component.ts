import { Component, OnInit, ViewChild, ɵConsole ,ElementRef,Directive, TemplateRef} from '@angular/core';
import { MotorquoteService } from '../../service/motorquote.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { GlobalService } from '../../service/global.service';
import Swal from 'sweetalert2';
// import { AppDateAdapter, APP_DATE_FORMATS } from '../motorquote/date.adapter';
import { Router, ActivatedRoute } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { Observable, Subscription, fromEvent } from 'rxjs';
import { config } from '../../../config';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'app/core/auth/auth.service';

@Component({
  selector: 'app-productionreport',
  templateUrl: './productionreport.component.html',
  styleUrls: ['./productionreport.component.scss']
})
export class ProductionreportComponent implements OnInit {

  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  partnerVal: any;
  partnerID: any;
  statusDescription: any;
  localStorageData: any;
  PartyCode: any;
  cedantId: any;
  userId: any;
  businessSource: any;
  userRole: any;
  userType: any;
  email: any;
  psw: any;
  regMinDate: Date;
  regMaxDate: Date;

  constructor(public _route: Router, public _activatedroute: ActivatedRoute, public motorQuoteService: MotorquoteService, public formBuilder: FormBuilder,  public globalService: GlobalService,private el: ElementRef, public dialog: MatDialog, private _authService: AuthService) { }

  
  regionArr  = [
    {value: '0', label: 'Dubai'},
    {value: '1', label: 'Abu Dhabi'},
    {value: '2', label: 'Rask Al Khaimah'},
    {value: '3', label: 'Fujairah'},
    {value: '4', label: 'Others'},
];

statusArr  = [
  {value: 'QUOTED', label: 'QUOTED'},
  {value: 'CONFIRM COVER', label: 'CONFIRM COVER'},
  {value: 'APPROVE', label: 'APPROVE'},
  {value: 'INITIATED', label: 'INITIATED'},
  {value: 'ADDITIONALINFO', label: 'ADDITIONALINFO'},
  {value: 'ISSUED', label: 'ISSUED'},
  {value: 'REFERRED', label: 'REFERRED'}
 
];

businessSrcArr = [

]

retreiveQuoteForm: FormGroup;
partnersArr: any = [];
public products:any = []; quotations:any = [];  fromDate:any = ""; toDate:any = ""; res_Status:any; lobCode:any; 
isSubmitted:boolean = false; gridStatus:boolean = false; loadProducts:boolean = false; quoteRes:boolean=false; loadPartner:boolean = false;
date = new Date(Date.now());
minDate =new Date(new Date().setMonth(new Date().getMonth() - 3));
frdate = new Date(new Date().setDate(new Date().getDate() - 7));
sessionData: FormGroup;

ngOnInit(): void {
  this.retrieveQuoteFormData();
  this.getQuotationFormData();
 
  

this.localStorageData = this.globalService.getLocalStorageData();
// console.log(this.localStorageData.PartnerId);
this.partnerID = this.localStorageData.PartnerId;
// console.log(this.partnerID);
this.PartyCode = this.localStorageData.PartyCode;

this.cedantId = this.localStorageData.CedantId;
// console.log(this.localStorageData.CedantId);
this.userId = this.localStorageData.UserId;
// console.log(this.localStorageData.UserId);
this.businessSource = this.localStorageData.BusinessSource;
// console.log( this.businessSource);
this.userRole = this.localStorageData.UserRole;
// console.log( this.userRole);
this.userType = this.localStorageData.UserType;
// console.log( this.userType);

this.sessionData = this.formBuilder.group({
  password: ['', Validators.required],
});


  if( this.partnerID != 1 &&  this.partnerID !=3){
       
    this.businessSrcArr = [ ] 
    
 

this.retreiveQuoteForm = this.formBuilder.group({
  partner : ['',Validators.required],
  product: ['',Validators.required],
  fromDate: ['',Validators.required],
  toDate: ['',Validators.required],
 // businessSrc: [this.businessSrcArr[0],Validators.required],
  quoteRefNum: [''],
  optionalText: [''],
  status: ['']
});
}else{

this.retreiveQuoteForm = this.formBuilder.group({
  partner : ['',Validators.required],
  product: ['',Validators.required],
  fromDate: ['',Validators.required],
  toDate: ['',Validators.required],
 // businessSrc: [this.businessSrcArr[0],Validators.required],
  quoteRefNum: [''],
  optionalText: [''],
  status: ['']
})

}


}

get f() { return this.retreiveQuoteForm.controls; }


saveData() {
  this.email = this.localStorageData.EmailAddress;
  this.psw = this.sessionData.value.password;
  // console.log(this.email);
  // console.log(this.psw);
  if (this.email == '') {
      this._route.navigate(['/sign-in']);
  } else {
      this._authService
          .validateuser(this.email, this.psw)
          .subscribe(() => {
              // const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/signed-in-redirect';
              // this.router.navigateByUrl(redirectURL);
          });
  }
  this._route.navigate(['/retrivequote']);
  this.close();
}
close() {
  this.dialog.closeAll();
}
getQuotationFormData() {
// this.loadPartner = this.globalService.spinnerShow(); 
this.motorQuoteService.getQuotationFormData().subscribe(response => {

    let formDataRes = response;
    this.partnersArr = formDataRes.Partners;
    this.partnersArr.forEach((item, index) => {

      if (item.PartnerId == this.partnerID) {
            this.partnerVal = item.PartnerId;
      }

    });
   // this.loadPartner = this.globalService.spinnerHide(); 
    this.retreiveQuoteForm.get('partner').setValue(this.partnerVal);

    this.businessSrcArr = formDataRes.busiSource;
 //   this.retreiveQuoteForm.get('businessSrc').setValue(this.businessSrcArr[0]);
    //this.callSearchHistroy();
    // console.log(this.partnerVal)
  
  });

}

 onVehiclAgeChange() {

    var d = new Date(this.retreiveQuoteForm.value.fromDate);
    let fromyear: number = d.getFullYear();
    let firstRegYear: number = d.getMonth();
    let date : number = d.getDate();

    let vhclNextYear = Number(firstRegYear);
    let nextdate = Number(date)+60;

    this.regMaxDate = new Date(fromyear, vhclNextYear, nextdate);
   // var p = new Date(this.retreiveQuoteForm.value.toDate);
  //  let policyStartDateYear: number = p.getMonth();

  //  let vhclNextYear = Number(vhclYear.value) + 1;
    let vhclPrevYear = Number(firstRegYear);
    this.regMinDate = new Date(fromyear, vhclPrevYear, date);
  
 }


callSearchHistroy(){

  if(sessionStorage.getItem("retreiveQuoteForm")!=null && sessionStorage.getItem("retreiveQuoteForm")!='' &&  typeof (sessionStorage.getItem("retreiveQuoteForm")) != undefined && typeof (sessionStorage.getItem("retreiveQuoteForm")) != "undefined"){

    let sessonData =JSON.parse(sessionStorage.getItem("retreiveQuoteForm"));
    // this.insuredDetailForm.get('partner').setValue(sessonData.partner);
  //  console.log(sessonData);
  //  var lobItem:any= [] ;
  //   this.lobs.forEach((item, index) => { console.log(sessonData.lob);
  //     if (item.value == sessonData.lob) {
  //       console.log(item);
  //       lobItem = item ;
        
  //       }
  //   });
   
    this.retreiveQuoteForm.get('fromDate').setValue(sessonData.fromDate);
    this.retreiveQuoteForm.get('toDate').setValue(sessonData.toDate);
    
    this.retreiveQuoteForm.get('businessSrc').setValue(sessonData.businessSrc);
    this.retreiveQuoteForm.get('status').setValue(sessonData.status);
    this.retreiveQuoteForm.get('optionalText').setValue(sessonData.optionalText);
    this.retreiveQuoteForm.get('product').setValue(sessonData.product);
    this.retreiveQuoteForm.get('quoteRefNum').setValue(sessonData.quoteRefNum);

    this.serachQuote();

    }
}




convertDate(inputFormat) {
  function pad(s) { return (s < 10) ? '0' + s : s; }
  var d = new Date(inputFormat);
  return ([ pad(d.getMonth()+1),pad(d.getDate()),d.getFullYear()].join('/'));
  
}

retrieveQuoteFormData(){
 // this.loadProducts = true; 

  this.motorQuoteService.retrieveQuoteFormData().subscribe(res => {
        let retrieveRes = res;
       // this.loadProducts = this.globalService.spinnerHide(); 
        this.products = retrieveRes.Products;
       // this.retreiveQuoteForm.value.product = this.products.Id;

  });
}

serachQuote(){
  this.quoteRes=true; 
  if(this.retreiveQuoteForm.invalid){
    return;
  }

  // var retriveSearchFormData:any = {partner:this.retreiveQuoteForm.value.partner,
  //   product: this.retreiveQuoteForm.value.product,
  //    fromDate:this.retreiveQuoteForm.value.fromDate,
  //    toDate:this.retreiveQuoteForm.value.toDate,
  //    quoteRefNum:this.retreiveQuoteForm.value.quoteRefNum,
  //    businessSrc:this.retreiveQuoteForm.value.businessSrc,
  //    status:this.retreiveQuoteForm.value.status,
  //    optionalText:this.retreiveQuoteForm.value.optionalText
  //  } ;
  // sessionStorage.setItem("retreiveQuoteForm", JSON.stringify(retriveSearchFormData));



  this.motorQuoteService.productionList(  this.retreiveQuoteForm.value.partner,
                                            this.retreiveQuoteForm.value.product.Id,
                                            this.convertDate(this.retreiveQuoteForm.value.fromDate),
                                            this.convertDate(this.retreiveQuoteForm.value.toDate),
                                            "MT"
                                           ).subscribe(res => {
   
    let quoteListRes = res;

    if (res.response_code == 1000) {
      const dialogRef = this.dialog.open(this.callAPIDialog);
  }

    if(quoteListRes.res_code == 1){
      this.res_Status = quoteListRes.res_status;
      this.quotations = quoteListRes.Quotations;
      this.lobCode = this.quotations[0].LOBCode;
      this.quoteRes = false;

      if(this.lobCode == 'HT'){
          this.quotations.forEach((item,index)=>{

              if(item == 'INITIATED'){
                this.statusDescription = item;
                this.quotations[index].mailStatus = false;
              }
                
          });
      }

      if(this.lobCode == 'MT'){
          this.quotations.forEach((item,index)=>{
              if(item == 'QUOTECONFIRMED' || item == 'INITIATED'){
                this.statusDescription = item;
                this.quotations[index].mailStatus = false;
              }
                
          });
      }
     
    }

    if(quoteListRes.res_code == 2){
      this.res_Status = quoteListRes.res_status;
      this.quoteRes = false;
    }
   
  });

  this.gridStatus = true;
 
}

getMotorQuoteDetail(quoteNum,status,schemeCode,QuoteType){
if(QuoteType == 'QUICKQUOTE')
{
  localStorage.setItem('SchemeCode', schemeCode);
 // this._route.navigate(["quickquote/update/" + quoteNum]);
  this._route.navigate(["motorquote/update/" + quoteNum]);
}
else{
  if(status == 'QUOTED' || status == 'REFREJECTED' || status == 'ADDITIONALINFO'){
      localStorage.setItem('SchemeCode', schemeCode);
        this._route.navigate(["motorquote/update/" + quoteNum]);
  }

  if( status == 'REFERRED' && this.businessSource == 'DIRECT' && this.partnerID == 1){
      localStorage.setItem('SchemeCode', schemeCode);
        this._route.navigate(["motorquote/update/" + quoteNum]);
  }
}
}

getFullQuote(QuotationNumber,SchemeCode){
  localStorage.setItem('SchemeCode', SchemeCode);
  this._route.navigate(["motorquote/update/"+ QuotationNumber]);
}

getApproveQuoteForPolicy(quoteNumber,status,schemeCode){
  if(status == 'REFAPPROVED' || status == 'QUOTECONFIRMED' || status == 'INITIATED') {
      this._route.navigate(["agentMotor/MTquotepage/approveQuote/" + quoteNumber]);
  }

  if(status == 'QUOTED' ){
      localStorage.setItem('SchemeCode', schemeCode);
        this._route.navigate(["agentMotor/MTquotepage/update/" + quoteNumber]);
  }

  if(status == 'REFREJECTED' ){
        if(this.businessSource == 'DIRECT' && this.partnerID == 1){
              localStorage.setItem('SchemeCode', schemeCode);
              this._route.navigate(["agentMotor/MTquotepage/update/" + quoteNumber]);
        }
 }

 if(status == 'ADDITIONALINFO' ){
      if(this.businessSource != 'DIRECT' || this.partnerID != 1){
            localStorage.setItem('SchemeCode', schemeCode);
            this._route.navigate(["agentMotor/MTquotepage/update/" + quoteNumber]);
      }
}

}
}
