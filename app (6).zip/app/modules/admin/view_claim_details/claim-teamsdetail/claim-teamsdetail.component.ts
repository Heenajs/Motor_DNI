import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ViewclaimService } from '../../../service/viewclaim.service';
import Swal from 'sweetalert2';
import { GlobalService } from '../../../service/global.service';
import { vehimodelyrs } from '../../motorquote/motoryear';
import { MatRadioChange } from '@angular/material/radio';

interface Visarigion{
  value: string;
  viewValue: string;
 }
 interface Updatestatus{
  value: string;
  viewValue: string;
 }
 interface Hours{
  value: string;
  viewValue: string;
 }
 interface Minuts{
  value: string;
  viewValue: string;
 }
 interface Times{
  value: string;
  viewValue: string;
 }

 
@Component({
  selector: 'app-claim-teamsdetail',
  templateUrl: './claim-teamsdetail.component.html',
  styleUrls: ['./claim-teamsdetail.component.scss']
})
export class ClaimTeamsdetailComponent implements OnInit {

  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('callAPIVehDialog') callAPIVehDialog: TemplateRef<any>;
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  
  claim_teamdetails: FormGroup; uploadDocs: FormGroup;
  public maskEid = [/[1-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/,];
  value: any; 
  language_code = 'ENG'; 
  country = 'United Arab Emirates';  
   vehicalmodelyears = vehimodelyrs;

 
  selectedYear: any ;
  invalidEID: boolean = true;
  partnerDataRes: any = []; formDataRes: any = []; cityArr: any = []; regType: any = []; tmpCountryList: any = []; vhclMakeArr: any = []; vhclModelArr: any = []; plateCodeArray: any = []; vehitrims: any = []; engineList: any = [];
  uplodMultipleSupportingDocs: any = []; supporting_docs: any = []; uplodMultipleVehDocs: any = []; garageListData: any = []; accidentLocationData: any = []; natureOfAccident: any = []; accidentAreaData: any = [];
  CoverType: string;
  PolicyType: string;
  schemeCode: string;
  public showLoader = {
    img_logo: false
  }
  landing_img: any;
  uploaded_img: any;
  uploaded_supporting_docs: any;
  uploaded_veh_docs: any;
  yearmod: any;
  accidentLocation: any;
  minDOB = new Date(new Date().setFullYear(new Date().getFullYear() - 99));
  maxDOB = new Date(new Date().setFullYear(new Date().getFullYear() - 18));
  policyMinDate = new Date(Date.now());
  policyMaxDate = new Date(new Date().setDate(new Date().getDate() + 30));
  accidentMinDate = new Date(new Date().setDate(new Date().getDate() - 30));
  modelId: any;
  vm: any;
  mYear: string = '';
  surveyForm: FormGroup;
  submitted: boolean = false;
  vMake: any;
  vMode: any;
  mReg: any;
  plaCode: any;
  policyNoButton: boolean = false;
  aaa: any;
  natureOfAccidentArray: any = [];
  constructor(public dialog: MatDialog, private _formBuilder: FormBuilder, public globalService: GlobalService, public motorQuoteService: MotorquoteService,public viewClaimService: ViewclaimService) { }


  ngOnInit(): void {
    this.claim_teamdetails = this._formBuilder.group({
      i_name: ['', [Validators.required,Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      e_id:  ['',[Validators.required,Validators.pattern('^784-?[0-9]{4}-?[0-9]{7}-?[0-9]{1}$')]],
      mob_number: ['', Validators.compose([Validators.required,Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
      email_Id: ['',[Validators.required,Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      location: ['', Validators.required],
      address: ['', Validators.required],
      alt_mob_no: [''],
      pol_num: ['', Validators.required],
      pol_exp_date: ['', Validators.required],
      m_year: ['', Validators.required],
      v_make: ['', Validators.required],
      v_model: ['', Validators.required],
      tc_num: ['',Validators.compose([Validators.required,Validators.minLength(8), Validators.maxLength(8)])],
      enginSize: ['', Validators.required],
      chassisNum: ['',Validators.compose([Validators.required,Validators.minLength(17), Validators.maxLength(17)])],
      reg_place: ['', Validators.required],
      plate_code: ['', Validators.required],
      plate_num: ['',Validators.compose([Validators.required,Validators.minLength(6), Validators.maxLength(6)])],
      accident_location: ['', Validators.required],
      accident_area: ['', Validators.required],
      accident_date: ['', Validators.required],
      a_hour: ['', Validators.required],
      a_minute: ['', Validators.required],
      a_duration: ['', Validators.required],
      nature_of_accident: ['', Validators.required],
      source_of_registration: ['', Validators.required],
      option1: ['', Validators.required],
      option2: [''],
      option3: [''],
      remarks1: [''],
      remarks2: [''],
      remarks3: [''],
      repair_Cost: [''],
      v_specification:[''],
      update_status:[''],
      estimated_parts_cost: ['', Validators.required],
      estimated_labor_cost: ['', Validators.required],
      estimated_other_cost: ['', Validators.required],
      total_cost: ['', Validators.required]
    });
    this.uploadDocs = this._formBuilder.group({
      supporting_FrontFilePath: '',
      supporting_FrontFileType: '',
      supporting_Doc: [''],
      vehicle_FrontFilePath: '',
      vehicle_FrontFileType:'',
    })
    console.log(this.claim_teamdetails.value)
    this.getAllFormData();
    // this.getGarageList();
    this.getNatureOfAccident();
    this.getAccidentLocation();
    



  this.surveyForm = this._formBuilder.group({
      claim_date: ['', Validators.required],
      claim_no: ['', Validators.required],
      additional_part: ['', Validators.required],
      repair_amount: ['', Validators.required],
      excess:['',Validators.required],
      redio1:['',Validators.required],
      redio2:['',Validators.required],
      redio3:['',Validators.required],
      redio4:['',Validators.required],
      redio5:['',Validators.required],
      redio6:['',Validators.required],
      redio7:['',Validators.required],
      redio8:['',Validators.required],
      redio9:['',Validators.required],
      redio10:['',Validators.required],
      redio11:['',Validators.required],
      redio12:['',Validators.required],
      redio13:['',Validators.required],
      redio14:['',Validators.required],
  });
}
  
  checkValidInputData(event: any, type) {
    this.globalService.checkValidInputData(event, type);
  }

  checkEID(value) {
    // console.log(this.insuredDetailForm);
    value = this.claim_teamdetails.value.emirates_id;
    // console.log(value);
    this.value = value;
    // console.log(this.value)
    // this.value = this.value.replace(/-/g, "");
    let pattern = /^784-?[0-9]{4}-?[0-9]{7}-?[0-9]{1}$/;
    // alert("pattern");
    // console.log(pattern.test(this.value));
    if (pattern.test(this.value) == false) {
      // alert("id is invalid");
      this.invalidEID = false;
    }
    else {
      this.invalidEID = true;
    }
    return;
    // if  
    if (this.invalidEID = true) {
      Swal.fire('Please Enter Valid Emirates Id', '', 'info')
    }
    if (this.value == "111111111111111" || this.value == "000000000000000" || this.value == "222222222222222" || this.value == "333333333333333") {
      this.invalidEID = false;
      this.claim_teamdetails.get("eIDCheck")?.setValue('1');

      // return this.invalidEID;
    }

    else {
      //The Luhn Algorithm.
      var nCheck = 0, nDigit = 0, bEven = false;
      this.value = this.value.replace(/\D/g, "");


      //784-1982-6961498-2

      for (let n = this.value.length - 1; n >= 0; n--) {

        var cDigit = this.value.charAt; nDigit = parseInt(this.value[n]);

        if (bEven) {
          if ((nDigit *= 2) > 9)
            nDigit -= 9;
        }

        nCheck += nDigit;
        bEven = !bEven;



      }

      if ((nCheck % 10) == 0) {
        //if valid, ok, check next
        this.invalidEID = false;
        this.claim_teamdetails.get("eIDCheck")?.setValue(1);

        return this.invalidEID;

      }
      else {
        this.invalidEID = true;
        this.claim_teamdetails.get("eIDCheck")?.setValue('');

        return this.invalidEID;
        //alert('Invalid Emirates ID. Please enter valid emirates Id including (-) dash/hypen.');
      }



    }

  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  //get All formData
  getAllFormData() {
    this.motorQuoteService.getDropdownData('COMPREHENSIVE','0',this.language_code,this.country,'').subscribe((res) => {
        this.cityArr = res.cityData;
        console.log( this.cityArr)
        this.regType = res.PlateCategory;
        this.formDataRes = res.countryData;
        this.tmpCountryList = this.formDataRes;
        // this.filteredNationCountries.next(this.formDataRes.slice());
        // res.PlateCategory.forEach((item, index) => {
        //   this.plateCatArray.push(item);
        // })
        // this.filteredPlateCat.next(this.plateCatArray.slice());
      });
  }

  //get vehicle make data
  getVhclMakeData(vhcleMake, year, type) { 
    // let yearmod = '';
    this.yearmod = year.value;
    console.log(this.yearmod)
    this.CoverType = 'MOTOR COMPREHENSIVE INSURANCE';
    this.PolicyType = 'INDIVIDUAL';
    this.schemeCode = '65S';
    this.motorQuoteService.getVhclMake(this.CoverType, this.PolicyType, this.language_code, this.yearmod, this.schemeCode).subscribe( res => {
      this.vhclMakeArr = res.vechileMakeValuesData;
      console.log(this.vhclMakeArr)
      // let vMakeVal;
    //   this.vhclMakeArr.forEach((item) => {
    //  if (item.VehicleMakeName == this.vMake) {
    //    vMakeVal = item;
       
    //  }
    //  });
    //  this.claim_teamdetails.get('v_make').setValue(vMakeVal);
    //  this.vhclMakeArr = [];
    //  this.vhclMakeArr.push({
    //    VehicleMakeId: 1,
    //    VehicleMakeName: this.vMake,
    //    Active: true,
    //    IsReferral: 0,
    //    CRS_VEH_CODE: 1
    //  })
     });

  }

  //get vehicle model data
  getVhclModel(vehclMkId, type, year) { 
    console.log(this.claim_teamdetails.value.v_make)
    this.motorQuoteService.getVehicleModel('P', this.claim_teamdetails.value.v_make, this.language_code, null, this.yearmod, this.schemeCode).subscribe(res => {
      this.vhclModelArr = res.vechileModelData;
      let vModeVal;
      this.vhclModelArr.forEach((item) => {
     if (item.VehicleModelName == this.vMode) {
      vModeVal = item;
     }
     });
     this.claim_teamdetails.get('v_model')?.setValue(vModeVal);
     });
   
  }

  //get plate code
  getPlateCode(regPlaceId, type) { 
    let plateSource = regPlaceId;

    let reg_type = 'PRIVATE';
    this.motorQuoteService.getPlateCode(this.language_code, plateSource, reg_type).subscribe(res => {
      this.plateCodeArray = res.plateCodeData;
      let plateCode;
    //   this.plateCodeArray.forEach((item) => {
    //  if (item.VehicleModelName == this.plaCode) {
    //   plateCode = item;
    //  }
    //  });
    //  this.claim_teamdetails.get('plate_code')?.setValue(plateCode);
    });
  }

  //get  trim details
  // getTrim(vhclModelId, type, year, modelName) { 
  //   this.motorQuoteService.getTrimList(
  //     this.claim_teamdetails.value.m_year.label,
  //     this.claim_teamdetails.value.v_model.VehicleModelName,
  //     this.claim_teamdetails.value.v_make.VehicleMakeName,
  //     '65S').subscribe(res => {
  //     this.vehitrims = res.response_message.LookupList;
  //     });
  //   this.getEngineList();
  // }
  getEngineList() {
    this.motorQuoteService.getEngineSizeListClaim(this.claim_teamdetails.value, this.schemeCode).subscribe(res => { 
      this.engineList = res.response_message?.LookupList;
    });
   
  }
    //garage list
    // getGarageList() {
    //   this.viewClaimService.getGarageList().subscribe((res) => {
    //     this.garageListData = res.garageList;
    //   })
    // }
  
     //Accident Location
  getAccidentLocation() {
    this.viewClaimService.getAccidentLocation().subscribe((res) => {
      this.accidentLocationData = res.accidentLocationData;
      console.log(this.accidentLocationData)
    });
  }
      //Accident Area
  getAccidentArea(locationId) {
    this.accidentLocation = locationId;
    this.viewClaimService.getAccidentArea(this.accidentLocation).subscribe((res) => {
      this.accidentAreaData = res.accidentAreaData;
    })
  }

  
    //nature of accident
    getNatureOfAccident() {
      this.viewClaimService.getNatureOfAccident('MT').subscribe((res) => {
        this.natureOfAccidentArray = res.accidentList
      })
    }

  saveClaimDetails() {
   
    this.checkEID(this.claim_teamdetails.value.emirates_id);
    
    if (this.claim_teamdetails.status == 'INVALID') {
      this.claim_teamdetails.markAllAsTouched();
      Swal.fire('', 'Please fill all mandatory data', 'error');
      return false;
    }
    if(this.submitted == false){
      Swal.fire('', 'Please fill Survey Form', 'error');
      return false
    }

    console.log(this.claim_teamdetails.value)
  }
  onFileChange(event, docName, files: FileList) {
    this.showLoader.img_logo = true;
     const formData = new FormData();
     formData.append('file', event.target.files[0]);
     formData.append('docName', docName);
     formData.append('source', 'B2B');
     formData.append('stage', 'QUOTE');
       formData.append('schemeCode', '65S');
       console.log(formData)
       this.motorQuoteService.uploadDocuments(formData).subscribe(res => { 
         this.showLoader.img_logo = false;
         this.landing_img = res.File;
         this.uploaded_img = res.FileDir;
         let fileType = res.File.split(".");
         fileType = fileType[fileType.length - 1];
         fileType = fileType == "pdf" ? "PDF" : "IMG";
         let formArrayValue: any = this.uploadDocs.value;
         formArrayValue[docName] = res.File;
         formArrayValue[docName + "FilePath"] = res.FileDir;
         let tempDocumentArray = {
           file_name: docName,
           file_dir: res.FileDir,
           docName: res.File,
         }
         console.log(tempDocumentArray);
         console.log(tempDocumentArray.file_dir);
         if (docName == 'supporting-document') {
           this.uploadDocs.get('supporting_FrontFilePath')?.setValue(res.FileDir);
           this.uploadDocs.get('supporting_FrontFileType')?.setValue(fileType);
         }
         else if (docName == 'veh-document') {
          this.uploadDocs.get('vehicle_FrontFilePath')?.setValue(res.FileDir);
          this.uploadDocs.get('vehicle_FrontFileType')?.setValue(fileType);
        }
         if (tempDocumentArray.file_name == 'supporting-document') {
           this.uploaded_supporting_docs = tempDocumentArray.file_dir;
           this.uplodMultipleSupportingDocs.push(this.uploaded_supporting_docs);
           console.log("1")
         }
         else if (tempDocumentArray.file_name == 'veh-document') {
          this.uploaded_veh_docs = tempDocumentArray.file_dir;
          this.uplodMultipleVehDocs.push(this.uploaded_veh_docs);
          console.log("2")
        }
        this.dialog.closeAll();
       });
  }


  //new start

  dateConvert(inputFormat) {
    let vDOEntryArray = inputFormat.split('/');
    let DOEntry = new Date();
    DOEntry.setDate(vDOEntryArray[0]);
    DOEntry.setMonth(vDOEntryArray[1] - 1);
    DOEntry.setFullYear(vDOEntryArray[2]);
    return DOEntry;
  }
 
  surveyReport(){
    if (this.surveyForm.status == 'INVALID') {
      this.surveyForm.markAllAsTouched();
      Swal.fire('','Please fill all mandatory data', 'error');
      return false;
    }else{
      console.log(this.surveyForm.value)
      this.dialog.closeAll();
      this.submitted = true
      console.log(this.surveyForm.controls.selectedOption1)
      // console.log(this.surveyForm.selectedOption1.value)
      
    }
  }
 
// new end


  image: any;
  openImgDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  visaregion: Visarigion[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'steak-1', viewValue: 'Abi Dhabi'},
    {value: 'steak-2', viewValue: 'Ajman'},
    {value: 'steak-3', viewValue: 'Sharjah'},
  ];
  updatestatus: Updatestatus[] = [
    {value: 'opt-0', viewValue: 'In Progress/Verification'},
    {value: 'opt-1', viewValue: 'Survey In Progress'},
    {value: 'opt-2', viewValue: 'Quotation Under Review'},
    {value: 'opt-3', viewValue: 'Quotation Approved'},
    {value: 'opt-4', viewValue: 'LPO Issued'},
    {value: 'opt-5', viewValue: 'Under Repair'},
    {value: 'opt-6', viewValue: 'Repair Completed'},
    {value: 'opt-7', viewValue: 'Dispatched'},
  ];

  hours: Hours[] = [
    {value: 'opt-0', viewValue: '01'},
    {value: 'opt-1', viewValue: '02'},
    {value: 'opt-2', viewValue: '03'},
    {value: 'opt-3', viewValue: '04'},
    {value: 'opt-4', viewValue: '05'},
    {value: 'opt-5', viewValue: '06'},
    {value: 'opt-6', viewValue: '07'},
    {value: 'opt-7', viewValue: '08'},
    {value: 'opt-8', viewValue: '09'},
    {value: 'opt-9', viewValue: '10'},
    {value: 'opt-10', viewValue: '11'},
    {value: 'opt-11', viewValue: '12'},
  ];
  minuts:Minuts[] = [
    {value: 'opt-0', viewValue: '00'},
    {value: 'opt-1', viewValue: '01'},
    {value: 'opt-2', viewValue: '02'},
    {value: 'opt-3', viewValue: '03'},
    {value: 'opt-4', viewValue: '04'},
    {value: 'opt-5', viewValue: '05'},
    {value: 'opt-6', viewValue: '06'},
    {value: 'opt-7', viewValue: '07'},
    {value: 'opt-8', viewValue: '08'},
    {value: 'opt-9', viewValue: '09'},
    {value: 'opt-10', viewValue: '10'},
    {value: 'opt-11', viewValue: '11'},
    {value: 'opt-12', viewValue: '12'},
    {value: 'opt-13', viewValue: '13'},
    {value: 'opt-14', viewValue: '14'},
    {value: 'opt-15', viewValue: '15'},
    {value: 'opt-16', viewValue: '16'},
    {value: 'opt-17', viewValue: '17'},
    {value: 'opt-18', viewValue: '18'},
    {value: 'opt-19', viewValue: '19'},
    {value: 'opt-20', viewValue: '20'},
    {value: 'opt-21', viewValue: '21'},
    {value: 'opt-22', viewValue: '22'},
    {value: 'opt-23', viewValue: '23'},
    {value: 'opt-24', viewValue: '24'},
    {value: 'opt-25', viewValue: '25'},
    {value: 'opt-26', viewValue: '26'},
    {value: 'opt-27', viewValue: '27'},
    {value: 'opt-28', viewValue: '28'},
    {value: 'opt-29', viewValue: '29'},
    {value: 'opt-30', viewValue: '30'},
    {value: 'opt-31', viewValue: '31'},
    {value: 'opt-32', viewValue: '32'},
    {value: 'opt-33', viewValue: '33'},
    {value: 'opt-34', viewValue: '34'},
    {value: 'opt-35', viewValue: '35'},
    {value: 'opt-36', viewValue: '36'},
    {value: 'opt-37', viewValue: '37'},
    {value: 'opt-38', viewValue: '38'},
    {value: 'opt-39', viewValue: '39'},
    {value: 'opt-40', viewValue: '40'},
    {value: 'opt-41', viewValue: '41'},
    {value: 'opt-42', viewValue: '42'},
    {value: 'opt-43', viewValue: '43'},
    {value: 'opt-44', viewValue: '44'},
    {value: 'opt-45', viewValue: '45'},
    {value: 'opt-46', viewValue: '46'},
    {value: 'opt-47', viewValue: '47'},
    {value: 'opt-48', viewValue: '48'},
    {value: 'opt-49', viewValue: '49'},
    {value: 'opt-50', viewValue: '50'},
    {value: 'opt-51', viewValue: '51'},
    {value: 'opt-52', viewValue: '52'},
    {value: 'opt-53', viewValue: '53'},
    {value: 'opt-54', viewValue: '54'},
    {value: 'opt-55', viewValue: '55'},
    {value: 'opt-56', viewValue: '56'},
    {value: 'opt-57', viewValue: '57'},
    {value: 'opt-58', viewValue: '58'},
    {value: 'opt-59', viewValue: '59'},
    {value: 'opt-60', viewValue: '60'},
    
  ];

  times:Times[] = [
    {value: 'opt-1', viewValue: 'AM'},
    {value: 'opt-2', viewValue: 'PM'},
  ];
  
 
  adduploaddoc1() {
    this.dialog.open(this.callAPIDialog);
      
 }
 adduploaddoc2() {
  this.dialog.open(this.callAPIVehDialog);  
}
 docupClose(){
    this.dialog.closeAll();
  }
  surveypop(){
    this.dialog.open(this.callAPIDialog1);     
  }


}
