import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerNopolicyComponent } from './customer-nopolicy.component';

describe('CustomerNopolicyComponent', () => {
  let component: CustomerNopolicyComponent;
  let fixture: ComponentFixture<CustomerNopolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerNopolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerNopolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
