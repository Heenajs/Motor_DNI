import { Component, OnInit,ViewChild ,TemplateRef} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatStepper } from '@angular/material/stepper';
import Swal from 'sweetalert2';

interface Product {
  value: string;
  viewValue: string;
}
interface Nationality{
  value: string;
  viewValue: string;
}
interface Subendorsement{
  value: string;
  viewValue: string;
}
interface Endorsement{
 value: string;
 viewValue: string;
}
interface Branch{
 value: string;
 viewValue: string;
}
interface CoverType{
 value: string;
 viewValue: string;
}

interface Visa{
 value: string;
 viewValue: string;
}

interface Visarigion{
 value: string;
 viewValue: string;
}
interface Partner{
 value: string;
 viewValue: string;
}


@Component({
  selector: 'app-customer-nopolicy',
  templateUrl: './customer-nopolicy.component.html',
  styleUrls: ['./customer-nopolicy.component.scss']
})
export class CustomerNopolicyComponent implements OnInit {

  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('stepper') stepper: MatStepper;

  panelOpenState = false;

  horizontalStepperForm: FormGroup;
  disabledStatus: boolean = false;

  formFieldHelpers: string[] = [''];
  Show: boolean=false;
  constructor(private _formBuilder: FormBuilder,public dialog: MatDialog,)
  {
  
  }


  ngOnInit(): void {

     // Horizontal stepper form
     this.horizontalStepperForm = this._formBuilder.group({
      policyDetails: this._formBuilder.group({
        have_Pol_Num: ['', Validators.required],
        pol_num: ['', Validators.required],
      }),
      step2: this._formBuilder.group({
         //  fullName: ['', Validators.required],
         //  lastName : ['', Validators.required],
         //  userName : ['', Validators.required],
         //  dueDate    : ['']
      }),
      step3: this._formBuilder.group({
       //  fullName: ['', Validators.required],
       //  lastName : ['', Validators.required],
       //  userName : ['', Validators.required],
       //  dueDate    : ['']
    }),
      step4: this._formBuilder.group({
              byEmail : this._formBuilder.group({
             //  companyNews     : [true],
             //  featuredProducts: [false],
             //  messages        : [true]
          }),

          pushNotifications: ['everything', Validators.required]
      })
  });

}
savepolicyDetails() {
    
  if (this.horizontalStepperForm.get('policyDetails').status == 'INVALID') {
    this.horizontalStepperForm.get('policyDetails').markAllAsTouched();
    Swal.fire('', "Please select all mandatory data", 'error')
    // this.stepper.previous();
    
  }
}

callChangeStepper(event: any, stepper) {
 
  if (event.selectedIndex == 0) {
    this.disabledStatus = false;
  }
}

  product: Product[] = [
    {value: 'steak-0', viewValue: 'Product A'},
    {value: 'pizza-1', viewValue: 'Product B'},
    {value: 'tacos-2', viewValue: 'Product C'},
  ];
  nation: Nationality[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'China'},
    {value: 'tacos-2', viewValue: 'France'},
  ];

  subendorsement: Subendorsement[] = [
    {value: 'steak-0', viewValue: 'Chang in Communication Address'},
    {value: 'pizza-1', viewValue: 'Chang in Email Address'},
    {value: 'pizza-2', viewValue: 'Chang in Mobile No'},
  ];
  endorsement: Endorsement[] = [
    {value: 'steak-0', viewValue: 'General Endorsement'},
    {value: 'pizza-1', viewValue: 'Addition/Deletion of Members'},
    {value: 'tacos-2', viewValue: 'Policy Cancellation'},
  ];
 
  visa: Visa[] = [
    {value: 'steak-0', viewValue: 'Visa Old'},
    {value: 'pizza-1', viewValue: 'Visa New'},
  ];
  visaregion: Visarigion[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'Abi Dhabi'},
    {value: 'steak-0', viewValue: 'Ajman'},
    {value: 'steak-0', viewValue: 'Sharjah'},
  ];

  branch: Branch[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'England'},
    {value: 'tacos-2', viewValue: 'India'},
    {value: 'tacos-2', viewValue: 'Japan'},
  ];
  partner: Partner[] = [
    {value: 'steak-0', viewValue: 'ABC Travel Agency'},
    {value: 'pizza-1', viewValue: 'AL Sayegh'},
    {value: 'tacos-2', viewValue: 'AL Sayegh insurance Broker'},
    {value: 'tacos-2', viewValue: 'Links insurance Broker'},
  ];
  coverTypes:CoverType[] = [
    {value: 'steak-0', viewValue: 'Self'},
    {value: 'pizza-1', viewValue: 'Self and Dependent'},
    {value: 'tacos-2', viewValue: 'Domestic Helper'},
    {value: 'tacos-3', viewValue: 'Parent'},
    {value: 'tacos-4', viewValue: 'Self Investor'}
  ];

  vehicalsearchClose() {
    this.dialog.closeAll();
  }
  
  searchVehicle() {
     this.dialog.open(this.callAPIDialog);     
  }
}
