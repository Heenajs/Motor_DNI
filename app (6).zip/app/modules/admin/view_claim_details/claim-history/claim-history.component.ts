import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-history',
  templateUrl: './claim-history.component.html',
  styleUrls: ['./claim-history.component.scss']
})
export class ClaimHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
