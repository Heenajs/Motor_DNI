import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { GlobalService } from '../../../service/global.service';
import { MotorquoteService } from '../../../service/motorquote.service';
import { Router, ActivatedRoute } from '@angular/router';

interface Visarigion{
  value: string;
  viewValue: string;
 }

 interface ClaimStatus{
  value: string;
  viewValue: string;
 }
@Component({
  selector: 'app-view-claims',
  templateUrl: './view-claims.component.html',
  styleUrls: ['./view-claims.component.scss']
})
export class ViewClaimsComponent implements OnInit {
  Search_claim: FormGroup;
  tabbody1:boolean = false;
  tabbody2:boolean = false;
  tabbody3:boolean = false;
  tabbody4:boolean = false;
  tabbody5:boolean = false;
  tabbody6:boolean = false;
  tabbody7:boolean = false;
  tabbody8:boolean = false;
  tabbody9:boolean = false;
  localStorageData: any;
  partnerId: any;
  userId: any;
  PartnerName: any;
  totalClaimList: any;
  totalClaimListLength: any;
  SubmittedArray: any = [];
  varificationArray: any;
  surveyArray: any;
  qApprovedArray: any;
  lpoIssuedArray: any;
  underRepayrArray: any;
  subLength = 0;
  verLength= 0;
  surLength= 0;
  qAppLength= 0;
  LPOLength= 0;
  URLength= 0;
  language_code = 'ENG'; country = 'United Arab Emirates';
  formDataRes: any = []; cityArr: any = []; regType: any = [];tmpCountryList: any = [];
  accidentMinDate = new Date(new Date().setDate(new Date().getDate() - 30));
  policyMinDate = new Date(Date.now());
  tcMin = 8;
  tcMax =10;
  constructor(  private _formBuilder: FormBuilder ,  public motorQuoteService: MotorquoteService , public globalService: GlobalService, public _route: Router, public _activatedroute: ActivatedRoute,) { }

  ngOnInit(): void {
    this.tab1();
    this.localStorageData = this.globalService.getLocalStorageData();
    console.log(this.localStorageData)
    this.partnerId = this.localStorageData.PartnerId;
    this.userId = this.localStorageData.UserId;
    this.PartnerName = this.localStorageData.PartnerName
    this.viewClaim();

    this.Search_claim = this._formBuilder.group({
      AccidentDate:['', Validators.required],
      i_name: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      claim_number: ['', Validators.required],
      chassisNum :  ['', Validators.compose([Validators.required, Validators.minLength(17), Validators.maxLength(17)])],
      pol_number: ['', Validators.required],
      plate_number:  ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(6)])],
      tc_number: ['', Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(10)])],
      mobileNum : ['', Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
      emailAdd :  ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      regPlace: ['', Validators.required],
      PR_number: ['', Validators.required],
      claimStatus: ['', Validators.required],

    });

    this.getAllFormData();
  }

  //search claim details
 
  checkValidInputData(event: any, type) {
    this.globalService.checkValidInputData(event, type);
  }
  getClaimDetailsByClaimrefno(claimRefNo){
    this._route.navigate(["claim-teams/update/" + claimRefNo]);
  }

  getAllFormData() {
    this.motorQuoteService.getDropdownData('COMPREHENSIVE', '0', this.language_code, this.country, '').subscribe((res) => {
      this.cityArr = res.cityData;
      this.regType = res.PlateCategory;
      this.formDataRes = res.countryData;
      this.tmpCountryList = this.formDataRes;
      // this.filteredNationCountries.next(this.formDataRes.slice());
      // res.PlateCategory.forEach((item, index) => {
      //   this.plateCatArray.push(item);
      // })
      // this.filteredPlateCat.next(this.plateCatArray.slice());
    
    
    });
  }
ValidTcNum(){
  if(this.Search_claim.value.regPlace.CityName != "Dubai"){
    this.tcMin = 10; this.tcMax = 10;
 }else{
   this.tcMin = 8; this.tcMax = 8;
          }
}
  Search_Claim(){
    if (this.Search_claim.status == 'INVALID') {
      this.Search_claim.markAllAsTouched();
      Swal.fire('', 'Please fill all mandatory data', 'error')
      return
    }

    console.log(this.Search_claim.value)
  }
  reset(){
    this.Search_claim.get('AccidentDate').setValue(null)
    this.Search_claim.get('i_name').setValue(null)
    this.Search_claim.get('claim_number').setValue(null)
    this.Search_claim.get('chassisNum').setValue(null)
    this.Search_claim.get('pol_number').setValue(null)
    this.Search_claim.get('plate_number').setValue(null)
    this.Search_claim.get('tc_number').setValue(null)
    this.Search_claim.get('mobileNum').setValue(null)
    this.Search_claim.get('emailAdd').setValue(null)
    this.Search_claim.get('regPlace').setValue(null)
    this.Search_claim.get('PR_number').setValue(null)
    this.Search_claim.get('claimStatus').setValue(null)

  }
  viewClaim(){
    console.log(this.partnerId);
    console.log(this.userId);
    this.motorQuoteService.getClaimList(this.partnerId , this.userId).subscribe((res) =>{
      if(res.response_code == "1"){
      this.totalClaimList = res.response_data
       this.totalClaimListLength = this.totalClaimList.length
     
       //  new Submitted
        this.totalClaimList.forEach((item) => {
        if (item.ClaimStatus=="SUBMITTED" || item.ClaimStatus=="REGISTERED" ) {
          this.SubmittedArray.push(item);
          this.subLength++
         }
         
        });

        // verificatin/Review
        // this.totalClaimList.forEach((item) => {
        //   if (item.ClaimStatus=="SUBMITTED") {
        //     this.varificationArray.push(item);
        //     this.verLength++
        //    }          
        //   }); 
        
        // Survey
        // this.totalClaimList.forEach((item) => {
        //     if (item.ClaimStatus=="SUBMITTED") {
        //       this.surveyArray.push(item);
        //       this.surLength++
        //      }          
        //     }); 
            
        // Quotation Approved 
        // this.totalClaimList.forEach((item) => {
        //   if (item.ClaimStatus=="SUBMITTED") {
        //     this.qApprovedArray.push(item);
        //     this.qAppLength++
        //    }          
        //   });  
          
        // LPO Issued
        // this.totalClaimList.forEach((item) => {
        //   if (item.ClaimStatus=="SUBMITTED") {
        //     this.lpoIssuedArray.push(item);
        //     this.LPOLength++
        //    }          
        //   });
        
        // Under Repair
        // this.totalClaimList.forEach((item) => {
        //   if (item.ClaimStatus=="SUBMITTED") {
        //     this.underRepayrArray.push(item);
        //     this.URLength++
        //    }          
        //   });
}

      });
  }
  
  tab1(){
    this.tabbody1=true;
    this.tabbody2=false;
    this.tabbody3=false;
    this.tabbody4=false;
    this.tabbody5=false;
    this.tabbody6=false;
    this.tabbody7=false;
  }
  tab2(){
    this.tabbody1=false;
    this.tabbody2=true;
    this.tabbody3=false;
    this.tabbody4=false;
    this.tabbody5=false;
    this.tabbody6=false;
    this.tabbody7=false;
  }
  tab3(){
    this.tabbody1=false;
    this.tabbody2=false;
    this.tabbody3=true;
    this.tabbody4=false;
    this.tabbody5=false;
    this.tabbody6=false;
    this.tabbody7=false;
  }
  tab4(){
    this.tabbody1=false;
    this.tabbody2=false;
    this.tabbody3=false;
    this.tabbody4=true;
    this.tabbody5=false;
    this.tabbody6=false;
    this.tabbody7=false;
  }
  tab5(){
    this.tabbody1=false;
    this.tabbody2=false;
    this.tabbody3=false;
    this.tabbody4=false;
    this.tabbody5=true;
    this.tabbody6=false;
    this.tabbody7=false;
  }
  tab6(){
    this.tabbody1=false;
    this.tabbody2=false;
    this.tabbody3=false;
    this.tabbody4=false;
    this.tabbody5=false;
    this.tabbody6=true;
    this.tabbody7=false;
  }
  tab7(){
    this.tabbody1=false;
    this.tabbody2=false;
    this.tabbody3=false;
    this.tabbody4=false;
    this.tabbody5=false;
    this.tabbody6=false;
    this.tabbody7=true;
  }
  visaregion: Visarigion[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'Abi Dhabi'},
    {value: 'steak-0', viewValue: 'Ajman'},
    {value: 'steak-0', viewValue: 'Sharjah'},
  ];
  claimStatus: ClaimStatus[] = [
    {value: 'New Submitted', viewValue: 'New Submitted'},
    {value: 'Verification/Review', viewValue: 'Verification/Review'},
    {value: 'Survey', viewValue: 'Survey'},
    {value: 'Quotation Approved', viewValue: 'Quotation Approved'},
    {value: 'LPO Issued', viewValue: 'LPO Issued'},
    {value: 'Under Repair', viewValue: 'Under Repair'},
  ];
}
