import { Component, OnInit,ViewChild ,TemplateRef} from '@angular/core';
import { FormBuilder, FormGroup, RequiredValidator, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ViewclaimService } from '../../../service/viewclaim.service';
import Swal from 'sweetalert2';
import { GlobalService } from '../../../service/global.service';
import { vehimodelyrs } from '../../motorquote/motoryear';
import { invalid } from 'moment';
import {insuredDetailForm , invalidData , insvehibys ,maskEid ,codeData} from '../../motorquote/variable';
interface Product {
   value: string;
   viewValue: string;
 }
 interface Nationality{
   value: string;
   viewValue: string;
 }
 interface Subendorsement{
   value: string;
   viewValue: string;
 }
 interface Endorsement{
  value: string;
  viewValue: string;
 }
 interface Branch{
  value: string;
  viewValue: string;
 }
 interface CoverType{
  value: string;
  viewValue: string;
 }

 interface Visa{
  value: string;
  viewValue: string;
 }

 interface Visarigion{
  value: string;
  viewValue: string;
 }
 interface Partner{
  value: string;
  viewValue: string;
 }


@Component({
  selector: 'app-register-claim',
  templateUrl: './register-claim.component.html',
  styleUrls: ['./register-claim.component.scss']
})

export class RegisterClaimComponent implements OnInit {

 @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  public maskEid = maskEid ;
  panelOpenState = false;

  horizontalStepperForm: FormGroup;
  SearchForm: FormGroup;
  formFieldHelpers: string[] = [''];
  Show: boolean=false;
  policyNoButton : boolean=false;
  plaCode: any;
  mReg: any;
  cityArr: any = []
  vMode: any;
  vMake: any;
  mYear: any;
  vehicalmodelyears = vehimodelyrs;
  vhclMakeArr: any = [];
  vhclModelArr: any = [];
  plateCodeArray: any = []; 
  vehitrims: any = [];
  engineList: any = [];
  policyMinDate = new Date(Date.now());
  policyMaxDate = new Date(new Date().setDate(new Date().getDate() + 30));
  regType: any = []; tmpCountryList: any = [];
  formDataRes: any = [];
  language_code = 'ENG'; 
  country = 'United Arab Emirates';
  yearmod: any;
  CoverType: string;
  PolicyType: string;
  schemeCode: string; 
  garageListData: any = []; 
  accidentLocationArray: any = [];
   natureOfAccidentArray: any = []; 
   accidentAreaData: any = [];
  accidentLocation: any;
  localStorageData: any;
  u_name: any;
  PartyCode: any;
  cedantId: any;
  userId: any;
  vmakeValue : boolean = false;
  vmodelValue : boolean = false;
  pCodelValue : boolean = false;
  submittedStep1 = false;
  submittedStep2 = false;
  submittedStep3 = false
  public steps = {
    step1 : true,
    step2 : true,
    step3 : true
  }
  public showLoader = {
    drivingLicenseFront: false,
    drivingLicenseBack: false,
    carRegistrationFront: false,
    carRegistrationback: false,
    driverEmiratesId_PassportFront: false,
    driverEmiratesId_PassportBack: false,
    policeReport: false,
    accidentphotos: false

  }
  landing_img: any;
  uploaded_img: any;
  uploaded_supporting_docs: any;
  uploaded_veh_docs: any;
  uplodMultipleSupportingDocs: any = [];
  uplodMultipleVehDocs: any = [];
  docNameType: any;
  sideForm: any;
  partnerId: any;
  partnerBranchArr: any = [];
  public creditLimit = { CreditLimit: 0, AvailableLimit: 0 }; public noCreditLimt = 0;
  branchId: any;
  branchVal: any;
  retrieveQuoteNumber: any = ''; 
  quoteDetail: any;
  disabledStatus: boolean = false;
  minlength: any;
  maxlength: any;
  partnersArr: any;
  Claim_Reference_Number: any;
  image: any;
  drivingLicF: any;
  drivingLicB: any;
  documentData: any;
  carRegistrationF: any;
  carRegistrationB: any;
  driverEmiratesF: any;
  driverEmiratesB: any;
  policeReport: any;
  AccidentPhotos: any;
  dlfDocName: any;
  dlbDocName: any;
  crfDocName: any;
  crbDocName: any;
  defDocName: any;
  debDocName: any;
  prDocName: any;
  apDocName: any;
  dlffileType: any;
  dlbfileType: any;
  crffileType: any;
  crbfileType: any;
  deffileType: any;
  debfileType: any;
  prfileType: any;
  apfileType: any;
  additionalDocFile: any =[];
  accidentLocationData: any;
  tempPolicyNumber: any;
  accidentMinDate = new Date(new Date().setDate(new Date().getDate() - 30));
  tcMin: number;
  tcMax: number;
  constructor(private _formBuilder: FormBuilder,public dialog: MatDialog,public globalService: GlobalService, public motorQuoteService: MotorquoteService,public viewClaimService: ViewclaimService)
  { }
  ngOnInit(): void {
    //new start
     this.getAccidentLocation();
    this.getAllFormData();
    this.getQuotationFormData();
    this.getNatureOfAccident();
    this.localStorageData = this.globalService.getLocalStorageData();
    this.partnerId = this.localStorageData.PartnerId;
    this.u_name = this.localStorageData.UserName;
    this.partner = this.localStorageData.PartnerId;
    this.PartyCode = this.localStorageData.PartyCode;
    this.cedantId = this.localStorageData.CedantId;
    this.userId = this.localStorageData.UserId;
   
    // Horizontal stepper form
  
    this.SearchForm = this._formBuilder.group({
      insuredName   :  ['',[Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      policyNumber :[''],
      plateNumber :['',[Validators.compose([ Validators.minLength(6),Validators.maxLength(6)])]],
      tcNumber:['',[Validators.compose([ Validators.minLength(8),Validators.maxLength(10)])]],
    });

    this.sideForm = this._formBuilder.group({
      schemeCode: ['', Validators.required],
      partnerID: ['', Validators.required],
      branchID: ['', Validators.required],
      Accounting: ['']
    });

    this.horizontalStepperForm = this._formBuilder.group({
     step1: this._formBuilder.group({

      InsName:  ['',[Validators.required,Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      Emirates_id: ['',[Validators.required,Validators.pattern('^784-?[0-9]{4}-?[0-9]{7}-?[0-9]{1}$')]],
      mobNum: ['',[Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])]],
      emailAdd: ['',[Validators.compose([Validators.required,Validators.pattern('[a-zA-Z0-9.-_-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])]],
      location:['', Validators.required],
      address:['', Validators.required],

      pol_numb: ['', Validators.required],
      pol_exp_date: ['', Validators.required],
      m_year: ['', Validators.required],
      v_make: ['', Validators.required],
      v_model: ['', Validators.required],
      tc_num: ['',[Validators.compose([ Validators.required,Validators.minLength(8),Validators.maxLength(10)])]],
      enginSize: ['', Validators.required],
      engineTrim: ['', Validators.required],
      chassisNum: ['',[Validators.compose([ Validators.required,Validators.minLength(17),Validators.maxLength(17)])]],
      reg_place: ['', Validators.required],
      plate_code: ['',[Validators.compose([ Validators.required,Validators.minLength(6),Validators.maxLength(6)])]],
      plate_num: ['', Validators.required],
     }),
     step2: this._formBuilder.group({
         acci_Loc: ['', Validators.required],
         Acci_City : ['', Validators.required],
         Nature_Acci : ['', Validators.required],
         acci_date : ['', Validators.required],
     }),
     step3: this._formBuilder.group({
         claimDesc : [''],
         Driving_License_FrontFilePath: ['', Validators.required],
         Driving_License_FrontFileType: '',
         Driving_License_BackFilePath: ['', Validators.required],
         Driving_License_BackFileType: '',
         Car_Registration_FrontFilePath: ['', Validators.required],
         Car_Registration_FrontFileType: '',
         Car_Registration_BackFilePath: ['', Validators.required],
         Car_Registration_BackFileType: '',
         Driver_Emirates_Id_Passport_FrontFilePath: ['', Validators.required],
         Driver_Emirates_Id_Passport_FrontFileType: '',
         Driver_Emirates_Id_Passport_BackFilePath: ['', Validators.required],
         Driver_Emirates_Id_Passport_BackFileType: '',
         Police_ReportFilePath: ['', Validators.required],
         Police_ReportFileType: '',
         Accident_PhotosFilePath: ['', Validators.required],
         Accident_PhotosFileType: '',
         supporting_Doc: '',
        }),
        step4: this._formBuilder.group({
             byEmail : this._formBuilder.group({
           
         }),

         
     })
 });
 
 }
 numberOnly(event): boolean {
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

checkValidInputData(event: any, type) {
  this.globalService.checkValidInputData(event, type);
}
reset(){
  this.SearchForm.get('insuredName').setValue(null)
  this.SearchForm.get('policyNumber').setValue(null)
  this.SearchForm.get('plateNumber').setValue(null)
  this.SearchForm.get('tcNumber').setValue(null)
}

searchData(){
  // Swal.fire("Error","Please Enter Any Valid Data ","warning") 
}

 saveStep1(){
  if(this.horizontalStepperForm.get('step1').status == "VALID"){
    this.submittedStep1 = true;
   }
  console.log(this.horizontalStepperForm.get('step1').value)
  
 }
 saveStep2(){
   if(this.horizontalStepperForm.get('step2').status == "INVALID"){
    return
   }

  this.motorQuoteService.registerClaimNew(
                   this.horizontalStepperForm.get('step1').get('pol_numb').value,
                   this.horizontalStepperForm.get('step2').get('acci_date').value,
                   this.horizontalStepperForm.get('step3').get('claimDesc').value,
                   this.horizontalStepperForm.get('step2').get('acci_Loc').value,
                   this.horizontalStepperForm.get('step2').get('Acci_City').value,
                   this.horizontalStepperForm.get('step1').get('InsName').value,
                   this.horizontalStepperForm.get('step1').get('location').value,
                   this.horizontalStepperForm.get('step1').get('chassisNum').value,
                   this.horizontalStepperForm.get('step1').get('emailAdd').value,
                   this.horizontalStepperForm.get('step1').get('v_make').value,
                   this.horizontalStepperForm.get('step1').get('v_model').value,
                   this.horizontalStepperForm.get('step1').get('engineTrim').value,
                   this.horizontalStepperForm.get('step1').get('enginSize').value,
                   this.horizontalStepperForm.get('step1').get('m_year').value,
                   this.horizontalStepperForm.get('step1').get('Emirates_id').value ,
                   this.horizontalStepperForm.get('step1').get('plate_code').value,
                   this.horizontalStepperForm.get('step1').get('plate_num').value,
                   this.horizontalStepperForm.get('step1').get('pol_exp_date').value,
                   this.horizontalStepperForm.get('step1').get('reg_place').value,
                   this.horizontalStepperForm.get('step1').get('mobNum').value,
                   this.horizontalStepperForm.get('step1').get('tc_num').value,
                   this.horizontalStepperForm.get('step2').get('Nature_Acci').value,
                                                        ).subscribe((res) =>{
                    if(res.response_code =="1")   {                               
                    console.log(res)
                    this.Claim_Reference_Number = res.response_data[0].claimrefnum
                    // Swal.fire("","Your Claim has been registered successfully ","success")
                    this.submittedStep2 = true
                    }


  });
 }

 submitClaim(){
  console.log(this.horizontalStepperForm.get('step3').value)
   if(this.horizontalStepperForm.get('step3').status == "INVALID"){
    Swal.fire("Error","Please Upload All Documents ","warning")
    return
   }
   console.log(this.Claim_Reference_Number)
   console.log(this.additionalDocFile)

  this.motorQuoteService.uploadClaimDocuments(this.Claim_Reference_Number,this.additionalDocFile).subscribe((res) =>{
                    if(res.response_code == "1"){
                    console.log(res)
                    this.submittedStep3 = true
                    // Swal.fire("","Your Claim has been registered successfully ","success")
                    }
                   
  });  

 }
 onFileChange(event, docName, files: FileList) {
  console.log(docName)
  this.docNameType = docName;
  if (this.docNameType == 'Driving_License_Front') {
    this.showLoader.drivingLicenseFront = true;
  }
  if (this.docNameType == 'Driving_License_Back') {
    this.showLoader.drivingLicenseBack = true;
  }
  if (this.docNameType == 'Car_Registration_Front') {
    this.showLoader.carRegistrationFront = true;
  }
  if (this.docNameType == 'Car_Registration_Back') {
    this.showLoader.carRegistrationback = true;
  }
  if (this.docNameType == 'Driver_Emirates_Id_Passport_Front') {
    this.showLoader.driverEmiratesId_PassportFront = true;
  }
  if (this.docNameType == 'Driver_Emirates_Id_Passport_Back') {
    this.showLoader.driverEmiratesId_PassportBack = true;
  }
  if (this.docNameType == 'Police_Report') {
    this.showLoader.policeReport = true;
  }
  if (this.docNameType == 'Accident_Photos') {
    this.showLoader.accidentphotos = true;
  }
   let formData = new FormData();
   formData.append('file', event.target.files[0]);
   formData.append('docName', docName);
   formData.append('source', 'B2B');
   formData.append('stage', 'QUOTE');
     formData.append('schemeCode', '65S');
     console.log(formData)
     this.motorQuoteService.uploadDocuments(formData).subscribe(res => { 
      console.log(res)
      this.documentData = res;
       this.landing_img = res.File;
       this.uploaded_img = res.FileDir;
       let fileType = res.File.split(".");
       fileType = fileType[fileType.length - 1];
       fileType = fileType == "pdf" ? "PDF" : "IMG";
       let formArrayValue: any = this.horizontalStepperForm.get('step3').value;
       formArrayValue[docName] = res.File;
       formArrayValue[docName + "FilePath"] = res.FileDir;
       let tempDocumentArray = {
         file_name: docName,
         file_dir: res.FileDir,
         docName: res.File,
       }
       this.additionalDocFile.push({
        "DocumentName":res.File ,
        "DocumentType": docName,
        "DocumentExtn":"png" ,
        "DocumentLink":res.FileDir 
      });
      console.log(this.additionalDocFile)
       if(res.res_code == "1"){
        if (this.docNameType == 'Driving_License_Front') {
          this.showLoader.drivingLicenseFront = false;
          this.drivingLicF = res.FileDir;
          this.dlfDocName = docName;
          this.dlffileType = fileType;
        }
        if (this.docNameType == 'Driving_License_Back') {
          this.showLoader.drivingLicenseBack = false;
          this.drivingLicB = res.FileDir;
          this.dlbDocName = docName;
          this.dlbfileType = fileType;
        }
        if (this.docNameType == 'Car_Registration_Front') {
          this.showLoader.carRegistrationFront = false;
          this.carRegistrationF = res.FileDir;
          this.crfDocName = docName;
          this.crffileType = fileType;
        }
        if (this.docNameType == 'Car_Registration_Back') {
          this.showLoader.carRegistrationback = false;
          this.carRegistrationB = res.FileDir;
          this.crbDocName = docName;
          this.crbfileType = fileType;
        }
        if (this.docNameType == 'Driver_Emirates_Id_Passport_Front') {
          this.showLoader.driverEmiratesId_PassportFront = false;
          this.driverEmiratesF = res.FileDir;
          this.defDocName = docName;
          this.deffileType = fileType;
        }
        if (this.docNameType == 'Driver_Emirates_Id_Passport_Back') {
          this.showLoader.driverEmiratesId_PassportBack = false;
          this.driverEmiratesB = res.FileDir;
          this.debDocName = docName;
          this.debfileType = fileType;
        }
        if (this.docNameType == 'Police_Report') {
          this.showLoader.policeReport = false;
          this.policeReport = res.FileDir;
          this.prDocName = docName;
          this.prfileType = fileType;
        }
        if (this.docNameType == 'Accident_Photos') {
          this.showLoader.accidentphotos = false;
          this.AccidentPhotos = res.FileDir;
          this.apDocName = docName;
          this.apfileType = fileType;
        }
       }
       if (docName == 'Driving_License_Front') {
         this.horizontalStepperForm.get('step3').get('Driving_License_FrontFilePath')?.setValue(res.FileDir);
         this.horizontalStepperForm.get('step3').get('Driving_License_FrontFileType')?.setValue(fileType);
       }
       else if (docName == 'Driving_License_Back') {
        this.horizontalStepperForm.get('step3').get('Driving_License_BackFilePath')?.setValue(res.FileDir);
        this.horizontalStepperForm.get('step3').get('Driving_License_BackFileType')?.setValue(fileType);
      }
      else if (docName == 'Car_Registration_Front') {
        this.horizontalStepperForm.get('step3').get('Car_Registration_FrontFilePath')?.setValue(res.FileDir);
        this.horizontalStepperForm.get('step3').get('Car_Registration_FrontFileType')?.setValue(fileType);
      }
      else if (docName == 'Car_Registration_Back') {
        this.horizontalStepperForm.get('step3').get('Car_Registration_BackFilePath')?.setValue(res.FileDir);
        this.horizontalStepperForm.get('step3').get('Car_Registration_BackFileType')?.setValue(fileType);
      }
      else if (docName == 'Driver_Emirates_Id_Passport_Front') {
        this.horizontalStepperForm.get('step3').get('Driver_Emirates_Id_Passport_FrontFilePath')?.setValue(res.FileDir);
        this.horizontalStepperForm.get('step3').get('Driver_Emirates_Id_Passport_FrontFileType')?.setValue(fileType);
      }
      else if (docName == 'Driver_Emirates_Id_Passport_Back') {
        this.horizontalStepperForm.get('step3').get('Driver_Emirates_Id_Passport_BackFilePath')?.setValue(res.FileDir);
        this.horizontalStepperForm.get('step3').get('Driver_Emirates_Id_Passport_BackFileType')?.setValue(fileType);
      } 
      else if (docName == 'Police_Report') {
        this.horizontalStepperForm.get('step3').get('Police_ReportFilePath')?.setValue(res.FileDir);
        this.horizontalStepperForm.get('step3').get('Police_ReportFileType')?.setValue(fileType);
      }
       else if (docName == 'Accident_Photos') {
        this.horizontalStepperForm.get('step3').get('Accident_PhotosFilePath')?.setValue(res.FileDir);
        this.horizontalStepperForm.get('step3').get('Accident_PhotosFileType')?.setValue(fileType);
      }

       if (tempDocumentArray.file_name == 'Accident_Photos') {
         this.uploaded_supporting_docs = tempDocumentArray.file_dir;
         this.uplodMultipleSupportingDocs.push(this.uploaded_supporting_docs);
         console.log("1")
         console.log(this.uplodMultipleSupportingDocs)
       }
      
     });
}
openImgDialog(img) {
  const dialogRef = this.dialog.open(this.callAPIDialog);
  dialogRef.afterClosed().subscribe((result) => { });
  this.image = img;
}
close()
 { this.dialog.closeAll(); 
}

accountChange(event) {
    let branch = this.sideForm.value.branchID;
    this.sideForm.get("Accounting").setValue(branch);
    this.getPartnerCreditLimit();
  }
getQuotationFormData() {
  this.motorQuoteService.getQuotationFormData().subscribe(response => {
    this.formDataRes = response;
    this.minlength = response.ChassisNoValidMin;
    this.maxlength = response.ChassisNoValidMax;
    this.partnersArr = this.formDataRes.Partners;
    if (this.retrieveQuoteNumber == '') {
      this.sideForm.get("partnerID")?.setValue(this.partnerId);
      this.getPartnerBranchList();
    }
  });
}
getPartnerBranchList() {
  this.partnerBranchArr = [];
  this.motorQuoteService
    .getpartnerBranch(this.sideForm.value.partnerID)
    .subscribe((res) => {
      let updateRes: any = res;
      this.partnerBranchArr = updateRes.branchList;
      this.branchId = updateRes.branchList[0];
      //  branch
      if (this.retrieveQuoteNumber == '') {
        this.partnerBranchArr.forEach((item, index) => {
          if (item.Id == this.branchId.Id) {
            this.branchVal = item;
          }
        });
        this.sideForm.get('branchID')?.setValue(this.branchVal.Id);
        this.sideForm.get('Accounting')?.setValue(this.branchVal.Id);
      }
      else {
        this.sideForm.get('Accounting')?.setValue(this.quoteDetail.CedantBrokerBranchId);
        this.sideForm.get('branchID')?.setValue(this.quoteDetail.CedantBrokerBranchId);
      }
    });
}
public getPartnerCreditLimit() {   // LOB 10 for motor
  if (this.sideForm.value.branchID != '') {
    this.motorQuoteService.partnerCreditLimit(3, this.partnerId, this.sideForm.value.branchID).subscribe(res => {
      if (res.response_message == null) {
        this.noCreditLimt = 0;
        this.creditLimit = { CreditLimit: 0, AvailableLimit: 0 };
      }
      else {
        this.creditLimit = res.response_message;
        this.noCreditLimt = 0;
      }
    })
  }
  else {
    setTimeout(() => { this.getPartnerCreditLimit(); }, 500);
  }
}
getParterLimitOnSelection() {
  this.partnerId = this.sideForm.value.partnerID;
  this.motorQuoteService.partnerCreditLimit(10, this.partnerId, this.sideForm.value.branchID).subscribe(res => {
    if (res.response_message == null) {
      this.noCreditLimt = 0;
      this.creditLimit = { CreditLimit: 0, AvailableLimit: 0 };
    }
    else {
      this.creditLimit = res.response_message;
      this.noCreditLimt = 1;
    }
  })
}
//get All formData
getAllFormData() {
  this.motorQuoteService.getDropdownData('COMPREHENSIVE','0',this.language_code,this.country,'').subscribe((res) => {
      this.cityArr = res.cityData;
      this.regType = res.PlateCategory;
      this.formDataRes = res.countryData;
      this.tmpCountryList = this.formDataRes;
      // this.filteredNationCountries.next(this.formDataRes.slice());
      // res.PlateCategory.forEach((item, index) => {
      //   this.plateCatArray.push(item);
      // })
      // this.filteredPlateCat.next(this.plateCatArray.slice());
    });
}

//get vehicle make data
getVhclMakeData(vhcleMake, year, type) { 
  // let yearmod = '';

  this.vmakeValue =true;
  this.yearmod = year.value;
  console.log(this.yearmod)
  this.CoverType = 'MOTOR COMPREHENSIVE INSURANCE';
  this.PolicyType = 'INDIVIDUAL';
  this.schemeCode = '65S';
  this.motorQuoteService.getVhclMake(this.CoverType, this.PolicyType, this.language_code, this.yearmod, this.schemeCode).subscribe( res => {
    this.vhclMakeArr = res.vechileMakeValuesData;
    console.log(this.vhclMakeArr)
    this.vmakeValue =false;
   });

}

//get vehicle model data
getVhclModel(vehclMkId, type, year) { 

  this.vmodelValue = true
  this.motorQuoteService.getVehicleModel('P', this.horizontalStepperForm.get('step1').value.v_make, this.language_code, null, this.yearmod, this.schemeCode).subscribe(res => {
    this.vhclModelArr = res.vechileModelData;
    this.vmodelValue = false
   });
 
}

//get plate code
getPlateCode(regPlaceId, type) { 

  this.pCodelValue = true
  let plateSource = regPlaceId;

  if(plateSource != "Dubai"){
    this.tcMin = 10; this.tcMax = 10;
  }else{
    this.tcMin = 8; this.tcMax = 8;
  }

  let reg_type = 'PRIVATE';
  this.motorQuoteService.getPlateCode(this.language_code, plateSource, reg_type).subscribe(res => {
    this.plateCodeArray = res.plateCodeData;
    
    this.pCodelValue = false
   });
}


getEngineList() {
  this.motorQuoteService.getEngineSizeListRegister(this.horizontalStepperForm.get('step1').value, this.schemeCode).subscribe(res => { 
    this.engineList = res.response_message?.LookupList;
  });
  this.trimlistData()
}

//trim list
trimlistData(){
this.motorQuoteService.getTrimListRegister(this.horizontalStepperForm.get('step1').value, this.schemeCode).subscribe(res => {
this.vehitrims =res
});
}

  //garage list
  getGarageList() {
    this.viewClaimService.getGarageList().subscribe((res) => {
      this.garageListData = res.garageList;
    })
  }
  
   //Accident Location
getAccidentLocation() {
  this.viewClaimService.getAccidentLocation().subscribe((res) => {
    this.accidentLocationData = res.accidentLocationData;
  });
}
    //Accident Area
    getAccidentArea(locationId) {
      this.accidentLocation = locationId;
      this.viewClaimService.getAccidentArea(this.accidentLocation).subscribe((res) => {
        this.accidentAreaData = res.accidentAreaData;
      })
}

  //nature of accident
  getNatureOfAccident() {
    this.viewClaimService.getNatureOfAccident('MT').subscribe((res) => {
      this.natureOfAccidentArray = res.accidentList
    })
  }


 dateConvert(inputFormat) {
  let vDOEntryArray = inputFormat.split('/');
  let DOEntry = new Date();
  DOEntry.setDate(vDOEntryArray[0]);
  DOEntry.setMonth(vDOEntryArray[1] - 1);
  DOEntry.setFullYear(vDOEntryArray[2]);
  return DOEntry;
}


 
 product: Product[] = [
  {value: 'steak-0', viewValue: 'Product A'},
  {value: 'pizza-1', viewValue: 'Product B'},
  {value: 'tacos-2', viewValue: 'Product C'},
];
nation: Nationality[] = [
  {value: 'steak-0', viewValue: 'Dubai'},
  {value: 'pizza-1', viewValue: 'China'},
  {value: 'tacos-2', viewValue: 'France'},
];

subendorsement: Subendorsement[] = [
  {value: 'steak-0', viewValue: 'Chang in Communication Address'},
  {value: 'pizza-1', viewValue: 'Chang in Email Address'},
  {value: 'pizza-2', viewValue: 'Chang in Mobile No'},
];
endorsement: Endorsement[] = [
  {value: 'steak-0', viewValue: 'General Endorsement'},
  {value: 'pizza-1', viewValue: 'Addition/Deletion of Members'},
  {value: 'tacos-2', viewValue: 'Policy Cancellation'},
];

visa: Visa[] = [
  {value: 'steak-0', viewValue: 'Visa Old'},
  {value: 'pizza-1', viewValue: 'Visa New'},
];
visaregion: Visarigion[] = [
  {value: 'steak-0', viewValue: 'Dubai'},
  {value: 'pizza-1', viewValue: 'Abi Dhabi'},
  {value: 'steak-0', viewValue: 'Ajman'},
  {value: 'steak-0', viewValue: 'Sharjah'},
];

branch: Branch[] = [
  {value: 'steak-0', viewValue: 'Dubai'},
  {value: 'pizza-1', viewValue: 'England'},
  {value: 'tacos-2', viewValue: 'India'},
  {value: 'tacos-2', viewValue: 'Japan'},
];
partner: Partner[] = [
  {value: 'steak-0', viewValue: 'ABC Travel Agency'},
  {value: 'pizza-1', viewValue: 'AL Sayegh'},
  {value: 'tacos-2', viewValue: 'AL Sayegh insurance Broker'},
  {value: 'tacos-2', viewValue: 'Links insurance Broker'},
];
coverTypes:CoverType[] = [
  {value: 'steak-0', viewValue: 'Self'},
  {value: 'pizza-1', viewValue: 'Self and Dependent'},
  {value: 'tacos-2', viewValue: 'Domestic Helper'},
  {value: 'tacos-3', viewValue: 'Parent'},
  {value: 'tacos-4', viewValue: 'Self Investor'}
];


}