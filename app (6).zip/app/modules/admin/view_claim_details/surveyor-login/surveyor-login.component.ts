import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

interface Visarigion{
  value: string;
  viewValue: string;
 }
 interface Updatestatus{
  value: string;
  viewValue: string;
 }
 interface Hours{
  value: string;
  viewValue: string;
 }
 interface Minuts{
  value: string;
  viewValue: string;
 }
 interface Times{
  value: string;
  viewValue: string;
 }

@Component({
  selector: 'app-surveyor-login',
  templateUrl: './surveyor-login.component.html',
  styleUrls: ['./surveyor-login.component.scss']
})
export class SurveyorLoginComponent implements OnInit {
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  surveyor_login: FormGroup

  constructor(public dialog: MatDialog, private _formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.surveyor_login = this._formBuilder.group({
      i_name: [''],
      e_id: [''],
      mob_number: [''],
      email_Id: [''],
      location: [''],
      address: [''],
      alt_mob_no: [''],
      pol_num: [''],
      pol_exp_date: [''],
      m_year: [''],
      v_make: [''],
      v_model: [''],
      tc_num: [''],
      enginSize: [''],
      chassisNum: [''],
      reg_plate: [''],
      plate_code: [''],
      plate_num: [''],
      accident_location: [''],
      accident_area: [''],
      accident_date: [''],
      a_hour: [''],
      a_minute: [''],
      a_duration: [''],
      nature_of_accident: [''],
      source_of_registration: [''],
      option1: ['', Validators.required],
      option2: [''],
      option3: [''],
      remarks1: [''],
      remarks2: [''],
      remarks3: [''],
      repair_Cost: [''],
      claim_date: [''],
      claim_no: [''],
      update_status: [''],
      additional_part: ['', Validators.required],
      repair_amount: ['', Validators.required],
      excess:['',Validators.required],
      estimated_parts_cost: ['', Validators.required],
      estimated_labor_cost: ['', Validators.required],
      estimated_other_cost: ['', Validators.required],
      total_cost: ['', Validators.required]
    });
  }

  saveClaimDetails() {
    if (this.surveyor_login.status == 'INVALID') {
      this.surveyor_login.markAllAsTouched();
      Swal.fire('', 'Please fill all mandatory data', 'error');
      return false;
    }
  }

  visaregion: Visarigion[] = [
    {value: 'steak-0', viewValue: 'Dubai'},
    {value: 'pizza-1', viewValue: 'Abi Dhabi'},
    {value: 'steak-0', viewValue: 'Ajman'},
    {value: 'steak-0', viewValue: 'Sharjah'},
  ];
  updatestatus: Updatestatus[] = [
    {value: 'opt-0', viewValue: 'Quotation Under Review'},
    {value: 'opt-1', viewValue: 'Under Repair'},
    {value: 'opt-2', viewValue: 'Survey In Progress'},
    {value: 'opt-3', viewValue: 'Survey Completed'},
  ];
  hours: Hours[] = [
    {value: 'opt-0', viewValue: '01'},
    {value: 'opt-1', viewValue: '02'},
    {value: 'opt-2', viewValue: '03'},
    {value: 'opt-3', viewValue: '04'},
    {value: 'opt-4', viewValue: '05'},
    {value: 'opt-5', viewValue: '06'},
    {value: 'opt-6', viewValue: '07'},
    {value: 'opt-7', viewValue: '08'},
    {value: 'opt-8', viewValue: '09'},
    {value: 'opt-9', viewValue: '10'},
    {value: 'opt-10', viewValue: '11'},
    {value: 'opt-11', viewValue: '12'},
  ];
  minuts:Minuts[] = [
    {value: 'opt-0', viewValue: '00'},
    {value: 'opt-1', viewValue: '01'},
    {value: 'opt-2', viewValue: '02'},
    {value: 'opt-3', viewValue: '03'},
    {value: 'opt-4', viewValue: '04'},
    {value: 'opt-5', viewValue: '05'},
    {value: 'opt-6', viewValue: '06'},
    {value: 'opt-7', viewValue: '07'},
    {value: 'opt-8', viewValue: '08'},
    {value: 'opt-9', viewValue: '09'},
    {value: 'opt-10', viewValue: '10'},
    {value: 'opt-11', viewValue: '11'},
    {value: 'opt-12', viewValue: '12'},
    {value: 'opt-13', viewValue: '13'},
    {value: 'opt-14', viewValue: '14'},
    {value: 'opt-15', viewValue: '15'},
    {value: 'opt-16', viewValue: '16'},
    {value: 'opt-17', viewValue: '17'},
    {value: 'opt-18', viewValue: '18'},
    {value: 'opt-19', viewValue: '19'},
    {value: 'opt-20', viewValue: '20'},
    {value: 'opt-21', viewValue: '21'},
    {value: 'opt-22', viewValue: '22'},
    {value: 'opt-23', viewValue: '23'},
    {value: 'opt-24', viewValue: '24'},
    {value: 'opt-25', viewValue: '25'},
    {value: 'opt-26', viewValue: '26'},
    {value: 'opt-27', viewValue: '27'},
    {value: 'opt-28', viewValue: '28'},
    {value: 'opt-29', viewValue: '29'},
    {value: 'opt-30', viewValue: '30'},
    {value: 'opt-31', viewValue: '31'},
    {value: 'opt-32', viewValue: '32'},
    {value: 'opt-33', viewValue: '33'},
    {value: 'opt-34', viewValue: '34'},
    {value: 'opt-35', viewValue: '35'},
    {value: 'opt-36', viewValue: '36'},
    {value: 'opt-37', viewValue: '37'},
    {value: 'opt-38', viewValue: '38'},
    {value: 'opt-39', viewValue: '39'},
    {value: 'opt-40', viewValue: '40'},
    {value: 'opt-41', viewValue: '41'},
    {value: 'opt-42', viewValue: '42'},
    {value: 'opt-43', viewValue: '43'},
    {value: 'opt-44', viewValue: '44'},
    {value: 'opt-45', viewValue: '45'},
    {value: 'opt-46', viewValue: '46'},
    {value: 'opt-47', viewValue: '47'},
    {value: 'opt-48', viewValue: '48'},
    {value: 'opt-49', viewValue: '49'},
    {value: 'opt-50', viewValue: '50'},
    {value: 'opt-51', viewValue: '51'},
    {value: 'opt-52', viewValue: '52'},
    {value: 'opt-53', viewValue: '53'},
    {value: 'opt-54', viewValue: '54'},
    {value: 'opt-55', viewValue: '55'},
    {value: 'opt-56', viewValue: '56'},
    {value: 'opt-57', viewValue: '57'},
    {value: 'opt-58', viewValue: '58'},
    {value: 'opt-59', viewValue: '59'},
    {value: 'opt-60', viewValue: '60'},
    
  ];

  times:Times[] = [
    {value: 'opt-1', viewValue: 'AM'},
    {value: 'opt-2', viewValue: 'PM'},
  ];

  adduploaddoc() {
    this.dialog.open(this.callAPIDialog);     
 }
 docupClose(){
    this.dialog.closeAll();
  }
 
  surveypop(){
    this.dialog.open(this.callAPIDialog1);     
  }

}
