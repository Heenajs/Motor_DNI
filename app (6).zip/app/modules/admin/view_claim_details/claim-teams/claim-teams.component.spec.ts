import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimTeamsComponent } from './claim-teams.component';

describe('ClaimTeamsComponent', () => {
  let component: ClaimTeamsComponent;
  let fixture: ComponentFixture<ClaimTeamsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimTeamsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimTeamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
