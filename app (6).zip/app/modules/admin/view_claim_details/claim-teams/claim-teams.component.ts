import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ViewclaimService } from '../../../service/viewclaim.service';
import Swal from 'sweetalert2';
import { GlobalService } from '../../../service/global.service';
import { vehimodelyrs } from '../../motorquote/motoryear';
import { Router, ActivatedRoute } from '@angular/router';
interface Visarigion {
  value: string;
  viewValue: string;
}
interface Updatestatus {
  value: string;
  viewValue: string;
}
interface Hours {
  value: string;
  viewValue: string;
}
interface Minuts {
  value: string;
  viewValue: string;
}
interface Times {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-claim-teams',
  templateUrl: './claim-teams.component.html',
  styleUrls: ['./claim-teams.component.scss']
})
export class ClaimTeamsComponent implements OnInit {
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('callAPIDialog') callAPIDialog2: TemplateRef<any>;
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  @ViewChild('callAPIVehDialog') callAPIVehDialog: TemplateRef<any>;
  

  claim_teams: FormGroup; 
  uploadDocs: FormGroup;
  public maskEid = [/[1-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/,];
  value: any; language_code = 'ENG'; country = 'United Arab Emirates'; vehicalmodelyears = vehimodelyrs;
  invalidEID: boolean = true;
  partnerDataRes: any = []; formDataRes: any = []; cityArr: any = []; regType: any = []; tmpCountryList: any = []; vhclMakeArr: any = []; vhclModelArr: any = []; plateCodeArray: any = []; vehitrims: any = []; engineList: any = [];
  uplodMultipleSupportingDocs: any = []; supporting_docs: any = []; uplodMultipleVehDocs: any = []; garageListData: any = []; accidentLocationData: any = []; natureOfAccident: any = []; accidentAreaData: any = [];
  CoverType: string;
  PolicyType: string;
  schemeCode: string;
  yearmod: any;
  multilpleFile: any = []
  image: any;
  minDOB = new Date(new Date().setFullYear(new Date().getFullYear() - 99));
  maxDOB = new Date(new Date().setFullYear(new Date().getFullYear() - 18));
  policyMinDate = new Date(Date.now());
  policyMaxDate = new Date(new Date().setDate(new Date().getDate() + 30));
  accidentMinDate = new Date(new Date().setDate(new Date().getDate() - 30));
  public showLoader = {
    img_logo: false
  }
  landing_img: any;
  uploaded_img: any;
  uploaded_supporting_docs: any;
  uploaded_veh_docs: any;
  accidentLocation: any;
  policyNoButton: boolean = false;
  fetchButton: boolean = true;
  showdata:boolean;
  hideField:boolean;
  retrieveQuoteNumber: any;
  retrieveclaimRefNumber: any;
  claimDetailsData: any;
  i_name: any;
  vhclMakeArrr: any[];
  locArray: any[];
  event: string;
  vehicleModelName: any;
  isButtonDisabled: boolean = false;
  supoortDocument: any[];
  vehicleDocument: any[];

  constructor(public dialog: MatDialog, private formBuilder: FormBuilder, public globalService: GlobalService, public motorQuoteService: MotorquoteService, public viewClaimService: ViewclaimService,public _route: Router, public _activatedroute: ActivatedRoute) { }

  ngOnInit(): void {
    this.claim_teams = this.formBuilder.group({
      CType:[''],
      i_name: ['', [Validators.required, Validators.pattern('^[a-zA-Z\.\/ ]+$')]],
      emirates_id: ['',[Validators.required,Validators.pattern('^784-?[0-9]{4}-?[0-9]{7}-?[0-9]{1}$')]],
      mobile_number: ['', Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
      email_address: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      nationality: ['', Validators.required],
      dob: ['', Validators.required],
      alt_mob_no: ['', Validators.compose([ Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^((050|052|054|055|056|057|058|059){1}([0-9]{7}))$/)])],
      pol_no: ['', Validators.required],
      pol_exp_date: ['', Validators.required],
      m_year: ['', Validators.required],
      v_make: ['', Validators.required],
      v_model: ['', Validators.required],
      tc_num: ['', Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(10)])],
      engine_size: ['', Validators.required],
      chassis_num: ['', Validators.compose([Validators.required, Validators.minLength(17), Validators.maxLength(17)])],
      reg_place: ['', Validators.required],
      plate_code: ['', Validators.required],
      plate_num: ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(6)])],
      accident_location: ['', Validators.required],
      accident_area: ['', Validators.required],
      accident_date: ['', Validators.required],
      nature_of_accident: ['', Validators.required],
      source_of_registration: ['', Validators.required],
      a_hour: ['', Validators.required],
      a_minute: ['', Validators.required],
      a_time: ['', Validators.required],
     
    })

    // option1: [''],
    // option2: [''],
    // option3: [''],
    // remarks1: [''],
    // remarks2: [''],
    // remarks3: [''],
    // select_action: ['']

    this.uploadDocs = this.formBuilder.group({
      supporting_FrontFilePath: '',
      supporting_FrontFileType: '',
      supporting_Doc: '',
      vehicle_FrontFilePath: '',
      vehicle_FrontFileType: '',
    })
    this.getAllFormData();
    this.getGarageList();
    this.getAccidentLocation();
    this.getNatureOfAccident();

    const routeParams = this._activatedroute.snapshot.params;
    if (routeParams.claimRefNo) {
      this.retrieveclaimRefNumber = routeParams.claimRefNo;
      console.log(this.retrieveclaimRefNumber);
     
    }
  }
  ngAfterViewInit(): void {
    if ((this.retrieveclaimRefNumber != '' && this.retrieveclaimRefNumber != undefined)) {
      setTimeout(() => { this.getClaimDetailsByClaimrefno(); }, 2000);
    }
 
  }

  checkValidInputData(event: any, type) {
    this.globalService.checkValidInputData(event, type);
  }

  checkEID(value) {
    value = this.claim_teams.value.emirates_id;
    this.value = value;
    this.value = this.value.replace(/-/g, "");
    let pattern = /^784-?[0-9]{4}-?[0-9]{7}-?[0-9]{1}$/;
    if (pattern.test(this.value) == false) {
      // alert("id is invalid");
      this.invalidEID = false;
    }
    else {
      this.invalidEID = true;
    }
    return;
    // if  
    if (this.invalidEID = true) {
      Swal.fire('Please Enter Valid Emirates Id', '', 'info')
    }
    if (this.value == "111111111111111" || this.value == "000000000000000" || this.value == "222222222222222" || this.value == "333333333333333") {
      this.invalidEID = false;
      this.claim_teams.get("eIDCheck")?.setValue('1');

      // return this.invalidEID;
    }

    else {
      //The Luhn Algorithm.
      var nCheck = 0, nDigit = 0, bEven = false;
      this.value = this.value.replace(/\D/g, "");


      //784-1982-6961498-2

      for (let n = this.value.length - 1; n >= 0; n--) {

        var cDigit = this.value.charAt; nDigit = parseInt(this.value[n]);

        if (bEven) {
          if ((nDigit *= 2) > 9)
            nDigit -= 9;
        }

        nCheck += nDigit;
        bEven = !bEven;



      }

      if ((nCheck % 10) == 0) {
        //if valid, ok, check next
        this.invalidEID = false;
        this.claim_teams.get("eIDCheck")?.setValue(1);

        return this.invalidEID;

      }
      else {
        this.invalidEID = true;
        this.claim_teams.get("eIDCheck")?.setValue('');

        return this.invalidEID;
        //alert('Invalid Emirates ID. Please enter valid emirates Id including (-) dash/hypen.');
      }



    }

  }

  faultclaim(){
    this.hideField=false;
  }
  recoclaim(){
    this.hideField=true;
  }
  Approve()
  {

    console.log(this.claim_teams.value)
    

    if (this.claim_teams.status == 'INVALID') {
       this.claim_teams.markAllAsTouched();
      Swal.fire('', 'Please fill all mandatory data', 'error')
       return
    }
    this.event = "APPROVE"
    this.motorQuoteService.UpdateClaim( this.retrieveclaimRefNumber,
      this.event,
      this.claim_teams.get('pol_no').value,
      this.claim_teams.get('accident_date').value,
      this.claim_teams.get('accident_location').value,
      this.claim_teams.get('accident_area').value,
      this.claim_teams.get('i_name').value,
      this.claim_teams.get('dob').value,
      this.claim_teams.get('nationality').value,
      this.claim_teams.get('chassis_num').value,
      this.claim_teams.get('email_address').value,
      this.claim_teams.get('v_make').value,
      this.claim_teams.get('v_model').value.VehicleModelName,
      this.claim_teams.get('engine_size').value,
      this.claim_teams.get('m_year').value,
      this.claim_teams.get('emirates_id').value,
      this.claim_teams.get('plate_code').value,
      this.claim_teams.get('plate_num').value,
      this.claim_teams.get('pol_exp_date').value,
      this.claim_teams.get('reg_place').value,
      this.claim_teams.get('mobile_number').value,

      ).subscribe((res) => {
if(res.response_code = "1"){
  this.isButtonDisabled = true; 
Swal.fire('',"Claim Updated Successfully", 'success')
 this.showdata=true;
}else if(res.response_code = "2"){
Swal.fire('', 'Please Provide Validate Input Values', 'error')
return
}else{
return
}

})
  }
  Reject()
  {
    this.event = "REJECT"
    this.showdata=false;
  }

 



  //get All formData
  getAllFormData() {
    this.motorQuoteService.getDropdownData('COMPREHENSIVE', '0', this.language_code, this.country, '').subscribe((res) => {
      this.cityArr = res.cityData;
      this.regType = res.PlateCategory;
      this.formDataRes = res.countryData;
      this.tmpCountryList = this.formDataRes;
      // this.filteredNationCountries.next(this.formDataRes.slice());
      // res.PlateCategory.forEach((item, index) => {
      //   this.plateCatArray.push(item);
      // })
      // this.filteredPlateCat.next(this.plateCatArray.slice());
    
     
    });
  }

  //get vehicle make data
  getVhclMakeData(vhcleMake, year, type) {
    // let yearmod = '';
    this.yearmod = year.value;
    this.CoverType = 'MOTOR COMPREHENSIVE INSURANCE';
    this.PolicyType = 'INDIVIDUAL';
    this.schemeCode = '65S';
    this.motorQuoteService.getVhclMake(this.CoverType, this.PolicyType, this.language_code, this.yearmod, this.schemeCode).subscribe(res => {
      this.vhclMakeArr = res.vechileMakeValuesData;
      let vMakeVal;
      this.vhclMakeArr.forEach((item) => {
       if (item.VehicleMakeName == this.claimDetailsData.VehicleMake) {
         vMakeVal = item;
        }
      });
      
      this.vhclMakeArr = [];
      this.vhclMakeArr.push({
        VehicleMakeId: 1,
        VehicleMakeName: this.claimDetailsData.VehicleMake,
        Active: true,
        IsReferral: 0,
        CRS_VEH_CODE: 1
      })
      this.claim_teams.get('v_make')?.setValue(this.vhclMakeArr[0]);
        
      });

      let regPlace;
      this.cityArr.forEach((item) => {
       if (item.CityName == this.claimDetailsData.RegistrationPlace) {
        regPlace = item;
        }
        this.claim_teams.get('reg_place')?.setValue(regPlace);
      });    
      }

  //get vehicle model data
    getVhclModel(vehclMkId, type, year) {
    this.motorQuoteService.getVehicleModel('P', this.vhclMakeArr[0], this.language_code, null, this.yearmod, this.schemeCode).subscribe(res => {
      this.vhclModelArr = res.vechileModelData;
      let vModel
      this.vhclModelArr.forEach((item) => {
     if ( item.VehicleModelName  == this.claimDetailsData.VehicleModel) {
      vModel = item;
      }
    });
    
    this.claim_teams.get('v_model')?.setValue(vModel);  
    });
  }

  //get plate code
  getPlateCode(regPlaceId, type) {
    let plateSource = regPlaceId;
    let reg_type = 'PRIVATE';
    this.motorQuoteService.getPlateCode(this.language_code, plateSource, reg_type).subscribe(res => {
      this.plateCodeArray = res.plateCodeData;
   

    let plateCode
    this.plateCodeArray.forEach((item) => {
    if ( item.PlateCode  == this.claimDetailsData.PlateCode) {
      plateCode = item;
    }
    this.claim_teams.get('plate_code')?.setValue(plateCode);
    });
  });
  }

  dateConvert(inputFormat) {
    let vDOEntryArray = inputFormat.split('/');
    let DOEntry = new Date();
    DOEntry.setDate(vDOEntryArray[0]);
    DOEntry.setMonth(vDOEntryArray[1] - 1);
    DOEntry.setFullYear(vDOEntryArray[2]);
    return DOEntry;
  }

  getEngineList() {
    this.motorQuoteService.getEngineSizeListClaim(this.claim_teams.value, this.schemeCode).subscribe(res => {

      if(res.response_code == "1"){
      this.engineList = res.response_message?.LookupList;
      console.log(this.engineList)
      }else{
        return
      }
    });
  }

  onFileChange(event, docName, files: FileList) {
    this.showLoader.img_logo = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('docName', docName);
    formData.append('source', 'B2B');
    formData.append('stage', 'QUOTE');
    formData.append('schemeCode', '65S');
    this.motorQuoteService.uploadDocuments(formData).subscribe(res => {
      this.showLoader.img_logo = false;
      this.landing_img = res.File;
      this.uploaded_img = res.FileDir;
      let fileType = res.File.split(".");
      fileType = fileType[fileType.length - 1];
      fileType = fileType == "pdf" ? "PDF" : "IMG";
      let formArrayValue: any = this.uploadDocs.value;
      formArrayValue[docName] = res.File;
      formArrayValue[docName + "FilePath"] = res.FileDir;
      let tempDocumentArray = {
        file_name: docName,
        file_dir: res.FileDir,
        docName: res.File,
      }

      // this.multilpleFile.push({
      //   "file": this.multilpleFile.FileDir,
      //   "fileType": fileType,
      //   'file_name': 'Other',
      //   'file_dir': this.multilpleFile.FileDir,
      //   'docName': this.multilpleFile.File,
      // });

      console.log(tempDocumentArray);
      console.log(tempDocumentArray.file_dir);
      if (docName == 'supporting-document') {
        this.uploadDocs.get('supporting_FrontFilePath')?.setValue(res.FileDir);
        this.uploadDocs.get('supporting_FrontFileType')?.setValue(fileType);
      }
      else if (docName == 'veh-document') {
        this.uploadDocs.get('vehicle_FrontFilePath')?.setValue(res.FileDir);
        this.uploadDocs.get('vehicle_FrontFileType')?.setValue(fileType);
      }
      if (tempDocumentArray.file_name == 'supporting-document') {
        this.uploaded_supporting_docs = tempDocumentArray.file_dir;
        this.uplodMultipleSupportingDocs.push(this.uploaded_supporting_docs);
      }
      else if (tempDocumentArray.file_name == 'veh-document') {
        this.uploaded_veh_docs = tempDocumentArray.file_dir;
        this.uplodMultipleVehDocs.push(this.uploaded_veh_docs);
      }
      this.dialog.closeAll();
    });
  }

  validatePolicyNum(event){
    this.policyNoButton = true
  }

  openImgDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog2);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  //garage list
  getGarageList() {
    this.viewClaimService.getGarageList().subscribe((res) => {
      this.garageListData = res.garageList;
    })
  }

  //Accident Location
  getAccidentLocation() {
    this.viewClaimService.getAccidentLocation().subscribe((res) => {
      this.accidentLocationData = res.accidentLocationData;
    });
  }

  //Accident Area
  getAccidentArea(locationId) {
    this.accidentLocation = locationId;
    this.viewClaimService.getAccidentArea( this.accidentLocation).subscribe((res) => {
      this.accidentAreaData = res.accidentAreaData;

      let acciArea
      this.accidentAreaData.forEach((item) => {
     if ( item.Id  == this.claimDetailsData.AccidentCity) {
      acciArea = item;
      }
      });
    this.claim_teams.get('accident_area')?.setValue(acciArea);
    })
  }

  //nature of accident
  getNatureOfAccident() {
    this.viewClaimService.getNatureOfAccident('MT').subscribe((res) => {
      this.natureOfAccident = res.accidentList

     
    })
  }

  submitClaimTeams() {
    if (this.claim_teams.status == 'INVALID') {
      // this.claim_teams.markAllAsTouched();
      // Swal.fire('', 'Please fill all mandatory data', 'error')
      //  return
    }
   

   
  }
  fetchData(){
    console.log(this.claim_teams.controls.tc_num.status)
    if (this.claim_teams.controls.tc_num.status == 'INVALID' || this.claim_teams.controls.pol_no.status == 'INVALID' || this.claim_teams.controls.chassis_num.status == 'INVALID') {
      this.claim_teams.get('tc_num').markAsTouched()
      this.claim_teams.get('pol_no').markAsTouched()
      this.claim_teams.get('chassis_num').markAsTouched()
      Swal.fire('', 'Please fill all mandatory data', 'error')
      return
    }

    this.motorQuoteService.searchClaimDetails(this.claim_teams.get('tc_num').value,
                                              this.claim_teams.get('pol_no').value,
                                              this.claim_teams.get('chassis_num').value,).subscribe((res) => {
      if(res.response_code == "1"){
        console.log(res)
      }else if(res.response_code == "2"){
      Swal.fire('', 'Please Provide Validate Input Values', 'error')
      return
      }else{
       return
      }

    })
  }

  getClaimDetailsByClaimrefno(){

    this.fetchButton = false;

    this.motorQuoteService.getClaimDetailsByClaimrefno( this.retrieveclaimRefNumber).subscribe((res) => {
    console.log(res)
    if(res.response_code == "1"){

    this.claimDetailsData = res.response_data[0]
    this.claim_teams.get('i_name')?.setValue(this.claimDetailsData.InsuredName);
    this.claim_teams.get('emirates_id')?.setValue(this.claimDetailsData.NationalId);
    this.claim_teams.get('dob')?.setValue(this.claimDetailsData.InsuredDOB);
    this.claim_teams.get('mobile_number')?.setValue(this.claimDetailsData.MobileNumber);
    this.claim_teams.get('email_address')?.setValue(this.claimDetailsData.EmailAddress);
    this.claim_teams.get('pol_no')?.setValue(this.claimDetailsData.PolicyNumber);
    // this.claim_teams.get('tc_num')?.setValue(this.claimDetailsData.InsuredDOB);
    this.claim_teams.get('chassis_num')?.setValue(this.claimDetailsData.ChassisNumber);
    this.claim_teams.get('pol_exp_date')?.setValue(this.claimDetailsData.PolicyExpiryDate);

    // Model Year
    let mYear
    this.vehicalmodelyears.forEach((item, index) => {
        if (item.label == this.claimDetailsData.ModelYear) {
          mYear = item;
        }
    });
    this.claim_teams.get('m_year')?.setValue(mYear);
    
    this.claim_teams.get('plate_num')?.setValue(this.claimDetailsData.PlateNumber);
    this.claim_teams.get('accident_date')?.setValue(this.claimDetailsData.AccidentDate);

     //Accident Location
      let acciLoc
      this.accidentLocationData.forEach((item) => {
      if ( item.Id  == this.claimDetailsData.AccidentLocation) {
      acciLoc = item;
      }
      this.claim_teams.get('accident_location')?.setValue(acciLoc);
      });

      let accinat
      this.accidentLocationData.forEach((item) => {
      if ( item.ClaimType  == this.claimDetailsData.ClaimType) {
        accinat = item;
      }
      this.claim_teams.get('nature_of_accident')?.setValue(accinat);
      });

    }
    });

      // get Claim Document Details
      this.motorQuoteService.getClaimDocsByClaimrefno( this.retrieveclaimRefNumber).subscribe((res) => {
      if(res.response_code == "1"){

      
       this.multilpleFile = res.response_data
       let VehicleDoc = [];
        let supportDoc = [];
        
        this.multilpleFile.forEach((item) => {
          if (item.DocumentType === "Accident_Photos") {
            VehicleDoc.push(item);
          } else {
            supportDoc.push(item);
          }
        });
        this.supoortDocument = supportDoc;
        this.vehicleDocument = VehicleDoc;
        
      }else{
        return
      }
          })
  }


  visaregion: Visarigion[] = [
    { value: 'steak-0', viewValue: 'Dubai' },
    { value: 'pizza-1', viewValue: 'Abi Dhabi' },
    { value: 'steak-0', viewValue: 'Ajman' },
    { value: 'steak-0', viewValue: 'Sharjah' },
  ];

  updatestatus: Updatestatus[] = [
    { value: 'opt-0', viewValue: 'In Progress/Verification' },
    { value: 'opt-1', viewValue: 'Survey In Progress' },
    { value: 'opt-2', viewValue: 'Quotation Under Review' },
    { value: 'opt-3', viewValue: 'Quotation Approved' },
    { value: 'opt-4', viewValue: 'LPO Issued' },
    { value: 'opt-5', viewValue: 'Under Repair' },
    { value: 'opt-6', viewValue: 'Repair Completed' },
    { value: 'opt-7', viewValue: 'Dispatched' },
  ];

  hours: Hours[] = [
    { value: 'opt-0', viewValue: '01' },
    { value: 'opt-1', viewValue: '02' },
    { value: 'opt-2', viewValue: '03' },
    { value: 'opt-3', viewValue: '04' },
    { value: 'opt-4', viewValue: '05' },
    { value: 'opt-5', viewValue: '06' },
    { value: 'opt-6', viewValue: '07' },
    { value: 'opt-7', viewValue: '08' },
    { value: 'opt-8', viewValue: '09' },
    { value: 'opt-9', viewValue: '10' },
    { value: 'opt-10', viewValue: '11' },
    { value: 'opt-11', viewValue: '12' },
  ];
  minuts: Minuts[] = [
    { value: 'opt-0', viewValue: '00' },
    { value: 'opt-1', viewValue: '01' },
    { value: 'opt-2', viewValue: '02' },
    { value: 'opt-3', viewValue: '03' },
    { value: 'opt-4', viewValue: '04' },
    { value: 'opt-5', viewValue: '05' },
    { value: 'opt-6', viewValue: '06' },
    { value: 'opt-7', viewValue: '07' },
    { value: 'opt-8', viewValue: '08' },
    { value: 'opt-9', viewValue: '09' },
    { value: 'opt-10', viewValue: '10' },
    { value: 'opt-11', viewValue: '11' },
    { value: 'opt-12', viewValue: '12' },
    { value: 'opt-13', viewValue: '13' },
    { value: 'opt-14', viewValue: '14' },
    { value: 'opt-15', viewValue: '15' },
    { value: 'opt-16', viewValue: '16' },
    { value: 'opt-17', viewValue: '17' },
    { value: 'opt-18', viewValue: '18' },
    { value: 'opt-19', viewValue: '19' },
    { value: 'opt-20', viewValue: '20' },
    { value: 'opt-21', viewValue: '21' },
    { value: 'opt-22', viewValue: '22' },
    { value: 'opt-23', viewValue: '23' },
    { value: 'opt-24', viewValue: '24' },
    { value: 'opt-25', viewValue: '25' },
    { value: 'opt-26', viewValue: '26' },
    { value: 'opt-27', viewValue: '27' },
    { value: 'opt-28', viewValue: '28' },
    { value: 'opt-29', viewValue: '29' },
    { value: 'opt-30', viewValue: '30' },
    { value: 'opt-31', viewValue: '31' },
    { value: 'opt-32', viewValue: '32' },
    { value: 'opt-33', viewValue: '33' },
    { value: 'opt-34', viewValue: '34' },
    { value: 'opt-35', viewValue: '35' },
    { value: 'opt-36', viewValue: '36' },
    { value: 'opt-37', viewValue: '37' },
    { value: 'opt-38', viewValue: '38' },
    { value: 'opt-39', viewValue: '39' },
    { value: 'opt-40', viewValue: '40' },
    { value: 'opt-41', viewValue: '41' },
    { value: 'opt-42', viewValue: '42' },
    { value: 'opt-43', viewValue: '43' },
    { value: 'opt-44', viewValue: '44' },
    { value: 'opt-45', viewValue: '45' },
    { value: 'opt-46', viewValue: '46' },
    { value: 'opt-47', viewValue: '47' },
    { value: 'opt-48', viewValue: '48' },
    { value: 'opt-49', viewValue: '49' },
    { value: 'opt-50', viewValue: '50' },
    { value: 'opt-51', viewValue: '51' },
    { value: 'opt-52', viewValue: '52' },
    { value: 'opt-53', viewValue: '53' },
    { value: 'opt-54', viewValue: '54' },
    { value: 'opt-55', viewValue: '55' },
    { value: 'opt-56', viewValue: '56' },
    { value: 'opt-57', viewValue: '57' },
    { value: 'opt-58', viewValue: '58' },
    { value: 'opt-59', viewValue: '59' },
    { value: 'opt-60', viewValue: '60' },

  ];

  times: Times[] = [
    { value: 'opt-1', viewValue: 'AM' },
    { value: 'opt-2', viewValue: 'PM' },
  ];

  adduploaddoc1() {
    this.dialog.open(this.callAPIDialog);
      
 }
 adduploaddoc2() {
  this.dialog.open(this.callAPIVehDialog);  
}
  close() {
    this.dialog.closeAll();
  }
  docupClose() {
    this.dialog.closeAll();
  }

}
