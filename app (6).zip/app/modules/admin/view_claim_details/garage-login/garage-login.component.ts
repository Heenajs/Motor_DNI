import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ViewclaimService } from '../../../service/viewclaim.service';
import Swal from 'sweetalert2';
import { GlobalService } from '../../../service/global.service';
import { vehimodelyrs } from '../../motorquote/motoryear';


interface Visarigion {
  value: string;
  viewValue: string;
}
interface Updatestatus {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-garage-login',
  templateUrl: './garage-login.component.html',
  styleUrls: ['./garage-login.component.scss']
})
export class GarageLoginComponent implements OnInit {
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  @ViewChild('callAPIVehDialog') callAPIVehDialog: TemplateRef<any>;
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;

  //declare formgroup
  repair_details: FormGroup; uploadDocs: FormGroup;
  public showLoader = {
    img_logo: false
  }
  vehicalmodelyears = vehimodelyrs; language_code = 'ENG'; country = 'United Arab Emirates';

  landing_img: any; uploaded_img: any; uploaded_repair_docs: any; image: any; uploaded_supporting_docs: any; uploaded_veh_docs: any; yearmod: any; CoverType: string; PolicyType: string; schemeCode: string;

  uplodMultipleSupportingDocs: any = []; uplodMultipleVehDocs: any = []; uplodMultipleRepairDocs: any = []; vhclMakeArr: any = []; vhclModelArr: any = []; engineList: any = []; cityArr: any = []; regType: any = [];
  formDataRes: any = []; tmpCountryList: any = []; plateCodeArray: any = [];


  constructor(public dialog: MatDialog, private _formBuilder: FormBuilder, public globalService: GlobalService, public motorQuoteService: MotorquoteService, public viewClaimService: ViewclaimService) { }

  ngOnInit(): void {
    this.repair_details = this._formBuilder.group({
      i_name: [''],
      e_id: [''],
      mob_number: [''],
      email_Id: [''],
      location: [''],
      address: [''],
      alt_mob_no: [''],
      pol_num: [''],
      pol_exp_date: [''],
      m_year: [''],
      v_make: [''],
      v_model: [''],
      tc_num: [''],
      enginSize: [''],
      chassisNum: [''],
      reg_plate: [''],
      plate_code: [''],
      plate_num: [''],
      email: [''],
      tc_number: [''],
      engineSize: [''],
      reg_place: [''],
      repair_quotation: ['', Validators.required],
      accessories_cost: ['', Validators.required],
      labor_cost: ['', Validators.required],
      other_cost: ['', Validators.required],
      total_cost: ['', Validators.required],
      repair_start_date: ['', Validators.required],
      repair_end_date: ['', Validators.required],
      repair_duration: ['', Validators.required],
      repair_remarks: [''],
      select_action: ['', Validators.required]
    })
    this.uploadDocs = this._formBuilder.group({
      supporting_FrontFilePath: '',
      supporting_FrontFileType: '',
      supporting_Doc: [''],
      vehicle_FrontFilePath: '',
      vehicle_FrontFileType: '',
      repar_FrontFilePath: '',
      repar_FrontFileType: ''
    })
    this.getAllFormData();
  }

  //get All formData
  getAllFormData() {
    this.motorQuoteService.getDropdownData('COMPREHENSIVE','0',this.language_code,this.country,'').subscribe((res) => {
        this.cityArr = res.cityData;
        this.regType = res.PlateCategory;
        this.formDataRes = res.countryData;
        this.tmpCountryList = this.formDataRes;
        // this.filteredNationCountries.next(this.formDataRes.slice());
        // res.PlateCategory.forEach((item, index) => {
        //   this.plateCatArray.push(item);
        // })
        // this.filteredPlateCat.next(this.plateCatArray.slice());
      });
  }

  //get plate code
  getPlateCode(regPlaceId, type) { 
    let plateSource = regPlaceId;
    let reg_type = 'PRIVATE';
    this.motorQuoteService.getPlateCode(this.language_code, plateSource, reg_type).subscribe(res => {
      this.plateCodeArray = res.plateCodeData;
    });
  }

  //get vehicle make data
  getVhclMakeData(vhcleMake, year, type) {
    // let yearmod = '';
    this.yearmod = year.value;
    this.CoverType = 'MOTOR COMPREHENSIVE INSURANCE';
    this.PolicyType = 'INDIVIDUAL';
    this.schemeCode = '65S';
    this.motorQuoteService.getVhclMake(this.CoverType, this.PolicyType, this.language_code, this.yearmod, this.schemeCode).subscribe(res => {
      this.vhclMakeArr = res.vechileMakeValuesData;
    });
  }

  //get vehicle model data
  getVhclModel(vehclMkId, type, year) { 
    this.motorQuoteService.getVehicleModel('P', this.repair_details.value.v_make, this.language_code, null, this.yearmod, this.schemeCode).subscribe(res => {
      this.vhclModelArr = res.vechileModelData;
    });
  }

  //get engine list data
  getEngineList( ) {
    this.motorQuoteService.getEngineSizeListClaim(this.repair_details.value, this.schemeCode).subscribe(res => { 
      this.engineList = res.response_message?.LookupList;
    });
  }


  submitRepairDetails() {
    if (this.repair_details.status == 'INVALID') {
      this.repair_details.markAllAsTouched();
      Swal.fire("", "Please fill all mandatory data", 'error')
    }
  }

  onFileChange(event, docName, files: FileList) {
    this.showLoader.img_logo = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('docName', docName);
    formData.append('source', 'B2B');
    formData.append('stage', 'QUOTE');
    formData.append('schemeCode', '65S');
    this.motorQuoteService.uploadDocuments(formData).subscribe(res => {
      this.showLoader.img_logo = false;
      this.landing_img = res.File;
      this.uploaded_img = res.FileDir;
      let fileType = res.File.split(".");
      fileType = fileType[fileType.length - 1];
      fileType = fileType == "pdf" ? "PDF" : "IMG";
      let formArrayValue: any = this.uploadDocs.value;
      formArrayValue[docName] = res.File;
      formArrayValue[docName + "FilePath"] = res.FileDir;
      let tempDocumentArray = {
        file_name: docName,
        file_dir: res.FileDir,
        docName: res.File,
      }
      console.log(tempDocumentArray);
      console.log(tempDocumentArray.file_dir);
      if (docName == 'supporting-document') {
        this.uploadDocs.get('supporting_FrontFilePath')?.setValue(res.FileDir);
        this.uploadDocs.get('supporting_FrontFileType')?.setValue(fileType);
      }
      else if (docName == 'veh-document') {
        this.uploadDocs.get('vehicle_FrontFilePath')?.setValue(res.FileDir);
        this.uploadDocs.get('vehicle_FrontFileType')?.setValue(fileType);
      }
      else if (docName == 'repair-document') {
        this.uploadDocs.get('repar_FrontFilePath')?.setValue(res.FileDir);
        this.uploadDocs.get('repar_FrontFileType')?.setValue(fileType);
      }
      if (tempDocumentArray.file_name == 'supporting-document') {
        this.uploaded_supporting_docs = tempDocumentArray.file_dir;
        this.uplodMultipleSupportingDocs.push(this.uploaded_supporting_docs);
      }
      else if (tempDocumentArray.file_name == 'veh-document') {
        this.uploaded_veh_docs = tempDocumentArray.file_dir;
        this.uplodMultipleVehDocs.push(this.uploaded_veh_docs);
      }
      else if (tempDocumentArray.file_name == 'veh-document') {
        this.uploaded_repair_docs = tempDocumentArray.file_dir;
        this.uplodMultipleRepairDocs.push(this.uploaded_repair_docs);
      }
    });
  }
  openImgDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }


  visaregion: Visarigion[] = [
    { value: 'steak-0', viewValue: 'Dubai' },
    { value: 'steak-1', viewValue: 'Abi Dhabi' },
    { value: 'steak-2', viewValue: 'Ajman' },
    { value: 'steak-3', viewValue: 'Sharjah' },
  ];

  updatestatus: Updatestatus[] = [
    { value: 'opt-0', viewValue: 'Quotation Under Review' },
    { value: 'opt-1', viewValue: 'Under Repair' },
    { value: 'opt-2', viewValue: 'Repair Completed' },
    { value: 'opt-3', viewValue: 'Dispatched' },
  ];

  adduploaddoc() {
    this.dialog.open(this.callAPIDialog);
  }
  adduploadVehDoc() {
    this.dialog.open(this.callAPIVehDialog);
  }
  docupClose() {
    this.dialog.closeAll();
  }

}
