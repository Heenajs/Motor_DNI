import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowpolicyinfoComponent } from './showpolicyinfo.component';

describe('ShowpolicyinfoComponent', () => {
  let component: ShowpolicyinfoComponent;
  let fixture: ComponentFixture<ShowpolicyinfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowpolicyinfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowpolicyinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
