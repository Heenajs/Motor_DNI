import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ViewpolicyService } from '../../../service/viewpolicy.service';
import { GlobalService } from '../../../service/global.service';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { MatDialog } from '@angular/material/dialog';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-showpolicyinfo',
  templateUrl: './showpolicyinfo.component.html',
  styleUrls: ['./showpolicyinfo.component.scss']
})
export class ShowpolicyinfoComponent implements OnInit {
  partnerId: any;
  username: any;

  Gender: any = [{value: "M", label: "Male"}, 
                {value: "F", label: "Female"}];
  policyNo: any;
  lob: any;
  policyDetail:any = [];
  quoteDetail:any = [];
  documentData:any = [];
  endorsmentHistoryData: any = [];
  quotationHistoryArr: any = [];
  crsPolNum:any;
  cvStartDate: any;
  cvEndDate: any;
  quoteNum: any;
  showData:boolean=true;
  issuedDate: any;
  POBoxNum: any;
  insuredMobile: any;
  insuredEmail: any;
  paymentType: any;
  SchemeType: any;
  CRSPolUID: any;
  memberData: any;
  medicalDocPath: any;
  insuredGender: any;
  insuredName: any;
  insuredDob: any;
  VisaLocation: any;
  serviceInputData: any;
  serviceOutputData: any;
  repushButton:boolean;
  inputData:boolean;
  hideshowedit:boolean;
  integStatus: any;
  comment: any;
  CRS_Quote_Number: any;
  isMortgage: any;

  holdername: any;
  contactaddr: any;
  nationality: any;
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  image: any;
  webQuoteNum: any;

  constructor(private formBuilder: FormBuilder, public dialog: MatDialog,  public motorQuoteService: MotorquoteService,public globalService: GlobalService, public viewpolicyService:ViewpolicyService, private router: Router, private _activatedroute:ActivatedRoute ) { }

  ngOnInit(): void {

    const routeParams = this._activatedroute.snapshot.params;
    if(routeParams){
      this.partnerId = routeParams.partner;
      this.username = routeParams.username;
      this.policyNo = routeParams.polnum;
      this.lob = routeParams.lob; 
    }
    console.log(routeParams)
   
    this.getCustomerPolicyDetail();
    

  }

  getMotorDocumentData(quoteNumber){
    this.motorQuoteService.getDataForEditQuoteDoc(quoteNumber).subscribe(res =>{
    
      this.documentData = res.getDataForEditQuoteDoc;
      let fileType:any;
      if(res.response_message!="Failed"){
        this.documentData.forEach((item, index) => {
          fileType = item.DocFileName.split(".");
          fileType =  fileType[fileType.length - 1];
          fileType = fileType == "pdf" ? "PDF" : "IMG";
          this.documentData[index].fileType = fileType;
        });
      }
    });
  }

  getCustomerPolicyDetail(){
    this.viewpolicyService.getCustomerPolicyDetails(this.partnerId,this.username,this.policyNo,this.lob).subscribe(res=>{
    this.showData=false;
      this.policyDetail = res.data[0];
      if(res.res_code == 1){
        this.crsPolNum   = this.policyDetail.CRSPolNumber;
        this.holdername   = this.policyDetail.PolicyHolderName;
        this.issuedDate = this.policyDetail.DateIssued;
        this.cvStartDate = this.policyDetail.CommencentDate;
        this.cvEndDate   = this.policyDetail.ExpiryDate;
        this.quoteNum = this.policyDetail.QuotationNumber;
        this.POBoxNum = this.policyDetail.POBOx;
        this.contactaddr = this.policyDetail.ContactAddress;
        this.insuredMobile = this.policyDetail.MobileNumber;
        this.insuredEmail = this.policyDetail.EmailAddress;
        this.paymentType = this.policyDetail.PaymentType;
        this.SchemeType = this.policyDetail.SchemeType;
        this.CRSPolUID = this.policyDetail.CRSPolUID;
       


        this.getMotorDocumentData(  this.quoteNum)
        this.getMotorQuoteDetail();
        // this.getTrafficList();

        // if(this.lob == 'HT'){
        //   this.quoteDetail = res.data[0];
        //   this.cvStartDate = (this.quoteDetail.CommencentDate);
        //   this.cvEndDate = (this.quoteDetail.ExpiryDate);
        //   this.getMemberDetail();
        //   this.getServiiceLogInputData();
        //   this.getServiiceLogOutputData();
        //   this.getStatus(this.lob,this.quoteDetail.QuotationNumber);
        // }
        // if(this.lob == 'HC'){
        //   this.quoteDetail = res.policyData[0];
        //   this.comment =  this.policyDetail.PolRemarks;
        //   this.cvStartDate = (this.quoteDetail.CommencentDate);
        //   this.cvEndDate = (this.quoteDetail.ExpiryDate);
        //   this.getHomeQuoteDetail();
        //   this.getStatus(this.lob,res.data[0].QuotationNumber);
        // }
        // if(this.lob == 'TR'){
        //   this.quoteDetail = res.policyData[0];
        //   this.comment =  this.policyDetail.PolRemarks;
        //   this.getTravelQuoteDetail();
        //   this.getStatus(this.lob,res.data[0].QuotationNumber);
        // }
        // if(this.lob == 'MT'){
        //   this.quoteDetail = res.data[0];
        //   this.comment = this.quoteDetail.PolRemarks;
        //   this.crsPolNum = this.quoteDetail.CRSPolNumber;
        //   this.cvStartDate = (this.quoteDetail.CommencentDate);
        //   this.cvEndDate = (this.quoteDetail.ExpiryDate);
        //  
        //   this.getMotorDocumentData(this.quoteNum);
        //   this.getStatus(this.lob,res.data[0].QuotationNumber);
        // }
        // this.getEndorsementHistory(1,'','','','HISTORY');
      }
    })
  }

  getMotorQuoteDetail() {
    
    this.motorQuoteService.getRetrieveQuote(this.quoteNum,'BTBPORTAL','').subscribe(res =>{
      console.log(res);
      if(res.response_code == 1){
        let memberlistRes = res;
        this.quoteDetail = memberlistRes.quotationDetailsDataForCustomer[0];
        this.insuredName = this.quoteDetail.InsuredName;
        this.insuredDob = (this.quoteDetail.InsuredDOB);
        this.insuredMobile = this.quoteDetail.InsuredMobile;
        this.insuredEmail = this.quoteDetail.InsuredEmail;
        this.POBoxNum =  this.quoteDetail.POBox;
        this.nationality = this.quoteDetail.Nationality;
        this.CRS_Quote_Number = this.quoteDetail.CRSQuoteNumber;
        this.isMortgage = this.quoteDetail.Mortgage;
        this.webQuoteNum = this.quoteDetail.QuotationNumber;
        console.log(this.webQuoteNum);
        this.Gender.forEach((item,index)=>{
          if(item.value == this.quoteDetail.InsuredGender){
              this.insuredGender = item.label;
          }
        });
        this.getQuotationHistory();
      }
    })
  }

  getQuotationHistory() {
    let quoteNumber = this.webQuoteNum;
    console.log(this.webQuoteNum)
    this.motorQuoteService.getQuotationHistory(quoteNumber, 'MT').subscribe((res) => {
      if (res.response_code == 1) {
        this.quotationHistoryArr = res.quotationHistoryList;
      }
    })
  }

  openImgDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog);
    dialogRef.afterClosed().subscribe((result) => {});
    this.image = img;
  }
  
  close() {
    this.dialog.closeAll();
  }

  goBack(){
    this.router.navigate(['viewpolicy/viewpolicydetail/' +this.partnerId+"/"+this.username+"/"+this.lob+"/"+this.policyNo ]);
  }
  


}
