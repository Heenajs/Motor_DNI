import { Component, OnInit, ElementRef,Input,EventEmitter,SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { MotorquoteService } from '../../service/motorquote.service';
import {ViewpolicyService} from '../../service/viewpolicy.service';
import { GlobalService } from '../../service/global.service';
import { Router } from '@angular/router';
import * as xlsx from 'xlsx';

interface LOB {
  value: string;
  label: string;
}

interface Partner {
   value: string;
   viewValue: string;
 }
 interface Nationality{
   value: string;
   viewValue: string;
 }
 

@Component({
  selector: 'app-viewpolicy',
  templateUrl: './viewpolicy.component.html',
  styleUrls: ['./viewpolicy.component.scss']
})
export class ViewpolicyComponent implements AfterViewInit  {
  viewPolicyForm:FormGroup;
  date = new Date(Date.now());
  frdate= new Date(new Date().setDate(new Date().getDate() - 7));
  partnersArr: any = [];
  // lobs: LOB[] = [
  //   { value: 'MT', label: 'Motor' },
  // ];

 
minDate =new Date(new Date().setMonth(new Date().getMonth() ));

fromMaxDate = new Date();
fromMinDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));

  displayedColumns: string[] = ['policyno', 'insname', 'exdate', 'policytype','existsi','existprem','sms','email'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  partnerID: any;
  localStorageData: any;
  partnerVal: any;
  quoteRes: boolean = false;
  gridStatus: boolean = false;
  policyData: any = [];
  res_Status:any;
  userName: any; 
  localStorDta: any;
  userrole: any;
 
  minDate1 = new Date(Date.now());

  statusArr  = [
    {value: 'ALL', label: 'ALL'},
    {value: 'APPROVED', label: 'Policy Approved'},
    {value: 'CANCELLED', label: 'Policy Cancelled'},
    {value: 'ISSUED', label: 'Policy Issued'}
   
   
  ];

  @Input() partnerUser ; // decorate the property with @Input()
  BranchId: any;
  ngAfterViewInit() {
          this.dataSource.paginator = this.paginator;
  }

  constructor(private formBuilder: FormBuilder,public motorQuoteService: MotorquoteService,public globalService: GlobalService, public viewpolicyService:ViewpolicyService, private router: Router) { }

  ngOnInit(): void {

    this.localStorageData = this.globalService.getLocalStorageData();
    this.userrole = this.localStorageData.UserRole;
    this.userName = this.localStorageData.EmailAddress;
    this.partnerID = this.localStorageData.PartnerId;
    this.BranchId = this.localStorageData.BranchId;
    this.viewPolicyForm = this.formBuilder.group({
      partner: ['', Validators.required],
      userSel: ['', Validators.required],
      policyFromDate: [new Date(new Date().setDate(new Date().getDate()-7)),this.frdate, Validators.required],
      policyToDate: [this.date, Validators.required],
      lob: ['MT', Validators.required],
      status:[this.statusArr[0]],
      optionalText : ['']
    });


    this.getQuotationFormData();
    this.dateValidation();
    this.getUserHerchy();

    
  }

  getUserList(){
    this.motorQuoteService.getUsers(this.viewPolicyForm.value.partner).subscribe(res => {

      this.userHerchyList = res.res_data;

      this.viewPolicyForm.get("userSel").setValue(this.userHerchyList[0]);
     
  });
    
  }
   //getformdata
   getQuotationFormData() {
    this.motorQuoteService.getQuotationFormData().subscribe(response => {
        let formDataRes = response;
        this.partnersArr = formDataRes.Partners;
        this.partnersArr.forEach((item, index) => {
          if (item.PartnerId == this.partnerID) {
                this.partnerVal = item.PartnerId;
          }
        }); 
        this.viewPolicyForm.get('partner').setValue(this.partnerVal);

        

      //  this.callSearchHistory();
        
      });
  }
  convertDate(inputFormat) {
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat);
    return ([pad(d.getMonth() + 1), pad(d.getDate()), d.getFullYear()].join('/'));
  }

  dateValidation(){
    
    let datechange =new Date(this.viewPolicyForm.value.policyFromDate);
  
    this.frdate = new Date(datechange.setMonth(datechange.getMonth() + 1));
    if(this.frdate > this.date){
      this.frdate = new Date(Date.now())
    }
    this.minDate1 = new Date(this.viewPolicyForm.value.policyFromDate);
    this.viewPolicyForm.get('policyToDate').setValue(this.frdate)
    // console.log( this.minDate1)
  }

  callSearchHistory(){
    if(sessionStorage){
    let sessonData =JSON.parse(sessionStorage?.getItem("policyFormDataSessionData"));
  
    //this.viewPolicyForm.get('lob').setValue(sessonData?.lob);
    this.viewPolicyForm.get('policyFromDate').setValue(sessonData?.policyFromDate);
    this.viewPolicyForm.get('policyToDate').setValue(sessonData?.policyToDate);
    this.viewPolicyForm.get('optionalText').setValue(sessonData?.optionalText);

    this.getPolicies();
    }
  }

  //getpolicy
  getPolicies() {
    this.quoteRes=true; 
    if (this.viewPolicyForm.invalid) {
      return
    }
    var viewPolicyFormData:any = {partner:this.viewPolicyForm.value.partner,
                                  lob:this.viewPolicyForm.value.lob,
                                  policyFromDate:this.viewPolicyForm.value.policyFromDate,
                                  policyToDate:this.viewPolicyForm.value.policyToDate,
                                  status:this.viewPolicyForm.value.status,
                                  optionalText:this.viewPolicyForm.value.optionalText} ;
    sessionStorage.setItem("policyFormDataSessionData", JSON.stringify(viewPolicyFormData));
    this.viewpolicyService.getPoliciesByUser(this.viewPolicyForm.value.partner,
                                             this.viewPolicyForm.value.userSel.UserId,
                                            this.viewPolicyForm.value.lob,
                                            this.viewPolicyForm.value.status,
                                            this.convertDate(this.viewPolicyForm.value.policyFromDate),
                                            this.convertDate(this.viewPolicyForm.value.policyToDate),
                                            this.viewPolicyForm.value.optionalText).subscribe(res => {
                                         
       
                this.policyData = res.data;
            
                if (res.res_code == 1) {
                    this.res_Status = res.res_status;
                    this.quoteRes = false;
                }
                if (res.res_code == 2) {
                    this.res_Status = res.res_status;
                  
                    this.quoteRes = false;
                }
      });
    this.gridStatus = true;
  }

  //Export to Excel
  exportToExcel(){
    const ws: xlsx.WorkSheet =  xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'epltable.xlsx');
  }

  //viewpolicydetailpage
  viewPolicyDetail(policyNo){
    this.router.navigate(['viewpolicy/viewpolicydetail/' + this.viewPolicyForm.value.partner + "/" + this.userName + "/" + this.viewPolicyForm.value.lob + "/" + policyNo ]);
  }
  
 

 userHerchyList = [];
getUserHerchy(){

  this.motorQuoteService.getPartnerUserList().subscribe(res => {

      this.userHerchyList = res.res_data;
      this.userHerchyList.forEach((item, index) => {
 
        if(this.localStorageData.UserId==item.UserId) this.viewPolicyForm.get("userSel")?.setValue(item);
      })
  });



}

ngOnChanges(changes: SimpleChanges) {
  // changes.prop contains the old and the new value...

  this.userHerchyList.forEach((item, index) => {
        
    if(changes.partnerUser.currentValue.UserId==item.UserId) 
    this.viewPolicyForm.get("userSel")?.setValue(item);
    })
    setTimeout(() => {
    this.getPolicies();} ,2000);

}

resetForm(){

  this.viewPolicyForm.reset();
}
fromDateFrom3month= new Date();
fromDateChange(event){
 

  const d =     new Date(this.viewPolicyForm.value.policyFromDate);
  let month  =d.getMonth();
  let today = new Date(); 
  this.fromDateFrom3month  = new Date(new Date(d).setMonth(month+3));
 // this.fromDateFrom3month = this.fromDateFrom3month.setMonth(month+3);
  


  var Difference_In_Time =  today.getTime() - this.fromDateFrom3month.getTime();
  if(Difference_In_Time<0)
  this.fromDateFrom3month = today;
  
}
  
}

export interface PeriodicElement {
  insname: string;
  policyno: number;
  exdate: string;
  policytype: string;
  existsi:string;
  existprem:string;
  sms:string;
  email:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
 
  
];