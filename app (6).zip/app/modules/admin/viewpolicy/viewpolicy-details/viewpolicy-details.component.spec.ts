import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewpolicyDetailsComponent } from './viewpolicy-details.component';

describe('ViewpolicyDetailsComponent', () => {
  let component: ViewpolicyDetailsComponent;
  let fixture: ComponentFixture<ViewpolicyDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewpolicyDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewpolicyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
