import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { MotorquoteService } from '../../../service/motorquote.service';
import { ViewpolicyService } from '../../../service/viewpolicy.service';
import { GlobalService } from '../../../service/global.service';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { MatDialog } from '@angular/material/dialog';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

interface Partner {
  value: string;
  viewValue: string;
}
interface Nationality{
  value: string;
  viewValue: string;
}
interface Renewstatus{
 value: string;
 viewValue: string;
}
interface Claimstatus{
 value: string;
 viewValue: string;
}

@Component({
  selector: 'app-viewpolicy-details',
  templateUrl: './viewpolicy-details.component.html',
  styleUrls: ['./viewpolicy-details.component.scss']
})
export class ViewpolicyDetailsComponent implements OnInit {

  Gender: any = [{value: "M", label: "Male"}, 
                {value: "F", label: "Female"}];
  CNValue: boolean = true;
  public partnerId:any; username:any; policyNo:any;lob: any;
  policyDetail:any = [];
  quoteDetail:any = [];
  documentData:any = [];
  endorsmentHistoryData: any = [];
  quotationHistoryArr: any = [];
  localStorageData: any = [];
  crsPolNum:any;
  cvStartDate: any;
  cvEndDate: any;
  quoteNum: any;
  issuedDate: any;
  POBoxNum: any;
  insuredMobile: any;
  insuredEmail: any;
  paymentType: any;
  SchemeType: any;
  CRSPolUID: any;
  memberData: any;
  medicalDocPath: any;
  insuredGender: any;
  insuredName: any;
  insuredDob: any;
  VisaLocation: any;
  serviceInputData: any;
  serviceOutputData: any;
  repushButton:boolean;
  inputData:boolean;
  hideshowedit:boolean;
  integStatus: any;
  comment: any;
  view_type:any = 'EDIT';
  sourceType='B2B'
  CRS_Quote_Number: any;
  isMortgage: any;
  CRS_POL_UID: any;
  debit_Note_Url: string;
  credit_Note_Url: string;
  pol_schedule_IIRIS_url: string;
  polUID: any;
  UIDNo: any;
  isDisabled: boolean = false;

  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  image: any;
  renewpolicyNo: any;
  prvPolNo: any;
  homeOfficeNum: any;

  constructor(private formBuilder: FormBuilder, public dialog: MatDialog,  public motorQuoteService: MotorquoteService,public globalService: GlobalService, public viewpolicyService:ViewpolicyService, private router: Router, private _activatedroute:ActivatedRoute ) { }

  ngOnInit(): void {
    this.localStorageData = this.globalService.getLocalStorageData();
    const routeParams = this._activatedroute.snapshot.params;
    console.log(routeParams);
    if(routeParams){
      this.partnerId = routeParams.partner;
      this.username = routeParams.username;
      this.policyNo = routeParams.polnum;
      this.lob = routeParams.lob; 
    }
    if (this.localStorageData.UserRole == 'RM') {
      this.isDisabled = true;
    }
    this.getCustomerPolicyDetail();
    
  }

  checkCN(){
    this.viewpolicyService.checkCN(this.lob).subscribe(res=>{
     
      this.CNValue = res.access_type;
    })
  }
  crlink= "" ;
  drlink = "" ;

  getCustomerPolicyDetail(){
    this.viewpolicyService.getCustomerPolicyDetails(this.partnerId,this.username,this.policyNo,this.lob).subscribe(res=>{
    
      this.policyDetail = res.data[0];
      if(res.res_code == 1){
        this.issuedDate = this.policyDetail.DateIssued;
        this.crsPolNum   = this.policyDetail.CRSPolNumber;
        this.renewpolicyNo = this.policyDetail.renewPolicyNumber;
        this.cvStartDate = this.policyDetail.CommencentDate;
        this.cvEndDate   = this.policyDetail.ExpiryDate;
        this.quoteNum = this.policyDetail.QuotationNumber;
        this.POBoxNum = this.policyDetail.POBOx;
        this.homeOfficeNum = this.policyDetail.HomeOfficeNumber;
        this.insuredMobile = this.policyDetail.MobileNumber;
        this.insuredEmail = this.policyDetail.EmailAddress;
        this.paymentType = this.policyDetail.PaymentType;
        this.SchemeType = this.policyDetail.SchemeType;
        this.CRSPolUID = this.policyDetail.CRSPolUID;
        this.crlink = this.policyDetail.CNLInk;
        this.drlink = this.policyDetail.DNLInk;
        this.getTrafficList();

        if(this.lob == 'HT'){
          this.quoteDetail = res.data[0];
          this.cvStartDate = (this.quoteDetail.CommencentDate);
          this.cvEndDate = (this.quoteDetail.ExpiryDate);
          this.getMemberDetail();
          this.getServiiceLogInputData();
          this.getServiiceLogOutputData();
          this.getStatus(this.lob,this.quoteDetail.QuotationNumber);
        }
        if(this.lob == 'HC'){
          this.quoteDetail = res.policyData[0];
          this.comment =  this.policyDetail.PolRemarks;
          this.cvStartDate = (this.quoteDetail.CommencentDate);
          this.cvEndDate = (this.quoteDetail.ExpiryDate);
          this.getHomeQuoteDetail();
          this.getStatus(this.lob,res.data[0].QuotationNumber);
        }
        if(this.lob == 'TR'){
          this.quoteDetail = res.policyData[0];
          this.comment =  this.policyDetail.PolRemarks;
          this.getTravelQuoteDetail();
          this.getStatus(this.lob,res.data[0].QuotationNumber);
        }
        if(this.lob == 'MT'){
          this.quoteDetail = res.data[0];
          this.comment = this.quoteDetail.PolRemarks;
          this.crsPolNum = this.quoteDetail.CRSPolNumber;
          this.cvStartDate = (this.quoteDetail.CommencentDate);
          this.cvEndDate = (this.quoteDetail.ExpiryDate);
          this.getMotorQuoteDetail();
          this.getMotorDocumentData(this.quoteNum);
          this.getStatus(this.lob,res.data[0].QuotationNumber);
        }
        this.getEndorsementHistory(1,'','','','HISTORY');
      }
    })
  }

//get member list
  getMemberDetail(){
  
    this.viewpolicyService.getMembersDetailByQuoteNo(this.quoteNum).subscribe(res=>{
      
      let memberListRes = res;
      this.quoteDetail = memberListRes.QuotationDetail[0];
      this.memberData = memberListRes.Members;
      this.medicalDocPath = memberListRes.PathPdf;
    
      this.Gender.forEach((item,index)=>{
        if(item.value == this.quoteDetail.PHGender){
          this.insuredGender = item.label;
        }
      });
      this.insuredName = this.quoteDetail.InsuredName;
      this.insuredDob = this.quoteDetail.MemberDOB;
      this.insuredMobile = this.quoteDetail.Mobile;
      this.insuredEmail = this.quoteDetail.EmailAddress;
      this.VisaLocation = this.quoteDetail.VisaLocation;
      this.memberData.forEach((item,index)=>{
      
    });
    });
  }

  //getstatuslogdata
  getServiiceLogInputData(){
    this.viewpolicyService.getServiceLogDetails(this.quoteNum,this.crsPolNum,'NEXTCAREINTEG','INPUT','TPAINTEGRATION','HT').subscribe(res=>{
      
      this.serviceInputData = res.ServiceLogDetails[0].ServiceInputOutputData;
    });
  }

  getServiiceLogOutputData(){
    this.viewpolicyService.getServiceLogDetails(this.quoteNum,this.crsPolNum,'NEXTCAREINTEG','INPUT','TPAINTEGRATION','HT').subscribe(res =>{
      
      this.serviceOutputData = res.ServiceLogDetails[0].ServiceInputOutputData;
      let outputData = JSON.parse(this.serviceOutputData);
      if(outputData.statusCode == 0 && outputData.statusDescription == 'Successfully Integrated'){
        this.repushButton = false;
        this.inputData= false;
        this.hideshowedit = false
      }
      else{
        this.hideshowedit = true;
        this.inputData = true;
        this.repushButton = true;
      }
    });
  }

  //getStatus
  getStatus(lob,quotationNumber){
    this.viewpolicyService.getIntegStatus(lob,quotationNumber).subscribe(res =>{
      
      this.integStatus = res.getIntegStatus;
    })
  }

  //for home get quote details
  getHomeQuoteDetail(){
    this.viewpolicyService.getQuotationDetailForHome(this.view_type,this.quoteNum,this.partnerId,this.sourceType).subscribe(res =>{
      
      let memberlistRes = res;
      this.quoteDetail = memberlistRes.quotationDetailsData[0];
      this.Gender.forEach((item,index)=>{
        if(item.value == this.quoteDetail.InsuredGender){
          this.insuredGender = item.label;
        }
      });
    });
    this.insuredName = this.quoteDetail.InsuredName;
    this.insuredDob = '';
  }

  //for travel get quote details
  getTravelQuoteDetail(){
    this.viewpolicyService.getQuotationDetailForTravel(this.view_type,this.quoteNum,this.partnerId,'B2B').subscribe(res =>{
      
      let memberlistRes = res;
      this.quoteDetail = memberlistRes.quotationDetailsData[0];
      this.Gender.forEach((item,index)=>{
        if(item.value == this.quoteDetail.InsuredGender){
          this.insuredGender = item.label;
        }
      });
      this.insuredName = this.quoteDetail.InsuredName;
      this.insuredDob = '';
    })
  }

  //for motor get quote details
  getMotorQuoteDetail(){
    this.motorQuoteService.getRetrieveQuote(this.quoteNum,'BTBPORTAL','').subscribe(res =>{
      
      if(res.response_code == 1){
        let memberlistRes = res;
        this.quoteDetail = memberlistRes.quotationDetailsDataForCustomer[0];
        this.insuredName = this.quoteDetail.InsuredName;
        this.insuredDob = (this.quoteDetail.InsuredDOB);
        this.insuredMobile = this.quoteDetail.InsuredMobile;
        this.insuredEmail = this.quoteDetail.InsuredEmail;
        this.POBoxNum =  this.quoteDetail.POBox;
        this.CRS_Quote_Number = this.quoteDetail.CRSQuoteNumber;
        this.isMortgage = this.quoteDetail.Mortgage;
        this.prvPolNo = this.quoteDetail.PrvInsPolNo;
        this.Gender.forEach((item,index)=>{
          if(item.value == this.quoteDetail.InsuredGender){
              this.insuredGender = item.label;
          }
      });
      }
    })
  }


  
openImgDialog(img) {
  const dialogRef = this.dialog.open(this.callAPIDialog);
  dialogRef.afterClosed().subscribe((result) => {});
  
  this.image = img;
}

close() {
  this.dialog.closeAll();
}


  //get documents data for retrive
  getMotorDocumentData(quoteNumber){
    this.motorQuoteService.getDataForEditQuoteDoc(quoteNumber).subscribe(res =>{
      
      this.documentData = res.getDataForEditQuoteDoc;
      let fileType:any;
      if(res.response_message!="Failed"){
        this.documentData.forEach((item, index) => {
          fileType = item.DocFileName.split(".");
          fileType =  fileType[fileType.length - 1];
          fileType = fileType.toLowerCase() == "pdf" ? "PDF" : "IMG";
          
          this.documentData[index].fileType = fileType;
        });
      }
    });
  }

  //get History
  getEndorsementHistory(type,EndSrNo,EndNum,Description,DataType){

    if(type == 1){
      this.viewpolicyService.getEndorsementHistory(this.lob,this.quoteNum,this.crsPolNum,'B2B',DataType,EndSrNo,EndNum).subscribe(res =>{
        
        this.endorsmentHistoryData = res.endorsementHistoryData;
      });
    }
    if(type == 2){
      this.viewpolicyService.getEndorsementHistory(this.lob,this.quoteNum,this.crsPolNum,'B2B',DataType,EndSrNo,EndNum).subscribe(res =>{
        if(res.response_code == 1){
          window.open(res.pdfPath, "_blank");
        }
      });
    }
    if(type == 3){
      Swal.fire("",Description, "info");
    }
  }

  //ViewPDF
  viewPDF(){
    if(this.lob == 'HC'){
      this.viewpolicyService.viewQuotePDF(this.partnerId,this.quoteNum,'',this.sourceType).subscribe(res =>{
        setTimeout(
          function() {}.bind(this),200);
        let viewPDF = res;
        if(viewPDF.response_code == 1){
          window.open(viewPDF.pdfPath, "_blank");
        }

      });
    }
    if(this.lob == 'HT'){
      this.viewpolicyService.quotationPlanPDFGenerate(this.quoteNum).subscribe(res => {
        setTimeout(
          function() {}.bind(this),200);
        let pdfRes = res;
        if(pdfRes.response_code == 1){
          window.open( pdfRes.pdfPath, "_blank");
        }
      });
    }
    if(this.lob == 'MT'){
      this.viewpolicyService.getQuoteDetailPDF(this.quoteNum).subscribe(res =>{
        setTimeout(
          function() {}.bind(this),200);
          let viewPDF =res;
          if(viewPDF.response_code == 1){
            window.open( viewPDF.pdfPath, "_blank");
          }
      });
    }
    if(this.lob == 'TR'){
      this.viewpolicyService.viewQuotePDF(this.partnerId,this.quoteNum,'B2B','').subscribe(res =>{
        setTimeout(
          function() {}.bind(this),200);
          let viewPDF = res;
          if (viewPDF.response_code == 1) {
            window.open( viewPDF.pdfPath, "_blank");
          }
      });
    }

  }
  viewMore(){

    

    this.router.navigateByUrl("viewpolicy/viewpolicydetail/showpolicyinfo/"+this.partnerId+"/"+this.username+"/"+this.lob+"/"+this.policyNo);
  }

  getproformaInvoice(){


    this.viewpolicyService.getproformainvoice(this.policyNo,this.quoteNum,'B2B',).subscribe(res=>{
      
    
        let polSchedulRes1 = res;
        if(polSchedulRes1.response_code == 1){
          // alert(1)
          window.open(polSchedulRes1.pdfPath, "_blank");
        }
    })
  }

   getBankDocument(){

    this.viewpolicyService.getBankDocument(this.policyNo,this.quoteNum,'B2B',).subscribe(res=>{
      
    
        let polSchedulRes1 = res;
        if(polSchedulRes1.response_code == 1){
          // alert(1)
          window.open(polSchedulRes1.pdfPath, "_blank");
        }
    })
  }

  editCall(){

    this.router.navigateByUrl("referrals/approveQuote/"+this.quoteNum);

  }
  //pdf for policy
  getPolicyPdf(type){
    if(this.lob == 'HT'){
      this.viewpolicyService.getMembersDetailByQuoteNo(this.quoteNum).subscribe(res =>{
        
        this.CRS_POL_UID = res.CRSPOlUID;
        if(this.CRS_POL_UID != null){
          this.debit_Note_Url = 'http://10.0.1.23:83/DocumentPrint/MID033.aspx?pEndtSrlNo=0&pDocType=PRM&pOutType=pdf&pLogo=Y&pPolUid='+this.CRS_POL_UID;
          this.credit_Note_Url =   'http://10.0.1.23:83/DocumentPrint/MID033.aspx?pEndtSrlNo=0&pDocType=BRK&pLogo=Y&pOutType=pdf&pPolUid='+this.CRS_POL_UID;
          if(type == 1){
            window.open(this.debit_Note_Url,"_blank");
          }
          if(type == 2){
            window.open(this.credit_Note_Url,"_blank");
          }
          if(type == 10){
            window.open(this.credit_Note_Url,"_blank");
          }
          if(this.VisaLocation == 'Abu Dhabi'){
            this.pol_schedule_IIRIS_url = ' http://10.0.1.23:83/DocumentPrint/MID002.aspx?pEndtSrlNo=0&pLogo=Y&pOutType=pdf&pPolUid='+this.CRS_POL_UID; 
          }
          else if(this.VisaLocation == 'Dubai'){
            this.pol_schedule_IIRIS_url = ' http://10.0.1.23:83/DocumentPrint/MID002.aspx?pEndtSrlNo=0&pLogo=Y&pOutType=pdf&pPolUid='+this.CRS_POL_UID;
          }
          else{
            this.pol_schedule_IIRIS_url = 'http://83.111.242.149:830/DocumentPrint/MID002.aspx?pPolUid='+this.CRS_POL_UID+'&pEndtSrlNo=0&pLogo=Y&pOutType=pdf';   
            this.pol_schedule_IIRIS_url = ' http://10.0.1.23:83/DocumentPrint/MID002.aspx?pEndtSrlNo=0&pLogo=Y&pOutType=pdf&pPolUid='+this.CRS_POL_UID;   
          }            
          if(type == 3){       
            window.open( this.pol_schedule_IIRIS_url, "_blank");
        }
        }
      });
    }
    if(this.lob == 'HC'){
      this.viewpolicyService.getPolicyDetail(this.partnerId,this.policyNo).subscribe(res =>{
        
        if(res.CoreUIDNo != null){
          this.polUID = res.CorePolNo;
          this.UIDNo = res.CoreUIDNo;
          this.debit_Note_Url =  'http://10.0.1.23:91/DocumentPrint/GIDN033.aspx?pEndtSrlNo=0&pDocType=PRM&pLogo=Y&pOutType=pdf&pPolUid='+this.UIDNo;
          this.credit_Note_Url = 'http://10.0.1.23:91/DocumentPrint/GIDN033.aspx?pEndtSrlNo=0&pDocType=BRK&pLogo=Y&pOutType=pdf&pPolUid='+this.UIDNo;
          if(type == 1){
            window.open(this.debit_Note_Url, "_blank");
          }
          if(type == 2){
            window.open(this.credit_Note_Url, "_blank");
          }
          if(type == 3){  
           
            this.viewpolicyService.getPolSchedulPDF(this.partnerId,this.policyNo,this.quoteNum).subscribe(res=>{
              
              setTimeout(
                function() {}.bind(this),1500);
                let polSchedulRes = res;
                if(polSchedulRes.response_code == 1){
                  window.open(polSchedulRes.pdfPath, "_blank");
                }
            });
          }
        }
      })
    }
    if(this.lob == 'TR'){
      this.debit_Note_Url = 'http://10.0.1.23:91/GIDN033.aspx?pEndtSrlNo=0&pDocType=PRM&pDocNo=178&pLogo=Y&pOutType=pdf&pPolUid='+this.CRSPolUID;
      this.credit_Note_Url =   'http://10.0.1.23:91/GIDN033.aspx?pEndtSrlNo=0&pDocType=BRK&pDocNo=178&pLogo=Y&pOutType=pdf&pPolUid='+this.CRSPolUID;
      if(type == 1){
        window.open( this.debit_Note_Url, "_blank");
      }
      if(type == 2){
        window.open( this.credit_Note_Url, "_blank");
      }
      if(type == 3){
        this.viewpolicyService.getPolicySchedulePDF(this.policyNo,'B2B',this.quoteNum).subscribe(res=>{
          
          setTimeout(
            function() {}.bind(this),1500);
            let polSchedulRes1 = res;
            if(polSchedulRes1.response_code == 1){
              // alert(1)
              window.open(polSchedulRes1.pdfPath, "_blank");
            }
        })
      }
      if(type == 4){
        this.viewpolicyService.getTravelCertificate(this.policyNo,'B2B',this.quoteNum).subscribe(res =>{
          
          if(res.response_code == 1){
            window.open(res.pdfPath, "_blank");
          }
        })
      }

    }
    if(this.lob == 'SM'){
      this.debit_Note_Url = 'http://10.0.1.23:91/DocumentPrint/GIDN033.aspx?pEndtSrlNo=0&pDocType=PRM&pDocNo=178&pLogo=Y&pOutType=pdf&pPolUid='+this.CRSPolUID;
      this.credit_Note_Url =   'http://10.0.1.23:91/DocumentPrint/GIDN033.aspx?pEndtSrlNo=0&pDocType=BRK&pDocNo=178&pLogo=Y&pOutType=pdf&pPolUid='+this.CRSPolUID;
      if(type == 1){  
        window.open( this.debit_Note_Url, "_blank");
      }
      if(type == 2){  
        window.open( this.credit_Note_Url, "_blank");
      }
      if(type == 3){
        this.viewpolicyService.getPolSchedulPDF1(this.policyNo,"B2B").subscribe(res=>{
          
          setTimeout(function() {}.bind(this),1500);
          let polSchedulRes2 = res;
          if(polSchedulRes2.response_code == 1){
            window.open(polSchedulRes2.pdfPath, "_blank");
          }
        })
      }
      if(type == 4){
        this.viewpolicyService.getTravelCertificate(this.policyNo,'B2B',this.quoteNum).subscribe(res=>{
          
          if(res.response_code == 1){
            window.open(res.pdfPath, "_blank");
          }
        })
      }
    }
  
              if(this.lob == 'MT'){
                if(type == 7){
                  window.open("https://portal.dni.ae/ShieldXLAPI/PDFDocuments/MT/DNIR-Motor-Policy-2017.PDF", "_blank");
              }
              if(type == 8){
                window.open("https://portal.dni.ae/ShieldXLAPI/PDFDocuments/MT/DNI_PANEL_GARAGE_LIST_8Mar2022.xlsx", "_blank");
            }
            if(type == 9){
              window.open("https://www.dni.ae/personal-insurance/motor/claim-procedure/", "_blank");
          }

          if(type == 10){
            window.open("https://portal.dni.ae/ShieldXLAPI/PDFDocuments/MT/IMC_Roadside_Card.jpeg", "_blank");
          }
      this.viewpolicyService.viewPolicySummary(this.policyNo,this.quoteNum,'B2B').subscribe(res=>{
        
        if(res.response_code == 1){
          if(type == 3){   
              window.open(res.pdfPath, "_blank");
          }
          if(type == 2){
              window.open(res.credit_note, "_blank");
          }
          if(type == 1){
              window.open(res.pdfPath, "_blank");
          }
          if(type == 4){
              window.open(res.hirePurchaselink, "_blank");
           }
           if(type == 5){
                window.open(res.bankletter, "_blank");
            }
       
        }
      })
    }
    

  }
  trafficData = [];
  //get member list
  getTrafficList(){

    this.viewpolicyService.getTrafficData(this.quoteNum,this.policyNo,"B2B").subscribe(res=>{

      this.trafficData = res.quotationDetailsData ;



    })


    

  }
  //get quotation history data
  getQuotationHistory(quoteNumber) {
    this.motorQuoteService.getQuotationHistory(quoteNumber, 'MT').subscribe(res => {
      if (res.response_code == 1) {
        this.quotationHistoryArr = res.quotationHistoryList;
      }
    });
  }
}
