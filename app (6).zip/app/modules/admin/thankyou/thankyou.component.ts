import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { MotorquoteService } from '../../service/motorquote.service';
import { GlobalService } from "../../service/global.service";
import { ViewpolicyService } from '../../service/viewpolicy.service';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { Observable, Subscription, fromEvent } from 'rxjs';
import { config } from '../../../config';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-thankyou',
  templateUrl: './thankyou.component.html',
  styleUrls: ['./thankyou.component.scss']
})
export class MotorThankyouComponent implements OnInit {
      webQuoteNum:any;

  public subscriptions: Subscription[] = [];
  public policyNum:any; paymentLoader:boolean = false; quoteNum:any;   localStorDta:any;  orderNumber:any; orderToken:any; policySceduleLink:any;
  public payment_transaction_ID_status:any; payment_Transaction_ID:any = ''; token:any; payPolicyNum:any; debit_Note_Url:any; polUID :any; credit_Note_Url:any; policy_Wording_Url:any;
  public creditNoteLink:any = ''; debitNoteLink:any; hirePurchaselink:any; bankLetterLink:any; response_msg:any =''; policyNumber:any = '';  navBarChange=0; pageStatus:any; CRSQuoteNumber:any;
  UIDNo :any; pol_schedule_IIRIS_url:any; docLoader:boolean = false; creditLoader:boolean = false; policyScedLoder:boolean =false;  showHideLoader:boolean = true; access_type:boolean = false;
  showDocumentLoader:boolean = false; hire_purchase_clause:any; mortgageBank:any; counter:number = 1; policyIssueError:boolean = false; bank_letter_clause:any;
      partnerId: any;
  public isPageLoading= true ;
  emailGroup:FormGroup;
  emailAddress: any;
  showTryAgain:boolean = true;
  confirmQuote: string;
  constructor(public _route: Router,public _activatedroute: ActivatedRoute,public dialog: MatDialog,public formBuilder: FormBuilder, public globalService:GlobalService,public motorQuoteService:MotorquoteService,public viewpolicyService:ViewpolicyService) { }
  @ViewChild('sendEmail') sendEmail: TemplateRef<any>;
  @ViewChild('sendPolicyEmail') sendPolicyEmail: TemplateRef<any>;


  ngOnInit() {
    this.emailGroup=this.formBuilder.group({
      emailId:['']
    });
      const routeParams = this._activatedroute.snapshot.params;
      if (routeParams.quoteNum) {
            this.webQuoteNum = routeParams.quoteNum;
          }
          
          this.viewQuotePDF();
    // const elemMainPanel = <HTMLElement>document.querySelector('.main-panel');
    // const statusModSub =  this.globalService.navChanged.subscribe(data => {
    //   localStorage.setItem('sidebarHideShoe',data.toString());

    //   this.navBarChange = data;

    // }) ;

    // const window_width = $(window).width();
    //   let $sidebar = $('.sidebar');
    //   let $sidebar_responsive = $('body > .navbar-collapse');
    //   let $sidebar_img_container = $sidebar.find('.sidebar-background');


    // this.subscriptions.push(statusModSub);

    this.localStorDta =  this.globalService.getLocalStorageData();
    this.partnerId = this.localStorDta.Partner_ID;
    this.orderNumber =  localStorage.getItem("Payment_Order_ID");
    this.orderToken  =  localStorage.getItem("Payment_Order_Tokan");
    this.quoteNum = localStorage.getItem('Payment_Quotation_Number');
    this.confirmQuote = localStorage.getItem('confirmQuote');
    
    this.policySceduleLink = localStorage.getItem('schedulelink');
    this.creditNoteLink = localStorage.getItem('creditNote');
    this.debitNoteLink = localStorage.getItem('debitNote');
    this.hire_purchase_clause = localStorage.getItem('hirePurchase');
    this.bank_letter_clause = localStorage.getItem('bankLetter');
    this.policyNumber =  localStorage.getItem('Policy_Number');
    this.pageStatus = localStorage.getItem('pageStatus');
    this.CRSQuoteNumber = localStorage.getItem('CRS_Quotation_Number');
   
    this.polUID = localStorage.getItem('Policy_UID');
    this.mortgageBank = localStorage.getItem('mortgage_bank');
//     if(this.policyNumber == undefined || this.policyNumber == 'undefined' || this.policyNumber == null  || this.policyNumber == 'null' || this.policyNumber == '')
//     this._route.navigate(['/dashboards/project/']);

        this.hirePurchaselink = this.hire_purchase_clause + this.polUID;
        this.bankLetterLink = this.bank_letter_clause + this.polUID;

        this.policy_Wording_Url = 'Policy_Wording.pdf';

              if(this.pageStatus =='PAYMENT' || this.pageStatus =='SENDPAYMENTLINK'){
                  this.showHideLoader = true;
                  this.verifyQuatationPayment();
              }

              if( this.pageStatus =='ISSUPOLICY' && ( this.policyNumber == undefined || this.policyNumber == 'undefined' || this.policyNumber == null  || this.policyNumber == 'null' || this.policyNumber == '')){
                      this.approvePolicyRequest();
              }
console.log(this.confirmQuote);
     // this.getCheckCN();
     setTimeout(()=>{ 
      // if( this.pageStatus == 'ISSUPOLICY'){
        this.callIntrigation();
      // }
    },1000);
  }
  corePolicyNo='1';
  callIntrigation(){
            this.motorQuoteService.polIntrigationCall(this.policyNumber,this.quoteNum).subscribe(res=>{
              this.isPageLoading= false ;
                this.corePolicyNo = res.core_data[0].CorePolicyNumber;
                this.isPageLoading= false ;
                
            });
  }
      //   gotoGetQuote(){
      //     localStorage.removeItem("schedulelink");
      //     localStorage.removeItem("hirePurchase");
      //     localStorage.removeItem('Payment_Quotation_Number');
      //     localStorage.removeItem('CRS_Quotation_Number');
      //     localStorage.removeItem('Policy_Number');
      //     localStorage.removeItem('pageStatus');
      //     this._route.navigateByUrl('/agentMotor/motorquote');
      // }

      // goToHome(){
      //     localStorage.removeItem("schedulelink");
      //     localStorage.removeItem("hirePurchase");
      //     localStorage.removeItem('Payment_Quotation_Number');
      //     localStorage.removeItem('CRS_Quotation_Number');
      //     localStorage.removeItem('Policy_Number');
      //     localStorage.removeItem('pageStatus');
      //     this._route.navigateByUrl('/dashboard');
      // }

viewQuotePDF() {
      this.motorQuoteService.getQuoteDetailPDF(this.webQuoteNum,this.partnerId,"B2B").subscribe(res => {
          
      });
  
    }

viewPolicy(){

}

//---------------------------------- SAVE QUOTATION PAYMENT -------------------------------------------//
saveQuotationPayment(){



}
//-------------------------------- VERIFY QUOTATION PAYMENT ----------------------------------------------//
verifyQuatationPayment(){


}

generatePDF(){

}

getDocumentUrls(type){
  // const dialogref = this.dialog.open(this.sendEmail);


        if(type == 1){


            this.viewpolicyService.viewPolicySummary(this.policyNumber,this.quoteNum,'B2B').subscribe(res=>{
                
                  if(res.response_code == 1){
                    if(type == 3){   
                        window.open(res.pdfPath, "_blank");
                    }
                    if(type == 2){
                        window.open(res.credit_note, "_blank");
                    }
                    if(type == 1){
                        window.open(res.pdfPath, "_blank");
                    }
                    if(type == 4){
                        window.open(res.hirePurchaselink, "_blank");
                     }
                     if(type == 5){
                          window.open(res.bankletter, "_blank");
                      }
                 
                  }
                })

           

              
        }
        if(type == 2){

              window.open(this.creditNoteLink, "_blank");
        }
        if(type == 3){

              window.open(this.debitNoteLink, "_blank");
        }
        if(type == 4){

            window.open(this.hirePurchaselink, "_blank");
        }
        if(type == 5){

            window.open(this.bankLetterLink, "_blank");
        }

      //   localStorage.removeItem('Payment_Quotation_Number');
      //   localStorage.removeItem('Policy_Number');
      //   localStorage.removeItem('Policy_UID');

}

goToURL(){
//       localStorage.removeItem("schedulelink");
//       localStorage.removeItem("hirePurchase");
//       localStorage.removeItem("bankLetter");
//       localStorage.removeItem('Payment_Quotation_Number');
//   //    localStorage.removeItem('Policy_Number');
//       localStorage.removeItem('pageStatus');

    //   if(this.pageStatus == 'SENDPAYMENTLINK'){
    //         this.motorQuoteService.webSiteLink("B2BMotor").subscribe(res =>{
    //                 location.href = res.fedility_website ;
    //         });
    //   }

      if(this.pageStatus == 'PAYMENT'){
            this._route.navigate(['agentMotor/motorquote']);
      }


}

//----------------------------------- APPROVE POLICY REQUEST -------------------------------------//
approvePolicyRequest() {

  this.motorQuoteService.approvePolicyRequest(this.CRSQuoteNumber, this.quoteNum,'B2B').subscribe(res => {

              if (res.response_code == 1) {
                let polNum = res.approvePolicyRequest.PolNo;
                let PolicyUid = res.approvePolicyRequest.PolicyUid;
                this.policyNumber = polNum;
                this.polUID = PolicyUid;

                this.hirePurchaselink =  this.hire_purchase_clause + this.polUID;
                this.bankLetterLink = this.bank_letter_clause + this.polUID;
                this.viewPolicySummary();
              }



  });
}

gotohome(){
      this._route.navigate(['dashboards/project']);
}

gotoGetQuote(){
      this._route.navigate(['/motorquote']);
}
count: number = 0;

tryAgain(){
  this.motorQuoteService.polIntrigationCall(this.policyNumber,this.quoteNum).subscribe(res=>{
    this.corePolicyNo = res.core_data[0].CorePolicyNumber;
    this.isPageLoading= false ;
   
      this.count++;
      if(this.count == 2 && res.core_data[0].CorePolicyNumber == ''){
        Swal.fire('','Please contact IT Support ','warning');
        this.showTryAgain = false;
        // this._route.navigate(['dashboards/project']);
      }
});

}
 //------------------------------------ VIEW POLICY SUMMARY ------------------------------------------//
 viewPolicySummary() {

  this.counter = this.counter + 1;

              this.motorQuoteService.viewPolicySummary(this.CRSQuoteNumber, this.quoteNum,'B2B','').subscribe(res => {
                
                  //   if (res.response_code == 1) {
                  //     this.showDocumentLoader = false;
                  //     this.policySceduleLink  = res.link_data.schedulelink;
                  //     this.creditNoteLink = res.credit_note;
                  //     this.debitNoteLink = res.debit_note;
                  //     this.hire_purchase_clause = res.hirePurchaselink;
                  //     this.bank_letter_clause = res.bankletter;
                  //     this.mortgageBank =  res.mortgageBank;
                  //     this.policyNumber = res.policy_number;


                  //         if( (this.policyNumber == undefined || this.policyNumber == 'undefined' || this.policyNumber == null  || this.policyNumber == 'null' || this.policyNumber == '')){
                  //               this.approvePolicyRequest();
                  //         }else{
                  //               this.showDocumentLoader = false;
                  //               this.policyIssueError = true;
                  //               // send mail to admin
                  //         }
                  //   }else{
                  //       this.showDocumentLoader = false;
                  //   }
             });


}

// getCheckCN(){
//       this.motorQuoteService.getCheckCN('MT').subscribe(res =>{

//             this.access_type = res.access_type;
//       });
// }

close(){
  this.dialog.closeAll();
}
sendProfomaMail(){
  
  this.emailAddress = this.emailGroup.value.emailId;
  this. viewpolicyService.sendMail(this.emailAddress).subscribe(res=>{
 
  })
  Swal.fire('', 'Email sent successfully!', 'success');
  this.viewpolicyService.getproformainvoice(this.policyNumber,this.quoteNum,'B2B',).subscribe(res=>{
    
setTimeout(()=>{                           // <<<---using ()=> syntax
  res
}, 3000);

   
   
      let polSchedulRes1 = res;
      if(polSchedulRes1.response_code == 1){
        // alert(1)
        window.open(polSchedulRes1.pdfPath, "_blank");
      }
  })
  
}


getproformaInvoice(){
  // const dialogref = this.dialog.open(this.sendEmail);
  // alert(1);
  // this.policyNumber,this.quoteNum,'B2B'
  this.viewpolicyService.getproformainvoice(this.policyNumber,this.quoteNum,'B2B').subscribe(res=>{
   
  
      let polSchedulRes1 = res;
      if(polSchedulRes1.response_code == 1){
        // alert(1)
        window.open(polSchedulRes1.pdfPath, "_blank");
      }
  })
}


}
