import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorquickComponent } from './motorquick.component';

describe('MotorquickComponent', () => {
  let component: MotorquickComponent;
  let fixture: ComponentFixture<MotorquickComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotorquickComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotorquickComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
