import { Component, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertType } from '@fuse/components/alert';
import { AuthService } from 'app/core/auth/auth.service';
import Swal from 'sweetalert2';
import { FuseValidators } from '@fuse/validators';
import { MotorquoteService } from '../../service/motorquote.service';
// import {Md5} from 'ts-md5/dist/md5';
//import { DeviceDetectorService } from 'ngx-device-detector';

interface language {
    value: string;
    viewValue: string;
  }

@Component({
    selector     : 'auth-sign-in',
    templateUrl  : './sign-in.component.html',
    encapsulation: ViewEncapsulation.None,
    animations   : fuseAnimations
})
export class AuthSignInComponent implements OnInit
{
    @ViewChild('signInNgForm') signInNgForm: NgForm;
    @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;

    alert: { type: FuseAlertType; message: string } = {
        type   : 'success',
        message: ''
    };
    signInForm: FormGroup;
    forgotpassword: FormGroup;
    showAlert: boolean = false;
    showAlert1: boolean = false;
    today = new Date();
    email: any;
    UserId: any;
    token: any;
    emailId: any;
    otpverify:boolean = true;
    passwordVerify: boolean = false;
    otp: any;
    password: any;
    resEmail: any;
    otpVerify: FormGroup;
    sum1: any;
    sum2: any;
    deviceInfo = null;
    ipDetail ;
    passwordexpiry: boolean = false;
    securityForm: FormGroup;

    currentPassword: (controlName: string, matchingControlName: string) => (formGroup: FormGroup) => void;
  acessMessage: any;
    /**
     * Constructor
     */
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _authService: AuthService,
        private _formBuilder: FormBuilder,
        private _router: Router,
        public dialog: MatDialog,
        public _motorquoteservice :MotorquoteService,
       // private deviceService: DeviceDetectorService
    )
    {
     this.epicFunction();

    }


    epicFunction() {


      
       // this.deviceInfo = this.deviceService.getDeviceInfo();
       // const isMobile = this.deviceService.isMobile();
       // const isTablet = this.deviceService.isTablet();
       // const isDesktopDevice = this.deviceService.isDesktop();
   
       // console.log(isMobile);  // returns if the device is a mobile device (android / iPhone / windows-phone etc)
       // console.log(isTablet);  // returns if the device us a tablet (iPad etc)
        //console.log(isDesktopDevice); // returns if the app is running on a Desktop browser.
      }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {



        this._authService.getIP().subscribe((res) => {


            this.ipDetail = res ;


            });

        
        if(this._authService.check()){

            this._router.navigateByUrl("/dashboards/project");
        }
        this.sum1 =Math.floor(Math.random() * 6) + 1;
    
        this.sum2 = Math.floor(Math.random() * 6) + 1;
      
        // Create the form
        this.signInForm = this._formBuilder.group({
            username     : ['', [Validators.required]],
            password  :  ['', Validators.compose([Validators.required,
                Validators.pattern(
                    /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}/
                  )])],
            // language  : ['', Validators.required],
            rememberMe: [''],
            firstNumber:  [this.randomNumber(), Validators.required],
            secondNumber: [this.randomNumber(), Validators.required],
            answer: ['', Validators.required],
        },
     //   [this.answerValidator]
        );


        this.forgotpassword = this._formBuilder.group({
            emailId :   ['', [Validators.required]],
            // otpData :   ['', [Validators.required]],
            // newPassword :   ['', [Validators.required]],

        });

        this.otpVerify = this._formBuilder.group({
          //  emailId :   ['', [Validators.required, Validators.email]],
            otpData :   ['', [Validators.required]],
            newPassword :   ['', [Validators.required]],

        });

        this.securityForm = this._formBuilder.group({
            currentPassword  : ['', [Validators.required]],
            newPassword      : ['', Validators.compose([Validators.required,
            Validators.pattern(
                /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}/
              )])],
            
            confirmPassword: ['', Validators.compose([Validators.required,
            Validators.pattern(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}/)])],

        },
        {
          validators: FuseValidators.mustMatch('newPassword', 'confirmPassword')
      }
        );

    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Sign in
     */
    
    signIn(): void
    {
let sum = Number(this.sum1) + Number(this.sum2) ;
let input = Number(this.signInForm.value.answer);
if(sum != input){
    this.alert = {
        type   : 'error',
        message: 'Please Enter Valid Captcha'
    };

    // Show the alert
    this.showAlert = true;
    //this.signInForm.reset();
   // this.signInForm.controls.firstNumber.reset()
   this.sum1 = Math.floor(Math.random() * 6) + 1;
    // this.signInForm.get("secondNumber").setValue(this.randomNumber());
this.sum2 = Math.floor(Math.random() * 6) + 1;
this.signInForm.get("answer")?.setValue(' ');
}
else{
        // Return if the form is invalid
        if ( this.signInForm.invalid )
        {
            return;
        }

        // Disable the form
       // this.signInForm.disable();

        // Hide the alert
        this.showAlert = false;
        // let pass =(Md5.hashStr(this.signInForm.value.password));
        // Sign in
        this._authService.validateuser(this.signInForm.value.username,this.signInForm.value.password)
            .subscribe(
                (res) => {
                  if(res.response_code==3){
                    Swal.fire("", res.response_message, "error");
                  }                   
                    if(res.response_code==4 || res.response_code==3){

                        this.signInForm.enable();

                        // Reset the form
                        this.signInNgForm.resetForm();
    
                        // Set the alert
                        this.alert = {
                            type   : 'error',
                            message: res.response_message
                        };
    
                        // Show the alert
                        this.showAlert = true;
                        this.sum1 = Math.floor(Math.random() * 6) + 1;
                        // this.signInForm.get("secondNumber").setValue(this.randomNumber());
                    this.sum2 = Math.floor(Math.random() * 6) + 1;
                    }


                   else if(res.response_data.user.ResetPassword=='1'){

                        Swal.fire("Password Expired","Your password has expired or requires you to change your password. Kindly enter your new password to continue to log in and access the DNI Portal.", "warning");
         this.otpverify= false
                        this.passwordexpiry= true
                        this.openDialog();
                  //      this._router.removeQueryParams(this._activatedRoute, 'param1');
         
                //   this._router.navigateByUrl('/forgot-password');
                // this._router.navigate([`./forgot-password`],
//    );

                    }
                 
                    else{


                      if(res.licExpiringMsg!=''){
                        Swal.fire("",res.licExpiringMsg, "warning");
                        const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/dashboards/project';
                         this._router.navigateByUrl(redirectURL);
                        }

                      
                        
                        else{
                                this.email = res.response_data.user.EmailAddress;
                                this.UserId = res.response_data.user.UserId;
                                this.token = res.response_data.token;
                                this._motorquoteservice.sendActivityData(this.email, this.UserId,this.token, this.ipDetail,location.href).subscribe((res) => 
                                {
                                 
                                })

                                const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/dashboards/project';

                             
                                this._router.navigateByUrl(redirectURL);

                        }
                    }

                },
                (response) => {
                    
                   
                    // Re-enable the form
                    this.signInForm.enable();

                    // Reset the form
                    this.signInNgForm.resetForm();

                    // Set the alert
                    this.alert = {
                        type   : 'error',
                        message: 'Wrong email or password \n To continue , press F5 to re-enter the user name and password'
                    };

                    // Show the alert
                    this.showAlert = true;
                    this.sum1 = Math.floor(Math.random() * 6) + 1;
                    // this.signInForm.get("secondNumber").setValue(this.randomNumber());
                this.sum2 = Math.floor(Math.random() * 6) + 1;
                }
            
            
            );
            }
        // console.log(pass)
        // this._authService.validateuser(this.signInForm.value.username,this.signInForm.value.password).subscribe(result=>{
            
            
        // })
    }

    languages: language[] = [
        {value: 'steak-0', viewValue: 'English'},
        {value: 'pizza-1', viewValue: 'Franch'},
      
      ];

      openDialog(){

        this.dialog.open(this.callAPIDialog1, {
   disableClose: true ,
  backdropClass: "hello",
      autoFocus: false
    });
      

      }

      close(){
        this.dialog.closeAll();
        this.forgotpassword.reset();
        this.otpVerify.reset();
        this.otpverify=true;
        this.passwordVerify=false;
      }

      updatepassword(){
        this._router.navigate(['forgot-password']);
      }

 forgot_password(){
      
    if (this.forgotpassword.status == 'INVALID') {
        this.forgotpassword.markAllAsTouched();
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Please Enter all the required fields!',
        });
    }else{

       this.emailId = this.forgotpassword.value.emailId;

       this._motorquoteservice.forgot_password(this.emailId )
       .subscribe(
           (res) => {
console.log(res);
if(res.response_message =='Success'){
    this.resEmail = res.Data[0].EmailAddress;
  //  Swal.fire('Please check your email for OTP');
    this.alert = {
        type   : 'success',
        message: 'The reset password link has been sent to DNI. You will be notified by email with the new password.'
    };

    // Show the alert
    this.showAlert1 = true;

    this.otpverify =false;
this.passwordVerify = true;
}
else
{
    // Swal.fire('Error processing your request');
    this.alert = {
        type   : 'error',
        message: 'Please Enter Valid Username'
    };

    // Show the alert
    this.showAlert1 = true;
    this.forgotpassword.reset();
    this.otpVerify.reset();
}
           

      });
    }
    }

    ConfirmedValidator(controlName: string, matchingControlName: string) {
        return (formGroup: FormGroup) => {
          const control = formGroup.controls[controlName];
          const matchingControl = formGroup.controls[matchingControlName];
          if (
            matchingControl.errors &&
            !matchingControl.errors.confirmedValidator
          ) {
            return;
          }
          if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ confirmedValidator: true });
          } else {
            matchingControl.setErrors(null);
          }
        };
      }

    answerValidator(form: AbstractControl) {
      
        const { firstNumber, secondNumber, answer } = form.value;
        if (+answer === parseInt(firstNumber) + parseInt(secondNumber)) {
          return null;
        }
        return { math: true };
      }


      
 savechanges(){
  
  let passwords=this.currentPassword == this.ConfirmedValidator
    // Return if the form is invalid
    if ( this.securityForm.invalid || passwords)
    {
      
        return ;
    }

  this._motorquoteservice.resetpassword(this.signInForm.value.username,this.securityForm.value).subscribe((res)=>{
 
  if ( res[0].StatusCode==404 )
  {
    Swal.fire('','Invalid Current Password','error');
    this.securityForm.reset();
      return;
      
  }
  else
  {
    Swal.fire('','Password changed successfully','success');
        this.securityForm.reset();
    this.close();
     
    return;
  }
  });
  
        }

      resetCaptcha(){
        //console.log('Eng');
                this.sum1 = Math.floor(Math.random() * 6) + 1;
            this.sum2 = Math.floor(Math.random() * 6) + 1;
            this.signInForm.get("answer")?.setValue('');
              }
    validateOtp(){

        if (this.otpVerify.status == 'INVALID') {
            this.otpVerify.markAllAsTouched();
            // Swal.fire({
            //     icon: 'error',
            //     title: 'Oops...',
            //     text: 'Please Enter all the required fields!',
            // });
               // Swal.fire('Error processing your request');
    this.alert = {
        type   : 'error',
        message: 'Please Enter all the required fields!'
    };

    // Show the alert
    this.showAlert1 = true;
        }else{

      this.otp = this.otpVerify.value.otpData;
      this.password = this.otpVerify.value.newPassword;

      this._motorquoteservice.validateOtp( this.resEmail,   this.otp,  this.password )
      .subscribe(
          (res) => {
console.log(res);
 if(res.Data[0].StatusCode == 200)
 {
    this.alert = {
        type   : 'error',
        message: res.Data[0].StatusMsg
    };

    // Show the alert
    this.showAlert1 = true;
 //  Swal.fire(res.Data[0].StatusMsg);
 
   this.signInForm.get('password').reset('')
   this.close();

//    this.otpverify =false;
//  this.passwordVerify = true;
//  this.forgotpassword.reset();

 }
else if(res.Data[0].StatusCode == 400)
{

   this.alert = {
    type   : 'error',
    message: res.Data[0].StatusMsg
};

// Show the alert
this.showAlert1 = true;

   this.forgotpassword.reset();
   this.otpVerify.reset();
}
//this._router.navigate(['motorscheme']);

     });

    }
    }

    randomNumber = () => {
        return  Math.floor(1000 * Math.random())
      };
}
