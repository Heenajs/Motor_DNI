import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, switchMap, tap } from 'rxjs/operators';
import { AuthUtils } from 'app/core/auth/auth.utils';
import{config}from './../../config';



@Injectable()
export class MasterService
{
    private _authenticated: boolean = false;

    /**
     * Constructor
     */
    constructor(
        private _httpClient: HttpClient,
    )
    {
    }
    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    public handleError(error: any) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return throwError(errorMessage);
    }

    public getVehicleMake(data): Observable<any> {

        return this._httpClient.post(`${config.apiUrl}VehicleMaster/getVechileMakeValues`,{rate_name:data.ratename,status:data.rateStatus})
              .pipe(catchError(this.handleError), tap(res => res));
      }

      public getVechileModel(data): Observable<any> {

        return this._httpClient.post(`${config.apiUrl}VehicleMaster/getVechileModel`,{rate_name:data.ratename,status:data.rateStatus})
              .pipe(catchError(this.handleError), tap(res => res));
      }

      public getMotorcylinder(data): Observable<any> {

        return this._httpClient.post(`${config.apiUrl}VehicleMaster/getMotorcylinder`,{rate_name:data.ratename,status:data.rateStatus})
              .pipe(catchError(this.handleError), tap(res => res));
      }

      public getVechilesSpecification(data): Observable<any> {

        return this._httpClient.post(`${config.apiUrl}VehicleMaster/getVechilesSpecification`,{rate_name:data.ratename,status:data.rateStatus})
              .pipe(catchError(this.handleError), tap(res => res));
      }

      public getVechileMasterData(data): Observable<any> {

        return this._httpClient.post(`${config.apiUrl}VehicleMaster/getVechileMasterData`,{rate_name:data.ratename,status:data.rateStatus})
              .pipe(catchError(this.handleError), tap(res => res));
      }

      public uploadMultipleDocuments(formData):Observable<any> {

        return this._httpClient.post(`${config.apiUrl}UploadDocsMaster/uploadMultipleDocumentsNew`,formData)
              .pipe(catchError(this.handleError),  tap(res => res));
      }

      public uploadDocuments(formData):Observable<any> {

        return this._httpClient.post(`${config.apiUrl}UploadDocsMaster/uploadDocuments`,formData)
              .pipe(catchError(this.handleError), tap(res => res));
      }
}