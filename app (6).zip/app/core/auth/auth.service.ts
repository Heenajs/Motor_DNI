import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { AuthUtils } from 'app/core/auth/auth.utils';
import { UserService } from 'app/core/user/user.service';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../../environments/environment';

(<any>window)._setInterValObj ;
(<any>window)._setInterValObjForToken ;
(<any>window)._setCounter ;
@Injectable()
export class AuthService
{
    private _authenticated: boolean = false;
    public _intervalOffset: number = 1000*60*50;
    public _intervalTokenOffset: number = 1000*60*50;
    public _intervalLogoutTimer: number = 25000;
    public _setInterValObj;
    public _setInterValObjForToken ;
    public _setInterValLogoutObj ;

    apiurl = environment.apiurl;

    /**
     * Constructor
     */
    constructor(
        private _httpClient: HttpClient,
        private _userService: UserService,
        private _router: Router,
    
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Setter & getter for access token
     */
    set accessToken(token: string)
    {
        localStorage.setItem('accessToken', token);
    }

    get accessToken(): string
    {
        return localStorage.getItem('accessToken') ?? '';
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Forgot password
     *
     * @param email
     */
    forgotPassword(email: string): Observable<any>
    {
        return this._httpClient.post('api/auth/forgot-password', email);
    }

    /**
     * Validate Token
     *
     * @param password
     */
     validateToken(token: string , email: string): Observable<any>
     {
         return this._httpClient.post(`${this.apiurl}User/validateToke`, {token:token,email:email});
     }

    /**
     * Reset password
     *
     * @param password
     */
    resetPassword(token: string,email: string, password: string): Observable<any>
    {
        return this._httpClient.post(`${this.apiurl}User/validateToken`, {token:token,email:email,password:password});
    }

    /**
     * Sign in
     *
     * @param credentials
     */
    signIn(credentials: { email: string; password: string }): Observable<any>
    {
        // Throw error, if the user is already logged in
        if ( this._authenticated )
        {
            return throwError('User is already logged in.');
        }

        return this._httpClient.post('api/auth/sign-in', credentials).pipe(
            switchMap((response: any) => {

                // Store the access token in the local storage
                this.accessToken = response.accessToken;

                // Set the authenticated flag to true
                this._authenticated = true;

                // Store the user on the user service
                this._userService.user = response.user;

                // Return a new observable with the response
                return of(response);
            })
        );
    }

    validateuser(username,password){
        return this._httpClient.post(`${this.apiurl}User/ValidateUser`, {
            Username: username,Password:password
        }).pipe(
            catchError(() =>

                // Return false
                of(false)
            ),
            switchMap((response: any) => {

                if(response.response_code==4 || response.response_code==3 || response.response_data.user.ResetPassword=='1'){

                    return of(response)
                }


                // Store the access token in the local storage
                this.accessToken = response.response_data.token;

                // Set the authenticated flag to true
                this._authenticated = true;

                // Store the user on the user service
                this._userService.user = response.response_data.user;

                localStorage.setItem("currentUser",JSON.stringify(response.response_data.user));

           

              //  this.sessionExpireHnadler();

                // Return true
                return of(response);
            })
        );
    }

    /**
     * Sign in using the access token
     */
    signInUsingToken(): Observable<any>
    {
       // alert(1)
        // Renew token
        return this._httpClient.post(`${this.apiurl}User/refresh_access_token`, {
            accessToken: this.accessToken
        }).pipe(
            catchError(() =>

                // Return false
                of(false)
            ),
            switchMap((response: any) => {

                // Store the access token in the local storage
                this.accessToken = response.response_data.token;

                // Set the authenticated flag to true
                this._authenticated = true;

                // Store the user on the user service
                this._userService.user =response.response_data.user;


          //      this.sessionExpireHnadler()
                // Return true
                return of(true);
            })
        );
    }

    /**
     * Sign out
     */
    signOut(): Observable<any>
    {
        // Remove the access token from the local storage
        localStorage.removeItem('accessToken');

        // Set the authenticated flag to false
        this._authenticated = false;

        // Return the observable
        return of(true);
    }

    /**
     * Sign up
     *
     * @param user
     */
    signUp(user: { name: string; email: string; password: string; company: string }): Observable<any>
    {
        return this._httpClient.post('api/auth/sign-up', user);
    }

    /**
     * Unlock session
     *
     * @param credentials
     */
    unlockSession(credentials: { email: string; password: string }): Observable<any>
    {
        return this._httpClient.post('api/auth/unlock-session', credentials);
    }

    /**
     * Check the authentication status
     */
    check(): Observable<boolean>
    {
        // Check if the user is logged in
        if ( this._authenticated )
        {
            return of(true);
        }

        // Check the access token availability
        if ( !this.accessToken )
        {
            return of(false);
        }

        // Check the access token expire date
        if ( AuthUtils.isTokenExpired(this.accessToken) )
        {
            return of(false);
        }

        // If the access token exists and it didn't expire, sign in using it
        return this.signInUsingToken();
    }

    sessionExpireHnadler(){

        (<any>window)._setInterValObj = setInterval(() => {

          //  Swal.fire("Your credit limit seems to be exhausted. Please contact the Credit Control department.","", "error");
               
               clearInterval((<any>window)._setInterValObj);
               

                this._router.navigate(['/sign-out'])
               
           
          }, this._intervalOffset);
}

ineterValDestroy(){

    clearInterval((<any>window)._setInterValObj);

}


getIP(): Observable<any>
{
    // Throw error, if the user is already logged in
   

    return this._httpClient.get('https://api.db-ip.com/v2/free/self').pipe(
        switchMap((response: any) => {

         
            return of(response);
        })
    );
}
}
