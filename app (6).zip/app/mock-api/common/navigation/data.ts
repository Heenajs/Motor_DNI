/* tslint:disable:max-line-length */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation: FuseNavigationItem[] = [
    {
        id   : 'dashboard',
        title: 'Dashboard',
        type : 'basic',
        icon : 'heroicons_outline:chart-pie',
        link : '/dashboards/project'
    } ,
    {
        title: 'Motor',
        type : 'basic',
        icon : 'heroicons_outline:annotation',
        link : '/motorquote'
    },
   

            // {
            //     id      : 'pages.pricing',
            //     title   : 'New Request',
            //     type    : 'collapsable',
            //     icon    : 'heroicons_outline:cash',
            //     children: [
            //         {
            //             id   : 'pages.pricing.modern',
            //             title: 'eKYC',
            //             type : 'collapsable',
            //             children: [
            //                 {
            //                     id   : '',
            //                     title: 'Individual',
            //                     type : 'basic',
            //                     link : '/individual'
            //                 },
            //                 {
            //                     id   : '',
            //                     title: 'Entity',
            //                     type : 'basic',
            //                     link : '/entity'
            //                 },


            //     ]
            // },




            //         {
            //             id   : 'pages.pricing.simple',
            //             title: 'MAF',
            //             type : 'basic',
            //             link : '/pages/pricing/simple'
            //         },

            //         {
            //             id   : 'pages.pricing.table',
            //             title: 'Claim',
            //             type : 'basic',
            //             link : '/pages/pricing/table'
            //         }
            //     ]
            // },



];
export const compactNavigation: FuseNavigationItem[] = [
    {
        id   : 'dashboard',
        title: 'Dashboard',
        type : 'basic',
        icon : 'heroicons_outline:chart-pie',
        link : '/dashboards/project'
    },
    {
        title: 'View Claim',
        type : 'basic',
        // icon : 'heroicons_outline:annotation',
        link : '/view-claim'
    },
  
];
export const futuristicNavigation: FuseNavigationItem[] = [
    {
        id   : 'dashboard',
        title: 'Dashboard',
        type : 'basic',
        icon : 'heroicons_outline:chart-pie',
        link : '/dashboards/project'
    },
    {
        title: 'View Claim',
        type : 'basic',
        // icon : 'heroicons_outline:annotation',
        link : '/view-claim'
    },
    
];
export const horizontalNavigation: FuseNavigationItem[] = [
    
    {
        id   : 'dashboard',
        title: 'Dashboard',
        type : 'basic',
        icon : 'heroicons_outline:chart-pie',
        link : '/dashboards/project'
    },
    {
        title: 'Get Quote',
        type : 'basic',
        icon : 'heroicons_outline:annotation',
        link : '/motorscheme'
    } ,
    {
        title: 'Retrive Quote',
        type : 'basic',
        icon : 'mat_outline:assignment_returned',
        link : '/retrivequote'
    } ,
    {
        title: 'Referrals',
        type : 'basic',
        icon : 'mat_outline:assignment',
        link : '/referrals'
    } ,
    {
        title: 'Quote Approval',
        type : 'basic',
        icon : 'mat_outline:approval',
        link : '/quoteapproval'
    } ,
    {
        title: 'View Policy',
        type : 'basic',
        icon : 'mat_outline:policy',
        link : '/viewpolicy'
    } ,
    {
        title: 'Renew Policy',
        type : 'basic',
        icon : 'heroicons_outline:annotation',
        link : '/renewpolicy'
    } ,
    {
        title: 'Quick Quote',
        type : 'basic',
        icon : 'heroicons_outline:annotation',
        link : '/quickquote'
    },
    {
        title: 'View Claim',
        type : 'basic',
        // icon : 'heroicons_outline:annotation',
        link : '/view-claim'
    } ,
    
    // {
    //     title: 'Payments',
    //     type : 'basic',
    //     icon : 'heroicons_outline:annotation',
    //     link : '/motorquote'
    // } ,
    // {
    //     id      : 'pages.pricing',
    //     title   : 'New Request',
    //     type    : 'collapsable',
    //     icon    : 'heroicons_outline:cash',
    //     children: [
    //         {
    //             id   : 'pages.pricing.modern',
    //             title: 'eKYC',
    //             type : 'collapsable',
    //             children: [
    //                 {
    //                     id   : '',
    //                     title: 'Individual',
    //                     type : 'basic',
    //                     link : '/individual'
    //                 },
    //                 {
    //                     id   : '',
    //                     title: 'Entity',
    //                     type : 'basic',
    //                     link : '/entity'
    //                 },


    //     ]
    // },





    //     ]
    // }
];
