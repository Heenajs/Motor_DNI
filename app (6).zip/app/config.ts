export const config = {
    apiUrl: 'https://testportal.dni.ae/ShieldXLAPI/index.php/',

  };
