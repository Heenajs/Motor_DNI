import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FuseMediaWatcherService } from '@fuse/services/media-watcher';
import { FuseNavigationService, FuseVerticalNavigationComponent } from '@fuse/components/navigation';
import { Navigation } from 'app/core/navigation/navigation.types';
import { NavigationService } from 'app/core/navigation/navigation.service';
import { MatCarousel, MatCarouselComponent } from '@ngmodule/material-carousel';
import { trigger, transition, query, style, animate, group } from '@angular/animations';
import { MotorquoteService } from '../../../../modules/service/motorquote.service';
import { GlobalService } from '../../../../modules/service/global.service';

const left = [
  query(':enter, :leave', style({ position: 'fixed', width: '50%' }), { optional: true }),
  group([
    query(':enter', [style({ transform: 'translateX(-65%)' }), animate('.3s ease-out', style({ transform: 'translateX(0%)' }))], {
      optional: true,
    }),
    query(':leave', [style({ transform: 'translateX(0%)' }), animate('.3s ease-out', style({ transform: 'translateX(65%)' }))], {
      optional: true,
    }),
  ]),
];

const right = [
  query(':enter, :leave', style({ position: 'fixed', width: '50%' }), { optional: true }),
  group([
    query(':enter', [style({ transform: 'translateX(65%)' }), animate('.3s ease-out', style({ transform: 'translateX(0%)' }))], {
      optional: true,
    }),
    query(':leave', [style({ transform: 'translateX(0%)' }), animate('.3s ease-out', style({ transform: 'translateX(-65%)' }))], {
      optional: true,
    }),
  ]),
];

@Component({
    selector     : 'modern-layout',
    templateUrl  : './modern.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [
      trigger('animImageSlider', [
        transition(':increment', right),
        transition(':decrement', left),
      ]),
    ]
})

export class ModernLayoutComponent implements OnInit, OnDestroy
{
  countertxt: number = 0;

  alettext_list = [
    {
      alerText:'Our System Will Be Down From 25-Jun-2022, 8.00 PM until 26-Jun-2022 8.00 AM -1'
    },
    {
      alerText:'Our System Will Be Down From 25-Jun-2022, 8.00 PM until 26-Jun-2022 8.00 AM -2'
    },
    {
      alerText:'Our System Will Be Down From 25-Jun-2022, 8.00 PM until 26-Jun-2022 8.00 AM -3'
    },
  ]

  //  arr:any = [{
  //   'image1': 'AAAA',
  //  },{
  //   "image1":'BBBB'
  //  }
  // ];
  //  i :any= 0;

     

    event_list = [
        {
          event:' Event 1',
          eventLocation:'Bangalore',
          eventDescription:'In bangalore, first event is going to happen. Please be careful about it',
          img: 'https://picsum.photos/900/500?random&t=1',
          eventStartDate: new Date('2019/05/20'),
          eventEndingDate: new Date('2019/05/24')
        },
         {
          event:' Event 2',
          eventLocation:'Dubai',
          eventDescription:'Dubai is another place to host so,e, first event is going to happen. Please be careful about it',
          img: 'https://picsum.photos/900/500?random&t=3',
          eventStartDate: new Date('2019/07/28'),
          eventEndingDate: new Date('2019/07/30')
        },
         {
          event:' Event 3',
          eventLocation:'New York',
          eventDescription:'NewYork sits on top of event hosting',
          img: 'https://picsum.photos/900/500?random&t=4',
          eventStartDate: new Date('2020/05/20'),
          eventEndingDate: new Date('2020/05/24')
        },
         {
          event:' Event 4',
          eventLocation:'Singapore',
          eventDescription:'Singapore is another great hosting city',
          img: 'https://picsum.photos/900/500?random&t=6',
          eventStartDate: new Date('2018/05/20'),
          eventEndingDate: new Date('2018/05/24')
        },
        {
          event:' Event 5',
          eventLocation:'Berlin',
          eventDescription: 'Berlin is best place to hang on',
          img: 'https://picsum.photos/900/500?random&t=7',
          eventStartDate: new Date('2017/07/10'),
          eventEndingDate: new Date('2017/08/14')
        },
        {
          event:' Event 6',
          eventLocation:'Mumbai',
          eventDescription:'Mumbai is hub of startups',
          img: 'https://picsum.photos/900/500?random&t=8',
          eventStartDate: new Date(),
          eventEndingDate: new Date()
        },
        {
          event:' Event 7',
          eventLocation:'Barcelona',
          eventDescription:'Barcelona is another good city',
          img: 'https://picsum.photos/900/500?random&t=6',
          eventStartDate: new Date(),
          eventEndingDate: new Date()
        },
      ]
      upcoming_events =  this.event_list.filter( event => event.eventStartDate > new Date());
      past_events = this.event_list.filter(event => event.eventEndingDate < new Date());
      current_events =  this.event_list.filter( event => (event.eventStartDate >= new Date() && (event.eventEndingDate <= new Date())))
    isScreenSmall: boolean;
    navigation: Navigation;
    private _unsubscribeAll: Subject<any> = new Subject<any>();
    items = [
        { title: 'Slide 1' },
        { title: 'Slide 2' },
        { title: 'Slide 3' },
      ]
    alertDiv: boolean=true;
  txtbox: { image: string; }[];
  arraylist: any=[];
  counter: number = -1;
  counterback: number =0;
  NotificationData: any;
  localStorageData: any;
  userRole: any;
  accessMSG: string;

    /**
     * Constructor
     */
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _router: Router,
        private _navigationService: NavigationService,
        private _fuseMediaWatcherService: FuseMediaWatcherService,
        private _fuseNavigationService: FuseNavigationService,
        private _MotorquoteService: MotorquoteService,
        public globalService: GlobalService
    )
    {

      this.arraylist=this.alettext_list
      // console.log(this.arr[0].i);

      
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for current year
     */
    get currentYear(): number
    {
        return new Date().getFullYear();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {

      this.localStorageData = this.globalService.getLocalStorageData();
      // console.log(this.localStorageData);
      this.userRole = this.localStorageData.UserRole;
      this.accessMSG = localStorage.getItem('accessmsg  ');

      if(this.userRole=="CEDANT")
      this.userRole = "ADMIN/UW";

      if(this.userRole=="BANCA")
      this.userRole = "BROKER";

        // Subscribe to navigation data
        this._navigationService.navigation$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((navigation: Navigation) => {
                this.navigation = navigation;
                // console.log( this.navigation);
            });

        // Subscribe to media changes
        this._fuseMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Check if the screen is small
                this.isScreenSmall = !matchingAliases.includes('md');
            });

            this.getNotification();
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Toggle navigation
     *
     * @param name
     */
    toggleNavigation(name: string): void
    {
        // Get the navigation
        const navigation = this._fuseNavigationService.getComponent<FuseVerticalNavigationComponent>(name);

        if ( navigation )
        {
            // Toggle the opened status
            navigation.toggle();
        }
    }
    addSlide() {
        this.items.push({
          title: `Slide 4`
        });
      }

      hideAlert(){
         this.alertDiv=!this.alertDiv;
      }




//  nextItem() {
//     this.i = this.i + 1;
//     this.i = this.i % this.arr.length;
//     console.log( this.i)
//     console.log(this.arr[this.i])

//     return this.arr[this.i];
// }

//  prevItem() {
//     if (this.i === 0) {
//       this.i = this.arr.length;
//     }
//     this.i = this.i - 1;
//     return this.arr[this.i];
// }

ChangeNavColor() {
  if (  this.userRole =='ADMIN' ) {
    return 'low';
  } else if (this.userRole =='UNDERWRITER') {
    return 'medium';
  } else{
    return 'bg-card';
  }
}

// --------------------------------------------

onNext() {
// console.log( this.alettext_list)
  if (this.countertxt != this.alettext_list.length - 1) {
      this.countertxt++;
  }
//   else{
//  this.countertxt =0;
//   }
}

onPrevious() {
  if (this.countertxt > 0) {
     this.countertxt--;
  }
  // else{
  //   this.countertxt =this.alettext_list.length-1;
  //    }
}
nextSlide(count){
  this.countertxt+=count;
  // console.log( this.countertxt);

  if( this.alettext_list.length-1 < this.countertxt){
    if(count == 1){
       this.counter++;
    }
      this.alettext_list[this.countertxt] = this.arraylist[ this.counter];


  }

  // console.log(this.alettext_list)
  if( this.countertxt == -1){
    if(count == -1){
      this.counterback++;
   }
     this.alettext_list[this.countertxt] = this.arraylist[ this.counterback];
  }
}

goToDashBoard(){

  this._router.navigateByUrl('/dashboards/project')
}

getNotification(){

  this._MotorquoteService.getNotificationData().subscribe((res)=>{
  
  // this.NotificationData = res?.response_data[0]?.MessageDesc;
  
  })
  
  }
}
