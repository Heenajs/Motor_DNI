import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { BooleanInput } from '@angular/cdk/coercion';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { User } from 'app/core/user/user.types';
import { UserService } from 'app/core/user/user.service';

import { FuseConfigService } from '@fuse/services/config';
import { FuseTailwindService } from '@fuse/services/tailwind';
import { AppConfig, Scheme, Theme } from 'app/core/config/app.config';
import { GlobalService } from '../../../modules/service/global.service';

@Component({
    selector       : 'user',
    templateUrl    : './user.component.html',
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
    exportAs       : 'user'
})
export class UserComponent implements OnInit, OnDestroy
{
    /* eslint-disable @typescript-eslint/naming-convention */
    static ngAcceptInputType_showAvatar: BooleanInput;
    /* eslint-enable @typescript-eslint/naming-convention */

    // theme
    config: AppConfig;
    scheme: 'dark' | 'light';
    theme: string;
    themes: [string, any][] = [];
    localStorageData: any;


    @Input() showAvatar: boolean = true;
    user: User;

    private _unsubscribeAll: Subject<any> = new Subject<any>();
    userRole: any;

    /**
     * Constructor
     */
    constructor(
        private _changeDetectorRef: ChangeDetectorRef,
        private _router: Router,
        private _userService: UserService,
        private _fuseConfigService: FuseConfigService,
        private _fuseTailwindService: FuseTailwindService,
        public globalService: GlobalService
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {

        this.localStorageData = this.globalService.getLocalStorageData();
//   console.log(this.localStorageData);
          //   this.userRole = this.localStorageData.RoleDesc;

        if(this._router.url=="/")
        this._router.navigate(['/dashboards/project']);
        // Subscribe to user changes
        this._userService.user$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((user: User) => {
                // console.log(user)
                this.user = user;

                // Mark for check
                this._changeDetectorRef.markForCheck();
            });


            
                // Get the themes
                this._fuseTailwindService.tailwindConfig$
                    .pipe(takeUntil(this._unsubscribeAll))
                    .subscribe((config) => {
                        this.themes = Object.entries(config.themes);
                    });
        
                // Subscribe to config changes
                this._fuseConfigService.config$
                    .pipe(takeUntil(this._unsubscribeAll))
                    .subscribe((config: AppConfig) => {
        
                        // Store the config
                        this.config = config;
                    });
            
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Update the user status
     *
     * @param status
     */
    updateUserStatus(status: string): void
    {
        // Return if user is not available
        if ( !this.user )
        {
            return;
        }

        // Update the user
        this._userService.update({
            ...this.user,
            status
        }).subscribe();
    }

    /**
     * Sign out
     */
    signOut(): void
    {
        localStorage.removeItem('renewalLocalstorageDta');
        localStorage.removeItem('retreiveQuoteForm');
        this._router.navigate(['/sign-out']);
    }

     /**
     * Set the scheme on the config
     *
     * @param scheme
     */
      setScheme(scheme: Scheme): void
      {
          this._fuseConfigService.config = {scheme};
      }
  
      /**
       * Set the theme on the config
       *
       * @param theme
       */
      setTheme(theme: Theme): void
      {
          this._fuseConfigService.config = {theme};
      }
}
